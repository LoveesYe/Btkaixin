function daochu() {
    request_plugin('get_config_content',{},function (res) {
        var html  =  "<div class='config_form'>" +
            "<div class='config_content'><textarea placeholder='留空则初始化配置文件' id='config_content' cols='88' rows='18'>"+res.data.content+"</textarea></div>" +
            "<br><div style='float: right;margin-right: 11px;'>" +
            "<a class='btn btn-success btn-sm'  download='插件配置.json' href='"+res.data.file_path+"'>导出配置</a> &nbsp;" +
            "<button class='btn btn-success btn-sm' onclick='wconfig()'>写入配置</button>" +

            "</div></div>";
        layer.open({
            type: 1 //Page层类型
            ,area: ['600px', '500px']
            ,title: '配置备份【导出配置请保存好,请不要自行填写,如果写错导致程序出错！】'
            ,shade: 0.2 //遮罩透明度
            ,maxmin: false //允许全屏最小化
            ,anim: 1 //0-6的动画形式，-1不开启
            ,content: html
        });
    });
}
/**
 * 写入配置
 */
function wconfig() {
    var content =  $("#config_content").val();
    request_plugin('wconfig',{content:content},function (res) {
        var icon   = (res.code == 0)?1:2;
        layer.msg(res.msg,{icon:icon});
    })
}
function lotus_show(title,w,h) {
    if (title == null || title == '') {
        var title=false;
    };
    if (url == null || url == '') {
        var url="404.html";
    };
    if (w == null || w == '') {
        var w=($(window).width()*0.5);
    };
    if (h == null || h == '') {
        var h=($(window).height() - 200);
    };
    var index = layer.open({
        type: 0,
        area: [w+'px', h +'px'],
        fix: false, //不固定
        maxmin: false,
        shadeClose: true,
        shade:0.2,
        title: title,
        content: 'text'
    });
}
