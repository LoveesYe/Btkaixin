<?php
use Medoo\Medoo;

class tool {
    public function __construct()
    {
        define('DS',PHP_EOL);
        define('BT_DB',__DIR__.'/../../data/default.db');
        define('PLU_DB',__DIR__.'/web.db');
        define('PLUGIN_NAME','urlpush');
        define('RUNTIME_DIR',__DIR__.'/runtime');
        define('STATIC_DIR',__DIR__.'/static');
        $os = get_os();
        if(get_os() == 'linux'){
            define("LOG_PATH",__DIR__.'/../../../../wwwlogs');
        }else{
            define("LOG_PATH",__DIR__.'/../../../wwwlogs');
        }
    }
    function update_remain($host,$type,$remain)
    {
        $this->db()->update('web',[
            $type=>$remain
        ],[
            'host'=>$host
        ]);
    }
    function bt_db(){
        return new medoo([
            'database_type' => 'sqlite',
            'database_file' => BT_DB
        ]);
    }
    function db(){
        return new medoo([
            'database_type' => 'sqlite',
            'database_file' => PLU_DB
        ]);
    }
    function get_config_json(){
        $arr = $this->db()->select('web','*');
        $data = [];
        foreach ($arr as $v){
            $host = $v['host'];
            $data[$host] = $v;
        }
        return $data;
        //return json_decode(file_get_contents($this->config_json),true);
    }
    function add_history($host,$type,$urls)
    {
        $config = $this->get_config_json()[$host];
        foreach ($urls as $url){
            $res = $this->db()->get('history','*',[
                'host'=>$host,
                'type'=>$type,
                'url'=>$url
            ]);
            if(empty($res)){
                $this->db()->insert('history',[
                    'host'=>$host,
                    'type'=>$type,
                    'url'=>$url,
                    'num'=>1,
                    'create_time'=>time()
                ]);
            }else{
                $this->db()->update('history',[
                    'num'=>$res['num']+1
                ],[
                    'host'=>$host,
                    'type'=>$type,
                    'url'=>$url
                ]);
            }
        }
        //删除数据
        $this->db()->delete('history',[
            'create_time[<]'=>time()-3*24*3600
        ]);
    }
}