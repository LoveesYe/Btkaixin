var btPluginBridge={
    version:1,
    subVersion:1,
	beginInitFlag:false,
	initPluginBridgeRegister:function(){
		console.info("%c[BTPluginBridge]%cBTPluginBridge V2.0\n                By 红石粉(xieyi1393)","color:green","color:orange");
		var that=this;
	    $.ajax({"url":"/static/btJSBridge/bridge.json","dataType":"json",cache:false,"success":function(ret){
	    		//console.log("%c[BTPluginBridge]%c检测到%c"+ret.length+"%c个插件,正在开始初始化","color:green","color:orange","color:red","color:orange");
	    	var waitLoad=[];
	    	for(item in ret.extendions){
	    		if(ret.extendions[item].search('\\.')!=-1 || ret.extendions[item].search('/')!=-1){
	    			console.error("%c[BTPluginBridge]%c检测到扩展%c"+ret.extendions[item]+"%c尝试加载外部文件,已停止加载","color:green","color:orange","color:red","color:orange");
	    			continue;
	    		}
	    		console.info("%c[BTPluginBridge]%c正在将扩展加入加载列表:%c"+ret.extendions[item],"color:green","color:orange","color:red");
	    		waitLoad.push("/static/btJSBridge/plugins/"+ret.extendions[item]+".js?_="+(new Date()).getTime());
	    		
	    	}
	    	for(item in ret.soft){
	    		if(ret.soft[item].search('\\.')!=-1 || ret.soft[item].search('/')!=-1){
	    			console.warn("%c[BTPluginBridge]%c检测到插件%c"+ret.soft[item]+"%c尝试加载外部文件,已停止加载","color:green","color:orange","color:red","color:orange");
	    			continue;
	    		}
	    		console.info("%c[BTPluginBridge]%c正在将插件加入加载列表:%c"+ret.soft[item],"color:green","color:orange","color:red");
	    		waitLoad.push("/static/btJSBridge/plugins/"+ret.soft[item]+".js?_="+(new Date()).getTime());
	    		
	    	}
	    	loadScript(waitLoad,function(){
	    			that.beginInitFlag=true;
	    			that.route();
	    		});
	    		setTimeout(function(){
	    			if(!that.beginInitFlag){
	    				console.warn("%c[BTPluginBridge]%c某些JS组件加载失败/弱网环境,尝试强制路由","color:green","color:orange");	
	    				that.route();
	    			}
	    		},5000);
	    	
	    },error:function(xhr,ret){
	    		layer.msg("面板插件桥初始化故障:"+ret,{icon:0});
	    }});
	},
	mountPoints:{
		"global":[],//全局
		"index":[],//主页 /
		"site":[],//网站 /site
		"ftp":[],//FTP /ftp
		"database":[],//数据库 /database
		"monitor":[],//监控 /control
		"secure":[],//安全 /firewall
		"file":[],//文件管理 /files
		"cron":[],//计划任务 /crontab
		"soft":[],//软件商店 /soft
		"config":[]//面板设置 /config
	},
	route:function(){
		routePoints={
			"/":"index",
			"/site":"site",
			"/ftp":"ftp",
			"/database":"database",
			"/control":"monitor",
			"/fallwall":"secure",
			"/files":"file",
			"/crontab":"cron",
			"/soft":"soft",
			"/config":"config"
		};
		x=routePoints[window.location.pathname];
		this.routeLoad('global');
		if(typeof x!="undefined" && x!=""){
			this.routeLoad(x);
		}
	},
	routeLoad:function(e){
		g=this.mountPoints[e];
		f=g.sort(function(a,b){return a.level-b.level});
		for(item in f){
			console.info("%c[BTPluginBridge]%c正在唤醒插件%c"+f[item].pluginId+"%c的%c"+e+"%c事件","color:green","color:orange","color:red","color:orange","color:red","color:orange");
			(f[item].processer)();
		}
	}
};
window.btPluginBrigeRegister=function(n,p,e,q){
    cfg={"pluginId":n,"processer":e,"level":q};
    btPluginBridge.mountPoints[p].push(cfg);
};
(function(btPluginBridge){
	var x=setInterval(function(){
		if(typeof $.ajax != "function")return;
		btPluginBridge.initPluginBridgeRegister();
		clearInterval(x);
	},500);}(btPluginBridge));