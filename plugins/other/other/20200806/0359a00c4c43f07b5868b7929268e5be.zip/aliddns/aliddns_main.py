#!/usr/bin/python
# coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: xxx <xxxx@qq.com>
# +-------------------------------------------------------------------

#+--------------------------------------------------------------------
#|   宝塔第三方应用开发aliddns
#+--------------------------------------------------------------------
import sys,os,json,time,crontab

#设置运行目录
os.chdir("/www/server/panel")

#添加包引用位置并引用公共包
sys.path.append("class/")
import public
import panelTask
t = panelTask.bt_task()
c = crontab.crontab()
#from common import dict_obj
#get = dict_obj();


#在非命令行模式下引用面板缓存和session对象
if __name__ != '__main__':
    from BTPanel import cache,session,redirect

    #设置缓存(超时10秒) cache.set('key',value,10)
    #获取缓存 cache.get('key')
    #删除缓存 cache.delete('key')

    #设置session:  session['key'] = value
    #获取session:  value = session['key']
    #删除session:  del(session['key'])


class aliddns_main:
    __plugin_path = "/www/server/panel/plugin/aliddns/"
    __config = None

    #构造方法
    def  __init__(self):
        pass

    
    #判断是否在计划任务中
    def is_running(self,args):
    	crontab_e_keyword='aliddns'
    	is_run=False
    	#读取计划任务文件
    	crontab_text=json.dumps(c.GetCrontab(''))
    	#判断是否有关键字
    	if crontab_e_keyword in crontab_text:
    	 	is_run=True
    	return is_run
    #内网穿透运行	
    def aliddns_run(self, args):
        ini_path = "/www/server/panel/plugin/aliddns/aliddns.json"
        ini_info = json.loads(public.ReadFile(ini_path, mode='r'))
        check_time = ini_info['check_time']
        # crontab_text="\n*/"+check_time+" * * * * /www/server/panel/plugin/aliddns/aliddns_update.py"
        crontab_text = "/www/server/panel/plugin/aliddns/aliddns_update.py"
        # 设置update文件权限
        crontab_ini = {}
        crontab_ini['name'] = '阿里域名动态解析'
        crontab_ini['type'] = 'minute-n'
        crontab_ini['where1'] = check_time
        crontab_ini['hour'] = ''
        crontab_ini['minute'] = ''
        crontab_ini['week'] = ''
        crontab_ini['save'] = ''
        crontab_ini['backupTo'] = 'localhost'
        crontab_ini['sType'] = 'toShell'
        crontab_ini['sName'] = 'aliddns'
        crontab_ini['sBody'] = crontab_text
        crontab_ini['urladdress'] = ''

        isExists = os.path.exists(ini_path)
        if isExists:
            # 创建计划任务
            do_text = c.AddCrontab(crontab_ini)
            do_text = True
        else:
            do_text = False
        return do_text

    # 定时任务文件追加这一行
    def stop_run(self, args):
        crontab_e_keyword = 'aliddns'
        c_zd = c.GetCrontab('')
        crontab_id = {}
        for index in range(len(c_zd)):
            crontab_gd = c_zd[index]
            if crontab_e_keyword in crontab_gd['sName']:
                crontab_id['id'] = int(crontab_gd['id'])
                break
        do_shell = c.DelCrontab(crontab_id)
        # 删除带有关键字的这一行
        return do_shell

    # 创建配置函数
    def to_c_html(self, args):
        html_url = args.templates
        return public.ReadFile('/www/server/panel/plugin/aliddns/templates/' + html_url, mode='r')
        
    # 判断是否已经配置了,并返回相关参数
    def is_ini(self, args):
        ini_path = "/www/server/panel/plugin/aliddns/aliddns.json"
        isExists = os.path.exists(ini_path)
        ini_info = {}
        if not isExists:
            ini_info['has'] = False
            # 创建文件
            # os.makedirs(ini_path)
            return ini_info
        else:
            ini_info['has'] = True
            ini_info['ini'] = json.loads(public.ReadFile(ini_path, mode='r'))
            return ini_info
            
    def get_logs(self, args):
        # 处理前端传过来的参数
        crontab_id = {}
        crontab_id['id'] = int(self.get_crontab_id(''))
        r_text = c.GetLogs(crontab_id)
        r_text = r_text['msg']
        r_text = r_text.replace('\n', '<br>')
        return_text = {}
        return_text['status'] = True
        return_text['text'] = r_text
        return return_text

            
    # 执行一次
    def del_logs(self, args):
        do_ini = {}
        do_ini['id'] = self.get_crontab_id('')
        do_r = c.DelLogs(do_ini)
        return do_r
        
    # 获取id函数
    def get_crontab_id(self, args):
        crontab_e_keyword = 'aliddns'
        c_zd = c.GetCrontab('')
        crontab_id = {}
        for index in range(len(c_zd)):
            crontab_gd = c_zd[index]
            if crontab_e_keyword in crontab_gd['sName']:
                crontab_id['id'] = int(crontab_gd['id'])
                break
        return crontab_id['id']
        
    # 创建配置文件
    def c_ini(self, args):
        fo = open("/www/server/panel/plugin/aliddns/aliddns.json", "w")
        ini_json = '{"app_key":"' + args.app_key + '","secret":"' + args.secret + '","check_time":"' + args.check_time + '","rr":"' + args.rr + '","domain":"' + args.domain + '","ttl":"' + args.ttl + '"}'
        # 配置写入文件
        fo.write(ini_json)
        # 关闭文件
        fo.close()
        # ip归零
        fo = open("/www/server/panel/plugin/aliddns/ip.txt", "w")
        ini_ip = '0.0.0.0'
        # 配置写入文件
        fo.write(ini_ip)
        # 关闭文件
        fo.close()

        if self.is_running(''):
            do_ini = {}
            do_ini['id'] = self.get_crontab_id('')
            do_ini['check_time'] = int(args.check_time)
            do_r = self.edit_crontab(do_ini)
            return do_r['status']
        else:
            self.aliddns_run('')
            return True



    	
    	

