#!/usr/bin/env python
# coding: utf-8
# 打开文件
##
import json
import requests
import random
import re
import chardet
import os,sys
import time

from aliyunsdkcore.client import AcsClient
import DescribeDomainRecordsRequest
import UpdateDomainRecordRequest
#设置运行目录
os.chdir("/www/server/panel")
#添加包引用位置并引用公共包
sys.path.append("class/")
import public
# 此类的作用是获取本地外网ip
class IP(object):
	def __init__(self):
		from tool import user_agent_list
		self.user_agent_list = user_agent_list
		# 网上找了几个获取ip的接口，为了防止过多的访问接口被封，每次调用随机选择
		self.api_list = [
			'http://ip.chinaz.com/getip.aspx',
			'http://www.net.cn/static/customercare/yourip.asp',
			'https://ip.cn/',
			'http://www.ip168.com/json.do?view=myipaddress',
			'http://pv.sohu.com/cityjson',
			'http://pv.sohu.com/cityjson',
			'http://ip.taobao.com/service/getIpInfo.php?ip=myip',
			'http://2018.ip138.com/ic.asp',
		]

	def ip_query(self):
		# 一直循环，直到成功获取到本地外网ip
		while True:
			url = random.sample(self.api_list, 1)[0]
			headers = random.sample(self.user_agent_list, 1)[0]
			try:
				res = requests.get(url, headers={'User-Agent':headers}, timeout=5)
				encoding = chardet.detect(res.content)['encoding']
				html = res.content.decode(encoding)
				out = re.findall(r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}',html)
				if out != []: return out[0] 
			except Exception as e:
				continue

#此类是修改阿里云的解析ip
class Aliyunddns(object):
	def __init__(self):
		self.local_ip = IP()
		# 通过配置文件获取相关信息
		ini_path="/www/server/panel/plugin/aliddns/aliddns.json"
		ini_info = json.loads(public.ReadFile(ini_path,mode='r'))
		self.client = AcsClient(ini_info['app_key'],ini_info['secret']);
		self.domain = ini_info['domain']
		self.rr = ini_info['rr']
		#获取二级域名
		

	#检测本地网络环境，是否是联网状态
	def IsConnectNet(self):
		try:
			requests.get('http://www.baidu.com',timeout=5)
			return True
		except requests.exceptions.ConnectionError as e:
			return False

	# 检测本地外网ip是否和解析的ip一致
	def CheckLocalip(self):
		if not self.IsConnectNet():
			print('网络不通...')
			return

		#这里为了防止频繁的访问阿里云api，会把ip存入本地的ip.txt文件中
		#每次都和本地文件中的ip地址进行对比，不一致再去访问阿里云api进行修改
		netip = self.local_ip.ip_query()
		if os.path.exists('/www/server/panel/plugin/aliddns/ip.txt'):
			with open('/www/server/panel/plugin/aliddns/ip.txt','r') as fp:
				file_ip = fp.read()

			if file_ip == netip:
				print('IP相同, 不需要重新解析。'+'当前IP：'+netip+';当前域名：'+ self.rr +'.'+self.domain)
			else:
				print('IP不相同, 开始重新解析...')
				with open('/www/server/panel/plugin/aliddns/ip.txt','w') as fp:
					fp.write(netip)
					fp.close()
				self.GetDomainRecords()
		else:
			print('文件不存在，直接写入外网IP')
			with open('/www/server/panel/plugin/aliddns/ip.txt','w') as fp: fp.write(netip)

	#开始更新
	def Update(self,ip,record,rr):
		udr = UpdateDomainRecordRequest.UpdateDomainRecordRequest()
		udr.set_accept_format('json')
		udr.set_RecordId(record['RecordId'])
		udr.set_RR(rr)
		udr.set_Type(record['Type'])
		udr.set_Value(ip)
		response = self.client.do_action_with_exception(udr)
		UpdateDomainRecordJson = json.loads(response.decode('utf-8'))
		print(UpdateDomainRecordJson)

	#获取阿里云域名解析信息
	def GetDomainRecords(self):
		DomainRecords = DescribeDomainRecordsRequest.DescribeDomainRecordsRequest()
		DomainRecords.set_DomainName(self.domain)
		DomainRecords.set_accept_format('json')
		response = self.client.do_action_with_exception(DomainRecords)
		record_dict = json.loads(response.decode('utf-8'))
		for record in record_dict['DomainRecords']['Record']:
			if not record['RR'] in self.rr:
				continue
			netip = self.local_ip.ip_query()

			if record['Value'] != netip:
				print('netip:',netip)
				print('aliip:',record['Value'])
				self.Update(netip, record,self.rr)

if __name__ == '__main__':
	ali = Aliyunddns()
	ali.CheckLocalip()