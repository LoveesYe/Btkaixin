#!/bin/bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH
install_tmp='/tmp/bt_install.pl'
public_file='/www/server/panel/install/public.sh'
download_Url='http://bt.02988.com'
pluginPath='/www/server/panel/plugin/jdoss'
pluginfile='s3fs-fuse.tar.gz'


Install()
{
	
	echo '正在安装...'
	#==================================================================
	#依赖安装开始
    if [ -f "/usr/local/bin/s3fs" ] || [ -f "/usr/bin/s3fs" ];then
       echo '环境已经安装...' > $install_tmp
    else
       echo '正在安装脚本文件...' > $install_tmp
	   mkdir -p ${pluginPath}
	   egrep -i "debian" /etc/issue /proc/version >/dev/null && SysName='Debian';
	   egrep -i "ubuntu" /etc/issue /proc/version >/dev/null && SysName='Ubuntu';
	   whereis -b yum | grep -q '/yum' && SysName='CentOS';
	   if [ "$SysName" == 'CentOS' ]; then
         sudo yum install -y automake fuse fuse-devel gcc-c++ git libcurl-devel libxml2-devel make openssl-devel
	   else
	     sudo apt-get install -y automake autotools-dev fuse g++ git libcurl4-openssl-dev libfuse-dev libssl-dev libxml2-dev make pkg-config
	   fi;
       wget -O ${pluginfile} ${download_Url}/download/s3fs-fuse.tar.gz
       tar -zxvf ${pluginfile}
       cd s3fs-fuse
       ./autogen.sh
       ./configure
       make && sudo make install
       echo '安装完成' > $install_tmp
       cd ..
       rm -fr ${pluginfile}
       rm -fr s3fs-fuse
	   if [ "$SysName" == 'CentOS' ] && [! -f "/usr/bin/s3fs" ]; then
        yum install -y s3fs-fuse
	   fi;
	   echo '安装完成' > $install_tmp
   fi
	#依赖安装结束
	#==================================================================
	wget -O ${pluginPath}/index.html $download_Url/jdoss/index.html -T 5
	wget -O ${pluginPath}/info.json $download_Url/jdoss/info.json -T 5
	wget -O ${pluginPath}/jdoss_main.py $download_Url/jdoss/jdoss_main.py -T 5
	wget -O ${pluginPath}/icon.png $download_Url/jdoss/icon.png -T 5
	wget -O ${pluginPath}/install.sh $download_Url/jdoss/install.sh -T 5
	\cp -a -r ${pluginPath}/icon.png /www/server/panel/BTPanel/static/img/soft_ico/ico-jdoss.png
	echo '================================================'
	echo '安装完成'
}

Uninstall()
{
	rm -rf $pluginPath
}

#操作判断
if [ "${1}" == 'install' ];then
	Install
elif [ "${1}" == 'uninstall' ];then
	Uninstall
else
	echo 'Error!';
fi
