#!/bin/bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH
#配置插件安装目录
install_path=/www/server/panel/plugin/ssh_manager
config_path=/etc/ssh/ssh_manager
sshrcFile=/etc/ssh/sshrc
#安装
Install()
{
    echo '正在安装...'
    #==================================================================
    #依赖安装开始
    # sshd_config文件备份
    cat /etc/ssh/sshd_config > /etc/ssh/sshd_config_bak
    
    # sshrc文件配置
    if [ ! -f "$sshrcFile" ];
    then
        #文件不存在直接输出内容至文件
        touch $sshrcFile
        echo "#!/bin/bash
python /etc/ssh/sendmail.py \$USER \${SSH_CLIENT%% *} \"\$(date +%F%t%k:%M)\" \$(hostname) >/dev/null 2>&1 & #ssh_manager" > $sshrcFile
    else
        #文件存在，判断是有执行内容
        text=`cat /etc/ssh/sshrc | grep -l -F -i '#ssh_manager'`
        # 判断内容是否存在
        if [ -z $text ]
        then
            #内容为空的时候
            echo "python /etc/ssh/sendmail.py \$USER \${SSH_CLIENT%% *} \"\$(date +%F%t%k:%M)\" \$(hostname) >/dev/null 2>&1 & #ssh_manager" >> $sshrcFile
        fi
        
    fi
    touch /etc/ssh/sendmail.py && cat $install_path/sendmail.py > /etc/ssh/sendmail.py && chmod 645 /etc/ssh/sendmail.py

    #依赖安装结束
    #==================================================================

    echo '================================================'
    echo '安装完成'
}

#卸载
Uninstall()
{
    sed -i '/#ssh_manager$/d' $sshrcFile
    rm -rf /etc/ssh/ssh_manager
    rm -rf /etc/ssh/sendmail.py
    rm -rf $install_path
}

#操作判断
if [ "${1}" == 'install' ];then
    Install
elif [ "${1}" == 'uninstall' ];then
    Uninstall
else
    echo 'Error!';
fi
