var config_explain = {
    explain: {
        "PasswordAuthentication":
        {
            "title":"密码认证",
            "content":"密码验证项，开启为允许密码验证",
        },
        "PubkeyAuthentication":
        {
            "title":"公钥认证",
            "content":"打开Pubkey认证方式，把pubkey放在~/.ssh/authorized_keys可使用密钥直接登录",
        },
        "PermitRootLogin":
        {
            "title":"root用户登录",
            "content":"是否允许root用户登录，默认为注释情况（允许root登录），如果限制root登录请取消注释的情况下关闭配置项",
        },
        "PrintMotd":
        {
            "title":"打印motd",
            "content":"服务器登陆欢迎信息。在linux中，设置/etc/issue和/etc/motd文件即可实现这样的登录欢迎信息。",
        },
        "PrintLastLog":
        {
            "title":"打印最后登录日志",
            "content":"指定 sshd(8) 是否在每一次交互式登录时打印最后一位用户的登录时间。默认值是‘yes’。",
        },
    },
    alert: function(type){
        var content = '<div style="margin: 15px">'+config_explain.explain[type].content+'</div>';
        layer.open({
            type: 1,
            title: config_explain.explain[type].title+"说明",
            area: '400px',
            closeBtn: 2,
            content: content,
        })
    }
}