//定义窗口尺寸
$('.layui-layer-page').css({ 'width': '1000px' });
//左测菜单切换效果
$(".bt-w-menu p").click(function () {
    $(this).addClass('bgw').siblings().removeClass('bgw')
});

var ssh_manager = {
    // ss配置信息
    config: function () {
        $('.plugin_body').html("<h1 style='text-align:center;margin-top:20%;'>页面加载中。。。</h1>");
        config_list = ["PasswordAuthentication","PubkeyAuthentication","PermitRootLogin","PrintMotd","PrintLastLog"];
        var tbody = '';
        for(key in config_list){
            var type=config_list[key];
            tbody += `
            <tr>
                <td>${type}</td>
                <td width="150">
                    <span class="glyphicon glyphicon-tag" onclick="config_explain.alert('${type}')"></span>
                </td>
                <td>
                    <span class="btswitch-p">
                        <input class="btswitch btswitch-ios" id="ssh_config_${type}_type" name="${type}_type" type="checkbox">
                        <label class="btswitch-btn phpmyadmin-btn" for="ssh_config_${type}_type" style="display:inline-flex;"></label>
                    </span>
                </td>
                <td>
                    <span class="btswitch-p">
                        <input class="btswitch btswitch-ios" id="ssh_config_${type}" name="${type}" type="checkbox">
                        <label class="btswitch-btn phpmyadmin-btn" for="ssh_config_${type}" style="display:inline-flex;" onclick="return ssh_manager.check_config_status('${type}')"></label>
                    </span>
                </td>
            </tr>`
        }

        var my_body = '<div class="ssh_manager-table"><div class="divtable">'
                        +'<table class="table table-hover">'
                            +'<thead>'
                                +'<tr><th>配置名</th><th width="150">说明</th><th>是否生效</th><th>配置属性</th></tr>'
                            +'</thead>'
                            +'<tbody>'+ tbody + '</tbody>'
                        +'</table></div><button type="button" class="btn btn-success btn-sm" onclick="ssh_manager.set_config()">保存</button><button type="button" class="btn btn-success btn-sm" style="float: right;" onclick="ssh_manager.reset_config()">修复ssh配置文件</button></div>';

        $('.plugin_body').html(my_body);

        request_plugin("get_config",{},function(res){
            $.each(res.data,function(index,value){
                $("#ssh_config_"+index+"_type").attr("checked",true);
                $("#ssh_config_"+index).attr("disabled",false);
                if(value == "yes"){
                    $("#ssh_config_"+index).attr("checked",true);
                }else{
                    $("#ssh_config_"+index).attr("checked",false);
                }
            })
        });
    },
    check_config_status: function(id){
        var r = $("#ssh_config_"+id+"_type").prop("checked");
        if (r==false) {
            layer.msg("请使配置生效来设置当前配置的属性！");
        }
        return r;
    },
    config2: function () {
        $('.plugin_body').html("<h1 style='text-align:center;margin-top:20%;'>页面加载中。。。</h1>");
        config_list = ["PasswordAuthentication","PubkeyAuthentication","PermitRootLogin","PrintMotd","PrintLastLog"];
        var html="";
        for(key in config_list){
            var type=config_list[key];
            html +=`
            <div class="line  mtb10">
                <div class="info-r  ml0">
                    <span class=" mr5">${type}:</span>
                    <span class="btswitch-p">
                        <input class="btswitch btswitch-ios" id="ssh_config_${type}_type" name="${type}_type" type="checkbox">
                        <label class="btswitch-btn phpmyadmin-btn" for="ssh_config_${type}_type" style="display:inline-flex;"></label>
                    </span>
                    <span class="btswitch-p">
                        <input class="btswitch btswitch-ios" id="ssh_config_${type}" name="${type}" type="checkbox">
                        <label class="btswitch-btn phpmyadmin-btn" for="ssh_config_${type}" style="display:inline-flex;"></label>
                    </span>
                </div>
            </div>
            `;
        }
        html += '<button type="button" class="btn btn-success btn-sm" style="margin-left: 10px;" onclick="ssh_manager.set_config()">保存</button>';
        $('.plugin_body').html(html);
        request_plugin("get_config",{},function(res){
            $.each(res.data,function(index,value){
                $("#ssh_config_"+index+"_type").attr("checked",true);
                if(value == "yes"){
                    $("#ssh_config_"+index).attr("checked",true);
                }else{
                    $("#ssh_config_"+index).attr("checked",false);
                }
            })
        });
    },
    set_config: function (){
        // var data = $(".plugin_body").find("input").serializeArray();
        var data = {};
        config_list = ["PasswordAuthentication","PubkeyAuthentication","PermitRootLogin","PrintMotd","PrintLastLog"];
        $.each(config_list,function(index,value){
            var type = $("#ssh_config_"+value+"_type").prop("checked");
            data[value] = {};
            data[value]["type"] = type;
            data[value]["value"] = $("#ssh_config_"+value).prop("checked");

        })
        request_plugin("set_config",{data:JSON.stringify(data)},function(res){
            layer.msg(res.msg);
            if (res.code == 0) {
                ssh_manager.config();
            }
        })
    },
    reset_config: function(){
        request_plugin("reset_config",{},function(res){
            layer.msg(res.msg);
        })
    },
    // 设置白名单
    allow: function (p) {
        $('.plugin_body').html("<h1 style='text-align:center;margin-top:20%;'>页面加载中。。。</h1>");
        if (p == undefined) p = 1;
        request_plugin('allow', { p: p, callback: 'ssh_manager.allow' }, function (res) {
            var tbody = '';
            for (var i=0 ; i < res.data.length ; i++) {
            	var data = res.data[i].replace("sshd:","");
                tbody += '<tr><td>' + data + '</td><td width="150"><a class="btlink lib-install" onclick="ssh_manager.allow_delete(\'' + res.data[i] + '\')"><span class="glyphicon glyphicon-trash"></span></a></td></tr>'
            }

            var my_body = '<button type="button" class="btn btn-success btn-sm" onclick="ssh_manager.allow_add()">添加</button>'
                        +'<div class="ssh_manager-table"><div class="divtable">'
                            +'<table class="table table-hover">'
                                +'<thead>'
                                    +'<tr><th>IP规则（Centos/RedHat 8 失效）</th><th width="150">操作</th></tr>'
                                +'</thead>'
                                +'<tbody>'+ tbody + '</tbody>'
                            +'</table></div>';

            $('.plugin_body').html(my_body);
        });
    },
    // 添加白名单
    allow_add: function () {
    	var _this = this;
        layer.open({
            type: 1,
            title: "添加IP规则",
            area: '400px',
            closeBtn: 2,
            btn: ['提交', '取消'],
            content: "<div class='bt-form pd20'>\
                <div class='line'>\
                    <span class='tname'>IP规则:</span>\
                    <div class='info-r c4'>\
                        <input class='bt-input-text mr5' type='text' name='ssh_manager_allow_add' value='' placeholder='IP规则' style='width:210px;' />\
                    </div>\
                </div>\
            </div>",
            yes: function (index, layers) {
                var data = $("[name=ssh_manager_allow_add]").val();
                request_plugin('allow_add', { data: data}, function (rdata) {
                    layer.msg(rdata.msg);
                    ssh_manager.allow()
                })
                layer.close(index);
            }
        })
    },
    // 删除白名单
    allow_delete: function(data){
        request_plugin('allow_delete', { data: data}, function (rdata) {
            layer.msg(rdata.msg);
            ssh_manager.allow()
        })
    },
    // 设置黑名单
    deny: function (p) {
        $('.plugin_body').html("<h1 style='text-align:center;margin-top:20%;'>页面加载中。。。</h1>");
        if (p == undefined) p = 1;
        request_plugin('deny', { p: p, callback: 'ssh_manager.deny' }, function (res) {
            var tbody = '';
            for (var i=0 ; i < res.data.length ; i++) {
            	var data = res.data[i].replace("sshd:","");
                tbody += '<tr><td>' + data + '</td><td width="150"><a class="btlink lib-install" onclick="ssh_manager.deny_delete(\'' + res.data[i] + '\')"><span class="glyphicon glyphicon-trash"></span></a></td></tr>'
            }

            var my_body = '<button type="button" class="btn btn-success btn-sm" onclick="ssh_manager.deny_add()">添加</button>'
                        +'<div class="ssh_manager-table"><div class="divtable">'
                            +'<table class="table table-hover">'
                                +'<thead>'
                                    +'<tr><th>IP规则（Centos/RedHat 8 失效）</th><th width="150">操作</th></tr>'
                                +'</thead>'
                                +'<tbody>'+ tbody + '</tbody>'
                            +'</table></div>';

            $('.plugin_body').html(my_body);
        });
    },
    // 添加白名单
    deny_add: function () {
		var _this = this;
        layer.open({
            type: 1,
            title: "添加黑名单IP规则",
            area: '400px',
            closeBtn: 2,
            btn: ['提交', '取消'],
            content: "<div class='bt-form pd20'>\
                <div class='line'>\
                    <span class='tname'>黑名单IP规则:</span>\
                    <div class='info-r c4'>\
                        <input class='bt-input-text mr5' type='text' name='ssh_manager_deny_add' value='' placeholder='IP规则' style='width:210px;' />\
                    </div>\
                </div>\
            </div>",
            yes: function (index, layers) {
                var data = $("[name=ssh_manager_deny_add]").val();
                request_plugin('deny_add', { data: data}, function (rdata) {
                    layer.msg(rdata.msg);
                    ssh_manager.deny()
                })
                layer.close(index);
            }
        })
    },
    // 删除白名单
    deny_delete: function(data){
        request_plugin('deny_delete', { data: data}, function (rdata) {
            layer.msg(rdata.msg);
            ssh_manager.deny()
        })
    },
    // 设置登陆事件接收人
    notice_receiver: function (p) {
        $('.plugin_body').html("<h1 style='text-align:center;margin-top:20%;'>页面加载中。。。</h1>");
        if (p == undefined) p = 1;
        request_plugin('notice_receiver', { p: p, callback: 'ssh_manager.notice_receiver' }, function (res) {
            var tbody = '';
            for (data in res.data) {
                let status = res.data[data].status == "true" ? "接收" : "忽略";
                tbody += '<tr><td>' + data + '</td><td width="150">' + status + '</td><td width="150">' + res.data[data].date + '</td><td width="150"><a class="btlink lib-install" onclick="ssh_manager.notice_receiver_delete(\'' + data + '\')"><span class="glyphicon glyphicon-trash"></span></a></td></tr>'
            }

            var my_body = '<button type="button" class="btn btn-success btn-sm" onclick="ssh_manager.notice_receiver_add()">添加</button>'
                        +'<div class="ssh_manager-table"><div class="divtable">'
                            +'<table class="table table-hover">'
                                +'<thead>'
                                    +'<tr><th>接收人邮箱</th><th>状态</th><th width="150">时间</th><th width="150">编辑</th></tr>'
                                +'</thead>'
                                +'<tbody>'+ tbody + '</tbody>'
                            +'</table></div>';

            $('.plugin_body').html(my_body);
        });
    },
    // 添加事件接收人
    notice_receiver_add: function(type){
        var _this = this;
        layer.open({
            type: 1,
            title: "添加消息通知用户",
            area: '400px',
            closeBtn: 2,
            btn: ['提交', '取消'],
            content: "<div class='bt-form pd20'>\
                <div class='line'>\
                    <span class='tname'>通知邮箱:</span>\
                    <div class='info-r c4'>\
                        <input class='bt-input-text mr5' type='text' name='ssh_manager_notice_receiver_add' value='' placeholder='请输入邮箱' style='width:210px;' />\
                    </div>\
                </div>\
            </div>",
            yes: function (index, layers) {
                var email = $("[name=ssh_manager_notice_receiver_add]").val();
                request_plugin('notice_receiver_add', { email: email}, function (rdata) {
                    layer.msg(rdata.msg);
                    ssh_manager.notice_receiver()
                })
                layer.close(index);
            }
        })
    },
    // 删除时间接收人
    notice_receiver_delete: function(email){
        request_plugin('notice_receiver_delete', { email: email}, function (rdata) {
            layer.msg(rdata.msg);
            ssh_manager.notice_receiver()
        })
    },
    // 设置登陆事件白名单
    notice_white: function (p) {
        $('.plugin_body').html("<h1 style='text-align:center;margin-top:20%;'>页面加载中。。。</h1>");
        if (p == undefined) p = 1;
        request_plugin('notice_white', { p: p, callback: 'ssh_manager.notice_white' }, function (res) {
            var tbody = '';
            for (data in res.data) {
                let status = res.data[data].status == "true" ? "生效" : "失效";
                tbody += '<tr><td>' + data + '</td><td width="150">' + status + '</td><td width="150">' + res.data[data].date + '</td><td width="150"><a class="btlink lib-install" onclick="ssh_manager.notice_white_delete(\'' + data + '\')"><span class="glyphicon glyphicon-trash"></span></a></td></tr>'
            }

            var my_body = '<button type="button" class="btn btn-success btn-sm" onclick="ssh_manager.notice_white_add()">添加</button>'
                        +'<div class="ssh_manager-table"><div class="divtable">'
                            +'<table class="table table-hover">'
                                +'<thead>'
                                    +'<tr><th>白名单IP</th><th>状态</th><th width="150">时间</th><th width="150">编辑</th></tr>'
                                +'</thead>'
                                +'<tbody>'+ tbody + '</tbody>'
                            +'</table></div>';

            $('.plugin_body').html(my_body);
        });
    },
    // 添加事件接收白名单
    notice_white_add: function(type){
        var _this = this;
        layer.open({
            type: 1,
            title: "添加登录事件通知白名单",
            area: '400px',
            closeBtn: 2,
            btn: ['提交', '取消'],
            content: "<div class='bt-form pd20'>\
                <div class='line'>\
                    <span class='tname'>IP:</span>\
                    <div class='info-r c4'>\
                        <input class='bt-input-text mr5' type='text' name='ssh_manager_notice_white_add' value='' placeholder='请输入IP' style='width:210px;' />\
                    </div>\
                </div>\
            </div>",
            yes: function (index, layers) {
                let ip = $("[name=ssh_manager_notice_white_add]").val();
                request_plugin('notice_white_add', { ip: ip}, function (rdata) {
                    layer.msg(rdata.msg);
                    ssh_manager.notice_white()
                })
                layer.close(index);
            }
        })
    },
    // 删除时间接收人
    notice_white_delete: function(ip){
        request_plugin('notice_white_delete', { ip: ip}, function (rdata) {
            layer.msg(rdata.msg);
            ssh_manager.notice_white()
        })
    },
    // 登陆通知配置
    notice_config: function () {
        $('.plugin_body').html("<h1 style='text-align:center;margin-top:20%;'>页面加载中。。。</h1>");
        request_plugin("get_notice_config",{},function(res){
            var ssl_status = res.data.ssl == "true"?"checked":"";
            var body = `
            <div class="soft-man-con bt-form">
                <div class="bt-form">
                    <div class="line">
                    	<span class="tname">通知状态：</span>
                        <div class="info-r">
                            <input class="btswitch btswitch-ios" id="y6w_stmp_notice_status" type="checkbox" name="status" value="${res.data.status}">
                            <label class="btswitch-btn" for="y6w_stmp_notice_status" title="SSH登录通知开启状态" style="margin-left: 100px;"></label>
                        </div>
                    </div>
                    <div class="line">
                        <span class="tname">smtp服务器：</span>
                        <div class="info-r">
                            <input type="text" name="smtp_server" value="${res.data.smtp_server}">
                            <span class="c9 mt10 mr5"></span>
                        </div>
                    </div>
                    <div class="line">
                        <span class="tname">smtp账号：</span>
                        <div class="info-r">
                            <input type="text" name="smtp_username" value="${res.data.smtp_username}">
                        </div>
                    </div>
                    <div class="line">
                        <span class="tname">smtp密码：</span>
                        <div class="info-r">
                            <input type="password" name="smtp_pwd" value="${res.data.smtp_pwd}">
                        </div>
                    </div>
                    <div class="line">
                        <span class="tname">smtp端口：</span>
                        <div class="info-r">
                            <input type="text" name="smtp_port" value="${res.data.smtp_port}">
                            <span class="c9 mt10 mr5">是否启用ssl:</span>
                            <input type="checkbox" name="ssl" value="true" ${ssl_status}>
                            
                        </div>
                        <span class="c9 mt10 mr5" style="color:red">*阿里服务器禁止了25端口，所以阿里服务器选用ssl才可以使用</span>
                    </div>
                    <div class="line">
                        <span class="tname">测试邮箱：</span>
                        <div class="info-r">
                            <input type="text" name="email_test" value="test@163.com">
                            <button type="button" class="btn btn-success btn-sm mr5 ml5 btn_conf_save" style="margin-left: 10px;" onclick="ssh_manager.notice_test_mail(this)">测试</button>
                            <span class="c9 mt10 mr5">向此邮箱发一封测试邮件</span>
                        </div>
                    </div>
                    <div class="line">
                        <button type="button" class="btn btn-success btn-sm" style="margin-left: 10px;" onclick="ssh_manager.save_notice_config()">保存</button>
                    </div>
                </div>
            </div>
            `;
            $(".plugin_body").html(body);
            if(res.data.status == "true"){
				$("#y6w_stmp_notice_status").attr("checked",true);
            }
			console.log(res);
    	})
    },
    // 保存配置信息
    save_notice_config: function () {
        var setting = $(".plugin_body").find("input").serializeArray();
		var data = {}
		$.each(setting,function(index,value){
			// console.log(index,value)
			data[value.name] = value['value']
		})
		console.log(data);
		request_plugin('save_notice_config', data, function (res) {
		    // console.log(res)
            layer.msg(res.msg);
            ssh_manager.notice_config();
        })
    },
    // 邮件发送测试
    notice_test_mail: function(){
        var setting = $(".plugin_body").find("input").serializeArray();
		var data = {}
		$.each(setting,function(index,value){
			data[value.name] = value['value']
        })
        request_plugin('notice_test_mail', data, function (res) {
		    // console.log(res)
            layer.msg(res.msg);
        })
    },
    // 联系方式
    contact: function () {
    	$('.plugin_body').html("<h3 style='text-align:center;margin-top:20%;'>QQ群：【925616983】 Email:root@bug-maker.com</h3>");
    },

    /**
     * 获取面板日志
     * @param p 被获取的分页
     */
    get_logs : function (p) {
        if (p == undefined) p = 1;
        request_plugin('get_logs', { p: p, callback: 'ssh_manager.get_logs' }, function (rdata) {
            var log_body = '';
            for (var i = 0; i < rdata.data.length; i++) {
                log_body += '<tr><td>' + rdata.data[i].addtime + '</td><td><span title="' + rdata.data[i].log + '">' + rdata.data[i].log + '</span></td></tr>'
            }

            var my_body = '<div class="demo-table"><div class="divtable">'
                        +'<table class="table table-hover">'
                            +'<thead>'
                                +'<tr><th width="150">时间</th><th>详情</th></tr>'
                            +'</thead>'
                            +'<tbody>'+ log_body + '</tbody>'
                        +'</table>'
                + '</div><div class="page" style="margin-top:15px">' + rdata.page + '</div</div>';

            $('.plugin_body').html(my_body);
        });
    }

}

/**
 * 发送请求到插件
 * 注意：除非你知道如何自己构造正确访问插件的ajax，否则建议您使用此方法与后端进行通信
 * @param plugin_name    插件名称 如：demo
 * @param function_name  要访问的方法名，如：get_logs
 * @param args           传到插件方法中的参数 请传入数组，示例：{p:1,rows:10,callback:"demo.get_logs"}
 * @param callback       请传入处理函数，响应内容将传入到第一个参数中
 */
function request_plugin(function_name, args, callback, timeout) {
	var plugin_name = "ssh_manager";
    if (!timeout) timeout = 3600;
    $.ajax({
        type:'POST',
        url: '/plugin?action=a&s=' + function_name + '&name=' + plugin_name,
        data: args,
        timeout:timeout,
        success: function(rdata) {
            if (!callback) {
                layer.msg(rdata.msg, { icon: rdata.status ? 1 : 2 });
                return;
            }
            return callback(rdata);
        },
        error: function(ex) {
            if (!callback) {
                layer.msg('请求过程发现错误!', { icon: 2 });
                return;
            }
            return callback(ex);
        }
    });
}

//第一次打开窗口时调用
ssh_manager.config();