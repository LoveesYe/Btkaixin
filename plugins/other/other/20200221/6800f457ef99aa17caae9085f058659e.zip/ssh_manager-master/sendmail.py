#!/usr/bin/python
# -*- coding: UTF-8 -*-

import sys
import time
import smtplib
import json
from email.mime.text import MIMEText

__config_path = "/etc/ssh/ssh_manager/"

def get_config(type):
    try:
        config_file = open(__config_path + type + ".json","r")
    except IOError:
        # 文件打开失败，写入日志
        print("read "+type+" file is fail!")
        if type != "notice_white":
            quit()
        else:
            config = {}
        
    else:
        config = json.loads(config_file.read())
        config_file.close()
    return config

def send_mail(username, passwd, recv, title, content, mail_host='smtp.163.com', port=25, ssl=False):
    '''
    发送邮件函数，默认使用163smtp
    :param username: 邮箱账号 xx@163.com
    :param passwd: 邮箱密码
    :param recv: 邮箱接收人地址，多个账号以逗号隔开
    :param title: 邮件标题
    :param content: 邮件内容
    :param mail_host: 邮箱服务器
    :param port: 端口号
    :return:
    '''
    try:
        msg = MIMEText(content)  # 邮件内容
        msg['Subject'] = title  # 邮件主题
        msg['From'] = username  # 发送者账号
        msg['To'] = recv  # 接收者账号列表
        if ssl == "false":
            smtp = smtplib.SMTP(mail_host, port=port)
        else:
            smtp = smtplib.SMTP_SSL(mail_host, port=port)
        smtp.login(username, passwd)  # 发送者的邮箱账号，密码
        smtp.sendmail(username, recv.split(','), msg.as_string())
        # 参数分别是发送者，接收者，第三个是把上面的发送邮件的内容变成字符串
        smtp.quit()  # 发送完毕后退出smtp
        # return True
    # except Exception, e:
    except Exception as e:
        # 错误信息写入日志
        print(e)
        # return e
    return True

config = get_config("config")
if config['status'] == "false":
    print("The status is false")
    quit()
    pass
else:
    print("The config's status is ",config['status'])

notice_white = get_config("notice_white")
ip = sys.argv[2]
if ip in notice_white and notice_white[ip]['status'] == "true":
    print("The IP is WhiteList")
    quit()
    pass

users = get_config("users")
to_user = []
if len(users) > 0:
    for user in users:
        if users[user]['status'] == "true":
            to_user.append(user)
            pass
    pass
else:
    quit()

smtp_server = str(config['smtp_server'])
smtp_username = str(config['smtp_username'])
smtp_pwd = str(config['smtp_pwd'])
smtp_port = str(config['smtp_port'])
smtp_ssl = str(config['ssl'])

content = "登陆IP:"+sys.argv[2]+"\n登陆用户:"+sys.argv[1]+"\n登陆时间:"+sys.argv[3]+"\n登陆主机名:"+sys.argv[4]
send_mail(smtp_username, smtp_pwd, ",".join(to_user), "SSH登陆通知！", content, smtp_server, smtp_port, smtp_ssl)