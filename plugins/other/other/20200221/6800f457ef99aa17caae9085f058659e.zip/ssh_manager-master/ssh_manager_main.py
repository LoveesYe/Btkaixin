#!/usr/bin/python
# coding: utf-8
# +-------------------------------------------------------------------
# | ssh管理器
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: 猪在天上飞 <root@bug-maker.com>
# +-------------------------------------------------------------------

import sys,os,json,time,smtplib,re
from email.mime.text import MIMEText

#设置运行目录
os.chdir("/www/server/panel")

#添加包引用位置并引用公共包
sys.path.append("class/")
import public

#from common import dict_obj
#get = dict_obj();


#在非命令行模式下引用面板缓存和session对象
if __name__ != '__main__':
    from BTPanel import cache,session,redirect


class ssh_manager_main:
    __plugin_path = "/www/server/panel/plugin/ssh_manager/"
    __ssh_path = "/etc/ssh/ssh_manager/"
    __config = None

    #构造方法
    def  __init__(self):
        self.__config = self.__get_config()
        pass
        
    # 获取配置信息
    def get_config(self,args):
        config_list = {"PasswordAuthentication","PubkeyAuthentication","PermitRootLogin","PrintMotd","PrintLastLog"}
        config = {}
        for key,value in enumerate(open(r'/etc/ssh/sshd_config', 'r')):
            if value.startswith("#") or value == "\n":
                continue
            else:
                tmp = value.split()
                if tmp[0] in config_list:
                    config[tmp[0]] = tmp[1]
                # config.append(value.split())
        return {'code': 0,'data': config}

    # 设置配置信息
    def set_config(self,args):
        # config_list = {"PasswordAuthentication","PubkeyAuthentication","PermitRootLogin","PrintMotd","PrintLastLog"}
        if "data" in args:
            data = json.loads(args['data'])
        else:
            data = {}
        config_list = {
            "PasswordAuthentication":{"type":"checkbox","value":["yes","no"]},
            "PubkeyAuthentication":{"type":"checkbox","value":["yes","no"]},
            "PermitRootLogin":{"type":"checkbox","value":["yes","no"]},
            "PrintMotd":{"type":"checkbox","value":["yes","no"]},
            "PrintLastLog":{"type":"checkbox","value":["yes","no"]}
        }
        config_file = public.readFile('/etc/ssh/sshd_config')
        for key in config_list:
            if key in data:
                if data[key]['value']:
                    k=0
                else:
                    k=1
                if data[key]['type']:
                    z=""
                else:
                    z="#"
                value = config_list[key]["value"][k]
                rep = "#*"+key+"\s+([0-9]+|yes|no)\s*\n"
                strr = z + key+" "+value+"\n"
                # strrr += strr
                config_file = re.sub(rep, strr, config_file)
        public.writeFile("/etc/ssh/sshd_config",config_file)
        self.RestartSsh()
        return {'code':0, 'msg': "设置成功"}

    # 恢复配置文件
    def reset_config(self,args):
        config_bak = public.readFile("/etc/ssh/sshd_config_bak")
        public.writeFile("/etc/ssh/sshd_config",config_bak)
        return {'code':0, 'msg': "恢复成功"}
        
    # 获取ssh白名单
    def allow(self,args):
        allow_list = []
        rec = "^sshd:.*"
        if not os.path.exists("/etc/hosts.allow"):
            public.writeFile("/etc/hosts.allow", "#")
        for key,value in enumerate(open(r'/etc/hosts.allow', 'r')):
            if len(re.findall("$\n#.*",value)) > 0:
                break
            if len(re.findall(rec,value)) > 0:
                allow_list.append(value.strip('\n'))
        count = len(allow_list)
        return {'code':0, 'data': allow_list, 'count':count}

    # 添加ssh白名单
    def allow_add(self,args):
        data = args['data']
        with open('/etc/hosts.allow', 'r+') as f:
            content = f.read()  
            f.seek(0, 0)
            f.write('sshd:'+data+"\n"+content)
        return {'code':0, 'msg': "添加成功"}
        
    # 删除ssh白名单
    def allow_delete(self,args):
        data = args['data']
        content = ""
        for key,value in enumerate(open(r'/etc/hosts.allow', 'r')):
            if len(re.findall(data+"\n",value)) > 0:
                continue
            else:
                content += value
        public.WriteFile("/etc/hosts.allow",content)
        return {'code':0, 'msg': "删除成功"}
        
    # 获取ssh黑名单
    def deny(self,args):
        deny_list = []
        rec = "^sshd:.*"
        if not os.path.exists("/etc/hosts.deny"):
            public.writeFile("/etc/hosts.deny", "#")
        for key,value in enumerate(open(r'/etc/hosts.deny', 'r')):
            if len(re.findall("$\n#.*",value)) > 0:
                break
            if len(re.findall(rec,value)) > 0:
                deny_list.append(value.strip('\n'))
        count = len(deny_list)
        return {'code':0, 'data': deny_list, 'count':count}

    # 添加ssh黑名单
    def deny_add(self,args):
        data = args['data']
        with open('/etc/hosts.deny', 'r+') as f:
            content = f.read()  
            f.seek(0, 0)
            f.write('sshd:'+data+"\n"+content)
        return {'code':0, 'msg': "添加成功"}

    # 删除ssh黑名单
    def deny_delete(self,args):
        data = args['data']
        content = ""
        for key,value in enumerate(open(r'/etc/hosts.deny', 'r')):
            if len(re.findall(data+"\n",value)) > 0:
                continue
            else:
                content += value
        public.WriteFile("/etc/hosts.deny",content)
        return {'code':0, 'msg': "删除成功"}

    # 获取消息接收人
    def notice_receiver(self,args):
        return {'code':0, 'data': self.get_file()}

    # 添加消息接收人
    def notice_receiver_add(self,args):
        data = {"status":"true","date":time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())}
        
        if self.set_file(args['email'],data):
            return {'code':0, 'msg': "添加成功"}
        else:
            return {'code':1, 'msg': "添加失败"}
    
    # 删除消息接收人
    def notice_receiver_delete(self,args):
        if self.delete_file(args['email']):
            return {'code':0, 'msg': "删除成功"}
        else:
            return {'code':1, 'msg': "删除失败"}


    # 消息接收白名单
    def notice_white(self,args):
        return {'code':0, 'data': self.get_file(None,"notice_white")}
    
    # 添加接收白名单IP
    def notice_white_add(self,args):
        data = {"status":"true","date":time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())}
        
        if self.set_file(args['ip'],data,"notice_white"):
            return {'code':0, 'msg': "添加成功"}
        else:
            return {'code':1, 'msg': "添加失败"}
    
    # 删除接收白名单IP
    def notice_white_delete(self,args):
        if self.delete_file(args['ip'],"notice_white"):
            return {'code':0, 'msg': "删除成功"}
        else:
            return {'code':1, 'msg': "删除失败"}

    # 获取ssh登陆通知配置信息
    def get_notice_config(self,args):
        # {"status":args['status'],"smtp_server":args['smtp_server'],"smtp_username":args['smtp_username'],"smtp_pwd":args['smtp_pwd'],"smtp_port":args['smtp_port'],"ssl":args['ssl']}
        return {'code': 0, 'data': self.__config}
        
    # 保存notice配置
    def save_notice_config(self,args):
        if not 'status' in args:
            args['status'] = "false"
        else:
            args['status'] = "true"
        if not 'ssl' in args:
            args['ssl'] = "false"
        else:
            args['ssl'] = "true"
        self.__config["status"] = args['status']
        self.__config["smtp_server"] = args['smtp_server']
        self.__config["smtp_username"] = args['smtp_username']
        self.__config["smtp_pwd"] = args['smtp_pwd']
        self.__config["smtp_port"] = args['smtp_port']
        self.__config["ssl"] = args['ssl']
        if self.__set_config():
            return {'code': 0, 'msg': "保存成功"}
        else:
            return {'code': 1, 'msg': "保存失败"}

    # 邮件发送测试
    def notice_test_mail(self,args):
        try:
            msg = MIMEText("这是一封测试邮件")
            msg['Subject'] = "这是一封测试邮件"
            msg['From'] = args['smtp_username']
            msg['To'] = args['email_test']
            if not "ssl" in args:
                smtp = smtplib.SMTP(str(args['smtp_server']), str(args['smtp_port']))
            else:
                smtp = smtplib.SMTP_SSL(str(args['smtp_server']), str(args['smtp_port']))
            smtp.login(str(args['smtp_username']), str(args['smtp_pwd']))
            smtp.sendmail(str(args['smtp_username']), args['email_test'], msg.as_string())
            smtp.quit()
            return {"msg":"发送成功！请注意查收"}
        except Exception as e:
            return {"msg":str(e)}

    #获取面板日志列表
    #传统方式访问get_logs方法：/plugin?action=a&name=demo&s=get_logs
    #使用动态路由模板输出： /demo/get_logs.html
    #使用动态路由输出JSON： /demo/get_logs.json
    def get_logs(self,args):
        #处理前端传过来的参数
        if not 'p' in args: args.p = 1
        if not 'rows' in args: args.rows = 12
        if not 'callback' in args: args.callback = ''
        args.p = int(args.p)
        args.rows = int(args.rows)

        #取日志总行数
        count = public.M('logs').count()

        #获取分页数据
        page_data = public.get_page(count,args.p,args.rows,args.callback)

        #获取当前页的数据列表
        log_list = public.M('logs').order('id desc').limit(page_data['shift'] + ',' + page_data['row']).field('id,type,log,addtime').select()
        
        #返回数据到前端
        return {'data': log_list,'page':page_data['page'] }
        
    #读取配置项(插件自身的配置文件)
    #@param key 取指定配置项，若不传则取所有配置[可选]
    #@param force 强制从文件重新读取配置项[可选]
    def __get_config(self,key=None,force=False):
        #判断是否从文件读取配置
        if not self.__config or force:
            config_file = self.__ssh_path + 'config.json'
            if not os.path.exists(config_file):
                public.WriteFile(config_file,json.dumps({}))
                return None
            f_body = public.ReadFile(config_file)
            if not f_body: return None
            self.__config = json.loads(f_body)

        #取指定配置项
        if key:
            if key in self.__config: return self.__config[key]
            return None
        return self.__config

    #设置配置项(插件自身的配置文件)
    #@param key 要被修改或添加的配置项[可选]
    #@param value 配置值[可选]
    def __set_config(self,key=None,value=None):
        #是否需要初始化配置项
        if not self.__config: self.__config = {}

        #是否需要设置配置值
        if key:
            self.__config[key] = value

        #写入到配置文件
        config_file = self.__ssh_path + 'config.json'
        public.WriteFile(config_file,json.dumps(self.__config))
        return True

    #读取配置项(插件自身的配置文件)
    def get_file(self,key=None,file_name="users"):
        #判断是否从文件读取配置

        that_file = self.__ssh_path + file_name + '.json'
        if not os.path.isdir(self.__ssh_path):
            os.mkdir(self.__ssh_path)
        if not os.path.exists(that_file):
            public.WriteFile(that_file,json.dumps({}))
            return None
        data = public.ReadFile(that_file)
        if not data: return None
        data = json.loads(data)

        #取指定配置项
        if key:
            if key in data: return data[key]
            return None
        return data

    #设置配置项(插件自身的配置文件)
    def set_file(self,key=None,value=None,file_name="users"):
        #是否需要初始化配置项
        data = self.get_file(None,file_name)
        if not data: data = {}
        #是否需要设置配置值
        if key:
            data[key] = value

        #写入到配置文件
        that_file = self.__ssh_path + file_name + '.json'
        public.WriteFile(that_file,json.dumps(data))
        return True

    #删除配置项(插件自身的配置文件)
    def delete_file(self,key=None,file_name="users"):
        #读取配置项
        data = self.get_file(None,file_name)

        #是否需要删除配置值
        if key in data:
            data.pop(key)
            #写入到配置文件
            that_file = self.__ssh_path + file_name + '.json'
            public.WriteFile(that_file,json.dumps(data))
            return True
        else:
            return False

    # 重启ssh服务
    def RestartSsh(self):
        version = public.readFile('/etc/redhat-release')
        act = 'restart'
        if not os.path.exists('/etc/redhat-release'):
            public.ExecShell('service ssh ' + act)
        elif version.find(' 7.') != -1:
            public.ExecShell("systemctl " + act + " sshd.service")
        else:
            public.ExecShell("/etc/init.d/sshd " + act)

