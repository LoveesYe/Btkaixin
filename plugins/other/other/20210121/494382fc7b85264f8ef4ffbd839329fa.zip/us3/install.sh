#!/bin/bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH
install_tmp='/tmp/bt_install.pl'
pluginPath='/www/server/panel/plugin/us3'

Install()
{
    echo '正在安装...'
    #===================================================
    #依赖安装开始
    if [ -f "/usr/local/bin/us3fs" ] || [ -f "/usr/bin/us3fs" ];then
        echo '环境已经安装...' > $install_tmp
    else
        echo '正在安装脚本文件...' > $install_tmp
        mkdir -p ${pluginPath}
        curl -o us3fs http://ufile-release.cn-bj.ufileos.com/us3fs%2Fus3fs
        chmod +x us3fs
        mv us3fs /usr/bin
        mkdir -p /etc/us3fs
        echo '安装完成' > $install_tmp
    fi
    #依赖安装完成
    \cp -a -r ${pluginPath}/icon.png /www/server/panel/BTPanel/static/img/soft_ico/ico-us3.png
	echo '================================================'
	echo '安装完成'
}

Uninstall()
{
	rm -rf $pluginPath
}

#操作判断
if [ "${1}" == 'install' ];then
	Install
elif [ "${1}" == 'uninstall' ];then
	Uninstall
else
	echo 'Error!';
fi