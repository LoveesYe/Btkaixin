# coding: utf-8
import sys, os
import time
if sys.version_info[0] == 2:
    reload(sys)
    sys.setdefaultencoding('utf-8')
os.chdir('/www/server/panel')
sys.path.append("class/")
import public, json, re


class us3_main(object):
    __path='/www/server/panel/plugin/us3'
    __path_sh='/www/server/panel/plugin/us3/us3.sh'
    __us3_list_json=__path+'/us3list.json'
    __us3all=[]
    #填写信息
    def GetUser(self, get):
        '''
        bucket      对象存储的Bucket名称
        access_key  ak
        secret_key  sk
        path        挂载目录
        endpoint    bucket域名url

        :param get:
        :return:
        '''
        bucket = get.bucket.strip()
        access_key = get.access_key.strip()
        secret_key = get.secret_key.strip()
        path = get.path.strip()
        endpoint = get.endpoint.strip()
        comd = public.ExecShell('which us3fs')[0]
        if not comd:
            return public.returnMsg(False, '插件未安装成功，请卸载插件，重新安装再试:')
        if not bucket or not access_key or not secret_key or not path or not endpoint:
            return public.returnMsg(False, '请填写完整信息')
        if "http" in endpoint:
            return public.returnMsg(False, '域名填写错误，不需要http')
        pathcheck = self.CheckDir(path)
        if pathcheck[0] == 0:
            return public.returnMsg(False, pathcheck[1])
        data_list = self.ReadConfig()
        for data in data_list:
            if data['bucket'] == bucket:
                return public.returnMsg(False, '%s 该Bucket已经添加' % bucket)
        ret = self.Mount(bucket, path, endpoint, access_key, secret_key)
        return ret

    def Mount(self, bucket, path, endpoint, ak, sk):
        if not os.path.exists(path):
            return public.returnMsg(False, '挂载目录不存在')
        ret = self.CheckUs3fs()
        config_path = "/etc/us3fs"
        if not ret:
            return ret
        if not os.path.exists(config_path):
            os.makedirs(config_path)

        conf_info_list = []
        info = "bucket: " + bucket+'\n'
        conf_info_list.append(info)
        info = "access_key: " + ak+'\n'
        conf_info_list.append(info)
        info = "secret_key: " + sk+'\n'
        conf_info_list.append(info)
        info = "endpoint: " + endpoint+'\n'
        conf_info_list.append(info)

        config_file = config_path + "/" + bucket + ".conf"
        try:
            fd = open(config_file, "w+")
            fd.writelines(conf_info_list)
            fd.close()
        except:
            fd=open(config_file, "w+", encoding="utf-8")
            fd.writelines(conf_info_list)
            fd.close()

        if not os.path.exists(config_file):
            return public.returnMsg(False, '未生成Bucket的配置文件')

        mount_cmd = "us3fs --passwd={0} -o allow_other {1} {2}".format(config_file, bucket, path)
        mount_ret = public.ExecShell(mount_cmd)
        if not mount_ret[0]:
            return public.returnMsg(False, '挂载失败，'+mount_ret[1])
        time.sleep(1)
        check = self.CheckMount(path)
        if not check:
            return public.returnMsg(False, '挂载失败')
        else:
            data = self.ReadConfig()
            user_info = {
                "bucket": bucket,
                "access_key": ak,
                "secret_key": sk,
                "path": path,
                "endpoint": endpoint
            }
            if not os.path.exists(self.__path_sh):
                public.writeFile(self.__path_sh, '#!/bin/sh')
                public.ExecShell('chmod +x %s'%self.__path_sh)
            shBody = public.readFile(self.__path_sh)
            if not shBody:
                shBody = '#!/bin/sh'
            retall = "%s\n%s"%(shBody, mount_cmd)
            public.writeFile(self.__path_sh, retall)
            data.append(user_info)
            public.writeFile(self.__us3_list_json, json.dumps(data))
            self.CheckInit()
            return public.returnMsg(True, '挂载%s成功'%path)

    #卸载
    def Umount(self, get):
        if not os.path.exists(self.__us3_list_json):
            return public.returnMsg(False, '未配置相关挂载信息')
        bucket = get.bucket.strip()
        data = self.ReadConfig()
        for i in range(len(data)):
            if data[i]['bucket'] == bucket:
                path = data[i]["path"]
                delindex = i

        if path == '':
            return public.returnMsg(False, '未挂载')
        public.ExecShell('umount %s'%path)
        check = self.CheckMount(path)
        if check:
            return public.returnMsg(False, '卸载失败，磁盘被占用，检查磁盘后再尝试:'+path)

        del (data[delindex])
        if len(data) < 1:
            self.DelSh()
        if os.path.exists("/etc/us3fs/%s.conf" %bucket):
            os.remove("/etc/us3fs/%s.conf" %bucket)
        public.writeFile(self.__us3_list_json, json.dumps(data))
        if os.path.exists(self.__path_sh):
            shinfo = public.ReadFile(self.__path_sh)
            newsh = ""
            shall = shinfo.split("\n")
            for shline in shall:
                if shline != "":
                    if bucket not in shline and path not in shline:
                        newsh = newsh + "\n" + shline
            public.writeFile(self.__path_sh, newsh)

        return public.returnMsg(True, '卸载成功')

    def CheckDir(self, inpath):
        if inpath in ('/,/run,/root,/boot,/usr,/bin,/etc,/proc,/var,/sys,/sbin,/lib,/lib64,/mnt,/media,/dev,/srv,/tmp,/run,/patch'):
            return 0, "不可挂载系统目录"
        if not os.path.exists(inpath):
            return 0, "挂载目录不存在"
        if os.listdir(inpath):
            return 0, "挂载目录必须为空，请移除相关内容"
        temp=public.ExecShell("df -h -P|grep '/'|grep -v tmpfs")[0]
        if inpath in (temp):
            return 0, '%s目录已经挂载' % inpath
        us3Body = self.ReadConfig()
        for i in range(len(us3Body)):
            if us3Body[i]["path"] == inpath:
                return 0, "%s目录已添加" % inpath
        return 1, 'success'

    #查看us3fs是否安装
    def CheckUs3fs(self):
        ret = int(public.ExecShell('which us3fs | grep us3fs | wc -l')[0])
        if ret == 0:
            return public.returnMsg(False, '未安装us3fs')
        return True

    #开机自启动
    def CheckInit(self):
        is_centos = True
        ret=int(public.ExecShell('which yum | grep yum | wc -l')[0])
        if ret==0:
            is_centos = False

        if not is_centos:
            local_path = "/etc/rc.local"

            self.WriteUbuntuRclocalService()

            if not os.path.exists("/etc/rc.local"):
                local_list = []
                local_list.append("#!/bin/bash\n")
                try:
                    fd=open(local_path, "w+")
                    fd.writelines(local_list)
                    fd.close()
                except:
                    fd=open(local_path, "w+", encoding="utf-8")
                    fd.writelines(local_list)
                    fd.close()

        if os.path.exists(self.__path_sh):
            rc_local = '/etc/rc.local'
            public.ExecShell("chmod +x /etc/rc.local")
            rcinit = public.readFile(rc_local)
            ret = self.__path_sh
            check_local = re.findall(ret, rcinit)
            if not check_local:
                public.ExecShell("echo 'bash %s'>>/etc/rc.local" % ret)

        if not is_centos:
            public.ExecShell("systemctl enable rc-local")
            public.ExecShell("systemctl start rc-local.service")

    #卸载的时候去掉
    def DelSh(self):
        strartde=public.ReadFile('/etc/rc.local')
        Newstrart=""
        host=strartde.split("\n")
        for _host in host:
            if _host not in ('bash %s'%self.__path_sh):
                Newstrart=Newstrart + _host + "\n"
        print(Newstrart)
        public.WriteFile('/etc/rc.local', Newstrart)

    def WriteUbuntuRclocalService(self):
        local_service_path="/etc/systemd/system/rc-local.service"
        local_info_set = []
        local_info_set.append("[Unit]\n")
        local_info_set.append("Description=/etc/rc.local Compatibility\n")
        local_info_set.append("ConditionPathExists=/etc/rc.local\n")
        local_info_set.append("\n")
        local_info_set.append("[Service]\n")
        local_info_set.append("Type=forking\n")
        local_info_set.append("ExecStart=/etc/rc.local start\n")
        local_info_set.append("TimeoutSec=0\n")
        local_info_set.append("StandardOutput=tty\n")
        local_info_set.append("RemainAfterExit=yes\n")
        local_info_set.append("SysVStartPriority=99\n")
        local_info_set.append("\n")
        local_info_set.append("[Install]\n")
        local_info_set.append("WantedBy=multi-user.target\n")

        if not os.path.exists(local_service_path):
            try:
                fd=open(local_service_path, "w+")
                fd.writelines(local_info_set)
                fd.close()
            except:
                fd=open(local_service_path, "w+", encoding="utf-8")
                fd.writelines(local_info_set)
                fd.close()

    #验证是否挂载成功
    def CheckMount(self, path):
        temp=public.ExecShell("df -h -P|grep '/'|grep -v tmpfs")[0];
        tempdisk=temp.split('\n')
        for tmp in tempdisk:
            if tmp!='':
                disk=tmp.split()
                if disk[5] == path:
                    return True
        return False

    #状态
    def GetStatus(self, get):
        info = self.GetUs3Info(get)
        return info

    #查看信息
    def GetUs3Info(self, get):
        if not os.path.exists(self.__us3_list_json):
            return public.returnMsg(False, '配置文件不存在')
        us3_info_list = json.loads(public.readFile(self.__us3_list_json))
        for i in range(len(us3_info_list)):
            disk = self.CheckMount(us3_info_list[i]["path"])
            if disk:
                us3_info_list[i]["status"] = 1
            else:
                us3_info_list[i]["status"] = 0

        return us3_info_list

    #重新挂载磁盘
    def ReloadDisk(self, get):
        if not os.path.exists(self.__path_sh):
            return public.returnMsg(False, '无挂载对象')
        flumes = public.ExecShell(self.__path_sh)[0]
        return public.returnMsg(True, '重新挂载完毕')

    #读取配置
    def ReadConfig(self):
        if not os.path.exists(self.__us3_list_json):
            public.writeFile(self.__us3_list_json, '[]')
        us3Body = public.readFile(self.__us3_list_json)
        if not us3Body:
            us3Body = '[]'
        data = json.loads(us3Body)
        return data