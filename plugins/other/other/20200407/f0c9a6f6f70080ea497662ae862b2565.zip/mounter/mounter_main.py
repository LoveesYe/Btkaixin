#!/usr/bin/python
# coding: utf-8
# +-------------------------------------------------------------------
# | mounter
# +-------------------------------------------------------------------
# | Copyright (c) 2020 cxbsoft All rights reserved.
# +-------------------------------------------------------------------
# | Author: cxbsoft@bsot.cn
# +-------------------------------------------------------------------

#+--------------------------------------------------------------------
#|   mounter
#+--------------------------------------------------------------------
import sys,os,json

#设置运行目录
os.chdir("/www/server/panel")

#添加包引用位置并引用公共包
sys.path.append("class/")
import public
import json
import os

#from common import dict_obj
#get = dict_obj();


#在非命令行模式下引用面板缓存和session对象
if __name__ != '__main__':
    from BTPanel import cache,session,redirect

    #设置缓存(超时10秒) cache.set('key',value,10)
    #获取缓存 cache.get('key')
    #删除缓存 cache.delete('key')

    #设置session:  session['key'] = value
    #获取session:  value = session['key']
    #删除session:  del(session['key'])


class mounter_main:
    __plugin_path = "/www/server/panel/plugin/mounter/"
    __config = None

    #构造方法
    def  __init__(self):
        pass

    def read_json(self,path):
        path = "/www/server/panel/plugin/mounter/jsons/"+path
        f = open(path)
        json_content = json.load(f)
        return json_content
    def write_json(self,path,content):
        path = "/www/server/panel/plugin/mounter/jsons/"+path
        f = open(path,"w")
        json.dump(content,f)
    def local_mount(self,args):
        html = """
        
        本地目录<input class='bt-input-text mr5' id='local_path' />
        &emsp;
        挂载目录<input class='bt-input-text mr5' id='mount_path' />
        <button class='btn btn-success btn-sm va0' onclick='sub_settings.new_local_mount()'>创建挂载</button>
        <table class="table table-hover">
		<thead>
		<tr>
		<th width="165">本地硬盘</th>
		<th width="120">本地目录</th>
        <th width='25' style="text-align:right;">操作</th>
		</tr><tr>
		</tr></thead>
		<tbody>
		"""
        local_mounts = self.read_json("local_mount.json")
        for local_mount in local_mounts:
            local_path = local_mount['local_path']
            mount_path = local_mount['mount_path']
            html = html + """
            
                <tr>
                <td>%s</td>
                <td>%s</td>
                <td style="text-align:right;"><a class='btlink' onclick='sub_settings.remove_local_mount("%s")'>删除</button></td>
                </tr>
            
            """%(local_path,mount_path,mount_path)
        html +=  """</tbody></table>"""
        return html
    def s3_mount_list(self,args):
        s3setlist = self.read_json("s3_mount.json")
        issets3 = s3setlist['issavesetting']
        if issets3 == "no":
            return "objectset"
            
        
        else:
            html = """
            
            Bucket<input class='bt-input-text mr5' id='bucket' />
            &emsp;
            挂载目录<input class='bt-input-text mr5' id='mount_path' />
            <button class='btn btn-success btn-sm va0' onclick='sub_settings.new_s3_mount()'>创建挂载</button>
            <table class="table table-hover">
            <thead>
            <tr>
            <th width="165">Bucket</th>
            <th width="120">本地目录</th>
            <th  style="text-align:right;">操作</th>


            </tr><tr>
            </tr></thead>
            <tbody>
            """

            s3_mounts = self.read_json("s3_bucket.json")
            for s3_mount in s3_mounts:
                bucket = s3_mount['bucket']
                mount_path = s3_mount['mount_path']
                html = html + """
                
                    <tr>
                    <td>%s</td>
                    <td>%s</td>
                    <td style="text-align:right;">
                    <a class='btlink' onclick='sub_settings.remove_s3_mount("%s")'>删除</a>
                    <a class='btlink' onclick='bucket_do.mg_object("%s")'>管理储存</a>
                    </td>
                    </tr>
                
                """%(bucket,mount_path,mount_path,mount_path)
            html +=  """</tbody></table>"""
            return html
        
    def create_local_mount(self,args):
        
        local_path = args['local_path']
        islocal = os.path.exists(local_path)
        mount_path = args['mount_path']
        ismount = True
        os.system("mkdir %s"%mount_path)
        
        returndata = {"local_path" : local_path , "mount_path" : mount_path , "islocal" : islocal , "ismount" : ismount}
        if(islocal and ismount):
            
            nowlocal = self.read_json("local_mount.json")
            willmount = True
            for localmount in nowlocal:
                if(localmount['mount_path'] == mount_path):
                    willmount = False
            if(willmount):

                os.system("mount %s %s"%(local_path,mount_path))
                newlocal = {"local_path" : local_path , "mount_path" : mount_path}
                nowlocal.append(newlocal)
                self.write_json("local_mount.json",nowlocal)
                returndata['success'] = "True"
            else:
                returndata['success'] = "False"
                returndata['error'] = "挂载目录被占用"
        else:
            returndata['success'] = "False"
            returndata['error'] = "挂载目录或本地目录不存在"
        return returndata
    def mg_object(self,args):
        mount_path = args['mount_path']
        files = os.listdir(mount_path)
        html = """
        
        
        <button class="btn btn-default btn-sm pull-left" onclick="UploadFiles('%s')">上传文件</button>
        <table class="table table-hover">
            <thead>
            <tr>
            <th>文件名</th>
            <th  style="text-align:right;">操作</th>
        </tr>
        <tbody>
        """%mount_path
        for filename in files:
            html += """
            <tr>
                    <td>%s</td>
                    <td style="text-align:right;">
                    <a class='btlink' onclick='bucket_do.download_s3_object("%s","%s")'>下载</a>
                    <a class='btlink' onclick='sub_settings.remove_s3_object("%s","%s")'>删除</a>
                    
                    </td>
            </tr>
            """%(filename,filename,mount_path,filename,mount_path)
        html +=  """</tbody></table>"""
        return html
    def websitelist(self,args):
        html = """
       目标对象储存
        <div class="layui-input-block">
            <select name="object" lay-verify="required">
        """
        return html
        objects = self.read_json("s3_bucket.json")
        for objectitem in objects:
            bucket = objectitem['bucket']
            mount_path = objectitem['mount_path']
            html  += "<option value='%s'>%s</option>"%(bucket,bucket)
        html += "</select></div>"
        html  +=
        """
            <table class="table table-hover">
            <thead>
            <tr>
            <th>站点</th>
            <th  style="text-align:right;">操作</th>
        </tr>
        <tbody>
        """
        data=public.M('sites').field('id,name,edate,path,status').order('id desc').select()
        for site in data:
            sitename = site['name']
            html += """
            <tr>
                    <td>%s</td>
                    <td style="text-align:right;">
                    <a class='btlink' onclick='websiteback.tobackup("%s")'>备份</a>
                    
                    </td>
            </tr>
            """%(sitename,sitename)
        html +=  """</tbody></table>"""
        return html
    def getfile(self,args):
        filename = args['filename']
        mount_path = args['mount_path']
        filepath = mount_path + "/" + filename
        isfile = os.path.isfile(filepath)
        if(isfile):
            return "notcwd"
        else:
            os.system("rm -rf /www/server/panel/plugin/mounter/temp/*")
            os.system("zip -r /www/server/panel/plugin/mounter/temp/%s.zip %s/*"%(filename,filepath))
            return "cwd"
    
    def create_s3_mount(self,args):
        
        bucket = args['bucket']
        
        mount_path = args['mount_path']
        ismount = True
        os.system("mkdir %s"%mount_path)
        
        returndata = {"bucket" : bucket , "mount_path" : mount_path , "ismount" : ismount}
        if(ismount):
            
            nowlocal = self.read_json("s3_bucket.json")
            willmount = True
            for localmount in nowlocal:
                if(localmount['mount_path'] == mount_path):
                    willmount = False
            keyinfo = self.read_json("s3_mount.json")
            hostname = keyinfo['hostname']
            
            if(willmount):
                
                os.system("s3fs %s %s  -o url=%s"%(bucket,mount_path,hostname))
                newlocal = {"bucket" : bucket , "mount_path" : mount_path}
                nowlocal.append(newlocal)
                self.write_json("s3_bucket.json",nowlocal)
                returndata['success'] = "True"
            else:
                returndata['success'] = "False"
                returndata['error'] = "挂载目录被占用"
        else:
            returndata['success'] = "False"
            returndata['error'] = "挂载目录或本地目录不存在"
        return returndata
    def websitebackup(self,args):
        sitename = args['sitename']
        mount_path = args['mount_path']
        site_id=public.M('sites').where('name=?',(sitename,)).getField('id')
        data=public.M('sites').where("id=?",(site_id,)).field('id,name,edate,path,status').select()
        siteinfo = data[0]
        sitepath = siteinfo['path']
        os.system("zip /www/server/panel/plugin/mounter/backup/%s.zip %s"%(sitename,sitepath))
        os.system("mkdir ")
        return data
    def s3_mount_setting(self,args):
        accesskey = args['accesskey']
        secretkey = args['secretkey']
        hostname = args['hostname']
        os.system("echo %s:%s > /etc/passwd-s3fs"%(accesskey,secretkey))
        keyinfo = {"accesskey" : accesskey , "secretkey" : secretkey , "hostname" : hostname , "issavesetting" : "true"}
        self.write_json("s3_mount.json",keyinfo)
        returninfo = {}
        returninfo['success'] = "True"
        return returninfo
    def remove_s3_mount(self,args):
        mount_path = args['mount_path']
        os.system("umount -v %s"%mount_path)
        x = 0
        nowlocal = self.read_json("s3_bucket.json")
        for localmount in nowlocal:
            if(localmount['mount_path'] == mount_path):
                del nowlocal[x]
            x += 1
        self.write_json("s3_bucket.json",nowlocal)
        returndata = {}
        returndata['success'] = "True"
        return returndata
    def remove_s3_object(self,args):
        mount_path = args['mount_path']
        filename = args['filename']
        os.system("rm -rf  %s/%s"%(mount_path,filename))
        x = 0
        nowlocal = self.read_json("s3_bucket.json")
        returndata = {}
        returndata['success'] = "True"
        
        return returndata
    def remove_local_mount(self,args):
        mount_path = args['mount_path']
        os.system("umount -v %s"%mount_path)
        x = 0
        nowlocal = self.read_json("local_mount.json")
        for localmount in nowlocal:
            if(localmount['mount_path'] == mount_path):
                del nowlocal[x]
            x += 1
        self.write_json("local_mount.json",nowlocal)
        returndata = {}
        returndata['success'] = "True"
        return returndata
    def s3_mount(self,args):
        keyinfo = self.read_json("s3_mount.json")
        hostname = keyinfo['hostname']
        accesskey = keyinfo['accesskey']
        secretkey = keyinfo['secretkey']
        html = """
        <div class='mdui-textfield'>
        <label class='mdui-textfield-label'>Access Key/ID</label>
        <input class='mdui-textfield-input' id='accesskey' value='%s' />
        </div>
        <div class='mdui-textfield'>
        <label class='mdui-textfield-label'>Secret Key</label>
        <input class='mdui-textfield-input' id='secretkey' value="%s" />
        </div>
        <div class='mdui-textfield'>
        <label class='mdui-textfield-label'>Hostname</label>
        <input class='mdui-textfield-input' id='hostname' value='%s' />
        </div>
        <button class='mdui-btn mdui-ripple' onclick='sub_settings.s3_mount()'>保存</button>
        """%(accesskey,secretkey,hostname)
        return html

