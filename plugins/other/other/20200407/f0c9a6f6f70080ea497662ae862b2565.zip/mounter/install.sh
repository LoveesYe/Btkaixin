#!/bin/bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH

#配置插件安装目录
install_path=/www/server/panel/plugin/mounter

#安装
Install()
{
	
	echo '正在安装...'
	#==================================================================
	#依赖安装开始
	sudo apt-get install make -y
	sudo apt-get install automake autotools-dev g++ git libcurl4-gnutls-dev libfuse-dev libssl-dev libxml2-dev make pkg-config -y
	git clone https://github.com/s3fs-fuse/s3fs-fuse.git
	cd s3fs-fuse
	./autogen.sh
	./configure
	make
	make install
	echo KS3ACCESSKEYID:KS3SECRETACCESSKEY > /etc/passwd-s3fs
	chmod 600 /etc/passwd-s3fs
	rm -rf  /www/server/panel/plugin/mounter/s3fs-fuse/*


	#依赖安装结束
	#==================================================================

	echo '================================================'
	echo '安装完成'
}

#卸载
Uninstall()
{
	rm -rf $install_path
}

#操作判断
if [ "${1}" == 'install' ];then
	Install
elif [ "${1}" == 'uninstall' ];then
	Uninstall
else
	echo 'Error!';
fi
