#!/bin/bash
PATH=/www/server/panel/pyenv/bin:/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH

#配置插件安装目录
install_path=/www/server/panel/plugin/disktool

#安装
Install()
{
	
	echo '正在安装...'
	#==================================================================
	#依赖安装开始
    if [ -f "/usr/bin/yum" ]; then
    yum install -y e4fsprogs xfsprogs
	elif [ -f "/usr/bin/apt-get" ]; then
	apt-get install xfsprogs -y
	fi
	modprobe ext4
	modprobe xfs
	#依赖安装结束
	#==================================================================

	echo '================================================'
	echo '安装完成'
}

#卸载
Uninstall()
{
	rm -rf $install_path
}

#操作判断
if [ "${1}" == 'install' ];then
	Install
elif [ "${1}" == 'uninstall' ];then
	Uninstall
else
	echo 'Error!';
fi
