<?php
if (!defined("PHP_ENCODER_CHECK")) define("PHP_ENCODER_CHECK", 1);
if (!defined("PHP_ENCODER_PATH")) define("PHP_ENCODER_PATH", "");
if (!defined("PHP_ENCODER_PATH_MSG")) define("PHP_ENCODER_PATH_MSG", "未授权路径$0");
if (!defined("PHP_ENCODER_DOMAIN")) define("PHP_ENCODER_DOMAIN", "");
if (!defined("PHP_ENCODER_DOMAIN_MSG")) define("PHP_ENCODER_DOMAIN_MSG", "未授权域名$0");
if (!defined("PHP_ENCODER_IP")) define("PHP_ENCODER_IP", "");
if (!defined("PHP_ENCODER_IP_MSG")) define("PHP_ENCODER_IP_MSG", "未授权IP$0");

if (defined("PHP_ENCODER_CHECK")) {
    $iscli = preg_match("/cli/i", php_sapi_name()) ? 1 : 0;
    $ck_rel = "";
    if (PHP_ENCODER_CHECK == 1 && !$iscli) {
        if (defined("PHP_ENCODER_PATH")) {
            $allowpath = getenv("DOCUMENT_ROOT");
            if (PHP_ENCODER_PATH != $allowpath) {
                $ck_rel .= str_replace("$0", $allowpath, PHP_ENCODER_PATH_MSG) . "\n";
            }
        }
        if (defined("PHP_ENCODER_DOMAIN")) {
            $domain = getenv("SERVER_NAME");
            if (PHP_ENCODER_DOMAIN != $domain) {
                $ck_rel .= str_replace("$0", $domain, PHP_ENCODER_DOMAIN_MSG) . "\n";
            }
        }
        if (defined("PHP_ENCODER_IP")) {
            $ip = getenv("SERVER_ADDR");
            if (PHP_ENCODER_IP != $ip) {
                $ck_rel .= str_replace("$0", $ip, PHP_ENCODER_IP_MSG) . "\n";
            }
        }
    }else{
        if (defined("PHP_ENCODER_PATH")) {
            $allowpath = `pwd`;
            if (PHP_ENCODER_PATH != $allowpath) {
                $ck_rel .= str_replace("$0", $allowpath, PHP_ENCODER_PATH_MSG) . "\n";
            }
        }
    }
    if (!empty($ck_rel)) {
        die($ck_rel);
    }
}
