#!/bin/bash
PATH=/www/server/panel/pyenv/bin:/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH

#配置插件安装目录
install_path=$(cd "$(dirname "$0")"; pwd)
pannelpath=$(cd "../../"; pwd)
ico_path=$pannelpath/BTPanel/static/img/soft_ico/ico-php_encoder.png
phpdir=/www/server/php
allow_version=(53  54  55  56  70  71  72  73  74)
# echo $ico_path
# echo $install_path
# exit
#安装
Install()
{
	
	echo '正在安装...'
	# pip install subprocess
	#==================================================================
	#依赖安装开始
	cp $install_path/icon.png $ico_path
	chmod -R +x *
	# chmod +x $install_path/install.sh
	# chmod +x $install_path/modules/*
	# chmod +x $install_path/tools/*
	# chmod +x $install_path/php-encoder/*
	echo "安装中..."
	
	backconfig=$phpdir/php_encoder.bak
	if [ -f $backconfig ]; then
	  cp  $backconfig  $install_path/php-encoder/php_encoder.h -f
	  echo "恢复上版本配置..."
	  rm -f $backconfig
	  echo "删除备份配置..."
	fi

	progress_line
    # makeall
	
    
	#依赖安装结束
	#==================================================================
    ln -s $install_path/tools/phpencode /usr/bin/phpencode -f
	echo '================================================'
	echo '安装完成'
}

makeall(){
    DIR=$phpdir
    for i in $(ls $DIR)
    do   
	  if [[ "${allow_version[@]}" =~ "${i}" ]]; then
        makeso "$i"
	  fi
    done
	# cp -r ./php-encoder/modules/* $install_path/modules/linux/
}

delall(){
    DIR=$phpdir
    for i in $(ls $DIR)
    do   
	  if [[ "${allow_version[@]}" =~ "${i}" ]]; then
	    soname=php_encoder${i}.so
        a="rm -f $phpdir/$i/lib/php/phpencoder/$soname"
		echo $a
		$a
	  fi
    done
	# cp -r ./php-encoder/modules/* $install_path/modules/linux/
}
#卸载
Uninstall()
{
	rm -rf $install_path
}

# 编译SO
makeso()
{
    rarfile="php_encoder.tar.gz"
	ver=$1
	echo "开始编译php${ver}..."
	if [ "$ver" != "" ];then
		soname=php_encoder${ver}.so
		sodir=$phpdir/$ver/lib/php/phpencoder/

		so_source=./modules/$soname;
		so_target=$phpdir/$ver/lib/php/phpencoder/$soname
	    echo "正在编译 ${soname}..."
		# 转到源码目录
		cd $install_path/php-encoder/
		./build.sh $ver
		if [ ! -d $sodir ]; then
			mkdir $sodir
		fi

		ls ./modules/

		# exit
		echo "停止php-fpm-$ver"
		/etc/init.d/php-fpm-$ver stop
		
		rm -rf $so_target
		a="cp -f $so_source  $so_target"
		$a
		# pwd
		# echo $a
		if [ -f $so_source ];then
			echo "$so_target生成成功"
			else
			ecno "$so_target生成失败"
		fi
		
		echo "#复制so到对应php扩展目录"
		
		# progress_line
		echo "启动php-fpm-$ver"
        /etc/init.d/php-fpm-$ver start
		#转到插件目录
		cd $install_path/
		rm $rarfile
        tar -rf   $rarfile ./php-encoder/modules/*
        tar -rf   $rarfile ./tools/*
        tar -rf   $rarfile ./ReadMe.txt
        # tar -tf $rarfile
        # cp $rarfile /www/server/panel/BTPanel/static/$rarfile
		
        echo "php${ver}编译完成"
        # test
	fi
}
test()
{
testfile=test.php
cat > $testfile <<-EOF 
<?php 
   echo "Success Installed\n\n\n"; 
?>
EOF
password=`cat ./php-encoder/php_encoder.h|grep CAKEY|awk '{print $3}'`
echo "PASSWORD:$password"
phpencode -f $testfile -p $password
php $testfile
cp $testfile /www/wwwroot/cnzz.csol.ltd/index.php
phpencode -f $testfile  -p $password -d
cat $testfile
}
progress_line(){
count=10
if [ ! $1=="" ]; then
	$count=$1
fi
# 设置间隔时间为0.5
INTERVAL=0.5
# 设置4个形状的编号，默认为0，不代表任何图像
COUNT="0"
while :
do
    # 执行循环,COUNT 每次循环加 1,(分别代表4种不同的形状)
    COUNT=`expr $COUNT + 1`
    case $COUNT in
    "1")
        echo -e '-'"\b\c"
        sleep $INTERVAL
        ;;
    "2")
        # \\签名的\代表转义字符
                echo -e '\\'"\b\c"
                sleep $INTERVAL
                ;;
    "3")
                echo -e "|\b\c"
                sleep $INTERVAL
                ;;
    "4")
                echo -e "/\b\c"
                sleep $INTERVAL
                ;;
    *)
        # 值为其他时重置为0
        COUNT="0"
		index=`expr $count + 1`
		if [ index >$index ]; then
			break;
		fi
		;;
    esac
done
}

#操作判断
if [ "${1}" == 'install' ];then
	Install
elif [ "${1}" == 'uninstall' ];then
	Uninstall
elif [ "${1}" == 'clean' ];then
	delall
elif [ "${1}" == 'test' ];then
    test
elif [ "$1" == 'make' ];then
    echo $2
	if [ "$2" != "" ];then
	    echo "make $2"
	    makeso $2
	else
	    makeall
	    echo "OK"
	fi
else 
	echo 'Error!';
fi
