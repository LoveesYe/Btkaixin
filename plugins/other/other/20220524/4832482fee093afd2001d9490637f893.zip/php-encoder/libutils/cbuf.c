/**
 *
 *  Created on: 2013/4/5
 *  Author: xjb
 *  Email: beymy.en@gmail.com
 */
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <errno.h>
#include <assert.h>
#include <ctype.h>

#include "cdefs.h"
#include "cbuf.h"

#define CBUF_HEX_LINE_SIZE 100

#define HEX_B1(p, n)            \
*(p)++ = hex[((n) >> 4)&0xf];   \
*(p)++ = hex[(n)&0xf];

#define HEX_B2(p, n)            \
HEX_B1((p), (n) >> 8);          \
HEX_B1((p), (n));

#define HEX_B4(p, n)            \
HEX_B2((p), (n) >> 16);         \
HEX_B2((p), (n));


/**
*@param bufҪд���cbuf_t
*@param strд����ַ���
*@param lenд��ĳ���
*@return �ɹ�����0,���޷���1,��������-1
*/
static int cbuf_resize(cbuf_t * buf, size_t increment)
{
    int res = 0;
    size_t new_size = 0;
    size_t len = 0;
    char *p = NULL;
    CHECK(buf == NULL, -1);
    CHECK(buf->start == NULL, -1);
    CHECK(increment <= 0, -1);
    CHECK(buf->size_max != 0 && buf->size_real >= buf->size_max, 1);

    new_size = buf->size_real + 2 * increment; /*������*/

    if(buf->size_max != 0)
    {
        /*����*/
        new_size = buf->size_real + increment;
        if(new_size > buf->size_max)
        {
            new_size = buf->size_max;
            res = 1;
            c_error("��size_max��С����,�޷���ȫ��չ");			
        }
    }
    len = buf->pos - buf->start;
    p =realloc(buf->start, new_size);
    if(p)
    {
        buf->size_real = new_size;
        buf->start = p;
        buf->pos = p + len;
        buf->end = buf->start + buf->size_real;
    }
    else
    {
        res = -1;
        c_error("realloc fail,errno[%d] %s", errno, strerror(errno));
    }
    return res;
}


/**
*@param min����������С��С,min > 0
*@param max������������С,���max==0���ʾ������,�����ʾ��������max >= min
*@return �ɹ�����0,���򷵻�-1
*/
int cbuf_init(cbuf_t *buf, size_t min, size_t max)
{
    CHECK(buf == NULL, -1);
    CHECK(min <= 0, -1);
    CHECK(max != 0 && max < min, -1);
    buf->size_min = min;
    buf->size_max = max;
    buf->size_real = min;
    buf->start = calloc(1, buf->size_real);
    if(buf->start)
    {
        buf->pos = buf->start;
        buf->end = buf->start+buf->size_real; //end����д
    }
    else
    {
        //error
        return -1;
    }
    return 0;
}


/**
*@param bufҪ�ͷŵ�cbuf_t
*/
void cbuf_destroy(cbuf_t * buf)
{
    if(buf)
    {
        if(buf->start)
        {
            free(buf->start);
        }
    }
}


/**
*@param min����������С��С,min > 0
*@param max������������С,���max==0���ʾ������,�����ʾ��������max >= min
*@return �ɹ�����cbuf_t,���򷵻�NULL
*/
cbuf_t *cbuf_new(size_t min, size_t max)
{
    cbuf_t * buf = NULL;
    CHECK(min <= 0, NULL);
    CHECK(max != 0 && max < min, NULL);
    buf = calloc(1, sizeof(*buf));
    if(buf)
    {
        if(cbuf_init(buf, min, max) != 0)
        {
            cbuf_free(buf);
            buf = NULL;
        }
    }
    return buf;
}

/**
*@param bufҪ�ͷŵ�cbuf_t
*/
void cbuf_free(cbuf_t * buf)
{
    if(buf)
    {
        cbuf_destroy(buf);
        free(buf);
    }
}

/**
*@param bufҪд���cbuf_t
*@param strд����ַ���
*@param lenд��ĳ���
*@return �ɹ�����0,���޷���1,��������-1
*/
int cbuf_append(cbuf_t * buf, const char *str, size_t len)
{
    int res = 0;
    CHECK(buf == NULL, -1);
    CHECK(str == NULL, -1);
    if(buf->pos + len >= buf->end)
    {
        res = cbuf_resize(buf, buf->pos + len - buf->end + 1);
        if(res == 1) /*����*/
        {
            len = buf->end - buf->pos - 1;
        }
    }
    if(res != -1)
    {
        memcpy(buf->pos, str, len);
        buf->pos += len;
        buf->pos[0] = '\0';
    }
    return res;
}

/**
*@param bufҪɾ����cbuf_t
*@param nҪɾ���ĳ���
*@return �ɹ�����0,��������-1
*/
int cbuf_remove(cbuf_t * buf, size_t n)
{
    CHECK(buf == NULL, -1);
    n = MIN(buf->pos-buf->start, n);
    buf->pos -= n;
    buf->pos[0] = '\0';
    return 0;
}

/**
*@param bufҪд���cbuf_t
*@param format��ʽ�ַ���
*@return �ɹ�����0,���޷���1,��������-1
*/
int cbuf_vprintf(cbuf_t * buf, const char *format, va_list args)
{
    int res = 0;
    int nwrite = 0;
    size_t remain_size = 0;
    va_list ap;
    CHECK(buf == NULL, -1);
    CHECK(format == NULL, -1);
    va_copy(ap, args);
    remain_size = buf->end - buf->pos;
    nwrite = vsnprintf(buf->pos, remain_size, format, ap);
    if(nwrite < 0)
    {
        //����
        res = -1;
        c_error("vsnprintf fail,errno[%d] %s", errno, strerror(errno));
    }
    else if(nwrite >= remain_size)
    {
        //�ض�
        //��С����������
        res = cbuf_resize(buf, nwrite - remain_size + 1);
        if(res >= 0)
        {
            va_copy(ap, args);
            remain_size = buf->end - buf->pos;
            nwrite = vsnprintf(buf->pos, remain_size, format, ap);
            if(nwrite < 0)
            {
                //����
                res = -1;
            }
            else if(nwrite >= remain_size)
            {
                //�ض�
                buf->pos += remain_size;
                res = 1;
            }
            else
            {
                //�ɹ�
                buf->pos += nwrite;
            }
        }
    }
    else
    {
        //�ɹ�
        buf->pos += nwrite;
    }

    if(res != -1)
    {
        buf->pos[0] = '\0';
    }
    return res;
}


/**
*@param bufҪд���cbuf_t
*@param format��ʽ�ַ���
*@return �ɹ�����0,���޷���1,��������-1
*/
int cbuf_printf(cbuf_t * buf, const char *format, ...)
{
    int res = 0;
    va_list args;
    CHECK(buf == NULL, -1);
    CHECK(format == NULL, -1);
    va_start(args, format);
    res = cbuf_vprintf(buf, format, args);
    va_end(args);

    return res;
}


/**
*@param bufҪд���cbuf_t
*@param format��ʽ�ַ���
*@return �ɹ�����0,���޷���1,��������-1
*/
int cbuf_printf_hex(cbuf_t * buf, const char *str, size_t len)
{
    static unsigned char hex[] = "0123456789abcdef";
    int res = 0;
    int row, col, i, j;
    char line[CBUF_HEX_LINE_SIZE], *p;
    CHECK(buf == NULL, -1);
    CHECK(str == NULL, -1);
    row = len / 16;
    col = len % 16;
    for(i = 0; i < row; i ++)
    {
        p = line;
        HEX_B4(p, i); //�к�
        *p ++ = 'h';
        *p ++ = ':';
        *p ++ = ' ';
        for(j = 0; j < 16; j ++)
        {
            HEX_B1(p, str[j]);
            *p ++ = ' ';
        }
        *p ++ = ';';
        *p ++ = ' ';
		
		//ԭ����
        //memcpy(p, str, 16); 
		for(j = 0; j < 16; j ++)
        {
			if(isprint(str[j])) {
				*p ++ = str[j];
			} else {
            	*p ++ = '.';
			}
        }
        //p += 16;
        
        *p ++ = '\n'; //����
        res = cbuf_append(buf, line, p - line);
        if(res != 0)
        {
            break;
        }
        //��һ��
        str += 16;
    }
    if(res == 0 && col > 0)
    {
        p = line;
        HEX_B4(p, i); //�к�
        *p ++ = 'h';
        *p ++ = ':';
        *p ++ = ' ';
        for(j = 0; j < col; j ++)
        {
            HEX_B1(p, str[j]);
            *p ++ = ' ';
        }
        for(; j < 16; j ++)
        {
            *p ++ = ' ';
            *p ++ = ' ';
            *p ++ = ' ';
        }
        *p ++ = ';';
        *p ++ = ' ';

		//ԭ����
        //memcpy(p, str, col); 
		for(j = 0; j < col; j ++)
        {
			if(isprint(str[j])) {
				*p ++ = str[j];
			} else {
            	*p ++ = '.';
			}
        }
        //p += col;
        
        *p ++ = '\n'; //����
        res = cbuf_append(buf, line, p - line);
    }

    if(res != -1)
    {
        buf->pos[0] = '\0';
    }

    return res;
}

void cbuf_reset(cbuf_t *buf)
{
    CHECK(buf == NULL,);
    buf->pos = buf->start;
    buf->pos[0] = '\0';
}

