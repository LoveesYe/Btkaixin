/******************************************************************************
  �� �� ��   : clog.c
  �� �� ��   : ����
  ��    ��   : xjb
  ��������   : 2014��11��14��
  ��������   : ��־
  �޸���ʷ   :
  1.��    ��   : 2014��11��14��
    ��    ��   : xjb
    �޸�����   : �����ļ�

*****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <strings.h>
#include <assert.h>
#include <limits.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <pthread.h>
#include <fcntl.h>
#include <unistd.h>
#include <glob.h>

#include "cdefs.h"
#include "cstr.h"
#include "cbuf.h"
#include "cconf.h"
#include "cdate.h"
#include "clog.h"




typedef struct clog_thread_s {
    cbuf_t *buf;
} clog_thread_t;



static const char *static_clog_level[] = {
    "DEBUG",
    "INFO",
    "NOTICE",
    "WARN",
    "ERROR",
    "FATAL",
    NULL
};

enum {
    LEVEL = 0,
    LOG_FILE,
    MAX_SIZE
};

static const char *static_config_options[] = {
    "level", "DEBUG",
    "log_file", "clog.log",
    "max_size", "100M",
    NULL
};

static pthread_rwlock_t clog_env_lock = PTHREAD_RWLOCK_INITIALIZER;
static pthread_key_t clog_thread_key;
static int clog_env_init_flag = 0;
static pthread_mutex_t clog_mutex_lock = PTHREAD_MUTEX_INITIALIZER;

static clog_t *default_log; //Ĭ����־


/**
*@brief ��ȡ����������
*
*@param name ����������
*
*@return ���ɹ��򷵻�����,���򷵻�-1
*/
static int get_option_index(const char *name) {
    int i;
    for(i = 0; static_config_options[i * 2] != NULL; i++) {
        if(strcmp(static_config_options[i * 2], name) == 0) {
            return i;
        }
    }
    return -1;
}

/**
*@brief ��ȡ�ȼ����ĵȼ�ֵ
*
*@param name ����������
*
*@return ���ɹ��򷵻صȼ�ֵ,���򷵻�-1
*/
static int get_level(const char *name) {
    int i;
    for(i = 0; static_clog_level[i] != NULL; i++) {
        if(strcmp(static_clog_level[i], name) == 0) {
            return i;
        }
    }
    return -1;
}

/**
*@brief �ͷ���־�߳�
*
*@param thread Ҫ�ͷŵ���־�̶߳���
*/
static void clog_thread_free(clog_thread_t *thread) {
    CHECK(thread == NULL,);

    if(thread->buf) {
        cbuf_free(thread->buf);
        thread->buf = NULL;
    }
    free(thread);
}


/**
*@brief ������־�߳�
*
*@return thread Ҫ�ͷŵ���־�̶߳���
*/
static clog_thread_t *clog_thread_create() {
    clog_thread_t *thread = NULL;
    thread = calloc(1, sizeof(*thread));
    if(thread) {
        thread->buf = cbuf_new(CLOG_BUF_MIN_SIZE, CLOG_BUF_MAX_SIZE);
        if(thread->buf == NULL) {
            clog_thread_free(thread);
            thread = NULL;
        }
    }
    return thread;
}


/**
*@brief �߳�����
*/
static void clog_clean_thread(void) {
    clog_thread_t *thread = NULL;
    thread = pthread_getspecific(clog_thread_key);
    if(thread) {
        clog_thread_free(thread);
    }
}


/**
*@brief ��ʼ����־����
*
*@return ���ɹ�����0,���򷵻�-1
*/
static int clog_env_init() {
    int ret = 0;
    pthread_rwlock_wrlock(&clog_env_lock);
    if(clog_env_init_flag == 0) {
        if(pthread_key_create(&clog_thread_key, (void (*)(void *)) clog_thread_free) != 0) {
            c_error("pthread_key_create fail,errno[%d] %s", errno, strerror(errno));
        } else if(atexit(clog_clean_thread) != 0) { //���߳��˳�
            ret = -1;
        } else {
            clog_env_init_flag = 1;
        }
    } else {
        c_warn("clog has been initialized");
    }
    pthread_rwlock_unlock(&clog_env_lock);
    return ret;
}


/**
*@brief ������־������
*
*@return ���ɹ�����NULL,���򷵻ش���ԭ��
*/
const char *clog_set_option(clog_t *log, const char *name, const char *value) {
    int ind = get_option_index(name);
    if(ind < 0) {
		return "No such option";
    }
	
    switch(ind) {
        case LEVEL: {
            log->level = get_level(value);
            break;
        }
        case LOG_FILE: {
            cstr_copy(log->log_file, value, sizeof(log->log_file));
            break;
        }
        case MAX_SIZE: {
            int max_size;
            if(sscanf(value, "%dM", &max_size) == 1) {
                log->max_size = max_size * 1024 * 1024;
            }
        }
    }

    return NULL;
}

static int set_option(void *data, const char *name, const char *value) {
	const char *error = clog_set_option(data, name, value);
	if(error != NULL) {
		return -1;
	}
	
	return 0;
}

/**
*@brief ������־Ĭ������
*/
static void set_default_options(clog_t *log) {
    int i;
    for(i = 0; static_config_options[i*2] != NULL; i ++) {
        set_option(log, static_config_options[i*2], static_config_options[i*2+1]);
    }
}


/**
*@brief ��ʼ����־
*
*@param log ��־����
*@param conf_file �����ļ�
*@return ���ɹ��򷵻�0,���򷵻�-1
*/
int clog_init(clog_t *log, const char *conf_file) {
    CHECK(log == NULL, -1);

	bzero(log, sizeof(*log));

    //��ʼ��
    if(clog_env_init() != 0) {
        return -1;
    }
    
    //����Ĭ������
    set_default_options(log);

	if(!cstr_empty(conf_file)) {
		cstr_copy(log->file, conf_file, sizeof(log->file));
	    //���������ļ�
	    config_parse_file(log->file, log, set_option);
	}

    return 0;
}


/**
*@brief ������־
*
*@param log ��־����
*/
void clog_destroy(clog_t *log) {
    CHECK(log == NULL,);
}


/**
*@brief ������־
*
*@param conf_file���ص������ļ�
*@return ���ɹ��򷵻���־����,���򷵻�NULL
*/
clog_t *clog_new(const char *conf_file) {
    clog_t *log = NULL;

    CHECK(conf_file == NULL, NULL);

    log = (clog_t *)calloc(1, sizeof(*log));
    if(log) {
        if(clog_init(log, conf_file) != 0) {
            free(log);
            log = NULL;
        }
    }
    return log;
}


/**
*@brief �ͷ���־
*
*@param log Ҫ���ٵ���־����
*/
void clog_free(clog_t *log) {
    CHECK(log == NULL,);

    clog_destroy(log);
    free(log);
}


/**
*@brief ��ȡ��ǰ�̵߳���־�̶߳���
*
*@return ���ɹ��򷵻���־�̶߳���,���򷵻�NULL
*/
static clog_thread_t *get_clog_thread() {
    clog_thread_t *thread = NULL;
    thread = (clog_thread_t *)pthread_getspecific(clog_thread_key);
    if(thread == NULL) {
        thread = clog_thread_create();
        if(thread == NULL) {
            c_error("clog_thread_create fail");
        } else if(pthread_setspecific(clog_thread_key, thread) != 0) {
            clog_thread_free(thread);
            thread = NULL;
        }
    }
    return thread;
}

static int clog_backup_trylock(clog_t *log, int fd) {
    \
    int ret;
    //����
    struct flock fl;

    fl.l_type = F_WRLCK;
    fl.l_start = 0;
    fl.l_whence = SEEK_SET;
    fl.l_len = 0;

    ret= pthread_mutex_trylock(&clog_mutex_lock);
    if(ret == EBUSY) {
        //OK
        return -1;
    } else if(ret != 0) {
        //ERROR
        return -1;
    }

    if(fcntl(fd, F_SETLK, &fl)) {
        if(errno == EAGAIN || errno == EACCES) {
            //OK
            /* EAGAIN on linux */
            /* EACCES on AIX */
        } else {
            c_error("lock fd[%d] fail, errno[%d]", fd, errno);
        }
        if(pthread_mutex_unlock(&clog_mutex_lock)) {
            c_error("pthread_mutex_unlock fail, errno[%d]", errno);
        }
        return -1;
    }

    return 0;
}

static int clog_backup_unlock(clog_t *log, int fd) {
    //�ͷ���
    int res = 0;
    struct flock fl;

    fl.l_type = F_UNLCK;
    fl.l_start = 0;
    fl.l_whence = SEEK_SET;
    fl.l_len = 0;

    if(fcntl(fd, F_SETLK, &fl)) {
        res = -1;
        c_error("unlock fd[%d] fail, errno[%d]", fd, errno);
    }

    if(pthread_mutex_unlock(&clog_mutex_lock)) {
        res = -1;
        c_error("pthread_mutext_unlock fail, errno[%d]", errno);
    }

    return res;
}

static int clog_backup_rename(clog_t *log) {
    int res = 0, ret;
    glob_t glob_buf;
    size_t pathc;
    char **pathv;
    char today[20];
    cdate_now_date(today, sizeof(today));
    char buf[1024];
    snprintf(buf, sizeof(buf), "%s.%s.*", log->log_file, today);

    int  max_num = 0;
    ret = glob(buf, GLOB_ERR | GLOB_MARK | GLOB_NOSORT, NULL, &glob_buf);
    if(ret == GLOB_NOMATCH) {
        max_num = 0;
    } else if(ret) {
        c_error("glob err, ret=[%d], errno[%d]", ret, errno);
        res = -1;
        goto exit;
    } else {
        pathv = glob_buf.gl_pathv;
        pathc = glob_buf.gl_pathc;

        snprintf(buf, sizeof(buf), "%s.%s.%%d%%n", log->log_file, today);

        int num = 0, len = 0;
        for(; pathc-- > 0; pathv++) {

            if(sscanf(*pathv, buf, &num, &len) != 1 ||
               (*pathv)[len] != '\0') {
                continue;
            } else {
                max_num = MAX(max_num, num);
            }
        }

        max_num ++;
    }
    globfree(&glob_buf);

    snprintf(buf, sizeof(buf), "%s.%s.%d", log->log_file, today, max_num);

    if(rename(log->log_file, buf)) {
        c_error("rename[%s]->[%s] fail, errno[%d]", log->log_file, buf, errno);
        res = -1;
    }

exit:

    return res;
}


/**
*@brief ��־����
*
*@return ���ɹ��򷵻���־�̶߳���,���򷵻�NULL
*/
static int clog_backup(clog_t *log) {
	int fd;
	if((fd = open(log->log_file, O_WRONLY)) == -1) {
        c_error("open file[%s] fail, errno[%d] %s", log->log_file, errno, strerror(errno));
		return -1;
    }

    if(clog_backup_trylock(log, fd) != 0) {
		close(fd);
        return -1;
    }

    //��־��С
    struct stat info;
    if(stat(log->log_file, &info)) {
        c_error("stat err, log_file=[%s], errno[%d]", log->log_file, errno);
        goto error;
    }

    if(info.st_size >= log->max_size) {
        if(clog_backup_rename(log) != 0) {
            goto error;
        }
    }

    clog_backup_unlock(log, fd);
	close(fd);
    return 0;

error:
    clog_backup_unlock(log, fd);
	close(fd);

    return -1;
}


/**
*@brief ��ʽ�������־
*
*@param log ��־����ָ��
*@param file �ļ���
*@param file_len �ļ�������
*@param fun ������
*@param fun_len ����������
*@param line �к�
*@param level ����ȼ�
*@param format ����ĸ�ʽ���ַ���
*
*@return ���ɹ�����0,���޷���1,��������-1
*/
void clog_printf(clog_t * log, const char *file, size_t file_len,
                 const char *fun, size_t fun_len, long line,
                 const int level, const char *format, ...) {
    int fd = -1;
    clog_thread_t *thread;
    cbuf_t *buf;
    char time[MAX_TIME_STR_LEN+1];
    va_list args;

    CHECK(log == NULL,);
    CHECK(file == NULL,);
    CHECK(fun == NULL,);
    CHECK(format == NULL,);

    va_start(args, format);

    //���������־
    if(level >= log->level) {
        if((thread = get_clog_thread()) == NULL) {
            c_error("get_clog_thread fail");
        } else {
            buf = thread->buf;
            cdate_now_datetime(time, sizeof(time));
            cbuf_printf(buf, "%s %s(%s:%ld) pid=%d\n", time, fun, file, line, getpid());
            //c_error("%s %p", format, args);
            cbuf_vprintf(buf, format, args);
			cbuf_append(buf, "\n\n", 2); //����
            if((fd = open(log->log_file, O_WRONLY | O_APPEND | O_CREAT, S_IRWXU | S_IRWXG | S_IRWXO)) == -1) {
                c_error("open file[%s] fail, errno[%d] %s", log->log_file, errno, strerror(errno));
            } else if(write(fd, cbuf_str(buf), cbuf_len(buf)) == -1) {
                c_error("write fail, errno[%d] %s", errno, strerror(errno));
            }

            if(fd >= 0) {
                close(fd);
            }

            struct stat info;
            if(stat(log->log_file, &info)) {
                c_error("stat err, log_file=[%s], errno[%d]", log->log_file, errno);
            } else if(info.st_size >= log->max_size) {                
				clog_backup(log);
            }

            cbuf_reset(buf);
        }
    }
    va_end(args);
}

/**
*@brief ��ʽ�����ʮ��������־
*
*@param log ��־����ָ��
*@param file �ļ���
*@param file_len �ļ�������
*@param fun ������
*@param fun_len ����������
*@param line �к�
*@param level ����ȼ�
*@param str Ҫ������ַ���
*@param len �ַ�������
*
*@return ���ɹ�����0,���޷���1,��������-1
*/
void clog_printf_hex(clog_t * log, const char *file, size_t file_len,
                     const char *fun, size_t fun_len, long line,
                     const int level, const char *str, size_t len) {
    int fd;
    clog_thread_t *thread;
    cbuf_t *buf;
    char time[MAX_TIME_STR_LEN];
    va_list args;
    ASSERT_PTR(log);
    ASSERT_PTR(file);
    ASSERT_PTR(fun);
    /*���������־*/
    if(level >= log->level) {
        if((thread = get_clog_thread()) == NULL) {
            c_error("get_clog_thread fail");
        } else {
            buf = thread->buf;
            cdate_now_datetime(time, sizeof(time));
            cbuf_printf(buf, "%s %s(%s:%ld) PID=%d\n", time, fun, file, line, getpid());
            cbuf_printf_hex(buf, str, len);
            cbuf_append(buf, "\n\n", 2);
            if((fd = open(log->log_file, O_WRONLY | O_APPEND | O_CREAT, S_IRWXU | S_IRWXG | S_IRWXO)) == -1) {
                c_error("open file[%s] fail, errno[%d] %s", log->log_file, errno, strerror(errno));
            } else if(write(fd, cbuf_str(buf), cbuf_len(buf)) == -1) {
                c_error("write fail, errno[%d] %s", errno, strerror(errno));
            }

            if(fd >= 0) {
                close(fd);
            }

			
			struct stat info;
			if(stat(log->log_file, &info)) {
				c_error("stat err, log_file=[%s], errno[%d]", log->log_file, errno);
			} else if(info.st_size >= log->max_size) {				  
				clog_backup(log);
			}

            cbuf_reset(buf);
        }
    }
    va_end(args);
}

void clog_set(clog_t *log) {
	default_log = log;
}

clog_t *clog_get() {
	return default_log;
}
