#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#include "cdefs.h"
#include "cstr.h"
// #include "cbuf.h"

#define FAIL(str, line) {                    	\
  printf("Fail on line %d: [%s]\n", line, str); \
  return str;                                   \
}

#define ASSERT(expr) {					\
  static_num_tests++;                   \
  if (!(expr)) FAIL(#expr, __LINE__);   \
}

#define RUN_TEST(test) { 		\
	const char *msg = test(); 	\
  	if(msg)					 	\
		return msg; 			\
}
  

static int static_num_tests = 0;


#define STR "A,B,C"
#define UPPER_STR "ABCDEFGHIJKLMNOPQRSTUVWXYZ,./;'[]1234567890"
#define LOWER_STR "abcdefghijklmnopqrstuvwxyz,./;'[]1234567890"
#define SPACE "\r\n\t\f\v "

const char *test_cstr_ltrim() 
{
	char s1[] = STR;
	char s2[] = SPACE STR SPACE;
	char s3[] = SPACE STR;
	char s4[] = STR SPACE;
	
	//�޿հ�
	ASSERT(strcmp(cstr_ltrim(s1), STR) == 0);

	//���ҿհ�
	ASSERT(strcmp(cstr_ltrim(s2), STR SPACE) == 0);

	//��հ�
	ASSERT(strcmp(cstr_ltrim(s3), STR) == 0);

	//�ҿհ�
	ASSERT(strcmp(cstr_ltrim(s4), STR SPACE) == 0);
	
	return NULL;
}

const char *test_cstr_rtrim() 
{	
	char s1[] = STR;
	char s2[] = SPACE STR SPACE;
	char s3[] = SPACE STR;
	char s4[] = STR SPACE;
	
	//�޿հ�
	ASSERT(strcmp(cstr_rtrim(s1), STR) == 0);

	//���ҿհ�
	ASSERT(strcmp(cstr_rtrim(s2), SPACE STR) == 0);

	//��հ�
	ASSERT(strcmp(cstr_rtrim(s3), SPACE STR) == 0);

	//�ҿհ�
	ASSERT(strcmp(cstr_rtrim(s4), STR) == 0);
	
	return NULL;
}

const char *test_cstr_split() 
{
	char s1[] = STR;
	char s2[] = STR;
	char *arr[5];

	//������
    ASSERT(cstr_split(s1, ",", arr, ARRAY_SIZE(arr)) == 3);
    ASSERT(strcmp(arr[0], "A") == 0);
    ASSERT(strcmp(arr[1], "B") == 0);
    ASSERT(strcmp(arr[2], "C") == 0);

    //����
    ASSERT(cstr_split(s2, ",", arr, 2) == 2);
    ASSERT(strcmp(arr[0], "A") == 0);
    ASSERT(strcmp(arr[1], "B,C") == 0);
	
	return NULL;
}

const char *test_cstr_substring() 
{
	char s1[] = STR;
	char *s;

	//ǰ1���ַ�
	s = cstr_substring(s1, 0, 1); 
	ASSERT(strcmp(s, "A") == 0);
	free(s);

	//ǰ2���ַ�
	s = cstr_substring(s1, 0, 2); 
	ASSERT(strcmp(s, "A,") == 0);
	free(s);

	//���1���ַ�
	s = cstr_substring(s1, strlen(s1)-1, strlen(s1)); 
	ASSERT(strcmp(s, "C") == 0);
	free(s);

	//���2���ַ�
	s = cstr_substring(s1, strlen(s1)-2, strlen(s1)); 
	ASSERT(strcmp(s, ",C") == 0);
	free(s);

	//�߽����
	s = cstr_substring(s1, 0, 10); 
	ASSERT(strcmp(s, s1) == 0);
	free(s);

	s = cstr_substring(s1, 3, 10); 
	ASSERT(strcmp(s, s1+3) == 0);
	free(s);
	
	return NULL;
}

const char *test_cstr_substr() 
{
	char s0[] = STR;
	char s1[] = STR;
	char s2[] = STR;
	char s3[] = STR;
	char s4[] = STR;
	char s5[] = STR;
	char s6[] = STR;

	//ǰ1���ַ�
	ASSERT(strcmp(cstr_substr(s1, 0, 1), "A") == 0);

	//ǰ2���ַ�
	ASSERT(strcmp(cstr_substr(s2, 0, 2), "A,") == 0);

	//���1���ַ�
	ASSERT(strcmp(cstr_substr(s3, strlen(s3)-1, strlen(s3)), "C") == 0); 

	//���2���ַ�
	ASSERT(strcmp(cstr_substr(s4, strlen(s4)-2, strlen(s4)), ",C") == 0); 

	//�߽����
	ASSERT(strcmp(cstr_substr(s5, 0, 10), s0) == 0);

	ASSERT(strcmp(cstr_substr(s6, 3, 10), s0+3) == 0);
	
	return NULL;
}

const char *test_cstr_trim() 
{
	char s1[] = STR;
	char s2[] = SPACE STR SPACE;
	char s3[] = SPACE STR;
	char s4[] = STR SPACE;
	
	//�޿հ�
	ASSERT(strcmp(cstr_trim(s1), STR) == 0);

	//���ҿհ�
	ASSERT(strcmp(cstr_trim(s2), STR) == 0);

	//��հ�
	ASSERT(strcmp(cstr_trim(s3), STR) == 0);

	//�ҿհ�
	ASSERT(strcmp(cstr_trim(s4), STR) == 0);
	
	return NULL;
}

const char *test_cstr_copy() 
{
	char s1[sizeof(STR)];
    cstr_copy(s1, STR, sizeof(s1));
    ASSERT(strcmp(s1, STR) == 0);

	char s2[sizeof(STR)-1];
    cstr_copy(s2, STR, sizeof(s2));
	ASSERT(strlen(s2) == strlen(STR)-1);
	ASSERT(memcmp(s2, STR, strlen(STR)-1) == 0);
	
	return NULL;
}

const char *test_cstr_empty() 
{
	//NULL
	ASSERT(cstr_empty(NULL));

	//�մ�
    ASSERT(cstr_empty(""));

	//�հ״�
    ASSERT(!cstr_empty(" "));

	//�ǿհ״�
    ASSERT(!cstr_empty("a"));
	
	return NULL;
}

const char *test_cstr_lower() 
{
	char s1[] = LOWER_STR;
	char s2[] = UPPER_STR;

#if 0
	cbuf_t buf;
	cbuf_init(&buf, 1024, 1024);

	cbuf_printf_hex(&buf, cstr_lower(s1), strlen(s1));

	c_error("\n%s", cbuf_str(&buf));
	
	cbuf_destroy(&buf);
#endif	
	
	ASSERT(strcmp(cstr_lower(s1), LOWER_STR) == 0);
	ASSERT(strcmp(cstr_lower(s2), LOWER_STR) == 0);
	
	return NULL;
}


const char *test_cstr_str() 
{
	char s1[] = "123456789";
	char s2[] = "3456";
	char s3[] = "789";
	char s4[] = "890";
	char s5[] = "1234567890";

	ASSERT(cstr_str(s1, s2, strlen(s1)) == s1+2);
	ASSERT(cstr_str(s1, s3, strlen(s1)) == s1+6);
	ASSERT(cstr_str(s1, s4, strlen(s1)) == NULL);
	ASSERT(cstr_str(s1, s5, strlen(s1)) == NULL);
	
	return NULL;
}



static const char *run_all_tests(void)
{
    RUN_TEST(test_cstr_ltrim);
	RUN_TEST(test_cstr_rtrim);
	RUN_TEST(test_cstr_split);
	RUN_TEST(test_cstr_substring);
	RUN_TEST(test_cstr_substr);
	RUN_TEST(test_cstr_trim);
	RUN_TEST(test_cstr_copy);
	RUN_TEST(test_cstr_empty);
	RUN_TEST(test_cstr_lower);
	RUN_TEST(test_cstr_str);
    return NULL;
}

int main(void)
{
    const char *fail_msg = run_all_tests();
    printf("%s, tests run: %d\n", fail_msg ? "FAIL" : "PASS", static_num_tests);
    return fail_msg == NULL ? 0 : -1;
}

