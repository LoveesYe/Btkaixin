#include <setjmp.h>
#define _try_ \
	jmp_buf __jmp_buf; \
	int __jmp_result = setjmp(__jmp_buf); \
	if (!__jmp_result) jmp_stack_push(&__jmp_buf); \
	if (!__jmp_result)

#define _catch_(x) \
	int x = __jmp_result; \
	if (!x) jmp_stack_pop(); \
	else

#define _throw_(x) longjmp(*jmp_stack_pop(), x);

#define MAX_JUMP 1024
typedef jmp_buf* jmp_stack[MAX_JUMP];
jmp_stack g_js;
int g_jsidx;

void jmp_stack_push(jmp_buf* jb)
{
	g_js[g_jsidx++] = jb;
}

jmp_buf* jmp_stack_pop()
{
	return g_js[--g_jsidx];
}
