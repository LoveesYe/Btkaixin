#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#include "cdefs.h"
#include "cbin.h"

#define FAIL(str, line) {                    	\
  printf("Fail on line %d: [%s]\n", line, str); \
  return str;                                   \
}

#define ASSERT(expr) {					\
  static_num_tests++;                   \
  if (!(expr)) FAIL(#expr, __LINE__);   \
}

#define RUN_TEST(test) { 		\
	const char *msg = test(); 	\
  	if(msg)					 	\
		return msg; 			\
}
  

static int static_num_tests = 0;


const char *test_cbin_bin_to_hex() 
{
	//unsigned char bin[8] = {0,1,2,3,255,254,253,252};
	//unsigned char hex[16] = "00010203fffefdfc";
	unsigned char bin[8] = {0x60,0x20,0x00,0x10,0x40,0x80,0x00,0x01};
	unsigned char hex[16] = "6020001040800001";
	unsigned char tmp[16];

	cbin_bin_to_hex(bin, tmp, 8);
	ASSERT(memcmp(tmp, hex, 16)== 0);
	return NULL;
}

const char *test_cbin_hex_to_bin() 
{
	unsigned char hex[16] = "00010203fffefdfc";
	unsigned char bin[8] = {0,1,2,3,255,254,253,252};
	unsigned char tmp[8];

	cbin_hex_to_bin(hex, tmp, 16);
	ASSERT(memcmp(tmp, bin, 8)== 0);
	return NULL;
}



static const char *run_all_tests(void)
{
    RUN_TEST(test_cbin_bin_to_hex);
	RUN_TEST(test_cbin_hex_to_bin);
    return NULL;
}

int main(void)
{
    const char *fail_msg = run_all_tests();
    printf("%s, tests run: %d\n", fail_msg ? "FAIL" : "PASS", static_num_tests);
    return fail_msg == NULL ? 0 : -1;
}


