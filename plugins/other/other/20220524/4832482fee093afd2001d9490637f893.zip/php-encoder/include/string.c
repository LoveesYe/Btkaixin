#include <stdio.h>
#include <string.h>

int char2uint(char *input, uint8_t *output)
{
    int i;
    for (i = 0; i < 24; i++)
    {
        output[i] &= 0x00;
        int j;
        for (j = 1; j >= 0; j--)
        {
            char hb = input[i * 2 + 1 - j];
            if (hb >= '0' && hb <= '9')
            {
                output[i] |= (uint8_t)((hb - '0') << (4 * j));
            }
            else if (hb >= 'a' && hb <= 'f')
            {
                output[i] |= (int8_t)((hb - 'a' + 10) << (4 * j));
            }
            else if (hb >= 'A' && hb <= 'F')
            {
                output[i] |= (int8_t)((hb - 'A' + 10) << (4 * j));
            }
            else
            {
                return -1;
            }
        }
    }
    return 0;
}
int strpos(char *haystack, const char *needle)
{
    char *p;
    p = strstr(haystack, needle);
    if (p)
    {
        return p - haystack;
    }
    return -1;
}

int substr(char *haystack, int start, int len, char *out)
{
    int i;
    for (i = 0; i < len; i++)
    {
        out[i] = haystack[start + i];
    }
    return 0;
}

char * replace (const char *str, const char *src, const char *dst)
{
const char* pos = str;
int count = 0;
while ((pos = strstr (pos, src))) {
count ++;
pos += strlen(src);
}

size_t result_len = strlen(str) + (strlen(dst) - strlen(src)) * count + 1;
char *result = (char *)malloc(result_len);
memset (result, 0, result_len);

const char *left = str;
const char *right = NULL;

while ((right = strstr(left, src))) {
strncat (result, left, right - left);
strcat (result, dst);
right += strlen(src);
left = right;
}
strcat(result, left);
return result;
}
