#include "md5.h"
#include "libutils/csha256.c"
#include "libutils/csha1.h"
#include "libutils/csha1.c"
#include "libutils/try.h"


char *_key;
char *SafeKey;
uint8_t key[256];

char *encode_mode;
char digest[128];
char* encodekey(char *text){
    if(DEBUG) {printf("ENCODE_MODE:%s",encode_mode);}
    if(strncmp(encode_mode,"sha256",6) == 0){
        bzero(digest, sizeof(digest));
        return csha256_hash(digest, text, NULL);
    }else if(strncmp(encode_mode,"sha1",4) == 0){
          bzero(digest, sizeof(digest));
         return csha1_hash(digest,text,0,NULL);//0,1,31,56,64
    }else{
     return md5(text);
    }
     
}