#include "php_encoder.h"
#include "include/confighelper.h"
#include "include/md5.h"
#include "libutils/csha256.c"
#include "libutils/csha1.h"
#include "libutils/csha1.c"
#include "libutils/try.h"
#include "include/aes.c"
#include "include/aes_crypt.c"
#include "include/file.c"
#include "include/string.c"

#ifndef STR1
#define STR1(R) #R
#endif

#ifndef STR2
#define STR2(R) STR1(R)
#endif

#ifndef DOMARK
#define DOMARK 0
#endif


//未加密禁止提示信息
#ifndef STRICT_MODE_ERROR_MESSAGE
#define STRICT_MODE_ERROR_MESSAGE Access Denied
#endif

//密钥
#ifndef CAKEY
#define CAKEY C1B78C52C9FFCB2004DC090B9B513EC3
#endif

// 无特征模式
#ifndef ENCODE_KEY_MODE
#define ENCODE_KEY_MODE 1
#endif

//是否允许运行未加密代码
#ifndef STRICT_MODE
#define STRICT_MODE 0
#endif
//加密方式md5/sha1/sha256
#ifndef ENCODE_MODE
#define ENCODE_MODE md5
#endif

//密钥长度32-128
#ifndef KEYLEN
#define KEYLEN 32
#endif

//调试排除模式
#ifndef STRICT_FILE
#define STRICT_FILE 1
#endif


// 版本信息
#ifndef EMAIL
#define EMAIL hkingsoft@qq.cn
#endif

#ifndef SITE
#define SITE  www.hkingsoft.cn
#endif

#ifndef VERSION
#define VERSION 1.3.8
#endif

#ifndef APPNAME
#define APPNAME PHPEncoder
#endif

//调试模式
#ifndef _DEBUG
#define _DEBUG 0
#endif

#define CAKEY2 46150861d427973cf6e7b0dbce7ba58e

int DEBUG = (int)_DEBUG;
char *_key;
char *SafeKey = STR2(CAKEY);
char *encode_mode = STR2(ENCODE_MODE);
int encode_key_mode = (int)ENCODE_KEY_MODE;
int keylen = (int)KEYLEN;
char digest[128];
uint8_t key[256];
const int _MAXBYTES = 1024 * 1024 * 2;
char *_encodekey(char *__key)
{

    if (DEBUG)
    {
        printf("ENCODE_MODE:%s\n", encode_mode);
        printf("ENCODE_KEY_MODE:%d\n", encode_key_mode);
    }
    if (strncmp(encode_mode, "sha256", 6) == 0)
    {
        if (encode_key_mode)
        {
            keylen = 128;
        }
        bzero(digest, sizeof(digest));
        return csha256_hash(digest, __key, NULL);
    }
    else if (strncmp(encode_mode, "sha1", 4) == 0)
    {
         if (encode_key_mode)
        {
            keylen = 128;
        }
        bzero(digest, sizeof(digest));
        return csha1_hash(digest, __key, 0, NULL); // 0,1,31,56,64
    }
    else
    {
         if (encode_key_mode)
        {
            keylen = 32;
        }
        return md5(__key);
    }
}

int getkey(uint8_t *_encodekeystr, int len)
{
    char *encode_key = STR2(CAKEY2);
    bzero(_encodekeystr, len);
    memset(_encodekeystr, 0, len);
    memcpy(_encodekeystr, encode_key, len);

    if (DEBUG)
    {
        printf("_encodekeystr:%s\n", _encodekeystr);
        printf("len:%d\n", len);
        printf("SafeKey:%s\n", SafeKey);
    }
    return len;
}

char *encodekey(char *__key)
{
    char *datap = _encodekey(__key);
    //判断是否是无特征模式
    if (encode_key_mode == 0)
    {
        if (DEBUG)
        {
            printf("特征模式:%s\n", datap);
        }
        return datap;
    }

    //无特征模式
    uint8_t _encodekeystr[keylen];
    int datalen = sizeof(datap);
    getkey(_encodekeystr, keylen);
    code_aes(1, datap, keylen, _encodekeystr, &datalen);
    if (DEBUG)
    {
        printf("无特征模式:%s\n,size:%d\n", _encodekeystr, sizeof(_encodekeystr));
    }
    //  printf("%s", _encodekeystr);
    // datap=STR2(CAKEY2);
    return datap;
}

char mark[300];
char *getmark()
{
    char *str=md5(encodekey(mark));
    sprintf(mark, "<?php if(!defined('%s')) {define('%s','%s');}?>\n",str,str,str);
    return mark;
}
