rm -rf *.php
app=`cat ../php_encoder.h|grep APPNAME|awk '{print $3,$4,$5,$6}'`
cat >> demo.php << EOF
<? 
include "./inc.php";
if(is_cli()){
  if(extension_loaded(trim("$app")))
        {
        echo "\033[32m$app is Load".time()."\033[0m\n";
        }else{
        echo "\033[31m$app not Found".time()."\033[0m\n";
        }
}else{
     if(extension_loaded(trim("$app"))){
        echo "$app is Load";
        }else{
        echo "$app not Found";
     }
}
EOF
cat >> inc.php << EOF
<? 
function is_cli(){
    return preg_match("/cli/i", php_sapi_name()) ? 1 : 0;
}
EOF

ver=53
if [ ! "$3" = "" ];then
    ver=$3
    ./build.sh
fi
echo "Version:$ver"

if [ ! "$2" = "" ];then
    cd ../../
    phpdir=/www/server/php
    ./install.sh make $ver
    soname=php_encoder${ver}.so
    cd ./php-encoder/tools/
    echo "更新so.."
fi

if [ ! "$3" = "" ];then
    rm -rf encode
    gcc encode.c -o encode
    sleep 2
fi
cp encode ../../tools/phpencode
cp phpencode.exe ../../tools/phpencode.exe



password=`cat ../php_encoder.h|grep CAKEY|awk '{print $3}'`
ENCODE_MODE=`cat ../php_encoder.h|grep ENCODE_MODE|awk '{print $3}'`
ENCODE_KEY_MODE=`cat ../php_encoder.h|grep ENCODE_KEY_MODE|awk '{print $3}'`
KEYLEN=`cat ../php_encoder.h|grep KEYLEN|awk '{print $3}'`
echo "password:$password"
echo "====================testing====================="
if [ $ENCODE_KEY_MODE = 1 ];then
phpencode -c -f ./  -p $password -n $KEYLEN -e $ENCODE_MODE -I -w
fi
if [ $ENCODE_KEY_MODE = 0 ];then
phpencode -c -f ./  -p $password -n $KEYLEN -e $ENCODE_MODE -I
fi
# ./encode -f ./demo.php  -p $password -e $ENCODE_MODE
count=1
if [ ! "$4" = "" ];then
    count=$4
fi
for ((i=1; i<=$count; i ++))
do
echo "====================testing$i====================="
php demo.php
done

cp *.php /www/wwwroot/t1.csol.ltd/
# if [ $ENCODE_KEY_MODE = 1 ];then
# ./encode -c -f ./  -p $password -n $KEYLEN -d -e $ENCODE_MODE -I -w
# fi
# if [ $ENCODE_KEY_MODE = 0 ];then
# ./encode -c -f ./  -p $password -n $KEYLEN -d -e $ENCODE_MODE -I
# fi

