<?php
//宝塔Linux面板插件demo for PHP
//@author 阿良<287962566@qq.com>

//必需面向对象编程，类名必需为bt_main
//允许面板访问的方法必需是public方法
//通过_get函数获取get参数,通过_post函数获取post参数
//可在public方法中直接return来返回数据到前端，也可以任意地方使用echo输出数据后exit();
//可在./php_version.json中指定兼容的PHP版本，如：["56","71","72","73"]，没有./php_version.json文件时则默认兼容所有PHP版本，面板将选择 已安装的最新版本执行插件
//允许使用模板，请在./templates目录中放入对应方法名的模板，如：test.html，请参考插件开发文档中的【使用模板】章节
//支持直接响应静态文件，请在./static目录中放入静态文件，请参考插件开发文档中的【插件静态文件】章节
class bt_main
{
    protected $dataPath;
    private $systemDir;
    private $tmpDirName;

    public function  __construct()
    {
        @chmod(PLU_PATH.'/fdisk.sh',0777);
        @chmod(PLU_PATH.'/mulu.ini',0777);
        @chmod(PLU_PATH.'/static',0777);
        $this->dataPath = PLU_PATH.'/static/';
        $this->tmpDirName = "/www/backup/disktool.";
//        $this->get_info();
        $this->systemDir =
            ['/swap','/etc','/','/root','/var','/boot','/home','/bin','/dev','/srv','/usr','/lib','/lib64','/sys','/proc','/sbin'];
    }

    //不允许被面板访问的方法请不要设置为公有方法
    public function test()
    {
        //_post()会返回所有POST参数，要获取POST参数中的username参数，请使用 _post('username')
        //可通过_version()函数获取面板版本
        //可通过_post('client_ip') 来获取访客IP
        //常量说明：
        //PLU_PATH 插件所在目录
        //PLU_NAME 插件名称
        //PLU_FUN  当前被访问的方法名称
        return array(
            _get(),
            _post(),
            _version(),
            PLU_FUN,
            PLU_NAME,
            PLU_PATH
        );
    }

    //分区操作
    function do_fq()
    {
        try {
        $post = _post();
        $cipan = trim($post['cipan']);
        $geshi = trim($post['geshi']);
        $mulu =  trim($post['mulu']);
        $fs =  trim($post['fs']);
        $start = trim($post['start']);
        if(strstr($cipan,':')){
            $cipan = explode(':',$cipan)[0];
        }
        if(strstr($cipan,'：')){
            $cipan = explode('：',$cipan)[0];
        }
        //磁盘特殊处理
        $fenqu = $cipan.'1';
        //读取mulu文件
         $mu = file_get_contents(PLU_PATH."/mulu.ini");
        if(strpos($mu,$fenqu)){
            throw new Exception('磁盘或目录被挂载过，请先使用【安全挂载和卸载】功能卸载目录！');
        }
        //强制执行分区
        if($fs == 2){
            //exec(" umount ".$fenqu);
            $command1 =  <<<EFS
#!/bin/bash
umount $fenqu
fdisk $cipan  <<EOF
d
w
EOF
EFS;
            file_put_contents(PLU_PATH.'/fdisk.sh',$command1);
            $re =  exec('sh '.PLU_PATH.'/fdisk.sh');
            
//            if($re !== 0){
//                throw  new Exception('删除分区失败');
//            }
            
            $command = <<<DS
#!/bin/bash
fdisk $cipan <<EOF
n
p
1


wq

w
EOF
mkfs.$geshi $fenqu <<EOF
y

EOF
DS;
    
            if($geshi == 'xfs'){
                $command = <<<DS
#!/bin/bash
fdisk $cipan <<EOF
n
p
1


wq

w
EOF
mkfs.$geshi -f $fenqu  <<EOF
y

EOF
DS;
            }
            file_put_contents(PLU_PATH.'/fdisk.sh',$command);
            exec('sh '.PLU_PATH.'/fdisk.sh',$res);
            if(empty($res)){
                throw new Exception('操作失败');
            }
            if (!file_exists($mulu)) {
                mkdir($mulu);
                chmod($mulu, 777);
            }
            $res2 = exec("mount ".$fenqu.' '.$mulu,$res3);
            if( $res2 == 0 ){
                if($start == 'yes'){
                    $line = <<<EOF
$fenqu $mulu $geshi defaults 0 0
EOF;
                    $this->st_disk($line);
                }
                $this->success('格式化分区挂载成功,请前往首页查看 ');
            }
            $this->error('分区失败');
        }
        
        $command = <<<DS
#!/bin/bash
fdisk $cipan <<EOF
n
p
1


wq

w
EOF
mkfs.$geshi $fenqu
DS;

        if($geshi == 'xfs'){
            $command = <<<DS
#!/bin/bash
fdisk $cipan <<EOF
n
p
1


wq

w
EOF
mkfs.$geshi -f $fenqu
DS;
        }
        //数据校验
        if(in_array($mulu,$this->systemDir)){
            //$this->error('不允许挂载系统目录,会导致系统崩溃');
            throw new Exception('不允许挂载系统目录,会导致系统崩溃');
        }
        if(empty($mulu)){
            //$this->error('请输入目录.如/mydata');
            throw new Exception('请输入目录.如/mydata');
        }
        //检测磁盘是否已经挂载
        exec("fdisk -l | grep ".$fenqu,$n);
        if(!empty($n)){
            //$this->error('磁盘已经分区挂载,请直接[安全挂载和卸载]');
            throw new Exception('磁盘已经分区,无需重复分区,为了您的数据安全,请直接【安全挂载和卸载】');
        }
        //检测是否挂载
         //exec('df -Th /'.$mulu,$n);
        exec('df -Th '.$mulu,$n);
        //&&  preg_match("/".$mulu."/",$n)
         if(!empty($n)  ){
            //$this->error('目录已经挂载');
             throw new Exception('目录已经挂载');
         }
        //数据校验
        if(!preg_match("/\//",$mulu)){
            //$this->error('前面必须带有/符号,表明目录');
            throw new Exception('前面必须带有/符号,表明目录');
        }


        if( file_exists($mulu) ){
            if(!$this->is_empty_dir($mulu) ){
                //$this->error('目录不为空,不允许挂载');
                throw new Exception('目录不为空,不允许挂载');
            }
        }




        file_put_contents(PLU_PATH.'/fdisk.sh',$command);
        exec('sh '.PLU_PATH.'/fdisk.sh',$res);
        if(empty($res)){
            throw new Exception('操作失败');
        }
        if (!file_exists($mulu)) {
            mkdir($mulu);
            chmod($mulu, 777);
        }
        $res2 = exec("mount ".$fenqu.' '.$mulu,$res3);
        if( $res2 == 0 ){
            if($start == 'yes'){
                $line = <<<EOF
$fenqu $mulu $geshi defaults 0 0
EOF;
                $this->st_disk($line);
            }


            $this->success('格式化分区挂载成功,请前往首页查看(首页信息可能有一定延迟，如果没出来稍等下再刷新看下)');
        }
        $this->error('分区失败');
        
        
        }catch (\Exception $e){
            $this->error($e->getMessage());
        }

    }
    //获取磁盘可用分区
    public function get_disk_location(){
        $res = $this->get_disk();
        $arr = [];
        foreach ($res as $v) {
            $d = explode(',',$v);
            if(count($d) == 1){
                $d = explode('，',$v);
            }
            $d[0] =  preg_replace('/Disk/','',$d[0]);
            if(preg_match('/a/',$d[0])){
                continue;
            }
            if(preg_match('/loop/',$d[0])){
                continue;
            }
            $arr[] = $d[0];
        }
        $command = 'df  -Th';
        exec($command, $df);
        foreach ($df as $k=>$v){
            if(preg_match("/tmpfs/",$v) ){
                unset($df[$k]);
            }
            if(preg_match("/boot/",$v) ){
                unset($df[$k]);
            }
        }
        $mulu =  file_get_contents(PLU_PATH.'/mulu.ini');
        $df[0] = "磁盘分区&nbsp;&nbsp;&nbsp;格式&nbsp;&nbsp;容量&nbsp;已用&nbsp;可用&nbsp;占比 目录";
        $this->success('success', ['arr'=>$arr,'df'=>$df,'mulu'=>$mulu  ]);
    }
    public function get_disk()
    {
        //原始
        //$command = "fdisk -l |grep -E \"Disk /dev/*\"";
        //$command =  'fdisk -l |grep -E "Disk /dev/.*?:|磁盘 /dev/.*?：|Disk /dev/.*?："';
        $command = "fdisk -l |grep -E \"Disk /dev/.*?:|磁盘 /dev/.*?：|Disk /dev/.*?：\"";
        exec($command, $res);
        return $res;
    }
    public function disk_info(){
        //原始
        $command = 'df  -Th';
        exec($command, $df);
        foreach ($df as $k=>$v){
            if(preg_match("/tmpfs/",$v) ){
                unset($df[$k]);
            }
        }
        $df[0] = "磁盘分区&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;格式&nbsp;&nbsp;&nbsp;&nbsp;容量&nbsp;&nbsp;&nbsp;已用&nbsp;&nbsp;&nbsp;可用&nbsp;&nbsp;&nbsp;占比&nbsp;&nbsp;&nbsp;&nbsp;目录";
        $this->success('success', ['df'=>$df ]);
    }
    public function index()
    {
        //$command =  'fdisk -l |grep -E "Disk /dev/.*?:|磁盘 /dev/.*?："';
        $command = 'fdisk -l';
        exec($command, $res);
        $arr = [];
        foreach ($res as $v) {
            if (!preg_match('/swap/', $v) && !preg_match('/root/', $v)) {
                $arr[] = $v;
            }
        }
        $this->success('success', $arr);
    }

    public function get_system()
    {
        $command = 'mount | grep "^/dev" ';
        exec($command, $res);
        foreach ($res as &$v) {
            $v = preg_replace('/on/', ' ', $v);
            $v = preg_replace('/type/', ' ', $v);
        }
        $this->success('success', $res);
    }

    public function mount()
    {
        $post = _post();
        $mulu = trim($post['mulu']);
        $fn = $post['fenqu'];
        if(strstr($fn,':')){
            $cipan = explode(':',$fn)[0];
        }
        if(strstr($fn,'：')){
            $cipan = explode('：',$fn)[0];
        }
        $fenqu = trim($cipan.'1');
        $start = trim($post['start']);
        //数据校验
        if(!preg_match("/\//",$mulu)){
            $this->error('前面必须带有/符号,表明目录');
        }
//        //检测磁盘是否已经挂载
        exec('df '.$fenqu,$n);
        if(!empty($n) && strpos($n[1],$fenqu)!==false ){
            $this->error('磁盘已经挂载');
        }
        //数据校验
        if(in_array($mulu,$this->systemDir)){
            $this->error('不允许挂载系统目录,会导致系统崩溃');
        }
        if(file_exists($mulu)   ){
            if(!$this->is_empty_dir($mulu)){
                $this->error('目录已存在且不为空,不允许挂载,请更换目录');
            }
        }
        //检测是否挂载
//        exec('df -Th /'.$mulu,$n);
//        if(!empty($n)){
//            $this->error('目录已经挂载,请不要重复挂载');
//        }
        if (!file_exists($mulu)) {
            mkdir($mulu);
            chmod($mulu, 777);
        }
        $command = 'sudo mount '.$fenqu. ' ' . $mulu . " 2>&1";
        if (exec($command, $output) == 0) {
            if(!empty($output[0])){
                $this->error('1.磁盘未分区,无法挂载,请【分区格式化挂载】<br>2.操作前注意数据备份');
            }
            if($start == 'yes'){
                $geshi = $this->get_disk_format($fenqu);
                $line = <<<EOF
$fenqu $mulu $geshi defaults 0 0
EOF;

//

                $this->st_disk($line);
            }
            $this->success('success');
        }
        $this->error($output);
    }
    //根据分区获取磁盘格式
    public function get_disk_format($fenqu)
    {
        $sh = <<<EOF
df -Th | grep "$fenqu"
EOF;
        exec($sh,$b);
        if(preg_match("/ext/",$b[0])){
            return 'ext4';
        }
        return 'xfs';
    }
    public function  st_disk($line)
    {
        $line  = trim($line);
        $arr = explode(" ",$line);
        $filename = $this->tmpDirName.md5($arr[1]);
        file_put_contents($filename,$line);
        //处理fstab
        $fs = file_get_contents('/etc/fstab');
        if(!strpos($fs,$line)){
            file_put_contents('/etc/fstab',PHP_EOL.$line,FILE_APPEND);
        }
    }
    //移除开机挂载
    public function  rm_disk($mulu)
    {
        //读取line
        $filename = $this->tmpDirName.md5($mulu);
        $line = file_get_contents($filename);
        $fs = file_get_contents("/etc/fstab");
        if(!empty($line)){
            $fss = str_replace($line,'',$fs);
            file_put_contents('/etc/fstab',trim($fss));
            @unlink($filename);
        }
    }
    function check_start()
    {
        $post = _post();
        $mulu =  trim($post['mulu']);
        $msg = file_exists($this->tmpDirName.md5($mulu))?'已设置':'未设置';
        $this->success($msg);
    }
    public function do_umount()
    {
        $post = _post();
        $mulu = trim($post['des']);
        try {
            //数据校验
            if(!preg_match("/\//",$mulu)){
                throw new Exception('前面必须带有/符号,表明目录');
            }
            //当前磁盘
            exec("df -Th | grep $mulu",$al);
            if(empty($al)){
                throw new Exception('此目录不存在或者未挂载');
            }
            if(!file_exists($mulu)){
                throw new Exception('此目录不存在或者未挂载');
            }
            if(file_exists($this->tmpDirName.md5($mulu))){
                $this->rm_disk($mulu);
            }
            $command = 'sudo umount ' .$mulu. " 2>&1";
            $res = exec($command);
            //file_put_contents(PLU_PATH.'/mulu.ini','');
            if ($res == 0) {
                //如果目录为空删除
                if(  file_exists($mulu) && $this->is_empty_dir($mulu) ){
                    @rmdir($mulu);
                }
                $this->success('success');
            }
        }catch (\Exception $e){
            $msg = '目录已被卸载或者目录处于忙碌状态';
            $this->error($e->getMessage());
        }
    }
    //获取json数据
    public function json($data)
    {
        echo json_encode($data);
        exit;
    }
    protected function success($msg = 'success', $data = null)
    {
        $this->json([
            'code' => 0,
            'msg' => $msg,
            'data' => $data
        ]);
    }
    protected function error($msg)
    {
        $this->json([
            'code' => -1,
            'msg' => $msg,
        ]);
    }
    function get_info(){
        $plugin_json = file_get_contents($this->dataPath.'/../../../data/plugin.json');
        $arr =  json_decode($plugin_json,true);
        foreach ($arr['list'] as $v){
            if($v['name']== PLU_NAME  && $v['endtime']<time()
                && $v['endtime'] !== 0
            ){
                $txt = file_get_contents($this->dataPath.'ms');
                $this->error(base64_decode($txt));
                //echo base64_decode($txt);exit;
            }
        }
    }
    function is_empty_dir($dir) {
        $command = ' ls '.$dir;
        exec($command,$res);
        return empty($res)?true:false;
    }
    function about(){
        try{
            @$json = json_decode(file_get_contents('http://www.waytomilky.com/notice.php'),true);
            $msg  = $json[PLU_NAME]['msg'];
        }catch (Exception $e){
            $msg = '欢迎使用插件!觉得可以的话给个好评哦!';
        }
        $this->success($msg);
    }
}


?>