#!/usr/bin/python
# coding: utf-8

# +--------------------------------------------------------------------
# |   Git项目部署工具
# +-------------------------------------------------------------------
# |   Author: 技术雨 <forxiaoyu@qq.com>
# +--------------------------------------------------------------------

import sys,os,json,string
if sys.version_info[0] == 2:
    reload(sys)
    sys.setdefaultencoding('utf-8')
elif sys.version_info[0] == 3:
    from importlib import reload
    reload(sys)

#设置运行目录
plugin_path = os.path.dirname(os.path.abspath(__file__))
panel_path = os.path.dirname(os.path.dirname(plugin_path))
os.chdir(panel_path)

#添加包引用位置并引用公共包
sys.path.append("class/")
import public,db,time

#在非命令行模式下引用面板缓存和session对象
if __name__ != '__main__':
    from BTPanel import cache,session,redirect

class git_deploy_main:
    __plugin_path = "%s/" % (plugin_path)
    __config = None
    __db_path = "%s/data/git_deploy.db" % (panel_path)
    __git_home = '/home/www'
    __repositoryPath = '/home/www/repository'

    # 构造方法
    def  __init__(self):
        self.__init_config()

        # 初始化数据库
        if not os.path.exists(self.__db_path) or os.path.getsize(self.__db_path) == 0:
            # 初始化数据库
            import db
            sql = db.Sql().dbfile('git_deploy')
            # print(sql)
            result = sql.fofile(self.__plugin_path+'default.sql')
            # print(result)

    # 初始化配置
    def __init_config(self):
        if self.__config: return
        self.__config = self.__get_config(None,True)
        return self.__config

    # 获取数据库对象
    def __table(self,table):
        import db
        return db.Sql().dbfile('git_deploy').table(table)

    # 首页
    def get_index(self,args):
        if not 'p' in args: args.p = 1
        if not 'rows' in args: args.rows = 10
        if not 'title' in args: args.title = ''
        args.p = int(args.p)
        args.rows = int(args.rows)
        args.title = public.checkInput(args.title)

        if public.GetSSHPort() == 22:
            # 设置git仓库首地址
            git_base_url = 'www@%s:%s/' % (public.GetLocalIp(),self.__repositoryPath[len(self.__git_home)+1:])
        else:
            ssh_port = '%s' % (public.GetSSHPort())
            # 设置git仓库首地址
            git_base_url = 'ssh://www@%s:%s%s/%s/' % (public.GetLocalIp(),ssh_port,self.__git_home,self.__repositoryPath[len(self.__git_home)+1:])

        #取网站数量
        count = self.__table('project')
        if args.title != '':
            count = count.where('title like ?','%'+args.title+'%')
        count = count.count()

        #取分页数据
        page_data = public.get_page(count,p=args.p,rows=args.rows,callback='git_deploy.get_index',result='1,2,3,4,5,8')
        #通过 page_data['shift'],page_data['ros']获取数据列表
        site_list = self.__table('project').order('id desc')
        if args.title != '':
            site_list = site_list.where('title like ?','%'+args.title+'%')
        site_list = site_list.limit(page_data['shift']+','+page_data['row']).field('id,title,info,branch,project_path,deploy_shell,exclude,add_time,update_time').select()

        if isinstance(site_list,str):
            return {'code':0,'msg':'系统错误'}

        #构造返回字典
        data = {'data':site_list,'page':page_data['page'],'title':args.title,'git_base_url':git_base_url}
        return {
            "code":1,
            "msg":"操作成功",
            "total":count,
            "data":data
        }

    # 添加项目
    def add_project(self,args):
        if not 'title' in args: args.title = ''
        if not 'info' in args: args.info = ''
        if not 'branch' in args: args.branch = ''
        if not 'project_path' in args: args.project_path = ''
        if not 'deploy_shell' in args: args.deploy_shell = ''
        if not 'exclude' in args: args.exclude = ''
        args.info = args.info.replace('\r','')
        args.deploy_shell = args.deploy_shell.replace('\r','')
        args.exclude = args.exclude.replace('\r','')

        if not all([args.title,args.branch,args.project_path]):
            return {'code':0,'msg':'参数错误'}


        projectData = self.__table('project').where('title=?',(args.title,)).find()
        if projectData:
            return {'code':0,'msg':'已存在同名项目'}

        now_time = int(time.time())
        data = {
            'title' : args.title,
            'info' : args.info,
            'branch' : args.branch,
            'project_path' : args.project_path,
            'deploy_shell' : args.deploy_shell,
            'exclude' : args.exclude,
            'add_time' : now_time,
            'update_time' : now_time
        }

        result = self.__table('project').insert(data)
        if isinstance(result,int):

            # 初始化项目
            if not os.path.exists(self.__repositoryPath):
                public.ExecShell('mkdir -p %s' % (self.__repositoryPath))

            project_git_rep = self.__repositoryPath+'/'+data['title']+'.git'
            if not os.path.exists(project_git_rep):
                # git init --bare sample.git
                # chown -R git:git sample.git
                # result = public.ExecShell('mkdir -p %s' % (project_git_rep))
                result = public.ExecShell('git init --bare %s' % (project_git_rep))
                if result[1] == '':
                    public.ExecShell('cd %s && git config core.sparsecheckout true' % (project_git_rep))

                    public.ExecShell('echo "/*" > %s/info/sparse-checkout' % (project_git_rep))
                    public.ExecShell('echo "%s" >> %s/info/sparse-checkout' % (data['exclude'],project_git_rep))


                    deploy_shell_init = '''#!/bin/bash
cd %s
%s
''' % (data['project_path'],data['deploy_shell'].replace('$','\$'))
                    # 用户自定义部署脚本
                    public.ExecShell('echo "%s" > %s/hooks/customer_shell.sh && chmod 777 %s/hooks/customer_shell.sh' % (deploy_shell_init,project_git_rep,project_git_rep))
                    # public.ExecShell('sed -i "s/\r//g" %s/hooks/customer_shell.sh' % (project_git_rep))

                    deploy_shell_default = '''#!/bin/bash
DeployPath="%s"
GitRepository="%s"
GitBranch="%s"
if [[ \$1 =~ .*/\$GitBranch$ ]];
then
    echo "\$GitBranch ref received. Deploying \$GitBranch branch to production..."
    git --work-tree=\$DeployPath --git-dir=\$GitRepository checkout -f -b \$GitBranch
    git --work-tree=\$DeployPath --git-dir=\$GitRepository checkout -f \$GitBranch
    git --work-tree=\$DeployPath --git-dir=\$GitRepository checkout -f
    . \$GitRepository/hooks/customer_shell.sh
else
    echo "Ref \$1 successfully received. Doing nothing: only the master branch may be deployed on this server."
fi
''' % (data['project_path'],project_git_rep,data['branch'])

                    # return deploy_shell_default

                    # 部署脚本
                    public.ExecShell('echo "%s" > %s/hooks/post-update && chmod 777 %s/hooks/post-update' % (deploy_shell_default,project_git_rep,project_git_rep))

                    public.ExecShell('chown -R www:www %s' % (project_git_rep))


            return {'code':1,'msg':'操作成功','data':{'id':result}}
        else:
            return {'code':0,'msg':'操作失败'}

    # 编辑项目
    def edit_project(self,args):
        if not 'id' in args: args.id = 0
        if not 'title' in args: args.title = ''
        if not 'info' in args: args.info = ''
        if not 'branch' in args: args.branch = ''
        if not 'project_path' in args: args.project_path = ''
        if not 'deploy_shell' in args: args.deploy_shell = ''
        if not 'exclude' in args: args.exclude = ''
        args.id = int(args.id)
        args.info = args.info.replace('\r','')
        args.deploy_shell = args.deploy_shell.replace('\r','')
        args.exclude = args.exclude.replace('\r','')

        if not all([args.title,args.branch,args.project_path]):
            return {'code':0,'msg':'参数错误'}

        projectData = self.__table('project').where('id=?',(args.id,)).find()
        if not projectData:
            return {'code':0,'msg':'项目不存在'}

        if args.title != projectData['title']:
            newProjectData = self.__table('project').where('title=?',(args.title,)).find()
            if newProjectData:
                return {'code':0,'msg':'已存在同名项目'}

        now_time = int(time.time())
        data = {
            'title' : args.title,
            'info' : args.info,
            'branch' : args.branch,
            'project_path' : args.project_path,
            'deploy_shell' : args.deploy_shell,
            'exclude' : args.exclude,
            'update_time' : now_time
        }

        result = self.__table('project').where('id = ?',(args.id,)).update(data)
        if result:

            project_git_rep = self.__repositoryPath+'/'+data['title']+'.git'

            # 仓库名字变更
            if projectData['title'] != data['title']:
                project_git_rep_old = self.__repositoryPath+'/'+projectData['title']+'.git'
                public.ExecShell('mv %s %s' % (project_git_rep_old,project_git_rep))

            # 部署脚本变更
            if projectData['branch'] != data['branch'] or projectData['project_path'] != data['project_path'] or projectData['title'] != data['title']:

                webhooks_shell_file  = '%s/hooks/webhooks' % (project_git_rep)
                if not os.path.exists(webhooks_shell_file):
                    webhooks_shell = '''#!/bin/bash
'''
                    public.ExecShell('echo "%s" > %s && chmod 777 %s' % (webhooks_shell,webhooks_shell_file,webhooks_shell_file))

                deploy_shell_default = '''#!/bin/bash
DeployPath="%s"
GitRepository="%s"
GitBranch="%s"
if [[ \$1 =~ .*/\$GitBranch$ ]];
then
    echo "\$GitBranch ref received. Deploying \$GitBranch branch to production..."
    git --work-tree=\$DeployPath --git-dir=\$GitRepository checkout -f -b \$GitBranch
    git --work-tree=\$DeployPath --git-dir=\$GitRepository checkout -f \$GitBranch
    git --work-tree=\$DeployPath --git-dir=\$GitRepository checkout -f
    . \$GitRepository/hooks/customer_shell.sh
else
    echo "Ref \$1 successfully received. Doing nothing: only the master branch may be deployed on this server."
fi
. %s
''' % (data['project_path'],project_git_rep,data['branch'],webhooks_shell_file)

                # 部署脚本
                public.ExecShell('echo "%s" > %s/hooks/post-update && chmod 777 %s/hooks/post-update' % (deploy_shell_default,project_git_rep,project_git_rep))

            # 用户自定义部署脚本变更
            if projectData['deploy_shell'] != data['deploy_shell']:
                deploy_shell_init = '''#!/bin/bash
cd %s
%s
''' % (data['project_path'],data['deploy_shell'].replace('$','\$'))
                # 用户自定义部署脚本
                public.ExecShell('echo "%s" > %s/hooks/customer_shell.sh && chmod 777 %s/hooks/customer_shell.sh' % (deploy_shell_init,project_git_rep,project_git_rep))
                # public.ExecShell('sed -i "s/\r//g" %s/hooks/customer_shell.sh' % (project_git_rep))

            # 排除目录变更
            if projectData['exclude'] != data['exclude']:
                public.ExecShell('echo "/*" > %s/info/sparse-checkout' % (project_git_rep))
                public.ExecShell('echo "%s" >> %s/info/sparse-checkout' % (data['exclude'],project_git_rep))

            return {'code':1,'msg':'操作成功','data':{'id':result}}
        else:
            return {'code':0,'msg':'操作失败'}

    # 删除项目
    def del_project(self,args):
        if not 'id' in args: args.id = 0
        args.id = int(args.id)

        if args.id == 0:
            return {'code':0,'msg':'参数错误'}

        projectData = self.__table('project').where('id = ?',(args.id,)).find()

        result = self.__table('project').delete(args.id)
        if result:

            # 删除项目仓库
            project_git_rep = self.__repositoryPath+'/'+projectData['title']+'.git'
            public.ExecShell('rm -r %s' % (project_git_rep))


            return {'code':1,'msg':'操作成功'}
        else:
            return {'code':0,'msg':'操作失败'}

    # 获取钩子
    def get_webhooks(self,args):
        if not 'id' in args: args.id = 0
        args.id = int(args.id)

        if args.id == 0:
            return {'code':0,'msg':'参数错误'}


        projectData = self.__table('project').where('id = ?',(args.id,)).find()

        if not projectData:
            return {'code':0,'msg':'参数错误'}

        return {
            'code':1,
            'msg':'操作成功',
            'data':{
                'webhooks_url' : projectData['webhooks_url'],
                'webhooks_password' : projectData['webhooks_password'],
                'webhooks_types' : projectData['webhooks_types'],
                'webhooks_status' : projectData['webhooks_status']
            }
        }

    # 更新钩子
    def update_webhooks(self,args):

        if not 'id' in args: args.id = 0
        if not 'webhooks_url' in args: args.webhooks_url = ''
        if not 'webhooks_password' in args: args.webhooks_password = ''
        if not 'webhooks_types' in args: args.webhooks_types = ''
        if not 'webhooks_status' in args: args.webhooks_status = 0
        args.id = int(args.id)
        webhooks_types = args.webhooks_types.split(',')

        result = self.__table('project').where('id = ?',(args.id,)).save('webhooks_url,webhooks_password,webhooks_types,webhooks_status',(args.webhooks_url,args.webhooks_password,args.webhooks_types,args.webhooks_status))

        # 更新hooks
        project = self.__table('project').where('id = ?',(args.id,)).find()
        project_git_rep = self.__repositoryPath+'/'+project['title']+'.git'

        webhooks_shell_file  = '%s/hooks/webhooks' % (project_git_rep)
        webhooks_shell = '''#!/bin/bash
webhooks_status=%s
webhooks_types='%s'
webhooks_url='%s'
webhooks_password='%s'

if [ \${webhooks_status} == 0 ];then
    return
else
    echo 'webhooks start'
fi

hooks=(\${webhooks_types//,/ })
# echo \${hooks[@]}
# echo \${webhooks_types}

# for s in \${hooks[@]}
# do
#     echo \$s
# done

hook=\${0##*/}
if [ \${hook} == 'post-receive' ];then
    if echo \\"\${hooks[@]}\\" | grep -w 'post-receive' &>/dev/null;then
        echo 'post-receive exec'

        zero_commit=\\"0000000000000000000000000000000000000000\\"
        commit_count=0
        excludeExisting=\\"--not\\"
        refnames=\\"\\"
        branch=\$(git branch | grep \\"*\\")
        currentBranch=\${branch:2}
        while read oldrev newrev refname; do
            # branch or tag get deleted
            if [ \\"\$newrev\\" = \\"\$zero_commit\\" ]; then
                continue
            fi

            # Check for new branch or tag
            if [ \\"\$oldrev\\" = \\"\$zero_commit\\" ]; then
                span=\`git rev-list \$newrev \$excludeExisting\`
            else
                span=\`git rev-list \$oldrev..\$newrev \$excludeExisting\`
            fi

            for COMMIT in \${span};
            do
                commit_count=\`expr \$commit_count + 1\`
            done

            author_user=\`git log --format=%%an -n 1 \${newrev}\`
            author_email=\`git log --format=%%ae -n 1 \${newrev}\`
            commit_user=\`git log --format=%%cn -n 1 \${newrev}\`
            commit_email=\`git log --format=%%ce -n 1 \${newrev}\`
            commit_message=\`git log --format=%%s -n 1 \${newrev}\`

            data=\'{\\"webhooks_password\\":\\"'\${webhooks_password}'\\",\\"hook\\":\\"post-receive\\",\\"branch\\":\\"'\${refname##*/}'\\",\\"author_user\\":\\"'\${author_user}'\\",\\"author_email\\":\\"'\${author_email}'\\",\\"commit_user\\":\\"'\${commit_user}'\\",\\"commit_email\\":\\"'\${commit_email}'\\",\\"commit_message\\":\\"'\${commit_message}'\\",\\"commit_count\\":\\"'\${commit_count}'\\"}\'

            curl -s -X POST -H \'Content-type:application/json\' -d \${data} \\"\$webhooks_url\\"
            echo -e \\"\\n\\"
        done

    fi
elif [ \${hook} == 'post-update' ];then
    if echo \\"\${hooks[@]}\\" | grep -w 'post-update' &>/dev/null;then
        if [ \$GitBranch == \${1##*/} ]; then
            echo 'post-update exec'
            cd \$GitRepository
            newrev=\`git rev-parse HEAD\`
            author_user=\`git log --format=%%an -n 1 \${newrev}\`
            author_email=\`git log --format=%%ae -n 1 \${newrev}\`
            commit_user=\`git log --format=%%cn -n 1 \${newrev}\`
            commit_email=\`git log --format=%%ce -n 1 \${newrev}\`
            commit_message=\`git log --format=%%s -n 1 \${newrev}\`

            data=\'{\\"webhooks_password\\":\\"'\${webhooks_password}'\\",\\"hook\\":\\"post-update\\",\\"branch\\":\\"'\${1##*/}'\\",\\"DeployPath\\":\\"'\${DeployPath}'\\",\\"author_user\\":\\"'\${author_user}'\\",\\"author_email\\":\\"'\${author_email}'\\",\\"commit_user\\":\\"'\${commit_user}'\\",\\"commit_email\\":\\"'\${commit_email}'\\",\\"commit_message\\":\\"'\${commit_message}'\\"}\'
            curl -s -X POST -H \'Content-type:application/json\' -d \${data} \\"\$webhooks_url\\"
            echo -e \\"\\n\\"
        fi
    fi
fi

''' % (args.webhooks_status,args.webhooks_types,args.webhooks_url,args.webhooks_password)
        public.ExecShell('echo "%s" > %s && chmod 777 %s' % (webhooks_shell,webhooks_shell_file,webhooks_shell_file))

        for hook_title in webhooks_types:
            hook_file = '%s/hooks/%s' % (project_git_rep,hook_title)
            if not os.path.exists(hook_file):
                hook_shell = '''#!/bin/bash
. %s
''' % (webhooks_shell_file)
                public.ExecShell('echo "%s" > %s && chmod 777 %s' % (hook_shell,hook_file,hook_file))
            else:
                hook_shell_old = public.ExecShell('grep -rn "%s" %s' % (webhooks_shell_file,hook_file))
                if hook_shell_old[0] == '':
                    hook_shell = '. %s' % (webhooks_shell_file)
                    public.ExecShell('echo "%s" >> %s && chmod 777 %s' % (hook_shell,hook_file,hook_file))


        return {
            'code':1,
            'msg':'操作成功'
        }

    # 获取公钥SHA256指纹
    def __getSSHFingerprint(self,sshPublicKey):
        import hashlib
        import base64
        b64pubkey = sshPublicKey[7:]
        missing_padding = 4 - len(b64pubkey) % 4
        if missing_padding:
            b64pubkey += '=' * missing_padding
        sha256 = hashlib.sha256()
        sha256.update(base64.urlsafe_b64decode(b64pubkey))
        return base64.urlsafe_b64encode(sha256.digest()).decode('utf-8').strip('=')

    # 获取公钥列表
    def get_sshkeys(self,args):

        if not os.path.exists(self.__db_path) or os.path.getsize(self.__db_path) == 0:
            # 初始化数据库
            import db
            sql = db.Sql().dbfile('git_deploy')
            # print(sql)
            result = sql.fofile(self.__plugin_path+'default.sql')
            # print(result)

        if not 'p' in args: args.p = 1
        if not 'rows' in args: args.rows = 10
        if not 'title' in args: args.title = ''
        args.p = int(args.p)
        args.rows = int(args.rows)
        args.title = public.checkInput(args.title)
        #取网站数量
        count = self.__table('sshkeys')
        if args.title != '':
            count = count.where('title like ?','%'+args.title+'%')
        count = count.count()

        #取分页数据
        page_data = public.get_page(count,p=args.p,rows=args.rows,callback='git_deploy.get_sshkeys',result='1,2,3,4,5,8')
        #通过 page_data['shift'],page_data['ros']获取数据列表
        site_list = self.__table('sshkeys').order('id desc')
        if args.title != '':
            site_list = site_list.where('title like ?','%'+args.title+'%')
        site_list = site_list.limit(page_data['shift']+','+page_data['row']).field('id,title,info,key,add_time,update_time').select()

        if isinstance(site_list,str):
            return {'code':0,'msg':'系统错误'}
        
        for index,site in enumerate(site_list):
            site['key_finger_print'] = 'SHA256:'+self.__getSSHFingerprint(site['key'])
            site_list[index] = site

        #构造返回字典
        data = {'data':site_list,'page':page_data['page'],'title':args.title}
        return {
            "code":1,
            "msg":"操作成功",
            "total":count,
            "data":data
        }

    # 添加公钥
    def add_sshkeys(self,args):
        if not 'title' in args: args.title = ''
        if not 'info' in args: args.info = ''
        if not 'key' in args: args.key = ''
        args.key = args.key.replace('\r','').replace('\n','')

        if not all([args.title,args.key]):
            return {'code':0,'msg':'参数错误'}

        sshkeysData = self.__table('sshkeys').where('key=?',(args.key,)).find()
        if sshkeysData:
            return {'code':0,'msg':'该公钥已存在'}

        now_time = int(time.time())
        data = {
            'title' : args.title,
            'info' : args.info,
            'key' : args.key,
            'add_time' : now_time,
            'update_time' : now_time
        }

        result = self.__table('sshkeys').insert(data)
        if isinstance(result,int):

            import re
            result = public.ExecShell('cat %s/.ssh/authorized_keys|grep \'^%s\'' % (self.__git_home,args.key))
            if result[0] == '':
                public.ExecShell('echo "%s" >> %s/.ssh/authorized_keys' % (args.key,self.__git_home))

            return {'code':1,'msg':'操作成功','data':{'id':result}}
        else:
            return {'code':0,'msg':'操作失败'}

    # 编辑公钥
    def edit_sshkeys(self,args):
        if not 'id' in args: args.id = 0
        if not 'title' in args: args.title = ''
        if not 'info' in args: args.info = ''
        if not 'key' in args: args.key = ''
        args.id = int(args.id)
        args.key = args.key.replace('\r','').replace('\n','')

        if not all([args.title,args.key]):
            return {'code':0,'msg':'参数错误'}

        now_time = int(time.time())
        data = {
            'title' : args.title,
            'info' : args.info,
            'key' : args.key,
            'update_time' : now_time
        }


        keyData = self.__table('sshkeys').where('id=?',(args.id,)).find()

        result = self.__table('sshkeys').where('id = ?',(args.id,)).update(data)
        if result:

            if keyData['key'] != args.key:
                import re
                result = public.ExecShell('cat %s/.ssh/authorized_keys|grep \'^%s\'' % (self.__git_home,keyData['key']))
                if result[0] != '':
                    public.ExecShell('sed -i "/%s/d" %s/.ssh/authorized_keys' % (keyData['key'].strip().replace('/','\/'),self.__git_home))
                    public.ExecShell('echo "%s" >> %s/.ssh/authorized_keys' % (args.key,self.__git_home))

            return {'code':1,'msg':'操作成功','data':{'id':result}}
        else:
            return {'code':0,'msg':'操作失败'}

    # 删除公钥
    def del_sshkeys(self,args):
        if not 'id' in args: args.id = 0
        args.id = int(args.id)

        if args.id == 0:
            return {'code':0,'msg':'参数错误'}

        keyData = self.__table('sshkeys').where('id=?',(args.id,)).find()

        result = self.__table('sshkeys').delete(args.id)

        if result:

            import re
            result = public.ExecShell('cat %s/.ssh/authorized_keys|grep \'^%s\'' % (self.__git_home,keyData['key']))
            if result[0] != '':
                public.ExecShell('sed -i "/%s/d" %s/.ssh/authorized_keys' % (keyData['key'].strip().replace('/','\/'),self.__git_home))

            return {'code':1,'msg':'操作成功'}
        else:
            return {'code':0,'msg':'操作失败'}

    # 修复插件
    def get_fix(self,args):
        self.install()
        return {"code":1,"msg":"修复完成"}

    # 获取服务器信息
    def __get_serverid(self):
        import panelAuth
        auth = panelAuth.panelAuth()
        return auth.create_serverid({})

    # 获取插件购买状态
    def __get_payinfo(self):
        import panelPlugin
        plugin = panelPlugin.panelPlugin()
        state = plugin.getEndDate('git_deploy')
        if state in ['未开通','待支付','已到期']:
            return False
        else:
            return True


    #读取配置项(插件自身的配置文件)
    #@param key 取指定配置项，若不传则取所有配置[可选]
    #@param force 强制从文件重新读取配置项[可选]
    def __get_config(self,key=None,force=False):
        #判断是否从文件读取配置
        if not self.__config or force:
            config_file = self.__plugin_path + 'config.json'
            if not os.path.exists(config_file):
                default = {}
                public.writeFile(config_file,json.dumps(default))
            if not os.path.exists(config_file): return None
            f_body = public.ReadFile(config_file)
            if not f_body: return None
            self.__config = json.loads(f_body)

        #取指定配置项
        if key:
            if key in self.__config: return self.__config[key]
            return None
        return self.__config

    #设置配置项(插件自身的配置文件)
    #@param key 要被修改或添加的配置项[可选]
    #@param value 配置值[可选]
    def __set_config(self,key=None,value=None):
        #是否需要初始化配置项
        if not self.__config: self.__config = {}

        #是否需要设置配置值
        if key:
            self.__config[key] = value

        #写入到配置文件
        config_file = self.__plugin_path + 'config.json'
        public.WriteFile(config_file,json.dumps(self.__config))
        return True

    # 获取平台版本
    def __get_platform(self):
        os_type_text = ''
        aptInstalled = public.ExecShell('command -v apt')
        if aptInstalled[0] != '':
            os_type_text = 'Ubuntu'

        yumInstalled = public.ExecShell('command -v yum')
        if yumInstalled[0] != '':
            os_type_text = 'CentOS'

        return os_type_text

    # 【命令行】 - 安装插件
    def install(self):
        print('开始安装插件')
        shell = '/usr/bin/git-shell'

        shellInstalled = public.ExecShell('command -v git')
        if shellInstalled[0] == '':
            print('未检测到Git，开始安装Git...')
            platform = self.__get_platform()
            if platform == 'CentOS':
                public.ExecShell('yum install git -y')
            elif platform == 'Ubuntu':
                public.ExecShell('apt install git -y')
            print('Git安装完成')

        print('配置用户信息')
        import re
        result = public.ExecShell('cat /etc/passwd|grep "^www:"')
        if result[0] != '':
            # print(result)
            userinfo = result[0].strip().split(':')
            # print(userinfo[5])
            # print(userinfo[6])
            if userinfo[6] != shell or userinfo[5] != self.__git_home:
                userinfo[5] = self.__git_home
                userinfo[6] = shell
                userinfo = ':'.join(userinfo)
                # print(userinfo)
                # print(result[0].strip())
                # print('sed -i "s/%s/%s/g" /etc/passwd' % (result[0].strip().replace('/','\/'),userinfo.replace('/','\/')))
                userResult = public.ExecShell('sed -i "s/%s/%s/g" /etc/passwd' % (result[0].strip().replace('/','\/'),userinfo.replace('/','\/')))
                print(userResult)
        else:
            result = public.ExecShell('useradd www -m -s /usr/bin/git-shell')
            print(result)

        print('配置目录及权限')
        public.ExecShell('chown -R www:www %s' % (self.__git_home))
        public.ExecShell('chmod 700 %s' % (self.__git_home))
        public.ExecShell('mkdir -p %s/.ssh' % (self.__git_home))
        public.ExecShell('chmod 700 %s/.ssh' % (self.__git_home))
        public.ExecShell('touch %s/.ssh/authorized_keys' % (self.__git_home))
        public.ExecShell('chmod 600 %s/.ssh/authorized_keys' % (self.__git_home))
        public.ExecShell('chown -R www:www %s/.ssh' % (self.__git_home))

        print('配置数据库信息')
        if not os.path.exists(self.__db_path) or os.path.getsize(self.__db_path) == 0:
            print('初始化数据库')
            # 初始化数据库
            import db
            sql = db.Sql().dbfile('git_deploy')
            # print(sql)
            result = sql.fofile(self.__plugin_path+'default.sql')
            print(result)
        else:
            print('更新数据库信息')
            create_sql = self.__table('sqlite_master').where('type = ? and name = ?',('table','project')).field('sql').find()
            # print(create_sql['sql'])
            if not 'webhooks_url' in create_sql['sql']:
                self.__table('project').execute('alter table project add "webhooks_url" TEXT')
                self.__table('project').execute('alter table project add "webhooks_password" TEXT')
                self.__table('project').execute('alter table project add "webhooks_types" TEXT')
                self.__table('project').execute('alter table project add "webhooks_status" INTEGER DEFAULT 0')
        print('插件安装完成')

    # 【命令行】 - 卸载插件
    def uninstall(self):
        nologin = '/sbin/nologin'
        import re
        result = public.ExecShell('cat /etc/passwd|grep "^www:"')
        if result[0] != '':
            print(result)
            userinfo = result[0].strip().split(':')
            # print(userinfo[5])
            # print(userinfo[6])
            if userinfo[6] != nologin:
                userinfo[6] = nologin
                userinfo = ':'.join(userinfo)
                # print(userinfo)
                # print(result[0].strip())
                # print('sed -i "s/%s/%s/g" /etc/passwd' % (result[0].strip().replace('/','\/'),userinfo.replace('/','\/')))
                userResult = public.ExecShell('sed -i "s/%s/%s/g" /etc/passwd' % (result[0].strip().replace('/','\/'),userinfo.replace('/','\/')))
                print(userResult)

        # 删除仓库
        projectDatas = self.__table('project').field('title').select()
        for projectData in projectDatas:
            project_git_rep = self.__repositoryPath+'/'+projectData['title']+'.git'
            public.ExecShell('rm -r %s' % (project_git_rep))

        # 删除公钥
        sshkeys = self.__table('sshkeys').field('key').select()
        for sshkey in sshkeys:
            public.ExecShell('sed -i "/%s/d" %s/.ssh/authorized_keys' % (sshkey['key'].strip().replace('/','\/'),self.__git_home))

        # 删除数据库文件 
        if os.path.exists(self.__db_path):
            os.remove(self.__db_path)

#在命令行模式下执行
if __name__ == "__main__":

    g = git_deploy_main()
    type = sys.argv[1]

    if type == 'install':
        g.install()
        exit()
    elif type == 'uninstall':
        g.uninstall()
        exit()
