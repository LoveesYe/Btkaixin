#!/bin/bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH

#配置插件安装目录
install_path=/www/server/panel/plugin/btgogs
install_path_tmp=$install_path'/tmp'
core_path=/www/server/btgogs

#安装
Install() {
  echo '正在安装...'
  #==================================================================
  Is_64bit=$(getconf LONG_BIT)
  #获取操作系统是否64位
  mkdir -p ${install_path}
  mkdir -p ${core_path}
  #设置权限
  chmod +x ${install_path}/operation.sh
  chmod +x ${install_path}/btgogservice
  ln -sf ${install_path}/btgogservice /etc/init.d/btgogservice
  chmod +x /etc/init.d/btgogservice

  #生成备案号木板文件
  if [ ! -f ${install_path}/custom/templates/base/keep_on_record.tmpl ]; then
    #如果有备份文件则复制备份文件，如果没有则新建立
    touch ${install_path}/custom/templates/base/keep_on_record.tmpl
    cat >${install_path}/custom/templates/base/keep_on_record.tmpl <<EOF
浙ICP备xxxx号-x
EOF

  fi

  Is_64bit=$(getconf LONG_BIT)
  pkg_x64_name='gogs-1.9-linux-amd64'
  pkg_x86_name='gogs-1.9-linux-386'
  #获取操作系统是否64位
  mkdir -p ${install_path_tmp}

  #判断资源文件夹是否存在如果存在则直接创建软连接 如果不存在复制默认资源到指定目录
  #2.安装依赖
  if [ "${PM}" == "yum" ] || [ "${PM}" == "dnf" ]; then
    su - root <<EOF
if hash git > /dev/null 2>&1 ; then 
	echo 'you have git ' >/dev/null 2>&1
else 
	yum -y install git
fi
if hash pip 2>/dev/null; then
	pip install ConfigParser
fi
if hash pip3 2>/dev/null; then
	pip3 install configparser
fi
if hash unzip > /dev/null 2>&1 ; then 
	echo 'you have zip/unzip ' >/dev/null 2>&1
else 
	yum install -y unzip zip
fi
EOF
  elif [ "${PM}" == "apt" ]; then
    if hash git >/dev/null 2>&1; then
      echo 'you have git ' >/dev/null 2>&1
    else
      sudo apt-get -y install git
    fi

    if hash pip >/dev/null 2>&1; then
      sudo pip install ConfigParser
    fi
    if hash pip3 >/dev/null 2>&1; then
      sudo pip3 install configparser
    fi
    if hash unzip >/dev/null 2>&1; then
      echo 'you have zip/unzip ' >/dev/null 2>&1
    else
      sudo apt-get install -y unzip zip
    fi
  fi

  #依赖安装结束

  if [ -f "${install_path_tmp}/gogs" ]; then
    ln -sf ${install_path}/gogs /usr/bin/gogs
  fi

  #执行释放命令
  # core_path

  if [ "${PM}" == "yum" ] || [ "${PM}" == "dnf" ]; then
    su - root <<EOF
unzip ${install_path}/core.zip -d ${core_path} -x "*.bat"
EOF
  elif [ "${PM}" == "apt" ]; then
    sudo unzip ${install_path}/core.zip -d ${core_path} -x "*.bat"
  fi

  #==================================================================
  #service gogsser start
  # /etc/init.d/btgogservice start
  if [ "${PM}" == "yum" ] || [ "${PM}" == "dnf" ]; then
    /etc/init.d/btgogservice start
  elif [ "${PM}" == "apt" ]; then
    sudo /etc/init.d/btgogservice start
  fi

  echo '================================================'
  echo '安装完成'

  #添加系统服务
  Service_Add

}

#卸载
Uninstall() {
  data_time=$(date "+%Y%m%d%H%M%S")
  cp ${install_path}/custom/conf/app.ini /www/backup/gogs/app_${data_time}.ini

  if [ "${PM}" == "yum" ] || [ "${PM}" == "dnf" ]; then

    su - root <<EOF
/etc/init.d/btgogservice stop >/dev/null 2>&1
rm -rf /etc/init.d/btgogservice
rm -rf $install_path
EOF
  elif [ "${PM}" == "apt" ]; then
    sudo /etc/init.d/btgogservice stop
    sudo rm -rf /etc/init.d/btgogservice
    sudo rm -rf $install_path
  fi
  Service_Del

}

#判断系统发行版本
Get_Dist_Name() {
  if grep -Eqii "CentOS" /etc/issue || grep -Eq "CentOS" /etc/*-release; then
    DISTRO='CentOS'
    PM='yum'
  elif grep -Eqi "Red Hat Enterprise Linux Server" /etc/issue || grep -Eq "Red Hat Enterprise Linux Server" /etc/*-release; then
    DISTRO='RHEL'
    PM='yum'
  elif grep -Eqi "Aliyun" /etc/issue || grep -Eq "Aliyun" /etc/*-release; then
    DISTRO='Aliyun'
    PM='yum'
  elif grep -Eqi "Fedora" /etc/issue || grep -Eq "Fedora" /etc/*-release; then
    DISTRO='Fedora'
    PM='yum'
  elif grep -Eqi "Debian" /etc/issue || grep -Eq "Debian" /etc/*-release; then
    DISTRO='Debian'
    PM='apt'
  elif grep -Eqi "Ubuntu" /etc/issue || grep -Eq "Ubuntu" /etc/*-release; then
    DISTRO='Ubuntu'
    PM='apt'
  elif grep -Eqi "Raspbian" /etc/issue || grep -Eq "Raspbian" /etc/*-release; then
    DISTRO='Raspbian'
    PM='apt'
  else
    DISTRO='unknow'
  fi
  echo $DISTRO
  echo $PM
}

#添加系统服务
Service_Add() {
  echo ${PM}
  if [ "${PM}" == "yum" ] || [ "${PM}" == "dnf" ]; then
    chkconfig --add btgogservice
    chkconfig --level 2345 btgogservice on

  elif [ "${PM}" == "apt" ]; then
    update-rc.d btgogservice defaults
  fi
}
#删除系统服务
Service_Del() {
  if [ "${PM}" == "yum" ] || [ "${PM}" == "dnf" ]; then
    chkconfig --del btgogservice
    chkconfig --level 2345 btgogservice off
  elif [ "${PM}" == "apt" ]; then
    update-rc.d btgogservice remove
  fi
}

Get_Dist_Name
#操作判断
if [ "${1}" == 'install' ]; then
  Install
elif [ "${1}" == 'uninstall' ]; then
  Uninstall
else
  echo 'Error!'
fi
