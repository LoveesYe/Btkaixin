import sys,os,shutil
panelPath = os.getenv('BT_PANEL')
os.chdir(panelPath)
sys.path.append("class/")
import public,json

__name = 'btgogs'
__path = panelPath + '/plugin/' + __name

def install():  
    # if not os.path.exists(__path+'/tmps'): os.makedirs(__path+'/tmps')


def update():
    install()

def uninstall():
    shutil.rmtree(__path)

def Schedule(a,b,c):
    '''
    a:已经下载的数据块
    b:数据块的大小
    c:远程文件的大小
    '''
    per = 100.0*a*b/c
    if per > 100:
        per = 100
    print( '%.2f%%' % per )

def autoinstallgit():
    import urllib
    print("downloading with urllib")
    url0 = "https://npm.taobao.org/mirrors/git-for-windows/2.10.0.windows.1/Git-2.10.0-64-bit.exe"
    file = "lecture.exe"
    print("downloading with " + file)
    LocalPath = os.path.join(__path+"/tmps/",file)
    #如果路径已存在则先删除
    #os.remove(LocalPath) 
    #os.path.join将多个路径组合后返回
    urllib.request.urlretrieve(url0,LocalPath,Schedule)
    #第一个参数url:需要下载的网络资源的URL地址
    #第二个参数LocalPath:文件下载到本地后的路径



if __name__ == "__main__":
    opt = sys.argv[1]
    if opt == 'update':
        update()
    elif opt == 'uninstall':
        uninstall()
    else:
        install()
