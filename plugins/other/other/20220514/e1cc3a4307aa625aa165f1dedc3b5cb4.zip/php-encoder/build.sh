#!/bin/bash
DIR=/www/server/php
CUR=$(cd "$(dirname "$0")"; pwd)
rm -f ./modules/*
allow_version=(52 53  54  55  56  70  71  72  73  74 80)

makeso()
{
    ver=$1
    if [[ "${allow_version[@]}" =~ "${ver}" ]]; then
      rm -f *.la
      rm -f *.lo
      rm -f *.so
      A="./configure --with-php-config=$DIR/$ver/bin/php-config --prefix=$CUR/modules/$ver/"
      B="mv ./modules/php_encoder.so ./modules/php_encoder$ver.so"
    #   echo $A
    #   echo $B
      $A
      make DESTDIR="modules/$ver"
      $B
      rm -f ./modules/php_encoder.la
      rm -f ./Makefile
      fi
}

makeall(){
    for i in $(ls $DIR)
    do   
        makeso "$i"
    done
    # ls ./modules/
}
if [ "${1}" == '' ];then
    makeall
elif  [[ "${allow_version[@]}" =~ "${1}" ]];then
    makeso "${1}"
else
    echo "error!"
fi

