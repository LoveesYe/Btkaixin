<?php

// Start of big_int v.1.0.7

function bi_from_str () {}

function bi_to_str () {}

function bi_base_convert () {}

function bi_add () {}

function bi_sub () {}

function bi_mul () {}

function bi_div () {}

function bi_mod () {}

function bi_cmp () {}

function bi_cmp_abs () {}

function bi_or () {}

function bi_xor () {}

function bi_and () {}

function bi_andnot () {}

function bi_is_zero () {}

function bi_is_one () {}

function bi_abs () {}

function bi_neg () {}

function bi_inc () {}

function bi_dec () {}

function bi_sqr () {}

function bi_sqrt () {}

function bi_sqrt_rem () {}

function bi_muladd () {}

function bi_bit_len () {}

function bi_bit1_cnt () {}

function bi_addmod () {}

function bi_submod () {}

function bi_mulmod () {}

function bi_divmod () {}

function bi_powmod () {}

function bi_factmod () {}

function bi_absmod () {}

function bi_invmod () {}

function bi_sqrmod () {}

function bi_gcd () {}

function bi_next_prime () {}

function bi_div_extended () {}

function bi_sign () {}

function bi_rand () {}

function bi_lshift () {}

function bi_rshift () {}

function bi_set_bit () {}

function bi_clr_bit () {}

function bi_inv_bit () {}

function bi_test_bit () {}

function bi_scan0_bit () {}

function bi_scan1_bit () {}

function bi_hamming_distance () {}

function bi_subint () {}

function bi_cmpmod () {}

function bi_miller_test () {}

function bi_is_prime () {}

function bi_jacobi () {}

function bi_fact () {}

function bi_pow () {}

function bi_serialize () {}

function bi_unserialize () {}

function bi_gcd_extended () {}

function bi_info () {}

// End of big_int v.1.0.7
