#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdarg.h>
#include <dirent.h>
#include <unistd.h>
#include <memory.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "../core.c"
long file_count = 0, success_file_count = 0, fail_file_count = 0, ignore_file_count = 0, isCrypted_file_count = 0, notisCrypted_file_count = 0;
void code_encrypt(char *file);
void code_decrypt(char *file);
void domark(char *file);
void scanRoot(char *path);
void code_work(char *file);
int isPHP(char *filename);

int notencode_file = 0; //排除不加密文件
int checkencode = 0;    //检测是否加密
int encode = 1;         //是加密还是解密
int nocolor = 0;        //不显示输出颜色
void errMsg(char *str, char *str2)
{
  if (nocolor == 1)
  {
    printf("%s%s\n", str, str2);
  }
  else
  {
    printf("\033[40;31m%s%s\033[0m\n", str, str2);
  }
}
void warnMsg(char *str, char *str2)
{
  if (nocolor == 1)
  {
    printf("%s%s\n", str, str2);
  }
  else
  {
    printf("\033[43;31m%s%s\033[0m\n", str, str2);
  }
}

void alertMsg(char *str, char *str2)
{
  if (nocolor == 1)
  {
    printf("%s%s \n", str, str2);
  }
  else
  {
    printf("\033[1;32m%s%s\033[0m\n", str, str2);
  }
}


void main(int argc, char **argv)
{

  DIR *hP;
  FILE *fp;
  char *path;
  char suf[1];
  encode = 1;
  // encode_key_mode=STR2(ENCODE_KEY_MODE);
  // encode_mode = STR2(ENCODE_MODE);
  int i;
  for (i = 1; i < argc; i++)
  {

    if (strncmp(argv[i], "-f", 2) == 0)
    {
      path = argv[i + 1];
      if (!isPHP(path) && path[strlen(path) - 1] != '/')
      {
        strcat(path, "/");
      }
    }
    //密钥
    else if (strncmp(argv[i], "-p", 2) == 0)
    {
      SafeKey = argv[i + 1];
    }
    //是否解密
    else if (strncmp(argv[i], "-d", 2) == 0)
    {
      encode = 0;
    }
    //特征密钥长度
    else if (strncmp(argv[i], "-n", 2) == 0)
    {
      keylen = atoi(argv[i + 1]);
      if (keylen > 128)
      {
        keylen = 128;
      }
      if (keylen < 8)
      {
        keylen = 8;
      }
    }
    //不输带颜色信息
    else if (strncmp(argv[i], "-c", 2) == 0)
    {
      nocolor = 1;
    }
    //忽略目录和文件
    else if (strncmp(argv[i], "-I", 2) == 0)
    {
      notencode_file = 1;
    }
    //加密方式 md5/sha1/sha256
    else if (strncmp(argv[i], "-e", 2) == 0)
    {
      encode_mode = argv[i + 1];
    }
    //检测是否加密
    else if (strncmp(argv[i], "-k", 2) == 0)
    {
      checkencode = 1;
    }
    //无特征模式
    else if (strncmp(argv[i], "-w", 2) == 0)
    {
      encode_key_mode = 1;
    }
    //检测是否加密
    else if (strncmp(argv[i], "-ak", 3) == 0)
    {
      checkencode = 2;
    }
    //检测是否加密
    else if (strncmp(argv[i], "-b", 2) == 0)
    {
      DEBUG = 1;
    }
    else if (strncmp(argv[i], "-?", 2) == 0)
    {
      printf("%s 参数:  \n\t -f [文件名或目录]  \n\t -n [密钥长度]  \n\t -p [密钥]  \n\t -e sha1/sha256/md5 \n\t -d  解密 \n\t -c 不显示颜色\n\n", argv[0]);
      exit(1);
    }
    else
    {
      //  if(DEBUG) printf("ARGV[%d]:[%s]\n",i,argv[i]);
    }
  }

  if (argc < 2)
  {
    errMsg("please input a valid path", " ");
    exit(1);
  }

  _key = encodekey(SafeKey);
  if (DEBUG)
  {
    printf("\nNOTENCODE_FILE:%d\n", notencode_file);
    printf("ENCODE_MODE:%s\n", encode_mode);
    printf("KEYLEN:%d\n", keylen);
    printf("ENCODE:%d\n", encode);
    printf("SafeKey:%s\n", SafeKey);
    printf("KEY:%s\n", _key);
    printf("NOCOLOR:%d\n", nocolor);
    printf("PATH:%s\n", path);
  }else{
    printf("ENCODE:%d\n",encode);
    printf("KEYLEN:%d\n", keylen);
    printf("SafeKey:%s\n",SafeKey);
    // printf("KEY:%s\n",_key);
    printf("PATH:%s\n",path);
  }
  // 排除要加密的文件
  if (notencode_file)
  {
    char nofile[100];
    sprintf(nofile, "%s.noencode", path);
    nofiles = readtext(nofile);
  }

  hP = opendir(path);
  if (hP == NULL)
  {
    fp = fopen(path, "r");
    if (fp == NULL)
    {
      errMsg(path, " is not a valid path ");
      // exit(1);
      return;
    }
    else
    {
      code_work(path);
    }
    fclose(fp);
    fflush(fp);
  }
  closedir(hP);
  scanRoot(path);
  if (checkencode >= 1)
  {
    printf("File Count:%d\nCrypted:%d\nNo Crypted:%d\n", file_count, isCrypted_file_count, notisCrypted_file_count);
  }
  else
  {
    printf("File Count:%d\n%s File Count:%d\nFail Count:%d\nIngore File Count:%d\n", file_count, encode ? "Crypted" : "Decrypted", success_file_count, fail_file_count, ignore_file_count);
  }
}

int isnotencode(char *_path)
{
  char *file;
  int i;
  for (i = 0; i < nofiles.size; i++)
  {
    file = nofiles.item[i];
    // printf("nofiles.item[%d]:%s \nfile:%s \nCMP:%s\n", i, file,_path,strstr(_path,file));
    if (strstr(_path, file) != NULL && file != "")
    {
      // return encode ? 1 : 0;
      return 1;
    }
  }
  return 0;
}

void scanRoot(char *path)
{
  struct dirent *dir = NULL;
  DIR *hP;
  // FILE *fp;
  int i;
  int l = 0;
  hP = opendir(path);
  struct stat stat_buf;
  if (hP == NULL)
    return;

  while (NULL != (dir = readdir(hP)))
  {
    if (strncmp(dir->d_name, ".", 1) == 0 || strncmp(dir->d_name, "..", 2) == 0)
      continue;
    l = strlen(path) + strlen(dir->d_name);
    char curPath[l + 1];
    memset(curPath, 0, sizeof(curPath));
    strcat(curPath, path);
    strcat(curPath, dir->d_name);
    stat(curPath, &stat_buf);
    if (DEBUG)
    {
      printf("PATH:%s\n", curPath);
    }
    if (isnotencode(curPath))
    {
      if (isPHP(dir->d_name))
      {
        ignore_file_count++;
        domark(curPath);
        errMsg("ingore this path:", curPath);
        file_count++; // php文件总数统计
        notisCrypted_file_count++;
      }
      continue;
    }

    // if it is a folder
    if (S_ISDIR(stat_buf.st_mode))
    {
      if (curPath[l - 1] != '/')
        strcat(curPath, "/");
      scanRoot(curPath);
    }
    else if (isPHP(dir->d_name))
    {
      code_work(curPath);
      file_count++; // php文件总数统计
    }
  }
}

int isPHP(char *filename)
{
  int i;
  char tmpS[5];
  memset(tmpS, 0, sizeof(tmpS));
  for (i = 0; i < strlen(filename); i++)
    if (i >= strlen(filename) - 4)
      tmpS[i - strlen(filename) + 4] = filename[i];
  tmpS[4] = '\0';
  return strncmp(tmpS, ".php", 4) == 0 ? 1 : 0;
}

void code_work(char *file)
{

  if (encode)
  {
    code_encrypt(file);
  }
  else
  {
    code_decrypt(file);
  }

  //   printf("encodekey:%s\n",encodekey(SafeKey));
}

void domark(char *file)
{
  if (!DOMARK)
    return;
  FILE *fp;
  struct stat stat_buf;
  char *datap;
  int len = keylen * 2;
  char lenBuf[keylen];
  int i, datalen;
  uint8_t enTag[keylen];
  fp = fopen(file, "rb");
  if (fp == NULL)
  {
    fail_file_count++;
    errMsg("File  not  found - ", file);
    perror("error");
    // exit(0);
    return;
  };

  memset(key, 0, sizeof(key));
  memcpy(key, _key, len);
  memcpy(enTag, key, keylen);
  memset(lenBuf, 0, keylen);

  if (DEBUG)
  {
    printf("\nkey:%s,SafeKey:%s,enTag:%s,_key:%s\n", key, SafeKey, enTag, _key);
  }

  fstat(fileno(fp), &stat_buf);
  datalen = stat_buf.st_size;
  datap = (char *)malloc(maxBytes);
  memset(datap, 0, sizeof(datap));
  fread(datap, datalen, 1, fp);
  fclose(fp);
  fflush(fp);

  char out[maxBytes];
  sprintf(out, "%s%s", getmark(), datap);
  // printf("\nkey:%s,SafeKey:%s,enTag:%s,_key:%s\n", key, SafeKey, enTag, _key);
  // printf("%s\n---%d---%d----%d\n", "", datalen, strlen(datap), strlen(out));
  // printf("%s\n",out);
  int pos = strpos(datap, mark);

  if (pos >= 0 && encode)
  {
    warnMsg("is Marked Ingore - ", file);
    return;
  }
  else if (pos >= 0)
  {
    substr(datap, strlen(mark), strlen(datap) - strlen(mark), out);
  }
  else if (pos < 0 && encode == 0)
  {
    return;
  }
  //  printf("datapos:%d\n",pos);
  fp = fopen(file, "wb");
  fwrite(out, strlen(out), 1, fp);
  fclose(fp);
  alertMsg("Success Marked Ingore - ", file);
}
// 解密
void code_decrypt(char *file)
{
  FILE *fp;
  struct stat stat_buf;
  char *datap;
  int len = keylen * 2;
  char lenBuf[keylen];
  int i, datalen;
  uint8_t enTag[keylen];
  fp = fopen(file, "rb");
  if (fp == NULL)
  {
    fail_file_count++;
    errMsg("File  not  found - ", file);
    perror("error");
    // exit(0);
    return;
  };

  memset(key, 0, sizeof(key));
  memcpy(key, _key, len);
  memcpy(enTag, key, keylen);
  memset(lenBuf, 0, keylen);

  if (DEBUG)
  {
    printf("\nkey:%s,SafeKey:%s,enTag:%s,_key:%s\n", key, SafeKey, enTag, _key);
  }
  fstat(fileno(fp), &stat_buf);
  datalen = stat_buf.st_size;
  datap = (char *)malloc(datalen);
  memset(datap, 0, sizeof(datap));
  fread(datap, datalen, 1, fp);
  fclose(fp);
  fflush(fp);

  if (memcmp(datap, enTag, keylen) == 0)
  {
    for (i = keylen; i < datalen; i++)
    {
      if (i < len)
        lenBuf[i - keylen] = datap[i];
      else
        datap[i - len] = datap[i];
    }
    code_aes(0, datap, datalen, key, &datalen);
    datalen = atoi(lenBuf);

    fp = fopen(file, "w+");
    fwrite(datap, datalen, 1, fp);
    fclose(fp);

    //  printf("datalen:%d key:%s  \n\n",datalen,key);
    success_file_count++;
    alertMsg("Success Decrypting - ", file);
  }
  else
  {
    fail_file_count++;
    errMsg("Not a valid crypted file.", file);
  }
  free(datap);
}

// 加密
void code_encrypt(char *file)
{
  int len = keylen * 2;
  FILE *fp;
  struct stat stat_buf;
  char *datap;
  int datalen;
  char oldfilename[keylen];
  char *prepare;
  char lenBuf[keylen];
  int i;
  uint8_t enTag[keylen];

  memset(key, 0, sizeof(key));
  memcpy(key, _key, len);
  memcpy(enTag, key, keylen);
  memset(lenBuf, 0, keylen);
  if (DEBUG)
  {
    printf("\nkey:%s,SafeKey:%s,enTag:%s,_key:%s\n", key, SafeKey, enTag, _key);
  }

  fp = fopen(file, "rb");
  if (fp == NULL)
  {
    fail_file_count++;
    errMsg("File  not  found - ", file);
    perror("error");
    // exit(0);
    return;
  }

  fstat(fileno(fp), &stat_buf);
  datalen = stat_buf.st_size;
  datap = (char *)malloc(maxBytes);
  memset(datap, 0, sizeof(datap));
  fread(datap, datalen, 1, fp);
  fclose(fp);
  fflush(fp);

  //   printf("datap:%s,datalen:%d key:%s enTag:%s \n\n",datap,datalen,key,enTag);
  sprintf(lenBuf, "%d", datalen);

  int isCrypted = (memcmp(datap, enTag, keylen) == 0);

  if (checkencode >= 1)
  {

    if (checkencode == 1)
    {
      alertMsg("Crypted:", isCrypted ? "True" : "False");
      exit(1);
    }
    if (isCrypted)
    {
      isCrypted_file_count++;
    }
    else
    {
      notisCrypted_file_count++;
    }
    printf("Crypted:%s - %s\n", isCrypted ? "True" : "False", file);
    return;
  }

  if (isCrypted)
  {
    errMsg(file, " Already Crypted");
    return;
  }
  else if (datalen < 1)
  {
    errMsg(file, " will not be crypted");
    return;
  }

  code_aes(1, datap, datalen, key, &datalen);
  fp = fopen(file, "wb");
  if (fp == NULL)
  {
    fail_file_count++;
    errMsg("Can not create crypt file(%s)", oldfilename);
    // exit(0);
    return;
  }
  fwrite(enTag, keylen, 1, fp);
  fwrite(lenBuf, keylen, 1, fp);
  fwrite(datap, datalen, 1, fp);
  fclose(fp);
  fflush(fp);

  alertMsg("Success Crypting - ", file);
  free(datap);
  success_file_count++;
}
