
#include "php_encoder.h"
#include "include/confighelper.h"
#include "include/md5.h"
#include "libutils/csha256.c"
#include "libutils/csha1.h"
#include "libutils/csha1.c"
#include "libutils/try.h"
#include "include/aes.c"
#include "include/aes_crypt.c"
#include "include/file.c"
#include "include/string.c"

#ifndef DOMARK
#define DOMARK 0
#endif
#define CAKEY2 46150861d427973cf6e7b0dbce7ba58e

#ifndef _DEBUG
#define _DEBUG 0
#endif

int DEBUG = (int)_DEBUG;
char *_key;
char *SafeKey = STR2(CAKEY);
char *encode_mode = STR2(ENCODE_MODE);
int encode_key_mode = (int)ENCODE_KEY_MODE;
int keylen = (int)KEYLEN;
char digest[128];
uint8_t key[256];

char *_encodekey(char *__key)
{

    if (DEBUG)
    {
        printf("ENCODE_MODE:%s\n", encode_mode);
        printf("ENCODE_KEY_MODE:%d\n", encode_key_mode);
    }
    if (strncmp(encode_mode, "sha256", 6) == 0)
    {
        if (encode_key_mode)
        {
            keylen = 128;
        }
        bzero(digest, sizeof(digest));
        return csha256_hash(digest, __key, NULL);
    }
    else if (strncmp(encode_mode, "sha1", 4) == 0)
    {
         if (encode_key_mode)
        {
            keylen = 128;
        }
        bzero(digest, sizeof(digest));
        return csha1_hash(digest, __key, 0, NULL); // 0,1,31,56,64
    }
    else
    {
         if (encode_key_mode)
        {
            keylen = 32;
        }
        return md5(__key);
    }
}

int getkey(uint8_t *_encodekeystr, int len)
{
    char *encode_key = STR2(CAKEY2);
    bzero(_encodekeystr, len);
    memset(_encodekeystr, 0, len);
    memcpy(_encodekeystr, encode_key, len);

    if (DEBUG)
    {
        printf("_encodekeystr:%s\n", _encodekeystr);
        printf("len:%d\n", len);
        printf("SafeKey:%s\n", SafeKey);
    }
    return len;
}

char *encodekey(char *__key)
{
    char *datap = _encodekey(__key);
    //判断是否是无特征模式
    if (encode_key_mode == 0)
    {

        if (DEBUG)
        {
            printf("特征模式:%s\n", datap);
        }
        return datap;
    }

    // //无特征模式

    uint8_t _encodekeystr[keylen];
    int datalen = sizeof(datap);
    getkey(_encodekeystr, keylen);
    code_aes(1, datap, datalen, _encodekeystr, &datalen);
    if (DEBUG)
    {
        printf("无特征模式:%s\n,size:%d\n", _encodekeystr, sizeof(_encodekeystr));
    }
    //  printf("%s", _encodekeystr);
    // datap=STR2(CAKEY2);
    return datap;
}

char mark[300];
char *getmark()
{
    sprintf(mark, "MARK%sMARK", STR2(CAKEY));
    sprintf(mark, "<?php if(!defined('%s')) {define('%s','%s');}?>\n", STR2(APPNAME), STR2(APPNAME), encodekey(mark));
    return mark;
}
