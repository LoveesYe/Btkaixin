#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#include "csha256.h"

#define FAIL(str, line) {                       \
  printf("Fail on line %d: [%s]\n", line, str); \
  return str;                                   \
}

#define ASSERT(expr) {                  \
  static_num_tests++;                   \
  if (!(expr)) FAIL(#expr, __LINE__);   \
}

#define RUN_TEST(test) {        \
    const char *msg = test();   \
    if(msg)                     \
        return msg;             \
}


static int static_num_tests = 0;


const char *test_csha256() {

	char digest[65];
	bzero(digest, sizeof(digest));

	ASSERT(strcmp(csha256_hash(digest, "", NULL),"e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855") == 0);
	ASSERT(strcmp(csha256_hash(digest, "1", NULL),"6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b") == 0);
	ASSERT(strcmp(csha256_hash(digest, "1111111111111111111111111111111", NULL),"bdb6820ec26e9e84cd7e39229e3013c3f16cb0eeab4d6169eb83dddaedfd508d") == 0);
	ASSERT(strcmp(csha256_hash(digest, "11111111111111111111111111111111111111111111111111111111", NULL),"9df2565d5163d54a49e6a8126bbd689614aeab8bc4aabfe69a8cb20975918ef2") == 0);
	ASSERT(strcmp(csha256_hash(digest, "1111111111111111111111111111111111111111111111111111111111111111", NULL),"3138bb9bc78df27c473ecfd1410f7bd45ebac1f59cf3ff9cfe4db77aab7aedd3") == 0);
	
    return NULL;
}


static const char *run_all_tests(void) {
    RUN_TEST(test_csha256);
    return NULL;
}


int main(void) {
    const char *fail_msg = run_all_tests();
    printf("%s, tests run: %d\n", fail_msg ? "FAIL" : "PASS", static_num_tests);

    return fail_msg == NULL ? 0 : -1;
}

