#!/bin/sh
make clean
make lib
