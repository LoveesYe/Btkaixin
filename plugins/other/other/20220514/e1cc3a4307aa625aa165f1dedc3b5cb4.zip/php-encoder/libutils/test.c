#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#include "cstr.h"

int main(int argc, char *argv[])
{
	char line[1024];
	bzero(line, sizeof(line));

	while((fgets(line, sizeof(line), stdin)) != NULL) {
		char *psam_no = cstr_trim(line);
		if(strlen(psam_no) != 16) {
			fprintf(stdout, "%s\t%s\n", psam_no, psam_no);
		} else {
			
			int i;
			int x1 = 0, x2 = 0;
			for(i = 8; i < 16; i+=2) {
				x1 ^= psam_no[i];
				x2 ^= psam_no[i+1];
			}

			//ת������
			if(x1 & 0x08) {
				x1 &= 0x09;
			} else {
				x1 &= 0x07;
			}
			x1 |= 0x30;

			if(x2 & 0x08) {
				x2 &= 0x09;
			} else {
				x2 &= 0x07;
			}
			x2 |= 0x30;

			char new_psam_no[16+1];
			cstr_copy(new_psam_no, psam_no, sizeof(new_psam_no));
			new_psam_no[6] = x1;
			new_psam_no[7] = x2;

			fprintf(stdout, "%s\t%s\n", psam_no, new_psam_no);
		}

		bzero(line, sizeof(line));
	}
	
	return 0;
}



