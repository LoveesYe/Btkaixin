#include <stdio.h>
#include <string.h>
#include <stdarg.h>

#include "cdefs.h"
#include "cbin.h"
#include "csha1.h"

#define leftrotate(x, n) (((x) << n) | ((x) >> (32-(n))))

#define bytes_to_u32(a, n)  (n) = ((a)[0] << 24 | (a)[1] << 16 | (a)[2] << 8 | (a)[3])

#define u32_to_bytes(n, a)  {   \
    (a)[0] = (n >> 24) & 0xff;  \
    (a)[1] = (n >> 16) & 0xff;  \
    (a)[2] = (n >> 8)  & 0xff;  \
    (a)[3] = (n >> 0)  & 0xff;  \
}

void csha1_init(csha1_ctx_t *ctx) {
    if(ctx != NULL) {
        bzero(ctx, sizeof(*ctx));
        ctx->h0 = 0x67452301;
        ctx->h1 = 0xefcdab89;
        ctx->h2 = 0x98badcfe;
        ctx->h3 = 0x10325476;
        ctx->h4 = 0xc3d2e1f0;
    }
}

void csha1_transform(csha1_ctx_t *ctx) {
    uint32_t w[80];
    uint32_t a = ctx->h0;
    uint32_t b = ctx->h1;
    uint32_t c = ctx->h2;
    uint32_t d = ctx->h3;
    uint32_t e = ctx->h4;
    uint32_t f, k, temp;
    int i, j;

    for(i = 0, j = 0; i < 16; i ++, j+=4) {
        bytes_to_u32(ctx->buf+j, w[i]);
    }

    for(; i < 80; i ++) {
        w[i] = leftrotate(w[i-3] ^ w[i-8] ^ w[i-14] ^ w[i-16], 1);
    }

    for(i = 0; i < 80; i++) {
        if(i >= 0 && i < 20) {
            f = (b & c) | ((~b) & d);
            k = 0x5a827999;
        } else if(i >= 20 && i < 40) {
            f = b ^ c ^ d;
            k = 0x6ed9eba1;
        } else if(i >= 40 && i < 60) {
            f = (b & c) | (b & d) | (c & d);
            k = 0x8f1bbcdc;
        } else if(i >= 60 && i < 80) {
            f = b ^ c ^ d;
            k = 0xca62c1d6;
        }

        temp = leftrotate(a, 5) + f + e + k + w[i];
        e = d;
        d = c;
        c = leftrotate(b, 30);
        b = a;
        a = temp;
    }
    ctx->h0 = ctx->h0 + a;
    ctx->h1 = ctx->h1 + b;
    ctx->h2 = ctx->h2 + c;
    ctx->h3 = ctx->h3 + d;
    ctx->h4 = ctx->h4 + e;
}

void csha1_update(csha1_ctx_t *ctx, char *data, unsigned int data_size) {
    unsigned int i, len;
    for(i = 0; i < data_size; i+=len) {
        len = MIN(data_size-i, 64);
        len = MIN(len, 64-ctx->buf_len);
        memcpy(ctx->buf + ctx->buf_len, data + i, len);
        ctx->buf_len += len;

        if(ctx->buf_len == 64) {
            csha1_transform(ctx);
            ctx->buf_len = 0;
        }
    }
    ctx->length += data_size;
}

void csha1_final(csha1_ctx_t *ctx, char digest[41]) {

    ctx->buf[ctx->buf_len++] = 0x80;
    while(ctx->buf_len != 56) {
        if(ctx->buf_len == 64) {
            csha1_transform(ctx);
            ctx->buf_len = 0;
        }
        ctx->buf[ctx->buf_len++] = 0x00;
    }

    ctx->length *= 8; //byte to bit
    while(ctx->buf_len < 64) {
        ctx->buf[ctx->buf_len] = (ctx->length >> ((64 - ctx->buf_len - 1) * 8)) & 0xff;
        ctx->buf_len ++;
    }

    csha1_transform(ctx);

    //����ctx->buf������
    u32_to_bytes(ctx->h0, ctx->buf);
    u32_to_bytes(ctx->h1, ctx->buf+4);
    u32_to_bytes(ctx->h2, ctx->buf+8);
    u32_to_bytes(ctx->h3, ctx->buf+12);
    u32_to_bytes(ctx->h4, ctx->buf+16);

    cbin_bin_to_hex(ctx->buf, (unsigned char *)digest, 20);
    digest[40] = 0x00;
}

char *csha1_hash(char digest[41], ...) {
    char *data;
	unsigned int data_size;
    va_list ap;
    csha1_ctx_t ctx;

    csha1_init(&ctx);

    va_start(ap, digest);
    while((data = va_arg(ap, char *)) != NULL) {
		data_size = va_arg(ap, unsigned int);
        csha1_update(&ctx, data, data_size);
    }
    va_end(ap);

    csha1_final(&ctx, digest);

    return digest;
}

