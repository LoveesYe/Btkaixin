
static unsigned char bhex[] = "0123456789abcdef";

static unsigned int hexb[] = {
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 1, 2, 3, 4, 5, 6, 7,
    8, 9, 0, 0, 0, 0, 0, 0,
    0, 10, 11, 12, 13, 14, 15, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 10, 11, 12, 13, 14, 15, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0
};



void cbin_bin_to_hex(const unsigned char *bin, unsigned char *hex, int size) {
    int i;
    for(i = 0; i < size; i++) {
        *hex++ = bhex[(bin[i] >> 4) & 0xf];
        *hex++ = bhex[bin[i] & 0xf];
    }
}

void cbin_hex_to_bin(const unsigned char *hex, unsigned char *bin, int size) {
    int i;
    for(i = 0; i < size; i+=2) {
        *bin++ = (hexb[(int)hex[i]]<<4) | hexb[(int)hex[i+1]];
    }
}

void cbin_bcd_to_asc(const unsigned char *bcd, unsigned char *asc, int size) {
    int i;
    for(i = 0; i < size; i++) {
        *asc++ = ((bcd[i] >> 4) & 0xf) + 0x30;
        *asc++ = (bcd[i] & 0xf) + 0x30;
    }
}

void cbin_asc_to_bcd(const unsigned char *asc, unsigned char *bcd, int size) {
    int i;
    for(i = 0; i < size; i+=2) {
        *bcd++ = ((asc[i] - 0x30) << 4) | (asc[i+1] - 0x30);
    }
}

