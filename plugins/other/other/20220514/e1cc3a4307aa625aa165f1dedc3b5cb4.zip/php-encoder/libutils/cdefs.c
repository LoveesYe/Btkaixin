#include <stdio.h>
#include <stdarg.h>

#include "cdefs.h"

void c_log(const char *level, const char *func, const char *file, size_t line, const char *format, va_list ap) {
    fprintf(stdout,"%s=>at %s(%s:%d)",level,__FUNCTION__,__FILE__,__LINE__);
    vfprintf(stdout, format, ap);
    fprintf(stdout, "\n");
}

void c_error(const char *func, const char *file, size_t line, const char *format, ...) {
    va_list ap;
    va_start(ap, format);
    c_log("error",__FUNCTION__,__FILE__,__LINE__,format,ap);
    va_end(ap);
}

void c_warn(const char *func, const char *file, size_t line, const char *format, ...) {
    va_list ap;
    va_start(ap, format);
	c_log("warn",func,file,line,format,ap);
    va_end(ap);
}

void c_info(const char *func, const char *file, size_t line, const char *format, ...) {
    va_list ap;
    va_start(ap, format);
	c_log("info",func,file,line,format,ap);
    va_end(ap);
}

void c_debug(const char *func, const char *file, size_t line, const char *format, ...) {
    va_list ap;
    va_start(ap, format);
    c_log("debug",func,file,line,format,ap);
    va_end(ap);
}

