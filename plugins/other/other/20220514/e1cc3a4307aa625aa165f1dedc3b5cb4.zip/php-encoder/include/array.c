#ifndef BLOCK
#define BLOCK 1024
#endif

typedef struct
{
    char *array; //数组空间
    int size;   //数组大小
} Array;

// 该结构体不定义为指针原因（传指针省空间）：
// 1.定义为指针后，就无法定义本地变量，一定是在某处另开一处空间，然后指针指向那里。
// 2.定义变量时不容易看出是指针。

// 该数组须实现以下功能：
// 1.创建数组array_creat
// 2.释放数组内存array_free
// 3.返回数组大小array_size
// 4.访问数组的某个位置array_at
// 5.空间不足时自增array_inflate
// 对应5个函数，下面分别实现：

Array array_creat(int init_size)
{
    Array a;
    a.size = init_size;
    a.array = (char *)malloc(sizeof(char) * a.size);
    return a;
}

// 为什么Array* array_creat(Array* a, int init_size)不行？
// 1.传进的指针可能指向NULL，a->array == NULL;
// 2.指针可能指向一个有效数组，需先free()
// 故自定义一个本地变量，赋值后，传出。

void array_free(Array *a)
{
    free(a->array);
    a->array = NULL;
    a->size = 0; //保险起见
}

void array_inflate(Array *a, int moresize)
{
    int *p = (char *)malloc(sizeof(char) * (a->size + moresize));
    //重新申请一块空间
    for (int i = 0; i < a->size; i++)
    { //旧数组复制到新数组
        p[i] = a->array[i];
    }
    free(a->array); //释放旧数组的空间
    a->array = p;   //值赋给a数组
    a->size += moresize;
}

int * array_at(Array *a, int index)
{ 
    //参数index为数组增加大小，一个BLOCK如下
    if (index > a->size)
    {
        array_inflate(a, (a->size / BLOCK + 1) * BLOCK - a->size);
    }
    return &(a->array[index]);
}
int array_size ( Array* a ){
	return a->size;
}


// int main(int argc, char *argv[])
// {
//     Array a;
//     a = array_creat(3);
//     printf("数组大小为：%d\n", array_size(&a));
//     *array_at(&a, 0) = 1;                          //访问数组0位置赋值
//     printf("数组0位置为：%d\n", *array_at(&a, 0)); //访问数组0位置读值
//     int number;
//     int cnt = 0; //计数器，也是数组的位
//     while (number != -1)
//     { //不断输入，等于-1时停止，测试自增功能
//         scanf("%d", &number);
//         if (number != -1)
//             *array_at(&a, cnt++) = number;
//     }
//     return 0;
// }