//显示拦截文件

#define STRICT_MODE 0

#define STRICT_MODE_ERROR_MESSAGE Access Denied
#define CAKEY F809264A00C5B4130B51CF5F90E870B2

// 无特征模式
#define ENCODE_KEY_MODE 1
#define DOMARK 0
//md5/sha1/sha256
#define ENCODE_MODE md5
//密钥长度32-128
#define KEYLEN 32

const int maxBytes = 1024 * 1024 * 2;
//版本
#define VERSION 1.3.8
//名称
#define APPNAME PHPEncoder
#define SITE  www.hkingsoft.cn
#define EMAIL hkingsoft@qq.cn
//调试模式
#define _DEBUG 0
#define STR1(R) #R
#define STR2(R) STR1(R)
#define STRICT_FILE 0