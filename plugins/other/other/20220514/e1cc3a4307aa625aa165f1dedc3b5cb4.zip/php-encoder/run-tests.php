<?
phpinfo();