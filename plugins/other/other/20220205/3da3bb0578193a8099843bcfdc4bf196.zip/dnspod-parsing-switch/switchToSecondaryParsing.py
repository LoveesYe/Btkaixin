#!/usr/bin/python
# coding: utf-8
import requests
import os
import json
import time
import sys
from urllib.parse import urlparse
import dnsapi
os.chdir("/www/server/panel")
sys.path.append("class/")
import public

def logWrite(log, btLogs = True):
    if(btLogs):
        public.WriteLog("DnsPod解析自动切换", log)
    logFile = open('/www/wwwlogs/dnspod_parsing_switch.log', 'a')
    logFile.write("["+time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()) + "] " + log + "\n")
    logFile.close()

if(not os.path.exists("/www/server/panel/plugin/dnspod_parsing_switch/config/main.json")):
    logWrite("找不到配置文件，程序启动失败")
    exit()
config = json.load(open("/www/server/panel/plugin/dnspod_parsing_switch/config/main.json"))
headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36 Edg/91.0.864.67"}

if(not config['automaticallySwitchBackTime'] == 0):
    pid = os.popen("ps -ef | grep '/dnspod_parsing_switch/switchBack.py' | grep -v grep | awk '{print $2}'").read()
    if(not pid == ""):
        os.popen('kill -9 '+pid)
    if(os.path.exists("/www/server/panel/pyenv/bin/python")):
        os.system("/www/server/panel/pyenv/bin/python /www/server/panel/plugin/dnspod_parsing_switch/switchBack.py &")
    else:
        os.system("python3 /www/server/panel/plugin/dnspod_parsing_switch/switchBack.py &")

def recordModify(domain, recordId, parsing, subDomain, recordType, ttl, ruleDict, generalDict):
    returnData = dnsapi.dnsapi().modifyRecord(domain, recordId, subDomain, recordType, parsing, ttl, "0")
    if(returnData['status'] == 1):
        try:
            if(generalDict['webHook'] != ""):
                requests.get(generalDict['webHook'].replace("$TYPE", "ms").replace("$RECORD", parsing).replace("$RULENAME", ruleDict['ruleName']))
        except:
            logWrite("发送WebHook请求失败！")
        logWrite("域名[" + subDomain + "." + domain + "]的解析被自动切换到副解析[" + parsing + "]")
    else:
        if(returnData['status'] != 2):
            logWrite("域名[" + subDomain + "." + domain + "]切换解析时出现了一个问题：" + json.dumps(returnData['data']), False)

def ruleDetermination(headers, monitoringPoints, ruleType, ruleParameter):
    try:
        response = requests.get(monitoringPoints,  headers = headers)
        html = response.text
        httpcode = response.status_code
        millisecond = int(response.elapsed.total_seconds()*1000)
    except:
        httpcode=''
        html=''
        millisecond = 1000000
        if('canNotAccess' == rule['ruleType']):
            return True
    if('accessTimeExceedsThreshold' == rule['ruleType']):
        if(millisecond > int(rule['ruleParameter'])):
            return True
    if('equalHttpcode' == rule['ruleType']):
        if(str(httpcode) == rule['ruleParameter']):   
            return True
    if('notEqualHttpcode' == rule['ruleType']):
        if(not str(httpcode) == rule['ruleParameter']):   
            return True
    if('existKeyword' == rule['ruleType']):
        if(rule['ruleParameter'] in html):
            return True
    if('doesNotExistKeyword' == rule['ruleType']):
        if(not rule['ruleParameter'] in html):
            return True
    return False

while(1):
    ruleFileList = os.listdir("/www/server/panel/plugin/dnspod_parsing_switch/config/rule")
    try:
        ruleFileList.remove(".keep")
    except:
        pass
    for ruleFile in ruleFileList:
        rule = json.load(open("/www/server/panel/plugin/dnspod_parsing_switch/config/rule/" + ruleFile))
        headers = {}
        headers['User-Agent'] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36 Edg/91.0.864.67"
        headers['Host'] = urlparse(rule['monitoringPoints']).netloc
        monitoringPointsTemp = rule['monitoringPoints'].replace(urlparse(rule['monitoringPoints']).netloc, rule['mainParsing']).replace("https://", "http://")
        if(ruleDetermination(headers, monitoringPointsTemp, rule['ruleType'], rule['ruleParameter'])):
            secondaryParsingArr = rule["secondaryParsing"].split("/")
            if(len(secondaryParsingArr) == 1):
                recordModify(rule['domain'], rule['recordId'], rule["secondaryParsing"], rule['subDomain'], rule['recordType'], rule['ttl'], rule, config)
            else:
                for secondaryParsing in secondaryParsingArr:
                    monitoringPointsTemp = rule['monitoringPoints'].replace(urlparse(rule['monitoringPoints']).netloc, secondaryParsing).replace("https://", "http://")
                    if(not ruleDetermination(headers, monitoringPointsTemp, rule['ruleType'], rule['ruleParameter'])):
                        recordModify(rule['domain'], rule['recordId'], secondaryParsing, rule['subDomain'], rule['recordType'], rule['ttl'], rule, config)
                        break
    time.sleep(config['detectionIntervalTime']*60)