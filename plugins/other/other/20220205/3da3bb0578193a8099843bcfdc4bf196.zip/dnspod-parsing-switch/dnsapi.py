import os
import sys
import json
import requests
from tencentcloud.common import credential
from tencentcloud.common.profile.client_profile import ClientProfile
from tencentcloud.common.profile.http_profile import HttpProfile
from tencentcloud.common.exception.tencent_cloud_sdk_exception import TencentCloudSDKException
from tencentcloud.dnspod.v20210323 import dnspod_client, models

class dnsapi():
    def __init__(self,mode="config", appId="", appKey="", configType="dnspod_cn", configPath="config/main.json"):
        self.nowPath = os.path.dirname(os.path.realpath(__file__))
        if(mode == "config"):
            self.configPath = self.nowPath + "/" + configPath
            if(os.path.exists(self.configPath)):
                configFile = open(self.configPath, 'r')
                configDict = json.loads(configFile.read())
                self.appId = configDict['appId']
                self.appKey = configDict["appKey"]
                self.configType = configDict["configType"]
            else:
                self.appId = ""
                self.appKey = ""
                self.configType = ""
        else:
            self.appId = appId
            self.appKey = appKey
            self.configType = configType
        if(self.configType == "dnspod_com"):
            self.apiBaseURL="https://api.dnspod.com/"
        elif(self.configType == "dnspod_cn"):
            self.apiBaseURL="https://dnsapi.cn/"

    def tencentCloudRequest(self, secretId, secretKey):
        try:
            cred = credential.Credential(secretId, secretKey)
            httpProfile = HttpProfile()
            httpProfile.endpoint = "dnspod.tencentcloudapi.com"
            clientProfile = ClientProfile()
            clientProfile.httpProfile = httpProfile
            client = dnspod_client.DnspodClient(cred, "", clientProfile)
        except TencentCloudSDKException as err:
            return False
        return client

    def getDomainList(self):
        returnData = {}
        if(self.configType == "dnspod_cn" or self.configType == "dnspod_com"):
            rdataType = "dnspod"
            postData = {'login_token': self.appId+','+self.appKey, 'format': 'json'}
            apiReturn = requests.post(self.apiBaseURL + 'Domain.List', postData, timeout=60).json()
            if(apiReturn['status']['code'] != "1"):
                returnData['status'] = -1
                returnData['data'] = apiReturn
            else:
                result = []
                for item in apiReturn['domains']:
                    dictTemp = {}
                    dictTemp['status'] = item['status']
                    dictTemp['domain_id'] = item['id']
                    dictTemp['grade_level'] = item['grade_level']
                    dictTemp['domain'] = item['name']
                    dictTemp['record_count'] = item['records']
                    dictTemp['ttl'] = item['ttl']
                    result.append(dictTemp)
                returnData['status'] = 1
                returnData['data'] = result
        elif(self.configType == "tencentapi_cn"):
            try:
                client = self.tencentCloudRequest(self.appId, self.appKey)
                if(client):
                    req = models.DescribeDomainListRequest()
                    params = {}
                    req.from_json_string(json.dumps(params))
                    resp = json.loads(client.DescribeDomainList(req).to_json_string())
                    result = []
                    for item in resp['DomainList']:
                        dictTemp = {}
                        dictTemp['id'] = item['DomainId']
                        dictTemp['status'] = item['DNSStatus']
                        dictTemp['grade_level'] = item['GradeLevel']
                        dictTemp['domain'] = item['Name']
                        dictTemp['record_count'] = item['RecordCount']
                        dictTemp['ttl'] = item['TTL']
                        result.append(dictTemp)
                    returnData['status'] = 1
                    returnData['data'] = result
                else:
                    returnData['status'] = -1
                    returnData['data'] = {}
            except TencentCloudSDKException as err:
                returnData['status'] = -1
                returnData['data'] = {"status": -1, "data": {"msg": str(err)}}
        return returnData

    def getRecordList(self, rootDomain):
        returnData = {}
        if(self.configType == "dnspod_cn" or self.configType == "dnspod_com"):
            rdataType = "dnspod"
            postData = {'login_token': self.appId+','+self.appKey, 'domain': rootDomain, 'format': 'json'}
            apiReturn = requests.post(self.apiBaseURL + 'Record.List', postData, timeout=60).json()
            if(apiReturn['status']['code'] != "1"):
                returnData['status'] = -1
                returnData['data'] = apiReturn
            else:
                result = []
                for item in apiReturn['records']:
                    dictTemp = {}
                    dictTemp['status'] = item['enabled']
                    dictTemp['id'] = item['id']
                    dictTemp['line_id'] = item['line_id']
                    dictTemp['name'] = item['name']
                    dictTemp['type'] = item['type']
                    dictTemp['ttl'] = item['ttl']
                    dictTemp['value'] = item['value']
                    result.append(dictTemp)
                returnData['status'] = 1
                returnData['data'] = result
        elif(self.configType == "tencentapi_cn"):
            try:
                client = self.tencentCloudRequest(self.appId, self.appKey)
                if(client):
                    req = models.DescribeRecordListRequest()
                    params = {
                        "Domain": rootDomain
                    }
                    req.from_json_string(json.dumps(params))
                    resp = json.loads(client.DescribeRecordList(req).to_json_string())
                    result = []
                    for item in resp['RecordList']:
                        dictTemp = {}
                        dictTemp['status'] = item['Status']
                        dictTemp['id'] = item['RecordId']
                        dictTemp['line_id'] = item['LineId']
                        dictTemp['name'] = item['Name']
                        dictTemp['type'] = item['Type']
                        dictTemp['ttl'] = item['TTL']
                        dictTemp['value'] = item['Value']
                        result.append(dictTemp)
                    returnData['status'] = 1
                    returnData['data'] = result
                else:
                    returnData['status'] = -1
                    returnData['data'] = {}
            except TencentCloudSDKException as err:
                returnData['status'] = -2
                returnData['data'] = {"status": -1, "data": {"msg": str(err)}}
        return returnData

    def getRecordInfo(self, domain, recordId):
        returnData = {}
        if(self.configType == "dnspod_cn" or self.configType == "dnspod_com"):
            rdataType = "dnspod"
            postData = {'login_token': self.appId+','+self.appKey, 'domain': domain, 'record_id': recordId, 'format': 'json'}
            apiReturn = requests.post(self.apiBaseURL + 'Record.Info', postData, timeout=60).json()
            if(apiReturn['status']['code'] != "1"):
                returnData['status'] = -1
                returnData['data'] = apiReturn
            else:
                dictTemp = {}
                dictTemp['status'] = apiReturn['record']['enabled']
                dictTemp['line_id'] = apiReturn['record']['record_line_id']
                dictTemp['name'] = apiReturn['record']['sub_domain']
                dictTemp['type'] = apiReturn['record']['record_type']
                dictTemp['ttl'] = apiReturn['record']['ttl']
                dictTemp['value'] = apiReturn['record']['value']
                returnData['status'] = 1
                returnData['data'] = dictTemp
        elif(self.configType == "tencentapi_cn"):
            try:
                client = self.tencentCloudRequest(self.appId, self.appKey)
                if(client):
                    req = models.DescribeRecordRequest()
                    params = {
                        "Domain": domain,
                        "RecordId": int(recordId)
                    }
                    req.from_json_string(json.dumps(params))
                    resp = json.loads(client.DescribeRecord(req).to_json_string())
                    dictTemp = {}
                    dictTemp['status'] = resp['RecordInfo']['Enabled']
                    dictTemp['line_id'] = resp['RecordInfo']['RecordLineId']
                    dictTemp['name'] = resp['RecordInfo']['SubDomain']
                    dictTemp['type'] = resp['RecordInfo']['RecordType']
                    dictTemp['ttl'] = resp['RecordInfo']['TTL']
                    dictTemp['value'] = resp['RecordInfo']['Value']
                    returnData['status'] = 1
                    returnData['data'] = dictTemp
                else:
                    returnData['status'] = -1
                    returnData['data'] = {}
            except TencentCloudSDKException as err:
                returnData['status'] = -1
                returnData['data'] = {"status": -1, "data": {"msg": str(err)}}
        return returnData

    def modifyRecord(self, domain, recordId, subDomain, recordType, value, ttl, recordLineId):
        returnData = {}
        recordInfo = self.getRecordInfo(domain, recordId)
        if(ttl == 0):
            ttl = recordInfo['data']['ttl']
        if(recordInfo['data']['value'] == value or recordInfo['data']['value'] == value + '.'):
            return {"status": 2, "data": {"msg": "The same as the original record, no need to modify"}}
        else:
            if(self.configType == "dnspod_cn" or self.configType == "dnspod_com"):
                rdataType = "dnspod"
                postData = {'login_token': self.appId+','+self.appKey, 'sub_domain': subDomain, 'domain': domain, 'record_id': recordId, 'record_type': recordType, 'record_line_id': '0', 'value': value, 'ttl': ttl, 'mx': '0', 'format': 'json'}
                apiReturn = requests.post(self.apiBaseURL + 'Record.Modify', postData, timeout=60).json()
                returnData['data'] = apiReturn
                if(apiReturn['status']['code'] == "1"):
                    returnData['status'] = 1
                else:
                    returnData['status'] = -1
            elif(self.configType == "tencentapi_cn"):
                try:
                    client = self.tencentCloudRequest(self.appId, self.appKey)
                    if(client):
                        req = models.ModifyRecordRequest()
                        params = {
                            "Domain": domain,
                            "RecordType": recordType,
                            "SubDomain": subDomain,
                            "RecordLine": "默认",
                            "RecordLineId": str(recordLineId),
                            "Value": value,
                            "TTL": int(ttl),
                            "RecordId": int(recordId)
                        }
                        req.from_json_string(json.dumps(params))
                        resp = json.loads(client.ModifyRecord(req).to_json_string())
                        returnData['status'] = 1
                        returnData['data'] = {"status": 1, "data": {"msg": "Successfully modified parsing"}}
                    else:
                        returnData['status'] = -1
                        returnData['data'] = {"status": -1, "data": {"msg": "A fatal error has occurred!"}}
                except TencentCloudSDKException as err:
                    returnData['status'] = -1
                    returnData['data'] = {"status": -1, "data": {"msg": str(err)}}
        return returnData