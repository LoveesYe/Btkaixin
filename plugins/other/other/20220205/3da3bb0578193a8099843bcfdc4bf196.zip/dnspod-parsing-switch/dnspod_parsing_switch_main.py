#!/usr/bin/python
# coding: utf-8
# +-------------------------------------------------------------------
# | Dnspod解析自动切换
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 吴先森(https://www.wunote.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: 吴先森 <i@mr-wu.top>
# +-------------------------------------------------------------------

# +--------------------------------------------------------------------
# |   宝塔第三方应用开发dnspod_parsing_switch
# +--------------------------------------------------------------------

import sys
import os
import json
import re
import time
from tld import get_fld
from tld import get_tld

os.chdir("/www/server/panel")
sys.path.append("class/")
import public
import dnsapi

if __name__ != '__main__':
    from BTPanel import cache, session, redirect

class dnspod_parsing_switch_main:
    __plugin_path = "/www/server/panel/plugin/dnspod_parsing_switch/"
    __config = None

    def __init__(self):
        pass

    def isIPV4(self, string_ip):
        if(re.match(r"^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$", string_ip, re.I)):
            return True
        else:
            return False

    def isIPV6(self, string):
        if(re.match(r"^(?:[A-F0-9]{1,4}:){7}[A-F0-9]{1,4}$", string_ip, re.I)):
            return True
        else:
            return False

    def logWrite(self, log):
        public.WriteLog("DnsPod解析自动切换", log)
        logFile = open('/www/wwwlogs/dnspod_parsing_switch.log', 'a')
        logFile.write("["+time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()) + "] " + log + "\n")
        logFile.close()

    def getStatus(self, args):
        result = re.sub("\D", "", os.popen('echo `ps ax | grep -i \'dnspod_parsing_switch/switchToSecondaryParsing.py\' | grep -v grep`').read())
        if(result == ''):
            return {'serviceStatus': 0, 'status': 1}
        else:
            return {'serviceStatus': 1, 'status': 1}

    def saveConfig(self, args):
        apiReturn = dnsapi.dnsapi("new", args.appId, args.appKey, args.configType).getDomainList()
        if(apiReturn['status'] != 1):
            return {"status":-1, 'msg':"抱歉，保存失败！连接腾讯云API失败！请检查您选择的接口类型是否正确、您输入的API信息是否正确有效！"}
        configDict = {
            'configVer': 2,
            'appId': args.appId,
            'appKey': args.appKey,
            'configType': args.configType,
            'webHook': args.webHook,
            'automaticallySwitchBackTime': int(args.automaticallySwitchBackTime),
            'detectionIntervalTime': int(args.detectionIntervalTime)
        }
        with open('/www/server/panel/plugin/dnspod_parsing_switch/config/main.json', "w") as f:
            json.dump(configDict, f, indent=2,sort_keys=True, ensure_ascii=False)
        self.logWrite('配置文件保存成功！')
        return {'msg': '保存成功！', 'status': 1}

    def deleteAllConfig(self, args):
        os.system("rm -rf /www/server/panel/plugin/dnspod_parsing_switch/config")
        os.system("mkdir -p /www/server/panel/plugin/dnspod_parsing_switch/config/rule")
        return {'status': 1, 'msg': '操作成功！'}

    def getMainConfig(self, args):
        if(os.path.exists('/www/server/panel/plugin/dnspod_parsing_switch/config/main.json')):
            configFile = open('/www/server/panel/plugin/dnspod_parsing_switch/config/main.json', 'r')
            configDict = json.loads(configFile.read())
            configFile.close()
            return {'status': 1, 'msg': '操作成功！', "data":configDict}
        else:
            return {'status': -1, 'msg': '错误！找不到配置文件！'}

    def deleteConfig(self, args):
        if(os.path.exists('/www/server/panel/plugin/dnspod_parsing_switch/config/main.json')):
            os.remove('/www/server/panel/plugin/dnspod_parsing_switch/config/main.json')
        self.logWrite('删除配置文件成功！')
        return {'msg': '删除成功！', 'status': 1}

    def saveRule(self, args):
        if(not os.path.exists('/www/server/panel/plugin/dnspod_parsing_switch/config/main.json')):
            return {'msg': '抱歉，找不到配置文件！', 'status': -1}
        try:
            rootDomain = get_fld('http://'+args.domain+'/')
        except:
            return {'msg': '输入域名的格式错误', 'status': -1}
        subDomain = args.domain.replace('.'+rootDomain, "")
        if(subDomain == rootDomain):
            subDomain = '@'
        returnData = dnsapi.dnsapi().getRecordList(rootDomain)
        if(returnData['status'] != 1):
            return {'msg': '操作失败！请检查您输入的域名是否正确、您是否拥有此域名的所有权！','returnData':returnData , 'status': -1}
        recordId = ''
        for record in returnData['data']:
            if(record['line_id'] == '0' and not (record['type'] == 'MX' or record['type'] == 'NS')):
                if(record['name'] == subDomain):
                    recordId = record['id']
                    recordType = record['type']
                    ttl = record['ttl']
                    break
        if(recordId == ''):
            return {'msg': '查询[recordsId]失败！找不到您的解析[' + args.domain + ']。请检查你的输入是否正确！', 'status': -1}
        records = args.secondaryParsing.split("/")
        records.append(args.mainParsing)
        for item in records:
            if(recordType == "CNAME"):
                try:
                    get_fld('http://'+args.domain+'/')
                except:
                    return {'msg': '抱歉，保存失败！解析类型与记录的值不匹配！必须全部为[CNAME]类型！', 'status': -1}
            elif(recordType == "A"):
                if(not self.isIPV4(item)):
                    return {'msg': '抱歉，保存失败！解析类型与记录的值不匹配！必须全部为[A]类型！', 'status': -1}
            elif(recordType == "AAAA"):
                if(not self.isIPV6(item)):
                    return {'msg': '抱歉，保存失败！解析类型与记录的值不匹配！必须全部为[AAAA]类型！', 'status': -1}
        ruleDict = {
            'ruleName': args.ruleName,
            'domain': rootDomain,
            'monitoringPoints': args.monitoringPoints,
            'ruleType': args.ruleType,
            'ruleParameter': args.ruleParameter,
            'ttl': ttl,
            'recordId': recordId,
            'recordType': recordType,
            'subDomain': subDomain,
            'mainParsing': args.mainParsing,
            'secondaryParsing': args.secondaryParsing
        }
        with open('/www/server/panel/plugin/dnspod_parsing_switch/config/rule/' + args.ruleName + '.json', "w") as ruleDictFile:
            json.dump(ruleDict, ruleDictFile, indent=2, sort_keys=True, ensure_ascii=False)
        self.logWrite("规则["+args.ruleName+"]保存成功")
        return {'msg': '保存成功！', 'status': 1}


    def getRuleList(self, args):
        ruleFileList = os.listdir("/www/server/panel/plugin/dnspod_parsing_switch/config/rule")
        try:
            ruleFileList.remove(".keep")
        except:
            pass
        pageID=int(args.page)
        lastPage = len(ruleFileList)/8
        if(int(lastPage)<lastPage):
            lastPage = int(lastPage)+1
        else:
            lastPage = int(lastPage)
        numberOfRules = len(ruleFileList)
        if(pageID == 0):
            a = 0
            rulesSnippetDict = []
            for ruleFile in ruleFileList:
                ruleTemp = {}
                ruleTemp['ruleName'] = ruleFileList[a].replace(".json", "")
                rulesSnippetDict.append(ruleTemp)
                a +=1
            return {'msg': '请求成功', "data":rulesSnippetDict, "pageId":0, "pageInfo":"共"+str(lastPage)+"页，"+str(numberOfRules)+"条日志", 'status': 1}
        if(pageID == -1):
            pageID = lastPage
        rulesSnippetDict = []
        a = (pageID - 1) * 8
        while(a < pageID * 8 and a < numberOfRules):
            ruleTemp = {}
            ruleTemp['ruleName'] = ruleFileList[a].replace(".json", "")
            rulesSnippetDict.append(ruleTemp)
            a +=1
        return {'msg': '请求成功', "data":rulesSnippetDict, "pageId":pageID, "lastPage":lastPage, "pageInfo":"共"+str(lastPage)+"页，"+str(numberOfRules)+"条日志", 'status': 1}

    def getRule(self, args):
        if(not os.path.exists("/www/server/panel/plugin/dnspod_parsing_switch/config/rule/" + args.ruleName + '.json')):
            return {'msg': '找不到此配置文件，请求失败！','rule':"" , 'status': -1}
        rule = json.load(open("/www/server/panel/plugin/dnspod_parsing_switch/config/rule/" + args.ruleName + '.json'))
        return {'msg': '请求成功！','rule':rule , 'status': 1}

    def delRule(self, args):
        if(os.path.exists('/www/server/panel/plugin/dnspod_parsing_switch/config/rule/'+ args.ruleName + '.json')):
            os.remove('/www/server/panel/plugin/dnspod_parsing_switch/config/rule/'+ args.ruleName + '.json')
        self.logWrite("规则["+args.ruleName+"]删除存成功")
        return {'msg': '删除规则成功！', 'status': 1}

    def switchBackToMainParsing(self, args):
        if(not os.path.exists('/www/server/panel/plugin/dnspod_parsing_switch/config/rule/'+ args.ruleName + '.json')):
            return {'msg': '抱歉，找不到规则文件！', 'status': -1}
        rule = json.load(open('/www/server/panel/plugin/dnspod_parsing_switch/config/rule/'+ args.ruleName + '.json'))
        returnData = dnsapi.dnsapi().modifyRecord(rule['domain'], rule['recordId'], rule['subDomain'], rule['recordType'], rule['mainParsing'], rule['ttl'], "0")
        if(returnData['status']):
            return {'msg': '切换成功！', 'data':returnData, 'status': 1}
        else:
            return {'msg': '切换失败！可能已经为主解析！', 'data':returnData, 'status': -1}    
        
    def displayOnce(self, args):
        if(os.path.exists('/www/server/panel/plugin/dnspod_parsing_switch/config/'+args.item)):
            return {'result': 0, 'status': 1}
        else:
            self.logWrite("触发了一次性显示内容["+args.item+"]")
            displayOnceFlag = open('/www/server/panel/plugin/dnspod_parsing_switch/config/'+args.item, 'a')
            displayOnceFlag.write('showed')
            displayOnceFlag.close()
            return {'result': 1, 'status': 1}

    def getLogs(self, args):
        if os.path.exists('/www/wwwlogs/dnspod_parsing_switch.log'):
            return {'msg': '查询成功！', 'logs': open('/www/wwwlogs/dnspod_parsing_switch.log').read(), 'status': 1}
        else:
            return {'msg': '查询成功！', 'logs': "抱歉，找不到日志！可能日志已经被清空？", 'status': 1}

    def deleteLogs(self, args):
        if os.path.exists('/www/wwwlogs/dnspod_parsing_switch.log'):
            os.remove('/www/wwwlogs/dnspod_parsing_switch.log')
        self.logWrite("清空了日志文件")
        return {'msg': '清空日志成功！', 'status': 1}

    def service(self, args):
        if(args.operating == 'start'):
            public.ExecShell('bash /www/server/panel/plugin/dnspod_parsing_switch/service.sh install')
            if(re.sub("\D", "", os.popen('echo `ps ax | grep -i \'dnspod_parsing_switch/switchToSecondaryParsing.py\' | grep -v grep`').read()) == ""):
                public.ExecShell('bash /www/server/panel/plugin/dnspod_parsing_switch/service.sh start &')
                if(re.sub("\D", "", os.popen('echo `ps ax | grep -i \'dnspod_parsing_switch/switchToSecondaryParsing.py\' | grep -v grep`').read()) == ""):
                    self.logWrite("无法启动服务！")
                    return {'msg': '抱歉，无法启动服务！请通过关于页面的邮箱联系开发者', 'status': 0}
                else:
                    self.logWrite("启动成功！但添加开机自动启失败！")
                    return {'msg': '启动成功！但添加开机自动启失败！', 'status': 1}
            else:
                self.logWrite("启动成功！并且添加开机自动启成功！")
                return {'msg': '启动成功！并且添加开机自动启成功！', 'status': 1}
        else:
            public.ExecShell('bash /www/server/panel/plugin/dnspod_parsing_switch/service.sh uninstall')
            public.ExecShell('bash /www/server/panel/plugin/dnspod_parsing_switch/service.sh stop')
            result = re.sub("\D", "", os.popen('echo `ps ax | grep -i \'dnspod_parsing_switch/switchToSecondaryParsing.py\' | grep -v grep`').read())
            result = result + re.sub("\D", "", os.popen('echo `ps ax | grep -i \'dnspod_parsing_switch/switchBack.py\' | grep -v grep`').read())
            if(not result == ""):
                self.logWrite("无法关闭服务！")
                return {'msg': '无法关闭服务！请尝试手动kill进程！', 'status': 0}
            else:
                self.logWrite("成功关闭了服务！")
                return {'msg': '成功关闭了服务！', 'status': 1}