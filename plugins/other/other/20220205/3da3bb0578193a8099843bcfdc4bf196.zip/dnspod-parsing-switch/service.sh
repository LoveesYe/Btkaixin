#!/bin/bash
case $1 in
install)
    chmod -Rf 775 /www/server/panel/plugin/dnspod_parsing_switch/*.sh
    chmod -Rf 775 /www/server/panel/plugin/dnspod_parsing_switch/*.py
    if [ -d "/lib/systemd/system" ]; then
        cp /www/server/panel/plugin/dnspod_parsing_switch/dnspod_parsing_switch /usr/lib/systemd/system/dnspod-parsing-switch.service
        systemctl daemon-reload
        systemctl start dnspod-parsing-switch.service
        systemctl enable dnspod-parsing-switch.service
    elif [ -d "/etc/init.d" ]; then
        cp /www/server/panel/plugin/dnspod_parsing_switch/dnspod_parsing_switch_init.sh /etc/init.d/dnspod_parsing_switch
        chmod -Rf 775 /etc/init.d/dnspod_parsing_switch
        chkconfig --add dnspod_parsing_switch
        chkconfig --level 2345 dnspod_parsing_switch on
        systemctl enable dnspod_parsing_switch.service
        /etc/init.d/dnspod_parsing_switch start
    fi
    ;;
uninstall)
    if [ -d "/lib/systemd/system" ]; then
        systemctl stop dnspod-parsing-switch.service
        systemctl disable dnspod-parsing-switch.service
        rm -rf /usr/lib/systemd/system/dnspod-parsing-switch.service
        systemctl daemon-reload
    elif [ -d "/etc/init.d" ]; then
        /etc/init.d/dnspod_parsing_switch stop
        chkconfig --level 2345 dnspod_parsing_switch off
        chkconfig --del dnspod_parsing_switch
        systemctl disable dnspod_parsing_switch.service
        rm -rf /etc/init.d/dnspod_parsing_switch
    fi
    ;;
start)
    if [ ! -f "/www/server/panel/pyenv/bin/python" ]; then
        python3 /www/server/panel/plugin/dnspod_parsing_switch/switchToSecondaryParsing.py
    else
        /www/server/panel/pyenv/bin/python /www/server/panel/plugin/dnspod_parsing_switch/switchToSecondaryParsing.py
    fi
    ;;
stop)
    kill $(ps -ef | grep "dnspod_parsing_switch/switchToSecondaryParsing.py" | grep -v grep | awk '{print $2}')
    kill $(ps -ef | grep "dnspod_parsing_switch/switchBack.py" | grep -v grep | awk '{print $2}')
    ;;
esac