#!/usr/bin/python
# coding: utf-8
import requests
import os
import json
import time
import sys
from urllib.parse import urlparse
os.chdir("/www/server/panel")
sys.path.append("class/")
import public
import dnsapi

config = json.load(open("/www/server/panel/plugin/dnspod_parsing_switch/config/main.json"))

def logWrite(log, btLogs = True):
    if(btLogs):
        public.WriteLog("DnsPod解析自动切换", log)
    logFile = open('/www/wwwlogs/dnspod_parsing_switch.log', 'a')
    logFile.write("["+time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()) + "] " + log + "\n")
    logFile.close()

def recordModify(domain, recordId, parsing, subDomain, recordType, ttl, ruleDict, generalDict):
    returnData = dnsapi.dnsapi().modifyRecord(domain, recordId, subDomain, recordType, parsing, ttl, "0")
    if(returnData['status'] == 1):
        try:
            if(generalDict['webHook'] != ""):
                requests.get(generalDict['webHook'].replace("$TYPE", "sm").replace("$RECORD", parsing).replace("$RULENAME", ruleDict['ruleName']))
        except:
            logWrite("发送WebHook请求失败！")
        logWrite("域名[" + subDomain + "." + domain + "]的解析被自动切换到主解析[" + parsing + "]")
    else:
        if(returnData['status'] != 2):
            logWrite("域名[" + subDomain + "." + domain + "]切换解析时出现了一个问题：" + json.dumps(returnData['data']), False)

while(1):
    ruleFileList = os.listdir("/www/server/panel/plugin/dnspod_parsing_switch/config/rule")
    try:
        ruleFileList.remove(".keep")
    except:
        pass
    for ruleFile in ruleFileList:
        rule = json.load(open("/www/server/panel/plugin/dnspod_parsing_switch/config/rule/" + ruleFile))
        headers = {}
        headers['User-Agent'] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36 Edg/91.0.864.67"
        headers['Host'] = urlparse(rule['monitoringPoints']).netloc
        try: 
            monitoringPointsTemp = rule['monitoringPoints'].replace(urlparse(rule['monitoringPoints']).netloc, rule['mainParsing']).replace("https://", "http://")
            response = requests.get(monitoringPointsTemp,  headers = headers)
            html = response.text
            httpcode = response.status_code
            millisecond = int(response.elapsed.total_seconds()*1000)
        except:
            httpcode=''
            html=''
            millisecond = 1000000
        if(not httpcode == ""):
            if('accessTimeExceedsThreshold' == rule['ruleType']):
                if(millisecond < int(rule['ruleParameter'])):
                    recordModify(rule["domain"], rule["recordId"], rule["mainParsing"], rule["subDomain"], rule["recordType"], rule["ttl"], rule, config)
            if('canNotAccess' == rule['ruleType']):
                recordModify(rule["domain"], rule["recordId"], rule["mainParsing"], rule["subDomain"], rule["recordType"], rule["ttl"], rule, config)
            if('equalHttpcode' == rule['ruleType']):
                if(not str(httpcode)==rule['ruleParameter']):   
                    recordModify(rule["domain"], rule["recordId"], rule["mainParsing"], rule["subDomain"], rule["recordType"], rule["ttl"], rule, config)
            if('notEqualHttpcode' == rule['ruleType']):
                if(str(httpcode) == rule['ruleParameter']):   
                    recordModify(rule["domain"], rule["recordId"], rule["mainParsing"], rule["subDomain"], rule["recordType"], rule["ttl"], rule, config)
            if('existKeyword' == rule['ruleType']):
                if(not rule['ruleParameter'] in html):
                    recordModify(rule["domain"], rule["recordId"], rule["mainParsing"], rule["subDomain"], rule["recordType"], rule["ttl"], rule, config)
            if('doesNotExistKeyword' == rule['ruleType']):
                if(rule['ruleParameter'] in html):
                    recordModify(rule["domain"], rule["recordId"], rule["mainParsing"], rule["subDomain"], rule["recordType"], rule["ttl"], rule, config)
    time.sleep(config['automaticallySwitchBackTime']*60)