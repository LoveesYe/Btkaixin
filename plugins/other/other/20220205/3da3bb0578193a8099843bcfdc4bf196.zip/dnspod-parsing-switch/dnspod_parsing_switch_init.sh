#!/bin/bash

### BEGIN INIT INFO
# Provides:          dnspod_parsing_switch
# Required-Start:    $all
# Required-Stop:
# Default-Start:     2 3 4 5
# Default-Stop:
# Short-Description: dnspod_parsing_switch
### END INIT INFO

#chkconfig: 2345 81 96
#description:dnspod_parsing_switch

case $1 in
	start):
        if [ ! -f "/www/server/panel/pyenv/bin/python" ]; then
            python3 /www/server/panel/plugin/dnspod_parsing_switch/switchToSecondaryParsing.py
            exit 0
        else
            /www/server/panel/pyenv/bin/python /www/server/panel/plugin/dnspod_parsing_switch/switchToSecondaryParsing.py
            exit 0
        fi
	;;
	stop):
        kill $(ps -ef | grep "dnspod_parsing_switch/switchToSecondaryParsing.py" | grep -v grep | awk '{print $2}')
        kill $(ps -ef | grep "dnspod_parsing_switch/switchBack.py" | grep -v grep | awk '{print $2}')
	;;
esac

exit 0