#!/bin/bash
PATH=/www/server/panel/pyenv/bin:/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH

#配置插件安装目录
install_path=/www/server/panel/plugin/dnspod_parsing_switch

#安装
Install() {

	echo '正在安装...'
	#==================================================================
	#依赖安装开始
	mkdir -p /www/server/panel/plugin/dnspod_parsing_switch/config/rule
	if [ -f "/www/server/panel/pyenv/bin/python" ]; then
		echo '使用宝塔Python3版本，无需安装Python3！'
		/www/server/panel/pyenv/bin/pip install requests
		/www/server/panel/pyenv/bin/pip install tld
		/www/server/panel/pyenv/bin/pip install tencentcloud-sdk-python
	else
		if ! [ -x "$(command -v python3)" ]; then
			if [ -f "/usr/bin/yum" ] && [ -d "/etc/yum.repos.d" ]; then
				echo '正在安装Python3（本服务器不存在Python3环境）'
				yum install python3 -y
				echo '如果安装失败，请尝试yum update或手动安装下试试？'
			elif [ -f "/usr/bin/apt-get" ] && [ -f "/usr/bin/dpkg" ]; then
				echo '正在安装Python3（本服务器不存在Python3环境）'
				apt-get install python3 -y
				echo '如果安装失败，请尝试apt-get update或手动下试试？'
			fi
		fi
		pip3 install requests
		pip3 install tld
		pip3 install tencentcloud-sdk-python
	fi

	#依赖安装结束
	#==================================================================
	bash /www/server/panel/plugin/dnspod_parsing_switch/service.sh stop

	echo '================================================'
	echo '安装完成'
}

#卸载
Uninstall() {
	bash /www/server/panel/plugin/dnspod_parsing_switch/service.sh stop
	bash /www/server/panel/plugin/dnspod_parsing_switch/service.sh uninstall
	rm -rf $install_path
}

#操作判断
if [ "${1}" == 'install' ]; then
	Install
elif [ "${1}" == 'uninstall' ]; then
	Uninstall
else
	echo 'Error!'
fi
