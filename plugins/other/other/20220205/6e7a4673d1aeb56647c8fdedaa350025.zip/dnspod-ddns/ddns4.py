import os
import json
import re
import time
import sys
import requests
os.chdir("/www/server/panel")
sys.path.append("class/")
import public
import dnsapi

def logWrite(log, btLogs = True):
    if(btLogs):
        public.WriteLog("DnsPod解析自动切换", log)
    logFile = open('/www/wwwlogs/dnspod_ddns.log', 'a')
    logFile.write("["+time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()) + "] " + log + "\n")
    logFile.close()

if(os.path.exists('/www/server/panel/plugin/dnspod_ddns/config/ipv6.json')):
    pid = os.popen("ps -ef | grep 'dnspod_ddns/ddns6.py' | grep -v grep | awk '{print $2}'").read()
    if(not pid == ""):
        os.popen('kill -9 '+pid)
    if(os.path.exists("/www/server/panel/pyenv/bin/python")):
        os.system("/www/server/panel/pyenv/bin/python /www/server/panel/plugin/dnspod_ddns/ddns6.py &")
    else:
        os.system("python3 /www/server/panel/plugin/dnspod_ddns/ddns6.py &")

if(not os.path.exists('/www/server/panel/plugin/dnspod_ddns/config/ipv4.json')):
    logWrite("[ipv4 ddns]由于找不到配置文件已经自动退出")
    exit()

generalDict = json.load(open('/www/server/panel/plugin/dnspod_ddns/config/general.json'))
configDict = json.load(open('/www/server/panel/plugin/dnspod_ddns/config/ipv4.json'))
while(1):
    try:
        userIp = requests.get('https://api.ipify.org/?format=json').json()['ip']
        apiReturn = dnsapi.dnsapi().modifyRecord(configDict['domain'], configDict['recordId'], configDict['recordName'], "A", userIp, 0, "0")
        if(apiReturn['status'] == 1 or apiReturn['status'] == 2):
            if(apiReturn['status'] == 1):
                try:
                    if(generalDict['webHook'] != ""):
                        requests.get(generalDict['webHook'].replace("$IP", userIp))
                except:
                    logWrite("发送WebHook请求失败！")
                logWrite("[ipv4 ddns]已经成功更新IP至[" + userIp + "]")
        else:
            logWrite("[ipv4 ddns]请求dnspod api时出现一个错误", False)
    except:
        logWrite("[ipv4 ddns]更新IP出现了一个错误", False)
    time.sleep(int(generalDict['detectionIntervalTime'])*60)