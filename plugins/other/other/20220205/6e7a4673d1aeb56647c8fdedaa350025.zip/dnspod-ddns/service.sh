#!/bin/bash
case $1 in
install)
    chmod -Rf 775 /www/server/panel/plugin/dnspod_ddns/*.sh
    chmod -Rf 775 /www/server/panel/plugin/dnspod_ddns/*.py
    if [ -d "/lib/systemd/system" ]; then
        cp /www/server/panel/plugin/dnspod_ddns/dnspod_ddns /usr/lib/systemd/system/dnspod-ddns.service
        systemctl daemon-reload
        systemctl start dnspod-ddns.service
        systemctl enable dnspod-ddns.service
    elif [ -d "/etc/init.d" ]; then
        cp /www/server/panel/plugin/dnspod_ddns/dnspod_ddns_init.sh /etc/init.d/dnspod_ddns
        chmod -Rf 775 /etc/init.d/dnspod_ddns
        chkconfig --add dnspod_ddns
        chkconfig --level 2345 dnspod_ddns on
        systemctl enable dnspod_ddns.service
        /etc/init.d/dnspod_ddns start
    fi
    ;;
uninstall)
    if [ -d "/lib/systemd/system" ]; then
        systemctl stop dnspod-ddns.service
        systemctl disable dnspod-ddns.service
        rm -rf /usr/lib/systemd/system/dnspod-ddns.service
        systemctl daemon-reload
    elif [ -d "/etc/init.d" ]; then
        /etc/init.d/dnspod_ddns stop
        chkconfig --level 2345 dnspod_ddns off
        chkconfig --del dnspod_ddns
        systemctl disable dnspod_ddns.service
        rm -rf /etc/init.d/dnspod_ddns
    fi
    ;;
start)
    if [ ! -f "/www/server/panel/pyenv/bin/python" ]; then
        python3 /www/server/panel/plugin/dnspod_ddns/ddns4.py
    else
        /www/server/panel/pyenv/bin/python /www/server/panel/plugin/dnspod_ddns/ddns4.py
        exit 0
    fi
    ;;
stop)
    kill $(ps -ef | grep "dnspod_ddns/ddns4.py" | grep -v grep | awk '{print $2}')
    kill $(ps -ef | grep "dnspod_ddns/ddns6.py" | grep -v grep | awk '{print $2}')
    ;;
esac