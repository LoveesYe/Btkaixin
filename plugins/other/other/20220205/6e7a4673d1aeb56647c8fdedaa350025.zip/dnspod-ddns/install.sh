PATH=/www/server/panel/pyenv/bin:/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH

install_path=/www/server/panel/plugin/dnspod_ddns

Install()
{
	
	echo '正在安装...'
	if [ ! -f "/www/server/panel/pyenv/bin/python" ];then
		if ! [ -x "$(command -v python3)" ]; then
			echo '检测到Python3并未按照，正在自动安装中'
			if [ -f "/usr/bin/yum" ] && [ -d "/etc/yum.repos.d" ]; then
				echo '正在安装Python3（本服务器不存在Python3环境）'
				yum install python3 -y
				echo '如果安装失败，请尝试yum update或手动安装下试试？'
			elif [ -f "/usr/bin/apt-get" ] && [ -f "/usr/bin/dpkg" ]; then
				echo '正在安装Python3（本服务器不存在Python3环境）'
				apt-get install python3	-y
				echo '如果安装失败，请尝试apt-get update或手动下试试？'
			fi
		fi
		pip3 install requests
		pip3 install urllib
		pip3 install tencentcloud-sdk-python
		if ! [ -x "$(command -v python3)" ]; then
		  echo '错误！Python3环境似乎安装失败！请手动检查是否存在Python3环境！' >&2
		  echo 'Error! Python3 installation failed'>/www/server/panel/plugin/dnspod_ddns/update.log
		  sleep 10
		fi
	else
		/www/server/panel/pyenv/bin/pip install requests
		/www/server/panel/pyenv/bin/pip install urllib
		/www/server/panel/pyenv/bin/pip install tencentcloud-sdk-python
		echo '使用宝塔Python3版本，无需安装Python3！'
	fi
	mkdir /www/server/panel/plugin/dnspod_ddns/config
	rm -rf /www/server/panel/plugin/dnspod_ddns/config/fiveStar
    bash /www/server/panel/plugin/dnspod_ddns/service.sh stop
    bash /www/server/panel/plugin/dnspod_ddns/dnspod_ddns_start_automatically.sh stop
	echo '================================================'
	echo '安装完成'
}

Uninstall()
{
    bash /www/server/panel/plugin/dnspod_ddns/service.sh stop
	rm -rf $install_path
}

if [ "${1}" == 'install' ];then
	Install
elif [ "${1}" == 'uninstall' ];then
	Uninstall
else
	echo 'Error!';
fi
