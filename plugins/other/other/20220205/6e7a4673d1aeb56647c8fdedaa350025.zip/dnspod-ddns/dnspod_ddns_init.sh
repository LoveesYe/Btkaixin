#!/bin/bash

### BEGIN INIT INFO
# Provides:          dnspod-ddns
# Required-Start:    $all
# Required-Stop:
# Default-Start:     2 3 4 5
# Default-Stop:
# Short-Description: Dnspod-DDNS
### END INIT INFO

#chkconfig: 2345 81 96
#description:dnspod_ddns

case $1 in
	start):
	    bash /www/server/panel/plugin/dnspod_ddns/service.sh start &
        exit 0
	;;
	stop):
	    bash /www/server/panel/plugin/dnspod_ddns/service.sh stop &
        exit 0
	;;
esac

exit 0