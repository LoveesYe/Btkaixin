#!/usr/bin/python
# coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 吴先森(http://www.wunote.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: 吴先森 <i@mr-wu.top>
# +-------------------------------------------------------------------

#+--------------------------------------------------------------------
#|   DnsPod DDNS
#+--------------------------------------------------------------------
import sys,os,json
import re
import time
import dnsapi
os.chdir("/www/server/panel")
sys.path.append("class/")
import public

if __name__ != '__main__':
    from BTPanel import cache,session,redirect

class dnspod_ddns_main:
    __plugin_path = "/www/server/panel/plugin/dnspod_ddns/"
    __config = None

    def logWrite(self, log):
        public.WriteLog("腾讯云域名动态解析", log)
        logFile = open('/www/wwwlogs/dnspod_ddns.log', 'a')
        logFile.write("["+time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()) + "] " + log + "\n")
        logFile.close()

    def getStatus(self, args):
        result=re.sub("\D", "", os.popen('echo `ps ax | grep -i \'dnspod_ddns/ddns4.py\' | grep -v grep`').read())
        result=result + re.sub("\D", "", os.popen('echo `ps ax | grep -i \'dnspod_ddns/ddns6.py\' | grep -v grep`').read())
        if(result == ''):
            return {'serviceStatus': 0, 'status': 1}
        else:
            return {'serviceStatus': 1, 'status': 1}

    def saveGeneralSettings(self, args):
        rData = dnsapi.dnsapi("parameter", args.appId, args.appKey, args.configType).getDomainList()
        if(rData['status'] == 1):
            configDict = {
                'appId': args.appId, 
                'appKey': args.appKey, 
                'webHook': args.webHook,
                'detectionIntervalTime': int(args.detectionIntervalTime),
                'configType': args.configType
            }
            with open('/www/server/panel/plugin/dnspod_ddns/config/general.json', "w") as f:
                json.dump(configDict, f,indent=2,sort_keys=True, ensure_ascii=False)
            if os.path.exists("/www/server/panel/plugin/dnspod_ddns/config/ipv4.json"):
                os.remove("/www/server/panel/plugin/dnspod_ddns/config/ipv4.json")
            if os.path.exists("/www/server/panel/plugin/dnspod_ddns/config/ipv6.json"):
                os.remove("/www/server/panel/plugin/dnspod_ddns/config/ipv6.json")
            self.logWrite("保存主配置文件成功！")
            return {"status":1, 'msg':"保存成功！"}
        else:
            return {"status":-1, 'msg':"抱歉，保存失败！连接腾讯云API失败！请检查您选择的接口类型是否正确、您输入的API信息是否正确有效！"}

    def getGeneralSettings(self,args):
        if(os.path.exists('/www/server/panel/plugin/dnspod_ddns/config/general.json')):
            config = json.load(open('/www/server/panel/plugin/dnspod_ddns/config/general.json'))
            return {"msg":"查询成功！", "config":config, "status":1}
        else:
            return {"msg":"找不到指定配置文件！", "status":-1}

    def deleteGeneralSettings(self, args):
        if os.path.exists('/www/server/panel/plugin/dnspod_ddns/config/general.json'):
            os.remove('/www/server/panel/plugin/dnspod_ddns/config/general.json')
        if os.path.exists("/www/server/panel/plugin/dnspod_ddns/config/ipv4.json"):
            os.remove("/www/server/panel/plugin/dnspod_ddns/config/ipv4.json")
        if os.path.exists("/www/server/panel/plugin/dnspod_ddns/config/ipv6.json"):
            os.remove("/www/server/panel/plugin/dnspod_ddns/config/ipv6.json")
        self.logWrite("删除主配置文件成功！")
        return {'msg': "删除配置文件成功！", 'status': 1}

    def getDomainList(self,args):
        if(os.path.exists('/www/server/panel/plugin/dnspod_ddns/config/general.json')):
            return {'msg': "查询成功",'data':dnsapi.dnsapi().getDomainList(), 'status': 1}
        else:
            return {"msg":"找不到指定配置文件！", "status":-1}

    def getRecordList(self,args):
        if(os.path.exists('/www/server/panel/plugin/dnspod_ddns/config/general.json')):
            return {'msg': "查询成功",'data':dnsapi.dnsapi().getRecordList(args.domain), 'status': 1}
        else:
            return {"msg":"找不到指定配置文件！", "status":-1}

    def saveConfig(self,args):
        configDict = {
            'domain': args.domain,
            'recordId': args.recordId,
            'recordName': args.recordName
        }
        if(args.type=='ipv4'):
            with open('/www/server/panel/plugin/dnspod_ddns/config/ipv4.json', "w") as f:
                json.dump(configDict, f,indent=2,sort_keys=True, ensure_ascii=False)
        else:
            with open('/www/server/panel/plugin/dnspod_ddns/config/ipv6.json', "w") as f:
                json.dump(configDict, f,indent=2,sort_keys=True, ensure_ascii=False)
        self.logWrite("保存配置文件["+args.type+" ddns]成功！")
        return {'msg':"保存配置文件["+args.type+" ddns]成功！",'status':1 }
        
    def getConfig(self,args):
        if(os.path.exists("/www/server/panel/plugin/dnspod_ddns/config/" + args.type + ".json")):
            config = json.load(open("/www/server/panel/plugin/dnspod_ddns/config/" + args.type + ".json"))
            return {"msg":"查询成功！", "config":config, "status":1}
        else:
            return {"msg":"没有此配置文件", "status":-1}

    def getLogs(self,args):
        if os.path.exists('/www/wwwlogs/dnspod_ddns.log'):
            return {'msg': '查询成功！', 'logs': open('/www/wwwlogs/dnspod_ddns.log').read(), 'status': 1}
        else:
            return {'msg': '查询成功！', 'logs': "抱歉，找不到日志！可能日志已经被清空？", 'status': 1}

    def deleteLogs(self, args):
        if os.path.exists('/www/wwwlogs/dnspod_ddns.log'):
            os.remove('/www/wwwlogs/dnspod_ddns.log')
        self.logWrite("清空了日志文件")
        return {'msg': '清空日志成功！', 'status': 1}

    def deleteConfig(self, args):
        if os.path.exists("/www/server/panel/plugin/dnspod_ddns/config/" + args.type + ".json"):
            os.remove("/www/server/panel/plugin/dnspod_ddns/config/" + args.type + ".json")
        self.logWrite("删除配置文件["+args.type+" ddns]成功！")
        return {'msg': "删除配置文件["+args.type+" ddns]成功！", 'status': 1}

    def displayOnce(self, args):
        if(os.path.exists('/www/server/panel/plugin/dnspod_ddns/config/'+args.item)):
            return {'result': 0, 'status': 1}
        else:
            self.logWrite("触发了一次性显示内容["+args.item+"]")
            displayOnceFlag = open('/www/server/panel/plugin/dnspod_ddns/config/'+args.item, 'a')
            displayOnceFlag.write('showed')
            displayOnceFlag.close()
            return {'result': 1, 'status': 1}

    def service(self, args):
        if(args.operating == 'start'):
            public.ExecShell('bash /www/server/panel/plugin/dnspod_ddns/service.sh install')
            result = re.sub("\D", "", os.popen('echo `ps ax | grep -i \'dnspod_ddns/ddns4.py\' | grep -v grep`').read())
            result = result + re.sub("\D", "", os.popen('echo `ps ax | grep -i \'dnspod_ddns/ddns6.py\' | grep -v grep`').read())
            if(result == ""):
                public.ExecShell('bash /www/server/panel/plugin/dnspod_ddns/service.sh start &')
                result = re.sub("\D", "", os.popen('echo `ps ax | grep -i \'dnspod_ddns/ddns4.py\' | grep -v grep`').read())
                result = result + re.sub("\D", "", os.popen('echo `ps ax | grep -i \'dnspod_ddns/ddns6.py\' | grep -v grep`').read())
                if(result == ""):
                    self.logWrite("无法启动服务！")
                    return {'msg': '抱歉，无法启动服务！请通过关于页面的邮箱联系开发者', 'status': 0}
                else:
                    self.logWrite("启动成功！但添加开机自动启失败！")
                    return {'msg': '启动成功！但添加开机自动启失败！', 'status': 1}
            else:
                self.logWrite("启动成功！并且添加开机自动启成功！")
                return {'msg': '启动成功！并且添加开机自动启成功！', 'status': 1}
        else:
            public.ExecShell('bash /www/server/panel/plugin/dnspod_ddns/service.sh uninstall')
            public.ExecShell('bash /www/server/panel/plugin/dnspod_ddns/service.sh stop')
            result = re.sub("\D", "", os.popen('echo `ps ax | grep -i \'dnspod_ddns/ddns4.py\' | grep -v grep`').read())
            result = result + re.sub("\D", "", os.popen('echo `ps ax | grep -i \'dnspod_ddns/ddns6.py\' | grep -v grep`').read())
            if(not result == ""):
                self.logWrite("无法关闭服务！")
                return {'msg': '无法关闭服务！请尝试手动kill进程！', 'status': 0}
            else:
                self.logWrite("成功关闭了服务！")
                return {'msg': '成功关闭了服务！', 'status': 1}