#!/bin/bash
PATH=/www/server/panel/pyenv/bin:/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH

#配置插件安装目录
install_path=/www/server/panel/plugin/btgitea
core_path=/www/server/btgitea
install_path_tmp=$core_path'/tmp'

#安装
Install() {
  echo '正在安装...'
  #==================================================================
  Is_64bit=$(getconf LONG_BIT)
  #获取操作系统是否64位
  mkdir -p ${install_path}

  #如果没有配置文件则生成配置文件
  if [ ! -f ${core_path}/custom/conf/app.ini ]; then
    #如果有备份文件则复制备份文件，如果没有则新建立
    if [ ! -f ${install_path}/custom/conf/app_bak.ini ]; then
      mv ${install_path}/custom/conf/app_bak.ini ${core_path}/custom/conf/app.ini
    # else
    # touch  ${install_path}/custom/conf/app.ini
    # cat>${install_path}/custom/conf/app.ini <<EOF
    # [default]

    # [server]
    # LANDING_PAGE=explore
    # EOF
    fi
  #判断头部是否有 [default]
  fi

  #移动备案号模板文件
  if [[ ! -f ${core_path}/custom/templates/base/keep_on_record.tmpl ]] && [[ -f ${install_path}/custom/templates/base/keep_on_record.tmpl ]]; then
    mv ${install_path}/custom/templates/base/keep_on_record.tmpl ${core_path}/custom/templates/base/keep_on_record.tmpl
  fi
  #生成备案号模板文件
  if [ ! -f ${core_path}/custom/templates/base/keep_on_record.tmpl ]; then
    #如果有备份文件则复制备份文件，如果没有则新建立
    touch ${core_path}/custom/templates/base/keep_on_record.tmpl
    cat >${core_path}/custom/templates/base/keep_on_record.tmpl <<EOF
浙ICP备xxxx号-x
EOF

  fi

  Is_64bit=$(getconf LONG_BIT)
  pkg_x64_name='gitea-1.9-linux-amd64'
  pkg_x86_name='gitea-1.9-linux-386'
  #获取操作系统是否64位
  mkdir -p ${install_path_tmp}

  #判断资源文件夹是否存在如果存在则直接创建软连接 如果不存在复制默认资源到指定目录

  #2.安装依赖
  if [ "${PM}" == "yum" ] || [ "${PM}" == "dnf" ]; then
    su - root <<EOF
if hash git > /dev/null 2>&1 ; then 
	echo 'you have git ' >/dev/null 2>&1
else 
	yum -y install git
fi
if hash pip 2>/dev/null; then
	pip install ConfigParser
fi
if hash pip3 2>/dev/null; then
	pip3 install configparser
fi
EOF
  elif [ "${PM}" == "apt" ]; then
    if hash git >/dev/null 2>&1; then
      echo 'you have git ' >/dev/null 2>&1
    else
      sudo apt-get -y install git
    fi

    if hash pip >/dev/null 2>&1; then
      sudo pip install ConfigParser
    fi
    if hash pip3 >/dev/null 2>&1; then
      sudo pip3 install configparser
    fi
  fi

  #依赖安装结束

  if [ -f "${core_path}/gitea" ]; then
    ln -sf ${core_path}/gitea /usr/bin/gitea
  fi

  #==================================================================

  echo '================================================'
  echo '安装完成，正在移动旧文件...'

  #执行释放命令
  # core_path

  if [ "${PM}" == "yum" ] || [ "${PM}" == "dnf" ]; then
    su - root <<EOF
unzip -o ${install_path}/core.zip -d ${core_path} -x "*.bat"
EOF
  elif [ "${PM}" == "apt" ]; then
    sudo unzip -o ${install_path}/core.zip -d ${core_path} -x "*.bat"
  else
    sudo unzip -o ${install_path}/core.zip -d ${core_path} -x "*.bat"
  fi

  # 如果没有配置文件，并且有老的配置文件存在则将老的配置文件移动到新的路径中
  if [[ ! -f ${core_path}/custom/conf/app.ini ]] && [[ -f ${install_path}/custom/conf/app.ini ]]; then
    cp ${install_path}/custom/conf/app.ini ${core_path}/custom/conf/app.ini
  fi

  # 如果没有二进制文件但是原来的目录中有二进制文件则移动到该核心目录下来
  if [[ ! -f ${core_path}/gitea ]] && [[ -f ${install_path}/gitea ]]; then
    mv ${install_path}/gitea ${core_path}/gitea
  fi

  # 二进制脚本授权
  if [ -f "${core_path}/middleware/lib/lib_gitea" ]; then
    if [ "${PM}" == "yum" ] || [ "${PM}" == "dnf" ]; then
      su - root <<EOF
    # /www/server/btgitea/middleware/go/code
    chmod +x ${core_path}/middleware/lib/lib_gitea
    # 解决升级或者备份还原数据后无法push问题
    ${core_path}/middleware/lib/lib_gitea --cmd CheckPreText
EOF
    elif [ "${PM}" == "apt" ]; then
      # /www/server/btgitea/middleware/go/code
      sudo chmod +x ${core_path}/middleware/lib/lib_gitea
      # 解决升级或者备份还原数据后无法push问题
      sudo ${core_path}/middleware/lib/lib_gitea --cmd CheckPreText
    else
      # /www/server/btgitea/middleware/go/code
      sudo chmod +x ${core_path}/middleware/lib/lib_gitea
      # 解决升级或者备份还原数据后无法push问题
      sudo ${core_path}/middleware/lib/lib_gitea --cmd CheckPreText
    fi

  fi

  echo '================================================'
  echo '操作完成'

  #设置权限
  chmod +x ${install_path}/operation.sh
  chmod +x ${core_path}/btgitservice
  ln -sf ${core_path}/btgitservice /etc/init.d/btgitservice
  chmod +x /etc/init.d/btgitservice

  #service giteaser start 启动服务
  # /etc/init.d/btgitservice start
  if [ "${PM}" == "yum" ] || [ "${PM}" == "dnf" ]; then
    /etc/init.d/btgitservice restart
  elif [ "${PM}" == "apt" ]; then
    sudo /etc/init.d/btgitservice restart
  fi

  #添加系统服务
  Service_Add

  if [ "${PM}" == "yum" ] || [ "${PM}" == "dnf" ]; then
    su - root <<EOF
  rm -rf  ${install_path}/core.zip
  rm -rf  ${install_path}/install.sh
  rm -rf  ${install_path}/install.py
EOF
  elif [ "${PM}" == "apt" ]; then
    sudo rm -rf ${install_path}/core.zip
    sudo rm -rf ${install_path}/install.sh
    sudo rm -rf ${install_path}/install.py
  fi

}

#卸载
Uninstall() {
  data_time=$(date "+%Y%m%d%H%M%S")
  cp ${core_path}/custom/conf/app.ini /www/backup/gitea/app_${data_time}.ini

  if [ "${PM}" == "yum" ] || [ "${PM}" == "dnf" ]; then

    su - root <<EOF
/etc/init.d/btgitservice stop >/dev/null 2>&1
rm -rf /etc/init.d/btgitservice
rm -rf $install_path
EOF
  elif [ "${PM}" == "apt" ]; then
    sudo /etc/init.d/btgitservice stop
    sudo rm -rf /etc/init.d/btgitservice
    sudo rm -rf $install_path
  fi
  Service_Del

}

#判断系统发行版本
Get_Dist_Name() {
  if grep -Eqii "CentOS" /etc/issue || grep -Eq "CentOS" /etc/*-release; then
    DISTRO='CentOS'
    PM='yum'
  elif grep -Eqi "Red Hat Enterprise Linux Server" /etc/issue || grep -Eq "Red Hat Enterprise Linux Server" /etc/*-release; then
    DISTRO='RHEL'
    PM='yum'
  elif grep -Eqi "Aliyun" /etc/issue || grep -Eq "Aliyun" /etc/*-release; then
    DISTRO='Aliyun'
    PM='yum'
  elif grep -Eqi "Fedora" /etc/issue || grep -Eq "Fedora" /etc/*-release; then
    DISTRO='Fedora'
    PM='yum'
  elif grep -Eqi "Debian" /etc/issue || grep -Eq "Debian" /etc/*-release; then
    DISTRO='Debian'
    PM='apt'
  elif grep -Eqi "Ubuntu" /etc/issue || grep -Eq "Ubuntu" /etc/*-release; then
    DISTRO='Ubuntu'
    PM='apt'
  elif grep -Eqi "Raspbian" /etc/issue || grep -Eq "Raspbian" /etc/*-release; then
    DISTRO='Raspbian'
    PM='apt'
  else
    DISTRO='unknow'
  fi
  echo $DISTRO
  echo $PM
}

#添加系统服务
Service_Add() {
#systemctl日志监听  参考文档 https://www.cnblogs.com/LC161616/p/13971370.html
# /etc/rsyslog.d/**.conf
# if $programname == 'programname' then /var/log/programname.log
# 停止往其他文件内写入，如果不加此句，会继续往/var/log/message写入。
# if $programname == 'programname' then stop  


  # journalctl -f -u  gitea.service   #查看服务运行日志（排查问题）
  # systemctl restart gitea.service 重启服务
  #systemctl daemon-reload 重新加载服务文件

  # 将gitea.service复制到如下目录即可实现服务
  # cp  ${PWD}/gitea.service /usr/lib/systemd/system/
  # ln  ${PWD}/gitea.service /usr/lib/systemd/system/
  # rm -rf /usr/lib/systemd/system/gitea.service

  # echo ${PM}
  if [ "${PM}" == "yum" ] || [ "${PM}" == "dnf" ]; then
    chkconfig --add btgitservice
    chkconfig --level 2345 btgitservice on

  elif [ "${PM}" == "apt" ]; then
    update-rc.d btgitservice defaults
  fi
}
#删除系统服务
Service_Del() {
  if [ "${PM}" == "yum" ] || [ "${PM}" == "dnf" ]; then
    chkconfig --del btgitservice
    chkconfig --level 2345 btgitservice off
  elif [ "${PM}" == "apt" ]; then
    update-rc.d btgitservice remove
  fi
}

Get_Dist_Name
#操作判断
if [ "${1}" == 'install' ]; then
  Install
elif [ "${1}" == 'uninstall' ]; then
  Uninstall
else
  echo 'Error!'
fi
