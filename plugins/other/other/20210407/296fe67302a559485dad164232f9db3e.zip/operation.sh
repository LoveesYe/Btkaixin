#!/bin/bash
install_path=/www/server/btgitea
if [ -x "/etc/init.d/btgitservice" ]; then
  service_file='/etc/init.d/btgitservice'
else
  service_file=${install_path}'/btgitservice'
  chmod +x ${service_file}
fi


if [ ! -x "${install_path}'/gitea'" ]; then
  chown root:root ${install_path}'/gitea'
  chmod +x ${install_path}'/gitea'
fi

#判断系统发行版本
Get_Dist_Name() {
  if grep -Eqii "CentOS" /etc/issue || grep -Eq "CentOS" /etc/*-release; then
    DISTRO='CentOS'
    PM='yum'
  elif grep -Eqi "Red Hat Enterprise Linux Server" /etc/issue || grep -Eq "Red Hat Enterprise Linux Server" /etc/*-release; then
    DISTRO='RHEL'
    PM='yum'
  elif grep -Eqi "Aliyun" /etc/issue || grep -Eq "Aliyun" /etc/*-release; then
    DISTRO='Aliyun'
    PM='yum'
  elif grep -Eqi "Fedora" /etc/issue || grep -Eq "Fedora" /etc/*-release; then
    DISTRO='Fedora'
    PM='yum'
  elif grep -Eqi "Debian" /etc/issue || grep -Eq "Debian" /etc/*-release; then
    DISTRO='Debian'
    PM='apt'
  elif grep -Eqi "Ubuntu" /etc/issue || grep -Eq "Ubuntu" /etc/*-release; then
    DISTRO='Ubuntu'
    PM='apt'
  elif grep -Eqi "Raspbian" /etc/issue || grep -Eq "Raspbian" /etc/*-release; then
    DISTRO='Raspbian'
    PM='apt'
  else
    DISTRO='unknow'
  fi
  echo $DISTRO
  echo $PM
}

Get_Dist_Name

if [ "${1}" == 'cache' ]; then
  rm -rf ${install_path}/custom/conf/app_tmp.ini
  cp ${install_path}/custom/conf/app.ini ${install_path}/custom/conf/app_tmp.ini
  sed -i '1i\[avirtualhead]' ${install_path}/custom/conf/app_tmp.ini
elif [ "${1}" == 'reduction' ]; then
  current=$(date "+%Y-%m-%d_%H%M%S")
  #mv  ${install_path}/custom/conf/app.ini  ${install_path}/custom/conf/.${current}app.ini
  rm -rf ${install_path}/custom/conf/app.ini
  cp ${install_path}/custom/conf/app_tmp.ini ${install_path}/custom/conf/app.ini
  #ed -i '1d' ${install_path}/custom/conf/app_tmp.ini
  sed -i "s/\[avirtualhead\]//g" ${install_path}/custom/conf/app.ini
  rm -rf ${install_path}/custom/conf/app_tmp.ini
elif [ "${1}" == 'service' ]; then
  if [ "${PM}" == "yum" ] || [ "${PM}" == "dnf" ]; then

    su - root <<EOF
${service_file} ${2}
EOF
  elif [ "${PM}" == "apt" ]; then
    sudo ${service_file} ${2}
  else
  echo   sudo ${service_file} ${2}
    sudo ${service_file} ${2}
  fi
else
  echo 'Error!'
fi
