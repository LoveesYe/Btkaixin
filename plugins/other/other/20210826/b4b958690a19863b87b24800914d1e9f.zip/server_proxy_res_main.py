#!/usr/bin/python
# coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: 麦乐  <1327444968@qq.com>
# +-------------------------------------------------------------------

#+--------------------------------------------------------------------
#|   服务器端口检测
#+--------------------------------------------------------------------
import sys,os,json,re
os.chdir("/www/server/panel")
sys.path.append("class/")
import public
import files
import platform
import re
class server_proxy_res_main:
    __plugname="server_proxy_res"
    __root = os.getcwd().replace("panel", "").replace("\\", "/")  # 面板根目录
    __plug_path="%spanel/plugin/%s/"%(__root,__plugname)
    __app_path="%s/%s/"%(__root,__plugname)
    __logs_path="%s/logs/"%(__app_path)
    __conf_file = "%sconfig.cfg.json"%(__app_path)
    __conf_file_bak = "%sconfig.cfg.bak"%(__app_path)
    __config="%sinfo.json"%(__plug_path)


    def __init__(self):
        self.config=json.loads(public.ReadFile(self.__config))
        try:
            lists = os.listdir(self.__logs_path) # 列出目录的下所有文件和文件夹保存到lists
            lists.sort(key=lambda fn: os.path.getmtime(self.__logs_path+fn)) # 按时间排序
            self.__log_file = os.path.join(self.__logs_path, lists[-1])      # 获取最新的文件保存到file_new
        except Exception as e:
             self.__log_file = os.path.join(self.__logs_path, "log.log")      # 获取最新的文件保存到file_new
        self.___server_file = "%sserver-%s.exe"%(self.__app_path,self.ostype()) if self.ostype() =="win" else "%sserver-%s"%(self.__app_path,self.ostype())
        # self.___server_file = "%s%s.exe"%(self.__app_path,self.__plugname) if self.ostype() =="win" else "%s%s"%(self.__app_path,self.__plugname)
        return

    # 读取n行
    def GetLines(self,fname,linecount=1):
        data=[]
        with open(fname, 'rb') as f:  # 打开文件
            lines = f.readlines()  # 读取文件指针范围内所有行
            i=0
            while True:
                if i>=linecount or i>=len(lines):
                    break
                data.append(lines[i].decode())
                i=i+1
            f.close()    
        return data

    def GetLastLines(self,fname,linecount=1):
        data=[]
        with open(fname, 'rb') as f:  # 打开文件
            lines = f.readlines()  # 读取文件指针范围内所有行
            i=len(lines)
            while True:
                i=i-1
                if i<len(lines)-linecount or i<=0:
                    break
                data.append(lines[i].decode())
            f.close()    
        return data
               
    #设置常用配置配置
    def SetConf(self,get):
        if "config" not in get:get.config=""
        _conf=get.config
        if _conf.strip() == "" : return public.returnMsg(False, "保存失败")
        try:
            __conf=self.toJson(_conf)
            __conf=str(json.loads(__conf))
            
            public.writeFile(self.__conf_file,_conf)
            #备份配置
            public.writeFile(self.__conf_file_bak,_conf)
            return public.returnMsg(True, '保存成功')
        except Exception as e:
            return public.returnMsg(False,"保存失败，格式不正确%s%s"%(__conf,str(e)))    
       


    # 读取常用配置
    def GetConf(self,get):
        try:
            _conf = public.readFile(self.__conf_file)
            # _conf=self.toJson(_conf)
            # _conf=str(json.loads(_conf))

            result = {
                "data":_conf,
                "conf":self.__conf_file,
                "isexists":os.path.exists(self.__conf_file),
                "status":True,
            }
            return result

        except Exception as e:
            return public.returnMsg(False,str(e))

    def format(self,text):
        import re
        text=text.replace("\\","")
        text=text.replace("\u001b","")
        text=re.sub('\[([\d]*)m',"",text)
        text=re.sub('x(\d{1})b',"",text)
        return text
    # 读取日志
    def GetLogs(self,get):
        if "lines" not in get:get.lines=50
        try:
            _logs="".join(self.GetLastLines(self.__log_file,get.lines))
            result = {
                "data":self.format(_logs),
                "log":self.__log_file,
                "status":True,
            }
            return result

        except Exception as e:
            return public.returnMsg(False,str(e))
    
    def install(self,get):
        # return self.config
        cmd="cd %s && %s install %s %s"%(self.__app_path,self.___server_file,self.__plugname,self.config["ps"])
        data=self.exec(cmd)
        if("success"  in data):
              return public.returnMsg(True,"服务%s安装成功"%(self.__plugname))
        else:
              return public.returnMsg(False,"服务%s安装失败"%(self.__plugname))

    def uninstall(self,get):
        cmd="cd %s && %s uninstall %s"%(self.__app_path,self.___server_file,self.__plugname)
        data=self.exec(cmd)
        if("success"  in data):
              return public.returnMsg(True,"服务%s卸载成功"%(self.__plugname))
        else:
              return public.returnMsg(False,"服务%s卸载失败"%(self.__plugname))

    def service_state(self,get):
       if "name" not in get:get.name=self.__plugname
       if "type" not in get:get.type="status"
       cmd = "/etc/init.d/"+get.name+" "+get.type
       if get.type=="status":
          cmd="ps aux|grep %s|grep -v grep|awk '{print $2}'"%(self.__plugname)
       data=self.format(self.exec(cmd))
       if data=="": return public.returnMsg(False,"%s 服务未安装"%(get.name))
       if get.type=="reload"  :
          if "Started" in data: return public.returnMsg(True,"%s服务重载成功"%(get.name)) 
       if get.type=="restart"  :
          if "Started" in data: return public.returnMsg(True,"%s服务重启成功"%(get.name)) 
       if get.type=="start" :
          if "Started" in data: return public.returnMsg(True,"%s服务启动成功"%(get.name)) 
       if get.type=="stop" :
          if "Stoped" in data: return public.returnMsg(True,"%s服务停止成功"%(get.name)) 
       
       if get.type=="status":
           state=(data.strip()!="")
           data="运行中" if data.strip()!=""  else "已停止"
           return public.returnMsg(state,data)

       return public.returnMsg(True,data)

    def ostype(self):
        sysstr = platform.system()
        if(sysstr =="Windows"):
            return "win"
        elif(sysstr == "Linux"):
            return "linux"
        else:
            return "macos"
    def toJson(self,str):
        str=re.sub(r'(\n|\r|\s)\s*\/\/.*(?:\r|\n|$)','',str)
        return str
    def exec(self, cmd):
        data=public.ExecShell(cmd)
        if(isinstance(data,str)):
            return data
        elif(isinstance(data,tuple) and len(data)>1):
            return data[0]
