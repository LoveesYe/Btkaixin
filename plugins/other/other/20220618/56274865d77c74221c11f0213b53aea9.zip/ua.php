<?php
return [
    'Baiduspider'=>'百度搜索',
//    'Baiduspider|Mobile'=>'百度移动',
    'Baiduspider-image'=>'百度图片',
    'Sogou'=>'搜狗搜索',
    'QIHU'=>'360搜索',
    '360Spider'=>'360搜索',
    'bingbot'=>'必应搜索',
    'Googlebot'=>'谷歌搜索',
    'YisouSpider'=>'神马搜索',
    'AhrefsBot'=>'AhrefsBot',
    'PetalBot'=>'华为搜索',
    'Applebot'=>'Apple搜索',
    'DotBot'=>'DotBot',
    'Chrome'
];