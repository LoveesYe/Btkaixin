<?php
require  'sync.php';
$sync = new Sync();
$sync->sync_log(60);