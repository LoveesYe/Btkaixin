<?php
use Medoo\Medoo;
trait UrlTool {
    function  format_url($host,$urls)
    {
        $tool = new tool();
        $config = $tool->get_config_json()[$host];
        if(empty($urls)){
            return [];
        }
        $gl = $config['gl'];
        $rep_str = $config['rep'];
        foreach ($urls as $key=>$url){
            if($config['xieyi'] == 'https://'){
                $urls[$key] =  str_replace('http://','https://',$url);
            }
        }
        //排除
        if(!empty($gl)){
           $urls =  $this->rm_str($gl,$urls);
        }
        if(!empty($rep_str)){
            $urls = $this->rep_str($rep_str,$urls);
        }
        return array_unique($urls);
    }
    function rep_str($rep_str,$urls)
    {
        foreach ($urls as &$url){
            if(preg_match("/#/",$rep_str)){
                $arr = explode('#',$rep_str);
                foreach ($arr as $v){
                    list($orgin,$new) = explode('=',$v);
                    $url = str_replace($orgin,$new,$url);
                }
            }else{
                list($orgin,$new) = explode('=',$rep_str);
                $url = str_replace($orgin,$new,$url);
            }
        }

        return $urls;
    }
    function rm_str($rm_str,$urls)
    {
        foreach ($urls as $key=>$url){
            if(preg_match("/#/",$rm_str)){
                $arr = explode('#',$rm_str);
                foreach ($arr as $v){
                    if(preg_match("/".$v."/",$url)){
                        unset($urls[$key]);
                    }
                }
            }else{
                if(preg_match("/".$rm_str."/",$url)){
                    unset($urls[$key]);
                }
            }
        }
        return $urls;
    }
}




class tool {
    public function __construct()
    {
        define('DS',PHP_EOL);
        define('BT_DB',__DIR__.'/../../data/default.db');
        define('PLU_DB',__DIR__.'/web.db');
        define('PLUGIN_NAME','urlpush');
        define('RUNTIME_DIR',__DIR__.'/runtime');
        define('STATIC_DIR',__DIR__.'/static');
        $os = get_os();
        if(get_os() == 'linux'){
            define("LOG_PATH",__DIR__.'/../../../../wwwlogs');
        }else{
            define("LOG_PATH",__DIR__.'/../../../wwwlogs');
        }
    }
    function update_remain($host,$type,$remain)
    {
        $this->db()->update('web',[
            $type=>$remain
        ],[
            'host'=>$host
        ]);
    }
    function bt_db(){
        return new medoo([
            'database_type' => 'sqlite',
            'database_file' => BT_DB
        ]);
    }
    function db(){
        return new medoo([
            'database_type' => 'sqlite',
            'database_file' => PLU_DB
        ]);
    }
    function get_config_json(){
        $arr = $this->db()->select('web','*');
        $data = [];
        foreach ($arr as $v){
            $host = $v['host'];
            $data[$host] = $v;
        }
        return $data;
    }
    function add_history($host,$type,$urls)
    {
        $config = $this->get_config_json()[$host];
        foreach ($urls as $url){
            $res = $this->db()->get('history','*',[
                'host'=>$host,
                'type'=>$type,
                'url'=>$url
            ]);
            if(empty($res)){
                $this->db()->insert('history',[
                    'host'=>$host,
                    'type'=>$type,
                    'url'=>$url,
                    'num'=>1,
                    'create_time'=>time()
                ]);
            }else{
                $this->db()->update('history',[
                    'num'=>$res['num']+1
                ],[
                    'host'=>$host,
                    'type'=>$type,
                    'url'=>$url
                ]);
            }
        }
        //删除数据
        $this->db()->delete('history',[
            'create_time[<]'=>time()-3*24*3600
        ]);
    }
}