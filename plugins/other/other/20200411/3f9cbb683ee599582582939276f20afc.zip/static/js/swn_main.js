var swn  = {
    PageLoad:function(page){
       var pagelist = ['index','about','extand',"logevent"];
            if(in_list(pagelist,page))
            {
               request_plugin("PageLoad",{"page":page},function (rdata) {
                    if(rdata["status"]!="Success")
                    {
                        $("div.plugin_body").html("Something Bad Happend ...");
                        layer.msg("出错啦！Msg:"+rdata["msg"],{icon:5});
                    }
                    else
                    {
                        $("div.plugin_body").html(rdata["html"]);
                        swn.PageData(page);
                    }
                });
            }
            else console.log("Uncorrect Static Page Request!");
    },


    PageData:function(page){
        switch (page) {
            case "index":       swn.LoadPage_Index();       break;
            case "extand":      swn.LoadPage_Extand();      break;
            case "logevent":    swn.LoadPage_LogEvent();    break;
        }
    },

    LoadPage_Index:function(){
        request_plugin("GetMailConfig","",function(rdata){
            $("#swn_service_status_on").css("display","none");
            $("#swn_service_status_off").css("display","none");

            // 服务状态显示
            if(rdata["Config"]["MailService"]=="Run") $("#swn_service_status_on").css("display","block");
            else  $("#swn_service_status_off").css("display","block");

            $("#swn_crontab_hour").val(rdata["Config"]["MailTime_Hour"]);
            $("#swn_crontab_minute").val(rdata["Config"]["MailTime_Minute"]);
            $("#swn_mailtype").val(rdata["Config"]["MailSendType"]);

            var num = rdata["Config"]["MailReceive"].length;
            if(num!=0){
                var html = '<tr><td colspan="2" width="85%">在这里配置接受邮件的用户邮箱，最多可以添加5个邮箱</td><td><button class="btn btn-success btn-sm" type="button" onclick="swn.AddMailReceive()"><i class="fa fa-plus-circle" style="color:white" aria-hidden="true"></i>添加收件用户</button></td></tr><tr><td width="30%">收件地址</td><td width="55%">备注信息</td><td>操作</td></tr>';
                for(var i=0;i<num;i++){
                    var data = rdata["Config"]["MailReceive"][i];
                    html = html + "<tr><td>" + data["MailAddress"] + "</td><td>"+ data["MailPs"] +"</td><td>"+
                        '<button class="btn btn-danger btn-sm" style="background-color: red" type="button" mail="'+data["MailAddress"]+'" onclick="swn.ReceiveMail_DEL(this)"><i class="fa fa-trash" style="color:white" aria-hidden="true"></i>删除</button>'+
                        '</td></tr>';
                }
                $("#swn_MailReceiveTable").html(html);
            }
        }, request_timeout);
    },

    LoadPage_Extand:function(){
      request_plugin("GetSafeClubRe","",function(rdata){
          if(rdata["status"]=="success"){
              var html = "";
              var num = rdata["SafeClub"].length;
              for(var i=0;i<num;i++){
                  var data = rdata["SafeClub"][i];
                  html = html + "<tr><td><img src=\""+data["icon"] + "\" width=\"15px\">&nbsp;&nbsp;&nbsp;<a href=\""+data["softurl"] + "\" class=\"btlink\">"+ data["softname"] + "</a></td><td>" + data["des"] + "</td><td>" + data["time"] + "</td></tr>";
              }
              $("#ExtandList_Table").html(html);
          }
      }, request_timeout);
    },

    LoadPage_LogEvent:function(){
         request_plugin("GetSafeEvent","",function(rdata){
          if(rdata["status"]=="success"){
              Lpage = 1; Ldata = rdata["SafeEvent"];
              swn.LoadEventPageData();
          }
      }, request_timeout);

    },

    LoadEventPageData:function(){
         var s,e; var html= "";
         var q,mpage;q=Ldata.length % pnum;
         if(q==0) mpage = (Ldata.length/pnum); else mpage = (Ldata.length-q)/pnum + 1;
         if(mpage==0) mpage =1;
         s = (Lpage-1)*pnum;e = (Lpage)*pnum;
         if(e>=Ldata.length) e =Ldata.length;
         if(Ldata.length == 0) $("#ExtandList_Table").html("<tr><td colspan=\"4\">暂无数据</td></tr>");
         else{
             for(var i=s;i<e;i++)
            {
               var data = Ldata[i];
               html = html + "<tr><td>"+(i+1)+ "</td><td><a href=\""+data["EventURL"]+"\" class=\"btlink\" target=\"_blank\">"+data["EventTitle"] + "</a></td><td>"+data["EventTime"]+"</td><td>";
               if(data["EventStatus"] == "success")     var status = "<span style=\"color：green\">已发送</span>";
               else if(data["EventStatus"]=="wait")   var status = "<span style=\"color: orange\">等待发送</span>";
               else status = "<span style=\"color: red\">发送失败</span>";
               html = html + status + "</td></tr>"
            }
        $("#ExtandList_Table").html(html);
         }
        $("#Page_Content").html("当前 "+Lpage +" 页/共 "+mpage +" 页");
    },

    LoadEventPageLeft:function(){
        if(Lpage==1) layer.msg("[错误]已经是第一页了!",{icon:5,time:1200});
        else {Lpage = Lpage -1;swn.LoadEventPageData();}
    },

    LoadEventPageRight:function(){
         var q,mpage;q=Ldata.length % pnum;
         if(q==0) mpage = (Ldata.length/pnum); else mpage = (Ldata.length-q)/pnum+1;
         if(mpage==0) mpage =1;
         if(Lpage==mpage) layer.msg("[错误]已经是最后一页了!",{icon:5,time:1200});
         else {Lpage = Lpage +1;swn.LoadEventPageData();}
    },

    AddMailReceive:function () {
        layer_iframe=layer.open({
            type: 1,
            title:"添加收件人信息",
            closeBtn: 0,
            shadeClose:true,
            anim: 2,
             area: ['380px', '30%'],
            content:' <div class="divtable mtb10"><div class="tablescroll"><table class="table table-hover" border="1">' +
                '<tr><td>收件地址</td><td><input id="swn_mail_mailaddress" class="form-control" style="width: 220px;"></td></tr>'+
                '<tr><td>备注信息</td><td><input id="swn_mail_ps" class="form-control" style="width: 220px;"></td></tr><tr><td colspan="2" align="center">'+
                '<button class="btn btn-success btn-sm" type="button" onclick="swn.AddMail_OK()"><i class="fa fa-check"" style="color:white" aria-hidden="true"></i>添加</button>'+
                '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'+
                '<button class="btn btn-danger btn-sm" type="button" onclick="swn.AddMail_NO()"><i class="fa fa-times"" style="color:white" aria-hidden="true"></i>取消</button>'+
                '</td></tr></table></div></div>'
        });
    },

    ReceiveMail_DEL:function(dom){
      request_plugin("DelMailReceive","MailAddress="+dom.getAttribute("mail"),function (rdata){
           if(rdata["status"]!="Success") {layer.msg("删除收件人失败!服务器返回的消息:"+rdata["msg"],{icon:5,time:3600});}
            else {
                 swn.PageLoad("index");
                  layer.msg("删除收件人成功",{icon:1,time:3600});
            }
      })
    },

    AddMail_OK:function(){
        var mail = {"MailAddress":$("#swn_mail_mailaddress").val(),"MailPs":$("#swn_mail_ps").val()};
        request_plugin("AddMailReceive",mail,function(rdata){
            layer.close(layer_iframe);
            if(rdata["status"]!="Success") {layer.msg("添加收件人失败!服务器返回的消息:"+rdata["msg"],{icon:5,time:3600});}
            else {
                  swn.LoadPage_Index();
                  layer.msg("添加收件人成功",{icon:1,time:3600});
            }
        },request_timeout)

    },

    AddMail_NO:function () {
        layer.close(layer_iframe);
    },

    Service_Start:function () {
         request_plugin("Service_StartCrontab","",function (rdata){
           if(rdata["status"]=="Success") {swn.LoadPage_Index();layer.msg("启动服务成功！",{icon:1,time:3600});}
           else {swn.LoadPage_Index();layer.msg("启动服务失败！未知错误!",{icon:1,time:3600});}
      })
    },

     Service_Stop:function () {
         request_plugin("Service_StopCrontab","",function (rdata){
           if(rdata["status"]=="Success") {swn.LoadPage_Index();layer.msg("停止服务成功！",{icon:1,time:3600});}
           else {swn.LoadPage_Index();layer.msg("停止服务失败！未知错误!",{icon:1,time:3600});}
      })
    },

    ServiceConfigSave:function () {
        request_plugin("SetMailConfig","MailTime_Hour="+$("#swn_crontab_hour").val()+"&MailTime_Minute="+$("#swn_crontab_minute").val()+"&MailSendType="+$("#swn_mailtype").val(),function (rdata){
           if(rdata["status"]=="Success") {swn.LoadPage_Index();layer.msg("保存配置成功！",{icon:1,time:3600});}
           else {swn.LoadPage_Index();layer.msg("保存配置失败！未知错误!",{icon:1,time:3600});}
      })
    },

    SendTestMail:function() {
        layer_wait = layer.msg("邮件发送中，请稍候...",{time:false})
        request_plugin("SendTestMail", "", function (rdata) {
            layer.close(layer_wait);
            if (rdata["status"] == "success") layer.msg(rdata["msg"], {time: 1800, icon: 1});
            else layer.msg(rdata["msg"], {time: 1800, icon: 5});
        },100000);
    }
}