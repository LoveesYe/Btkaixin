#!/usr/bin/python
# coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyright (c) 2020 吴先森(https://www.wunote.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: 吴先森 <i@mr-wu.top>
# +-------------------------------------------------------------------

import sys,os,json

os.chdir("/www/server/panel")

sys.path.append("class/")
import public

if __name__ != '__main__':
    from BTPanel import cache,session,redirect


class dnspod_record_main:
    __plugin_path = "/www/server/panel/plugin/dnspod_record/"
    __config = None

    def  __init__(self):
        pass


    def _check(self,args):
        return True

    #访问/dnspod_record/index.html时调用的默认方法，需要在templates中有index.html，否则无法正确响应模板
    def index(self,args):
        return self.get_logs(args)
    
    def get_domain_id(self,args):
        f = json.load(open("/www/server/panel/plugin/dnspod_record/login.json"))
        url = 'https://dnsapi.cn/Domain.List'
        par = {'login_token':f['userid']+','+f['token'],'format':'json'}
        apireturn=json.loads(public.HttpPost(url,par,timeout=60))
        return apireturn

    def save_token(self,args):
        url = 'https://dnsapi.cn/Domain.List'
        par = {'login_token':args.userid+','+args.token,'format':'json'}
        apireturn=json.loads(public.HttpPost(url,par,timeout=60))
        if(apireturn['status']['code']=='1'):
            dict_var = {
                'token': args.token, 
                'userid': args.userid,
            }
            with open('/www/server/panel/plugin/dnspod_record/login.json', "w") as f:
                json.dump(dict_var, f,indent=2,sort_keys=True, ensure_ascii=False)  # 写为多行
            return {'msg': '保存成功！','apireturn':apireturn,'status':1 }
        else:
            return {'msg': '无法连接DnsPod，请检查您输入是否正确！API返回消息已经打印在Console中，如果需要您可以查看','apireturn':apireturn,'status':0}

    def get_token(self,args):
        f = open("/www/server/panel/plugin/dnspod_record/login.json")
        return json.load(f)

    def get_all(self,args):
        f = open("/www/server/panel/plugin/dnspod_record/config.json")
        return json.load(f)

    def save_domainId(self,args):
        url = 'https://dnsapi.cn/Record.List'
        f = json.load(open("/www/server/panel/plugin/dnspod_record/login.json"))
        par = {'login_token':f['userid']+','+ f['token'],'domain_id':args.domainId,'format':'json'}
        apireturn=json.loads(public.HttpPost(url,par,timeout=60))
        if(apireturn['status']['code']=='1'):
            dict_var = {
                'domainId': args.domainId,
                'domain': args.Domain,
                'token': f['token'], 
                'userid': f['userid']
            }

            with open('/www/server/panel/plugin/dnspod_record/config.json', "w") as f:
                json.dump(dict_var, f,indent=2,sort_keys=True, ensure_ascii=False)  # 写为多行
            return {'msg': '成功选择！快去\'解析设置\'选项卡设置解析吧！','apireturn':apireturn,'status':1 }
        else:
            return {'msg': '出现意料之外的错误！请尝试重启插件或联系开发者！','apireturn':apireturn,'status':0}
    
    def config_delete(self,args):
        if os.path.exists('/www/server/panel/plugin/dnspod_record/login.json'):
            os.remove('/www/server/panel/plugin/dnspod_record/login.json')
        if os.path.exists('/www/server/panel/plugin/dnspod_record/config.json'):
            os.remove('/www/server/panel/plugin/dnspod_record/config.json')
            
    def config_exists(self,args):
        f = open("/www/server/panel/plugin/dnspod_record/info.json")
        plugin_config = json.load(f)
        if(public.md5(plugin_config['checks'])=='8d9a8e2f69fcb23ede83781211c3c45f'):
            return os.path.exists('/www/server/panel/plugin/dnspod_record/login.json')
        else:
            return 0

    def config_exists_d(self,args):
        return os.path.exists('/www/server/panel/plugin/dnspod_record/config.json')
        
    def get_config(self,args):
        f = open("/www/server/panel/plugin/dnspod_record/login.json")
        login_config = json.load(f)
        url = 'https://dnsapi.cn/Domain.Info'
        par = {'login_token':login_config['userid']+','+login_config['token'],'domain_id':login_config['domainId'],'format':'json'}
        apireturn=json.loads(public.HttpPost(url,par,timeout=60))
        if(str(apireturn['status']['code'])=='1'):
            domain=apireturn['domain']['name']
        else:
            domain='获取失败'
        return {'token':login_config['token'],'userid':login_config['userid'],'domainId':login_config['domainId'],'domain':domain}

        
    def record_get(self,args):
        f = open("/www/server/panel/plugin/dnspod_record/config.json")
        login_config = json.load(f)
        url = 'https://dnsapi.cn/Record.List'
        par = {'login_token':login_config['userid']+','+login_config['token'],'domain_id':login_config['domainId'],'format':'json'}
        return json.loads(public.HttpPost(url,par,timeout=60))
        
    def record_remove(self,args):
        f = open("/www/server/panel/plugin/dnspod_record/config.json")
        login_config = json.load(f)
        url = 'https://dnsapi.cn/Record.Remove'
        par = {'login_token':login_config['userid']+','+login_config['token'],'domain_id':login_config['domainId'],'record_id':args.recordId,'format':'json'}
        return json.loads(public.HttpPost(url,par,timeout=60))
        
    def record_create(self,args):
        f = open("/www/server/panel/plugin/dnspod_record/config.json")
        login_config = json.load(f)
        url = 'https://dnsapi.cn/Record.Create'
        par = {'login_token':login_config['userid']+','+login_config['token'],'domain_id':login_config['domainId'],'sub_domain':args.recordName,'record_type':args.RecordType,'record_line':args.recordLine,'value':args.RecordValue,'format':'json'}
        return json.loads(public.HttpPost(url,par,timeout=60))

    def record_modify(self,args):
        f = open("/www/server/panel/plugin/dnspod_record/config.json")
        login_config = json.load(f)
        url = 'https://dnsapi.cn/Record.Modify'
        par = {'login_token':login_config['userid']+','+login_config['token'],'domain_id':login_config['domainId'],'sub_domain':args.recordName,'record_id':args.recordId,'record_type':args.RecordType,'record_line':args.recordLine,'value':args.RecordValue,'mx':'0','format':'json'}
        return json.loads(public.HttpPost(url,par,timeout=60))
        
    def __get_config(self,key=None,force=False):
        if not self.__config or force:
            config_file = self.__plugin_path + 'config.json'
            if not os.path.exists(config_file): return None
            f_body = public.ReadFile(config_file)
            if not f_body: return None
            self.__config = json.loads(f_body)

        if key:
            if key in self.__config: return self.__config[key]
            return None
        return self.__config

    def __set_config(self,key=None,value=None):
        if not self.__config: self.__config = {}

        if key:
            self.__config[key] = value

        config_file = self.__plugin_path + 'config.json'
        public.WriteFile(config_file,json.dumps(self.__config))
        return True

