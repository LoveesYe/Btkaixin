#!/usr/bin/python
# coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: MrChen <857388489@qq.com>
# +-------------------------------------------------------------------

# +--------------------------------------------------------------------
# |   域名whois查询
# +--------------------------------------------------------------------
import json
import os
import sys

# 设置运行目录
os.chdir("/www/server/panel")

# 添加包引用位置并引用公共包
sys.path.append("class/")
import requests, json

# 在非命令行模式下引用面板缓存和session对象
if __name__ != '__main__':
    from BTPanel import cache, session, redirect


class whois_main:
    __plugin_path = "/www/server/panel/plugin/whois/"
    __recent_path = "/www/server/panel/plugin/whois/recent.json"
    __config = None

    # 构造方法
    def __init__(self):
        pass

    def check(self, args):
        url = '''https://whois.22.cn/Api.aspx?auth=btplugin&domain=%s&format=json&detail=%s''' %(args.domain,args.detail)
        data = requests.get(url, timeout=60)
        try:
            jsonData = data.json()
        except:
            return {'status': 0, 'msg': '程序发生错误，请联系作者修复!'}
        else:
            if json.dumps(jsonData)=="未授权":
                return {'status': 0, 'msg': '接口未授权！'}
            dataList = self.getRecentList()
            res={"domain": args.domain, "result": jsonData}
            if res in dataList:
                dataList.remove(res)
            if len(dataList)==10:
                dataList.pop()
            dataList.insert(0,res)
            with open(self.__recent_path, mode='w') as f:
                json.dump(dataList, f)
                f.close()
                return jsonData

    def recent(self, args):
        data = self.getRecentList()
        return data

    def getRecentList(self):
        with open(self.__recent_path, mode='r') as f:
            data = json.load(f)
            f.close()
            return data
