<?php
require 'vendor/autoload.php';
require  'medoo.php';

use QL\QueryList;
use QL\Ext\AbsoluteUrl;

/**
 * 开发者    阿修罗 2020/4/26
 * 联系方式  email whndeweilai@163.com
 * QQ       610176732
 * Class    bt_main
 */
class bt_main{


    public $post;
    public $get;
    public $database;
    

	//不允许被面板访问的方法请不要设置为公有方法
    function __construct()
    {
        define("DS","/");
        define("STATIC_FILE",PLU_PATH."/static/");
        ini_set('max_execution_time',0);
        ini_set('memory_limit','512m');
        $this->get = $this->trim_arr(_get());
        $this->post = $this->trim_arr(_post());
        
        $db_config = self::read_web_config();
        $this->database =   [
            // 必须配置项
            'database_type' => 'mysql',
            'database_name' => $db_config['database'],
            'server' => $db_config['host'],
            'username' => $db_config['username'],
            'password' => $db_config['password'],
            'charset' => 'utf8',
            'port' => $db_config['port'],
            'prefix' => $db_config['prefix'],
        ];
    }
	//获取标题
	function get_html(){
	    $param = _post();
	    $host = trim($param['host']);
	    $title_rule = trim($param['title_rule']);
        $content_rule = trim($param['content_rule']);
        $status = $param['status'];
        $rules = [
            'title'=>[$title_rule,'text'],
            'content'=>[$content_rule,'html']
        ];
        //$rt = QueryList::get($host)->rules($rules)->query()->getData();
        $rt = $this->get_one_content($host,$rules);
        
        $this->success('success',$rt);
    }
  
    function get_one_content($host,$rules){
        $rt = QueryList::get($host)->rules($rules)->query()->getData();
        return $rt;
    }

    function get_list_content($host,$rules,$range){
        //$range  = trim($post['range_rule']);
        $ql = QueryList::getInstance();
        $ql->use(AbsoluteUrl::class);
        $ql = QueryList::get($host)
            ->rules($rules)
            ->range($range)
            ->query()
            ->getData(function ($item) use ($ql,$host){
                $item['link'] = $ql->absoluteUrlHelper($host,$item['link']);
                return $item;
            });
        //转换绝对链接
         return $ql->all();
    }

    //获取列表
    function  do_get_list(){
        $post = $this->trim_arr($this->post);
        if( empty($post['range_rule']) || empty($post['host']) || empty($post['link_rule'])  ){
            $this->error('请输入必要信息');
        }
        
        $host = $post['host'];
//        $ql = QueryList::getInstance();
//        $ql->use(AbsoluteUrl::class);
//或者自定义函数名
        
        $rules = [
//            'title'=> [$post['title_rule'],'text'],
            'link' => [$post['link_rule'],'href'],
            'img'  =>  [$post['thump_rule'],'src'],
//            'desc' => [$post['desc_rule'],'text']
        ];
        
        if(empty($post['thump_rule'])){
            $rules = [
//                'title'=> [$post['title_rule'],'text'],
                'link' => [$post['link_rule'],'href'],
//                'desc' => [$post['desc_rule'],'text']
            ];
        }
        
        
        $range  = trim($post['range_rule']);
//        $ql = QueryList::get($post['host'])
//                ->rules($rules)
//                ->range($range)
//                ->query()
//                ->getData(function ($item) use ($ql,$post){
//                    $item['link'] = $ql->absoluteUrlHelper($post['host'],$item['link']);
//                    return $item;
//                });
//        //转换绝对链接
//        $data=$ql->all();
        $data = $this->get_list_content($host,$rules,$range);
        //$this->push_sql($data);
        $this->success('success',$data);
    }
    
    
    function get_web_list(){
        $config = self::read_config();
        $rule_list = "";
        foreach ($config as $key=>$val){
            $rule_list .= "<option value='".$key."'>采集对象:".$key."</option>";
        }
        $this->success('success',[
            'rule_list'=>$rule_list
        ]);
    }
    
    function save_web_config(){
        $param = $this->post;
        file_put_contents(STATIC_FILE."web_config",serialize($param));
        $this->success();
    }
    
    function get_web_config(){
        $web_config = self::read_web_config();
        $this->success('success',$web_config);
        
    }
    
    //获取分类
    function  ds_form(){
        $web_config = self::read_web_config();
        $database = new medoo($this->database);
        
        $cat_list = '';
        if($web_config['cms_type']=='typecho'){
            $cat = $database->select('metas',['mid','name'],['type'=>'category']);
            if(empty($cat)){
                $this->error('请填写完整正确的【网站配置】以获取数据库访问权限');
            }
            foreach ($cat as $val){
                $cat_list .= "<option value='".$val['mid']."'>".$val['name']."</option>";
            }
        }
        $config = self::read_config();
        $rule_list = '';
        foreach ($config as $key=>$val){
                $rule_list .= "<option value='".$key."'>".$key."</option>";
        }
        
        $this->success('success',[
            'cat_list'=>$cat_list,
            'rule_list'=>$rule_list
        ]);
    }
    
    public function getPath(){
        $web_config = self::read_web_config();
        $this->json([
            'path'=>PLU_PATH."/console.php",
            'dir'=> PLU_PATH,
            'myurl'=> $web_config['myurl']
        ]);
    }
    
    
    //手动爬取内容
    function push_sql($data){
        foreach ($data as $val){
            $host = $val['link'];
            $rules = [
                'title'=>[".topic-3bY8Hw-9",'text'],
                'content'=>[".main_content-LcrEruCc",'html']
            ];
            $content =  $this->get_one_content($host,$rules);
            $this->insert_typecho_database($content['title'],$content['content'] );
        }
    }
    
  
    function insert_typecho_database($title,$content){
        $database = new medoo($this->database);
        //插入之前检测是否重复
        $res = $database->select('contents','*',['title'=>$title]);
        if(!empty($res)){
            return;
        }
        
        $id =  $database->insert("contents", [
            "title" => $title,
            "text"  => $content,
            'type'  => 'post',
            'allowComment'=>1,
            'allowPing'=>1,
            'allowFeed'=>1,
            'authorId'=>1,
            'created' => time(),
            'modified' => time()
        ]);
        //更新slug
        $database->update('contents',[
            'slug'  => $id
        ],['title'=>$title]);
        //更新分类id
        $rid = $database->insert('relationships',[
            'cid'=>$id,
            'mid'=>1
        ]);
    }
    function get_rule_config(){
        $url = trim(_post()['url']);
        $config = self::read_config();
        $rule_config= $config[$url];
        $this->success('success',[
            'rule_config'=>$rule_config
        ]);
    }
    
    
    function get_rule_list(){
        $config  = self::read_config();
        $table  = '';
        if(empty($config)){
            $this->success('success',[
                'table'=> $table
            ]);
        }
        foreach ($config as $val){
            $url = $val['url'];
            $table.= <<<EOF
<tr>
<td>$url</td>
<td><button onclick="show_edit_rule('$url')" class="btn btn-success btn-xs">编辑</button>&nbsp; <button onclick="del_rule('$url')" class="btn  btn-xs">删除</button></td>
</tr>
EOF;
 
        }
        $this->success('success',[
            'table'=>$table
        ]);
    }
    
    function  del_rule(){
        $url = trim(_post()['url']);
        $config = self::read_config();
        unset($config[$url]);
        file_put_contents(STATIC_FILE."config",serialize($config));
        $this->success('删除成功!');
    }
    
    function set_rule(){
        $param =  $this->trim_arr(_post());
        if(empty($param['url'])   ){
            $this->error('网址不能为空');
        }
        $res =  self::put_config($param);
        if($res){
            $this->success();
        }
        $this->error('保存出错');
    }
    
    static function put_config($param){
        if(empty($param)){
            return false;
        }
        $config = self::read_config();
        $config[$param['url']] = $param;
        file_put_contents(STATIC_FILE."config",serialize($config));
        return true;
    }
    function put_web_config($param){
        if(empty($param)){
            return false;
        }
        $config = self::read_config();
        $config[$param['myurl']] = $param;
        file_put_contents(STATIC_FILE."web_config",serialize($config));
        return true;
    }
    static function read_config(){
        $config =  file_get_contents(STATIC_FILE."config");
        return unserialize($config);
    }
    static function read_web_config(){
        $config =  file_get_contents(STATIC_FILE."web_config");
        return unserialize($config);
    }
    //success
    protected function success($msg = 'success',$data = null){
        $this->json([
            'code'=>0,
            'msg'=>$msg,
            'data'=>$data
        ]);
    }
    //error
    protected function error($msg){
        $this->json([
            'code'=>-1,
            'msg'=>$msg,
        ]);
    }
    //获取json数据
    public function json($data){
        echo json_encode($data);
        exit;
    }

    function trim_arr($arr){
        if(empty($arr)){
            return $arr;
        }
        foreach ($arr as &$val){
            $val = trim($val);
        }
        return $arr;
    }
    
    function about(){
        try{
            @$json = json_decode(file_get_contents('https://www.waytomilky.com/notice.php'),true);
            $msg  = $json[PLU_NAME]['msg'];
        }catch (Exception $e){
            $msg = '欢迎使用插件!觉得可以的话给个好评哦!';
        }
        $this->success($msg);
    }
}


?>