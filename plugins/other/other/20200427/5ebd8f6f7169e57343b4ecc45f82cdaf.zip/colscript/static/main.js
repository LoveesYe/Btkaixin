
//定义窗口尺寸
$('.layui-layer-page').css({ 'width': '650px' });

//左测菜单切换效果
$(".bt-w-menu p").click(function () {
    $(this).addClass('bgw').siblings().removeClass('bgw')
});

//第一次打开窗口时调用
get_list();



/*抓取列表*/
function get_list() {
    var html =
        "<div class='u_main'>" +
        "<b >此页面仅用于测试列表页抓取</b>" +
        "<hr class=\"layui-bg-gray\">" +
        "<p><span>抓取网址</span> <input value='' id='host' class='bt-input-text'></p>" +
        "<p><span>列表切片</span>  <input placeholder='列表与块的规则,最常见的比如ul>li' value='' id='range_rule' class='bt-input-text'></p>" +
        // "<p><span>列表标题</span>  <input value='' id='title_rule' class='bt-input-text'></p>" +
        "<p><span>列表链接</span>  <input value='' placeholder='列表链接的类或者元素' id='link_rule' class='bt-input-text'></p>" +
        "<p><span>列表缩略图</span>  <input placeholder='非必填' value='' id='thump_rule' class='bt-input-text'></p>" +
        "<p>" +
        "<span></span><button class='btn btn-success btn-sm' onclick='w_list()'>写入测试数据</button>&nbsp;" +
        "<button class='btn btn-success btn-sm' onclick='do_get_list()'>提取列表</button>&nbsp;" +
        "</p>" +
        "<div class='u_output'>" +
        "<h3></h3>" +
        "<textarea class='hidden' cols='113' rows='15'></textarea>" +
        "</div>" +
        "</div>";
    $('.plugin_body').html(html);
}

function w_list() {
    $("#host").val("https://news.ifeng.com/");
    $("#range_rule").val(".news-stream-basic-news-list>li");
    // $("#title_rule").val("li>.news-stream-newsStream-news-item-infor>h2>a");
    $("#link_rule").val(".news-stream-newsStream-image-link");
    $("#thump_rule").val(".news-stream-newsStream-image-link>img");
}

//文章页抓取
function  get_index() {
    var html =
        "<div class='u_main'>" +
        "<b>此页面仅用于测试文章页抓取</b>" +
        "<hr class=\"layui-bg-gray\">" +
        "<p><span>抓取网址</span> <input  id='host' class='bt-input-text'></p>" +
        "<p><span>标题规则</span> <input  id='title_rule' class='bt-input-text'></p>" +
        "<p><span>文章规则</span> <input  id='content_rule' class='bt-input-text'></p>" +
        "<p><span></span> <button class='btn btn-success btn-sm' onclick='w_content()'>写入测试数据</button> <button class='btn btn-success btn-sm' onclick='get_html_text()'>提取文章页测试</button>&nbsp;</p>" +
        // "<button class='btn btn-success btn-sm' onclick='get_html_text(1)'>GBK转码提取(针对乱码)</button>&nbsp;" +
        //"<button class='btn btn-success btn-sm' onclick='get_html_text(2)'>提取图片地址</button>" +
        "</p>" +
        "<div class='u_output'>" +
        "<h3></h3>" +
        "<textarea class='hidden' cols='113' rows='15'></textarea>" +
        "</div>" +
        "</div>";
    $('.plugin_body').html(html);
}

function w_content() {
    $("#host").val("https://news.ifeng.com/c/7vzhBoRSEjI");
    $("#title_rule").val(".topic-3bY8Hw-9");
    $("#content_rule").val(".main_content-LcrEruCc");
}

/*采集单页*/
function get_html_text(status) {
    var tip = layer.msg('处理中...',{icon:16,time:0});
    if (!status)  status = 0;
    var host = $("#host").val();
    var title_rule = $("#title_rule").val();
    var content_rule = $("#content_rule").val();
    request_plugin('get_html',{host:host,content_rule:content_rule,title_rule:title_rule,status:status},function (res) {
        console.log(res);
        layer.close(tip);
        var nt = "<div class='res_content'><h3>"+res.data.title+"</h3>"+res.data.content+"</div>";
        if(res.code !== 0 ){
            layer.msg(res.msg);
        }
        //自定页
        layer.open({
            type: 1,
            title:'采集结果',
            //skin: 'layui-layer-rim', //加上边框
            area: ['800px', '600px'],
            anim: 2,
            maxmin: true, //开启最大化最小化按钮
            content: nt
        });
        //$(".u_output").html();
    })
}

//规则设置展示
function show_rule() {
    var tip =   layer.msg('加载中...',{icon:16});
    request_plugin("get_rule_list",{},function (res) {
        layer.close(tip);
        console.log(res);
        var html =
            "<div  class='u_main'>" +



            "<div class='u_form'><form id='main-form' action='set_rule'>" +
            "<p><span>目标网址</span>  <input value='' id='url' name='url' class='bt-input-text'></p>" +
            "<p><span>切片规则</span>  <input value='' name='range_rule' id='range_rule' class='bt-input-text'></p>" +
            // "<p><span>列表标题</span>  <input value='' name='link_title_rule' id='title_rule' class='bt-input-text'></p>" +
            "<p><span>列表链接</span>  <input value='' id='link_rule' name='link_rule' class='bt-input-text'></p>" +
            "<p><span>列表缩略图</span>  <input placeholder='非必填' value='' id='thump_rule' name='thump_rule' class='bt-input-text'></p>" +
            "<p><span>文章标题</span>  <input value='' id='title_rule' class='bt-input-text' name='title_rule'></p>" +
            "<p><span>文章内容</span>  <input value='' id='content_rule' name='content_rule' class='bt-input-text'></p>" +
            "<p><span>编码(beta)</span><select class='bt-input-text' name='web_encode'>" +
            "<option value='utf-8'>utf-8</option>" +
            "<option value='gbk'>gbk</option>" +
            "</select> " +
            "</p>" +
            "<p>" +
            "<p><span></span><button onclick='set_rule()' type='submit' class='btn btn-success btn-sm' >保存规则</button></p>" +
            "</form></div>" +


            "<div class='u_pro divtable mtb10'>" +
            "<table class='table '>" +
            "<thead>" +
            "<tr> <th>目标网址</th> <th width='100px'>操作</th>   </tr>" +
            "</thead>" +
            "<tbody>" +
            res.data.table +
            "</tbody>" +
            "</table>" +
            "</div>" +


            "</div>";
        $('.plugin_body').html(html);
    })

}
//编辑规则
function show_edit_rule(url) {
    var tip =   layer.msg('加载中...',{icon:16});
    request_plugin('get_rule_config',{url,url},function (res) {
        layer.close(tip);
        var rule_config = res.data.rule_config;
        console.log(rule_config);
        $("input[name=url]").val(rule_config.url);
        $("input[name=range_rule]").val(rule_config.range_rule);
        // $("input[name=link_title_rule]").val(rule_config.link_title_rule);
        $("input[name=link_rule]").val(rule_config.link_rule);
        $("input[name=thump_rule]").val(rule_config.thump_rule);
        $("input[name=title_rule]").val(rule_config.title_rule);
        $("input[name=content_rule]").val(rule_config.content_rule);
        $("select[name=web_encode]").val(rule_config.web_encode);
    })
}
//规则设置
function set_rule() {
    sub_form("#main-form",'set_rule',function (res) {
        var icon = res.code == 0?1:2;
        layer.msg(res.msg,{icon:icon},function () {
            show_rule();
        })
    });
}

//删除规则
function  del_rule(url) {
    layer.confirm("确认删除网址规则:<span class='red'>"+url+"</span>吗?<br>注意:删除后会重载此页,请及时保存表单数据", { title: "删除确认" },function () {
        var tip =   layer.msg('加载中...',{icon:16});
        request_plugin('del_rule',{url:url},function (res) {
            var icon = res.code == 0?1:2;
            layer.msg(res.msg,{icon:icon},function () {
                show_rule();
            })
        })
    })
}





function do_get_list() {
    var tip = layer.msg('处理中...',{icon:16,time:0});
    var host = $("#host").val();
    var range_rule = $("#range_rule").val();
    // var title_rule = $("#title_rule").val();
    var link_rule = $("#link_rule").val();
    var thump_rule = $("#thump_rule").val();
    var desc_rule = $("#desc_rule").val();

    request_plugin('do_get_list',{
        host:host,
        range_rule:range_rule,
        // title_rule:title_rule,
        link_rule:link_rule,
        thump_rule:thump_rule,
        desc_rule:desc_rule
    },function (res) {
        layer.close(tip);
        if(!res){
            layer.alert('爬虫被拦截或者爬取失败');
        }
        if(res.code<0){
            layer.msg(res.msg,{icon:2});
            return false;
        }
        var str = '<div class="list_content">';
        var data = res.data;
        for (var i in data){
            var img = '';
            if(data[i]['img'] !== undefined){
                img +=  "<p><img src='"+ data[i]['img']+"'></p>";
            }

            str += "<p style='margin-top: 10px;margin-left: 10px'>网址:"+data[i]['link']+"</p>"+
                img;
        }
        str += "</div>";
        var nt = "<pre>"+res.data+"</pre>";
        layer.open({
            type: 1,
            title:'采集结果',
            area: ['800px', '600px'],
            anim: 2,
            maxmin: true, //开启最大化最小化按钮
            content: str
        });
    })
}

function web_config_form() {
    var tip = layer.msg('处理中...',{icon:16,time:0});
    // request_plugin('get_web_list',{},function (res) {
    //     var rule_list = res.data.rule_list;
        request_plugin('get_web_config',{},function (res) {
            layer.close(tip);
            var html = "<div class='u_main'>" +
                "<form class='main-form' >" +
                "<p><span>网站地址</span><input name='myurl' class='bt-input-text'></p>" +
                "<p><span>网站系统类型</span><select  name='cms_type' class='bt-input-text bt-select'>" +
                "<option value='typecho'>typecho</option>" +
                "</select></p>" +
                // "<p><span>网址规则</span><select name='website' class='bt-input-text bt-select'>" +
                // rule_list +
                // "</select></p>" +
                "<p><span>mysql主机地址</span><input name='mysql_host' class='bt-input-text'></p>" +
                "<p><span>端口</span><input name='port' value='3306' class='bt-input-text'></p>" +
                "<p><span>用户名</span><input name='username'  class='bt-input-text'></p>" +
                "<p><span>密码</span><input name='password'  class='bt-input-text'></p>" +
                "<p><span>数据库名</span><input name='database' class='bt-input-text'></p>" +
                "<p><span>表前缀</span><input name='prefix' value='typecho_' class='bt-input-text'></p>" +
                "<p>" +
                "<span></span><button class='btn btn-success btn-sm' onclick='save_web_config()'>保存配置</button>&nbsp;" +
                "</p>" +
                "</form>" +
                // "<p> <a id='myurl'  class='btlink' href='/' target='_blank'>前往网站查看</a> </p>" +
                "</div>";
            $('.plugin_body').html(html);
            var web_config = res.data;
            $("input[name=myurl]").val(web_config.myurl);
            $("select[name=cms_type]").val(web_config.cms_type);
            $("select[name=website]").val(web_config.website);
            $("input[name=mysql_host]").val(web_config.mysql_host);
            $("input[name=username]").val(web_config.username);
            $("input[name=password]").val(web_config.password);
            $("input[name=database]").val(web_config.database);

            $("input[name=port]").val(web_config.port);
            $("input[name=prefix]").val(web_config.prefix);
            // $("#myurl").attr('href',web_config.myurl);
        });
    // })
}


function save_web_config() {
    var tip = layer.msg('处理中...',{icon:16,time:0});
    sub_form('.main-form','save_web_config',function (res) {
        layer.close(tip);
        var icon = res.code == 0?1:2;
        layer.msg(res.msg,{icon:icon});
    });
}

function ds_form() {
    var tip = layer.msg('处理中...',{icon:16,time:0});
    request_plugin('ds_form',{},function (res) {
        layer.close(tip);
        if(res.code<0){
            var html = "<div class='u_main'>" +
                "<p><span>网址规则</span><select class='bt-input-text' name='website'>" +
                "</select></p>" +
                "<p><span>注意:</span>请选择采集待入库的文章分类(需要先设置[网站配置])</p>"+
                "<p><span>分类</span><select name='cat_id' class='bt-input-text'>" +
                "</select></p>" +
                "<p><span></span><button class='btn btn-success btn-sm' onclick='create_ds()'>增加定时采集任务</button><a class='btlink' style='margin-left: 20px' target='_blank' href='/crontab'>前往 [计划任务] ,查看已生成的定时任务</a></p>" +
                "</div>";
            $('.plugin_body').html(html);
            layer.alert(res.msg);
            return false;
        }
        var html = "<div class='u_main'>" +
            "<p><span>网址规则</span><select class='bt-input-text' name='website'>" +
            res.data.rule_list +
            "</select></p>" +
            "<p><span>注意:</span>请选择采集待入库的文章分类(需要先设置[网站配置])</p>"+
            "<p><span>分类</span><select name='cat_id' class='bt-input-text'>" +
            res.data.cat_list +
            "</select></p>" +
            "<p><span></span><button class='btn btn-success btn-sm' onclick='create_ds()'>增加定时采集任务</button><a class='btlink' style='margin-left: 20px' target='_blank' href='/crontab'>前往 [计划任务] ,查看已生成的定时任务</a></p>" +
            "</div>";
        $('.plugin_body').html(html);


    })
}


//定时推送
function create_ds() {
    var website = $('select[name=website]').val();
    var cat_id = $('select[name=cat_id]').val();
    var cat_name = $('select[name=cat_id]').find("option:selected").text();

    if(website==''||website==null|| cat_id==''||cat_id==null){
        layer.msg('请先填写【网站配置】');
        return false;
    }
    request_plugin("getPath",{},function (res) {
        var path = res.path;
        var dir = res.dir;
        var myurl = res.myurl;
        //存储域名
        var args = {
            "name":"【网站采集】为站点"+myurl+"生成的定时任务,采集目标"+website+"目标分类:"+cat_name,
            "type":"hour",
            "where1":"",
            "hour":"",
            "minute": 30,
            "week":"",
            "sType": "toShell",
            "sBody": "php "+path+" -a "+website+" -b "+cat_id,
            "sName":"",
            "backupTo": "localhost",
            "save":"",
            "urladdress":""
        };
        $.ajax({
            type:'POST',
            url: '/crontab?action=AddCrontab',
            data: args,
            success: function(rdata) {
                layer.alert("恭喜您!采集计划任务"+rdata.msg+",<br>请前往宝塔<a class='btlink' target='_blank' href='/crontab'>[计划任务]</a>里查看", {icon: rdata.status ? 1 : 2 });
                return;
            },
            error: function(ex) {
                layer.msg('请求过程发现错误!', { icon: 2 });
                return;
            }
        });
    });


}


function about() {
    var tip = layer.msg('处理中...',{icon:16,time:0});
    request_plugin('about',{},function (res) {
        console.log(res);
        var msg = res.msg;
        if(msg == null){
            msg = "欢迎使用插件,觉得好的话给个好评哦!";
        }
        layer.close(tip);
        var html =
            "  <div id=\"404_logo\" align=\"center\"><a target='_blank' href='https://www.waytomilky.com/'><img src='https://www.waytomilky.com/usr/uploads/2019/04/2930328315.png'></a></div><br/>\n" +
            "                <div id=\"404_dev\" >\n" +
            "                    <table align=\"left\"  style=\"position:absolute; left:10%\" border=\"0\">\n" +
            "                        <tr ><td>&nbsp;</td></tr>\n" +
            "                        <tr ><td><a target='_blank' href='https://www.waytomilky.com/'>开发人员： 阿修罗</a></td></tr>\n" +
            "                        <tr ><td>&nbsp;</td></tr>\n" +
            "                        <tr ><td>官方网站： <a target='_blank' class='green' href='https://www.waytomilky.com/'>https://www.waytomilky.com/</a></td></tr>\n" +
            "                        <tr ><td>&nbsp;</td></tr>\n" +
            "                        <tr ><td>QQ群支持：<a target=\"_blank\" href=\"//shang.qq.com/wpa/qunwpa?idkey=289eaf4dfef0cc9220256b90ff502bef467767f6f790b817ce1cbe7658b5b3b3\"><img border=\"0\" src=\"//pub.idqqimg.com/wpa/images/group.png\" alt=\"PHP-LotusAdmin&amp;宝塔插件反\" title=\"PHP-LotusAdmin&amp;宝塔插件反\"></a></td></tr>\n" +
            "                        <tr ><td>&nbsp;</td></tr>\n" +
            "                        <tr ><td>支持开发者：<a style='color:green' target='_blank' href='https://www.aliyun.com/minisite/goods?userCode=efobqs6x'>阿里云|云小站</a> </td></tr>\n" +


            "                        <tr ><td>&nbsp;</td></tr>\n" +
            "                        <tr ><td><b>使用说明,务必查看:</b></td></tr>\n" +

            "                        <tr ><td>&nbsp;</td></tr>\n" +
            "                        <tr ><td>1.插件依赖PHP>=7.0,不影响网站设置</td></tr>\n" +

            "                        <tr ><td>&nbsp;</td></tr>\n" +
            "                        <tr ><td>2.插件依赖PHP-CLI>=7.0 此项在宝塔面板 【网站】->【PHP命令行版本】中修改</td></tr>\n" +

            "                        <tr ><td>&nbsp;</td></tr>\n" +
            "                        <tr ><td>3.关于【规则设置】根据已有规则参考设置</td></tr>\n" +


            "                        <tr ><td>&nbsp;</td></tr>\n" +
            "                        <tr ><td><b>开发者公告:</b></td></tr>\n" +

            "                        <tr ><td>&nbsp;</td></tr>\n" +
            "                        <tr ><td>"+msg+"</td></tr>\n" +

            "                    </table>\n" +
            "                </div>\n" +
            "                </div>";

        $('.plugin_body').html(html);
    })


}


