var plugin_name = 'colscript';
/**
 * 发送请求到插件
 * 注意：除非你知道如何自己构造正确访问插件的ajax，否则建议您使用此方法与后端进行通信
 * @param plugin_name    插件名称 如：colscript
 * @param function_name  要访问的方法名，如：get_logs
 * @param args           传到插件方法中的参数 请传入数组，示例：{p:1,rows:10,callback:"colscript.get_logs"}
 * @param callback       请传入处理函数，响应内容将传入到第一个参数中
 */
function request_plugin(function_name, args, callback, timeout, method) {
    if (!timeout) timeout = 30000;
    if (!method)  method = 'POST';
    $.ajax({
        type:method,
        url: '/plugin?action=a&s=' + function_name + '&name=' + plugin_name,
        data: args,
        timeout:timeout,
        dataType:'json',
        success: function(rdata) {
            if (!callback) {
                layer.msg(rdata.msg, { icon: rdata.status ? 1 : 2 });
                return;
            }
            return callback(rdata);
        },
        error: function(ex) {
            if (!callback) {
                layer.msg('请求过程发现错误!', { icon: 2 });
                return;
            }
            return callback(ex);
        }
    });
}

function sub_form(elem,function_name,callback,data) {
    if(!data) data = {};
    var options = {
        url: '/plugin?action=a&s=' + function_name + '&name=' + plugin_name,
        type: 'post',
        dataType: "json",
        data: data,
        clearForm: false,
        resetForm: false,
        cache: false,
        async: false,
        success: function (data) {
            if (!callback) {
                layer.msg(data.msg, { icon: data.status ? 1 : 2 });
                return;
            }
            return callback(data);
        },
        error: function (ex) {
            if (!callback) {
                layer.msg('请求过程发现错误!', { icon: 2 });
                return;
            }
            return callback(ex);
        }
    };
    // bind form using 'ajaxForm'
    $(elem).ajaxForm(options).submit(function (data) {
    });
}