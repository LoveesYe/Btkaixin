<?php
//require "medoo.php";
//require "vendor/autoload.php";
require 'index.php';

use QL\QueryList;
use QL\Ext\AbsoluteUrl;

class console{
    
    protected $database;
    protected $website;
    protected $cms_type;
    protected $web_config;
    protected $config;
    
    //不允许被面板访问的方法请不要设置为公有方法
    function __construct($website,$cat_id)
    {
        define("DS","/");
        define("STATIC_FILE",__DIR__."/static/");
        $db_config = self::read_web_config();
        $this->web_config = $db_config;
        $this->database =   [
            // 必须配置项
            'database_type' => 'mysql',
            'database_name' => $db_config['database'],
            'server' => $db_config['host'],
            'username' => $db_config['username'],
            'password' => $db_config['password'],
            'charset' => 'utf8',
            'port' => $db_config['port'],
            'prefix' => $db_config['prefix'],
        ];
        $config_all = self::read_config();
        //属性注入
        $this->website = $website;
        $this->cat_id = $cat_id;
        $this->config = $config_all[$website];
    }
    
    function init(){
        $config_all = self::read_config();
        $website = $this->website;
        $config = $config_all[$website];
    
        if(empty($config['thump_rule'])){
            $rules = [
                'title'=> [$config['title_rule'],'text'],
                'link' => [$config['link_rule'],'href'],
                //'desc' => [$config['desc_rule'],'text']
            ];
        }else{
            $rules = [
                'title'=> [$config['title_rule'],'text'],
                'link' => [$config['link_rule'],'href'],
                'img'  =>  [$config['thump_rule'],'src'],
                //'desc' => [$config['desc_rule'],'text']
            ];
        }
    
        $data = $this->get_list_content($website,$rules,$config['range_rule']);
    
        $this->push_sql($data);
    }
    
    function get_list_content($host,$rules,$range){
        $ql = QueryList::getInstance();
        $ql->use(AbsoluteUrl::class);
        $ql = QueryList::get($host)
            ->rules($rules)
            ->range($range)
            ->query()
            ->getData(function ($item) use ($ql,$host){
                $item['link'] = $ql->absoluteUrlHelper($host,$item['link']);
                return $item;
            });
        //转换绝对链接
        return $ql->all();
    }
    
    //手动爬取内容
    function push_sql($data){
        $config = $this->config;
        echo "[网站采集]插件开始执行定时任务(觉得好的话别忘了给好评哦,@阿修罗需要您的支持 \n官网:http://www.waytomilky.com/ 点个广告也是爱):\n----------------------------------------------------------------\n";
        $i = 0;
        foreach ($data as $val){
            $host = $val['link'];
            $rules = [
                'title'=>[$config['title_rule'],'text'],
                'content'=>[$config['content_rule'],'html']
            ];
            $content =  $this->get_one_content($host,$rules);
            $cms_type = ($this->web_config)['cms_type'];
            if($cms_type == 'typecho'){
                $res =  $this->insert_typecho_database($content['title'],$content['content'],$this->cat_id,$host);
                if($res){
                    $i++;
                }
            }
            if($cms_type == 'wordpress')  $this->insert_wordpress_database($content['title'],$content['content'],$this->cat_id,$host);
        }
        if($i==0){
            echo "报告老板,执行完毕,因为内容重复,未入库任何内容\n";
        }else{
            echo  "报告老板,执行完毕,新增".$i."条新闻,美滋滋,别忘了给插件好评哦!!!\n";
        }
    }
    
    function get_one_content($host,$rules){
        $rt = QueryList::get($host)->rules($rules)->query()->getData();
        return $rt;
    }
    
    function insert_typecho_database($title,$content,$cat_id,$host){
        $database = new medoo($this->database);
        //插入之前检测是否重复
        @$res = $database->select('contents',"*",['title'=>$title]);
        @$metas  = $database->select('metas',['count'],['mid'=>$cat_id]);
        $count = $metas[0]['count'];
        if(!empty($res)|| empty($title) || empty($content) ){
            echo "检测到文章重复或者内容为空,未加入库: \n采集自网址:$host \n采集时间:".date("Y-m-d H:i:s")."\n标题:".$title."\n----------------------------------------------------------------\n";
            return false;
        }
        $cid =  $database->insert("contents", [
            "title" => trim($title),
            "text"  => $content,
            'type'  => 'post',
            'allowComment'=>'1',
            'allowPing'=>'1',
            'allowFeed'=>'1',
            'authorId'=>1,
            'created' => time(),
            'modified' => time()
        ]);
        $cid = (int)$cid;
        //更新slug
        $database->update('contents',[
            'slug'  => $cid
        ],['title'=>$title]);
        //更新分类id
        $database->insert('relationships',[
            'cid'=>$cid,
            'mid'=>$cat_id
        ]);
        //更新count
        $database->update('metas',
            ['count'=>$count+1],
            ['mid'=>$cat_id]
        );
        
        echo "新增文章:\n采集自网址:$host \n采集时间:".date("Y-m-d H:i:s")." \n标题:".$title."\n----------------------------------------------------------------\n";
        return true;
    }
    
    function insert_wordpress_database($title,$content,$cat_id){
        $database = new medoo($this->database);
        //插入之前检测是否重复
        $res = $database->select('contents','*',['title'=>$title]);
        if(!empty($res)){
            return;
        }
        
        $id =  $database->insert("contents", [
            "title" => $title,
            "text"  => $content,
            'type'  => 'post',
            'allowComment'=>1,
            'allowPing'=>1,
            'allowFeed'=>1,
            'authorId'=>1,
            'created' => time(),
            'modified' => time()
        ]);
        //更新slug
        $database->update('contents',[
            'slug'  => $id
        ],['title'=>$title]);
        //更新分类id
        $rid = $database->insert('relationships',[
            'cid'=>$id,
            'mid'=>1
        ]);
    }

    static function read_config(){
        $config =  file_get_contents(STATIC_FILE."config");
        return unserialize($config);
    }
    static function read_web_config(){
        $config =  file_get_contents(STATIC_FILE."web_config");
        return unserialize($config);
    }

}

//初始化类
echo "开始执行:\n";
$param  = getopt("a:b:");
$console = new console($param["a"],$param["b"]);
$console->init();
