#!/bin/bash -e
# chkconfig: 2345 99 90
# description: /www/server/panel/plugin/mfboot/mfboot.py by moofei 
# processname: mfboot
cd /www/server/panel/plugin/mfboot; 
RETVAL=0
pidfile=/var/run/mfboot.pid
exefile=/www/server/panel/plugin/mfboot/mfboot.py

#set -e


run(){
    nohup python /www/server/panel/plugin/mfboot/mfboot.py --run >>/www/server/panel/plugin/mfboot/boot.log 2>&1 &
}
start(){
    nohup python /www/server/panel/plugin/mfboot/mfboot.py --run >>/www/server/panel/plugin/mfboot/boot.log 2>&1 &
}
stop(){
    echo "mfboot stop"
}

status(){    
    echo ""
}

case "$1" in
    start)
        start
        ;;
    run)
        run
        ;;
    stop)
        stop
        ;;
    status)
        ;;
    restart)
        start
        ;;
    *)
        echo "Usage:$0 start|run|stop|status|restart"
        exit 1
esac
exit $RETVAL