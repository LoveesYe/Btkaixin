#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "cdefs.h"
#include "cstack.h"


int cstack_push(cstack_t *stack, void *data)
{
    return clist_insert_next(stack, NULL, data);
}

int cstack_pop(cstack_t *stack, void **data)
{
    return clist_remove_next(stack, NULL, data);
}



