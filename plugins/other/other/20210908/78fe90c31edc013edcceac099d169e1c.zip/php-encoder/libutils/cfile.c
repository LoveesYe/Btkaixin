#include <stdio.h>
#include <string.h>
#include <errno.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>


#include "cdefs.h"
#include "cstr.h"
#include "cfile.h"

#define MAX_BUFFER_SIZE 4096

#if 0
int c_mkdir(const char *pathname) {
	return mkdir(pathname, S_IRWXU | S_IRGRP | S_IXGRP | S_IRWXG | S_IROTH | S_IXOTH);
}
#endif

/*
*�ݹ鴴��Ŀ¼,������Ŀ¼
*@return �ɹ�����0,ʧ�ܷ���-1
*/
int cfile_mkdirs(const char *dir, mode_t mode)
{	
    int ret = 0;
    char copy_dir[CFILE_MAX_PATH];
    char *p = copy_dir;

	CHECK(dir == NULL, -1);

	if(cstr_empty(dir))
	{
		return 0;
	}

    cstr_copy(copy_dir, dir, sizeof(copy_dir));

    while((p = strchr(p+1, '/')) != NULL)
    {
        *p = '\0';
        ret = mkdir(copy_dir, mode);
        if(ret != 0 && errno != EEXIST)
        {
			c_error("error mkdir[%s] %s", copy_dir, strerror(errno));
            return -1;
        }
		*p = '/';
    }

    ret = mkdir(copy_dir, mode);

    if(ret != 0 && errno != EEXIST)
    {
		c_error("error mkdir[%s] %s", copy_dir, strerror(errno));
        return -1;
    }

    return 0;
}


/*
*��ȡ·���е��ļ���
*@return �ɹ������ļ�����ʼλ��,ʧ�ܷ���NULL
*/
char *cfile_get_filename(char *path) {
	char *p;
	CHECK(path == NULL, NULL);
	p = strrchr(path, '/');
    return p == NULL ? path : p+1;
}


/*
*�ļ����еĺ�׺��
*@return �ɹ����غ�׺����ʼλ��,ʧ�ܷ���NULL
*/
char *cfile_get_suffix(char *filename) {
	char *p;
	CHECK(filename == NULL, NULL);
	p = strrchr(filename, '.');
    return p;
}


/*
*�����ļ�,�����Ŀ¼�������򴴽�
*@return �ɹ������ļ�������,ʧ�ܷ���NULL
*/
int cfile_create(char *path) {
	

	int fd;
	char buf[CFILE_MAX_PATH];
	char *filename;

	CHECK(path == NULL, -1);

	filename = cfile_get_filename(path);

	snprintf(buf, sizeof(buf), "%.*s", (int)(filename-path), path);

	if(!cstr_empty(buf)) {
		if(cfile_mkdirs(buf, CFILE_DEFAULT_DIR_MODE) != 0) {
			return -1;
		}
	}

	if((fd = open(path, O_CREAT|O_EXCL|O_RDWR|O_APPEND, CFILE_DEFAULT_FILE_MODE)) < 0) {
		c_error("�����ļ�[%s]����,%s", path, strerror(errno));
	}
	
    return fd;
}


/*
*�����ļ�
*@return �ɹ�����0,ʧ�ܷ���-1
*/
int cfile_copy(char *source_path, char *dest_path) {
	int ret = 0;
	int source_fd = -1, dest_fd = -1;
	char path[CFILE_MAX_PATH], *p;
	char buf[MAX_BUFFER_SIZE];
	size_t bytes_read, bytes_write, n;

	p = strrchr(dest_path, '/');
	if(p != NULL) {
		snprintf(path, sizeof(path), "%.*s", (int)(p - dest_path), dest_path);
		if(cfile_mkdirs(path, CFILE_DEFAULT_DIR_MODE) != 0) {
			return -1;
		}
	}

	if((source_fd = open(source_path, O_RDONLY)) == -1) {
		ret = -1;	
	} else if((dest_fd = open(dest_path, O_WRONLY|O_APPEND|O_CREAT|O_EXCL, CFILE_DEFAULT_FILE_MODE)) == -1) {
		ret = -1;
	}

	while(ret == 0 && (bytes_read = read(source_fd, buf, sizeof(buf)))) {
		if(bytes_read == (size_t)-1) {
			//error
			ret = -1;
			break;
		}
		bytes_write = 0;
		while(bytes_write < bytes_read) {
			n = write(dest_fd, buf+bytes_write, bytes_read-bytes_write);
			if(n == (size_t)-1) {
				//error
				ret = -1;
				break;
			}
			bytes_write += n;
		}
	}

	if(source_fd != -1) {
		close(source_fd);
	}

	if(dest_fd != -1) {
		close(dest_fd);
	}

	return ret;
}

