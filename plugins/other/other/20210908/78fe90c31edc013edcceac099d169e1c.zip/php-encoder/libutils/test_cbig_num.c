#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#include "cbig_num.h"
#include "crsa.h"

#define FAIL(str, line) {                       \
  printf("Fail on line %d: [%s]\n", line, str); \
  return str;                                   \
}

#define ASSERT(expr) {                  \
  static_num_tests++;                   \
  if (!(expr)) FAIL(#expr, __LINE__);   \
}

#define RUN_TEST(test) {        \
    const char *msg = test();   \
    if(msg)                     \
        return msg;             \
}


static int static_num_tests = 0;


const char *test_cbig_num() {
    cbig_num_t a, b, n, e, d, i;

    n = cbig_num_parse("A3767ABD1B6AA69D7F3FBF28C092DE9ED1E658BA5F0909AF7A1CCD907373B7210FDEB16287BA8E78E1529F443976FD27F991EC67D95E5F4E96B127CAB2396A94D6E45CDA44CA4C4867570D6B07542F8D4BF9FF97975DB9891515E66F525D2B3CBEB6D662BFB6C3F338E93B02142BFC44173A3764C56AADD202075B26DC2F9F7D7AE74BD7D00FD05EE430032663D27A57", 16);
    e = cbig_num_parse("03", 16);
    i = cbig_num_parse("8A7C182B22BE2AA9FD5F4824F7FA46CE1485F8725FA0C4DFE85EF7D40D6EA245D7268BCC79DEC0BBC73C030A1C0B749B7A867513795E34D35BAEFAB65641E8361E6E3F4089E3C2F69EDD05B1035CE5857BB8FEE8372E2E1C42A65C8DED99417ED257D87ECD68D186D5FE2C767EF17E1F33E3034941C8EE7069AFFFF63BCA77F23AC55DE9BC8876585B9F8E3BF36EEFC2", 16);
		
    cbig_num_print(crsa_encrypt(i, e, n), NULL);
    cbig_num_print(crsa_decrypt(i, e, n), NULL);
    
    return NULL;
}


static const char *run_all_tests(void) {
    RUN_TEST(test_cbig_num);
    return NULL;
}


int main(void) {
    const char *fail_msg = run_all_tests();
    printf("%s, tests run: %d\n", fail_msg ? "FAIL" : "PASS", static_num_tests);

    return fail_msg == NULL ? 0 : -1;
}
