#include <stdio.h>
#include <string.h>
#include <ctype.h>

#include "cdefs.h"
#include "cstr.h"
#include "cconf.h"


/**
*���������ļ�
*@return �ɹ�����0,��������-1
*/
int config_parse_file(char *filename, void *data, int (*handler)(void *,const char *, const char *))
{
	int ret = 0;
	FILE *fp = NULL;
	char line[CCONF_LINE_SIZE+1], name[sizeof(line)], value[sizeof(line)];
	int line_no = 0;
	fp = fopen(filename, "r");
	if(fp == NULL)
	{
		c_error("open file %s fail", filename);
		ret = -1;
	}
	else
	{
		while(fgets(line, sizeof(line), fp) != NULL)
		{
			line_no ++;
			cstr_trim(line);
			//����/ע��
			if(line[0] == '\0' || line[0] == '#')
			{
				continue;
			}
			//������
			if (sscanf(line, "%s %[^\r\n#]", name, value) != 2) 
			{
				c_error("file %s,line %d is invalid,ignored", filename, line_no);
	      	}
			else if(handler && handler(data, name, value) != 0)
			{
				ret = -1;
				c_error("file %s,line %d parse error", filename, line_no);
				break;
			}
		}
		fclose(fp);
	}
	return ret;
}



