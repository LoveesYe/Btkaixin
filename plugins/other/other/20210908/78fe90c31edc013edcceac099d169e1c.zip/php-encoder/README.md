# php encoder   

### 简述
- 更新:给encoder增加批量解密功能
- 更新:增加了STRICT_MODE,如果只允许服务器执行加过密的php文件,此举可防止黑客或其他人执行任意php文件。  
- 更新:改进了加密算法 使用高强度的AES256 CBC模式进行加密  


基于php encoder  
主要做了以下改进：  
 **增加了批量加密 更加方便**  
 **原生加密算法太弱易被破解,升级了加密算法，更加安全可靠**  
加密的优点：  
 **可防止源码泄露，本程序是php扩展加密运行，只能在vps上运行，由于需要扩展进行动态解密，加密后被别人全部下载也无法被破解**  
 **商业源码可加密核心功能，只开放接口给客户**  
 **部分公司需要团队开发的，可防止源码泄露**  
 **其他。。。我编不出来了**  
### 效果演示  
原生代码:  
```
加密前:
<? 
include "./inc.php";
include "./inc.php";
include "./inc.php";
include "./inc.php";
function is_cli(){
    return preg_match("/cli/i", php_sapi_name()) ? 1 : 0;
}
if(is_cli()){
  if(extension_loaded("PHP Encoder"))
        {
        echo "\033[32mPHP Encoder is Load\033[0m";
        }else{
        echo "\033[31mPHP Encoder not Found\033[0m";
        }
}else{
    phpinfo();
}
?>
加密后：
f��oxV.C4CB��f��2{��\�z^F�k384�������Xl�}�9���nQZ��PmP����Is�5$,
�\��L��л>ï��tq2�a�Z#9�.!3u�(w�]�U�]PI���p��㥀\J7�q=�@P�����J
[1�\��i��X7��#��%�@�
```


### 使用方法：  
1. 下载本程序并解压到某个目录
2. 在encoder目录中执行php bin中的phpize自动生成扩展所需文件（如果你的php里没有可以去官网下载）
3. 执行./configure --with-php-config=[php config path] 进行配置，[php config path]是你的php-config的绝对路径
4. 修改php_encoder.h中的CAKEY，改为一个你认为安全的字符串
5. 执行make生成扩展 modules/php_encoder.so
6. 把扩展路径加入php.ini中 重启php
7. 进入tools文件夹 执行make
8. 执行./encoder [目录或文件] ，后面带上你要加密的目录或文件即可自动开始加密

执行./encoder [path] 是加密 后面加-d参数则是解密 例如
```
./encoder -f /home/web/ -p 123 -d
```
表示解密web目录的所有php文件

更多参数详解:
-d  解密方式
-n [长度] 加密串长度
-p [密钥] 密钥
-c 不显示颜色
-e sha1/sha256/md5
现在可以访问php文件，如果前面没有发生错误，应该可以正常执行了。
