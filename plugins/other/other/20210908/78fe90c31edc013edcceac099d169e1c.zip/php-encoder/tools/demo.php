<? 
include "./inc.php";
include "./inc.php";
include "./inc.php";
include "./inc.php";
function is_cli(){
    return preg_match("/cli/i", php_sapi_name()) ? 1 : 0;
}
if(is_cli()){
  if(extension_loaded("PHP Encoder"))
        {
        echo "\033[32mPHP Encoder is Load\033[0m";
        }else{
        echo "\033[31mPHP Encoder not Found\033[0m";
        }
}else{
    phpinfo();
}
