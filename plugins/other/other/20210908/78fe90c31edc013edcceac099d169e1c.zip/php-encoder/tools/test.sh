rm *.php
app="PHP Encoder";
cat >> demo.php << EOF
<? 
include "./inc.php";
include "./inc.php";
include "./inc.php";
include "./inc.php";
function is_cli(){
    return preg_match("/cli/i", php_sapi_name()) ? 1 : 0;
}
if(is_cli()){
  if(extension_loaded("$app"))
        {
        echo "\033[32m$app is Load\033[0m";
        }else{
        echo "\033[31m$app not Found\033[0m";
        }
}else{
    phpinfo();
}
EOF
cat >> inc.php << EOF
<? 
if(is_cli()){
echo "\033[33m<INCLUDE>\033[0m\n";
}else{
echo "<INCLUDE>";    
}
EOF

sleep 2
./build.sh
ver=53
if [ ! "$3" = "" ];then
    ver=$3
fi
cp encode ../../tools/phpencode
cp phpencode.exe ../../tools/phpencode.exe

if [ ! "$2" = "" ];then
    cd ../../
    ls
    phpdir=/www/server/php
    ./install.sh make $ver
    soname=php_encoder${ver}.so
    cd ./php-encoder/tools/
fi

keylen=""
if [ ! "$1" = "" ];then
    keylen="-n $1 -w"
    # keylen="-n $1 -p FwWpZKxH7twCAG4JQMO12 -e sha256 "
fi

./encode -f demo.php  $keylen
./encode -f demo.php  -k $keylen
cat demo.php
echo -e '\n\033[31m==========================================测试SO START==========================================\033[0m\n'
php demo.php
echo -e '\n\033[31m==========================================测试SO   END==========================================\033[0m\n'

cp *.php /www/wwwroot/t1.csol.ltd/

./encode -f demo.php  -d  $keylen
cat demo.php
./encode -f demo.php  -k $keylen


