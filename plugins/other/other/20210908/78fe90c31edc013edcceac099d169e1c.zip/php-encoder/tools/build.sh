###
 # @Author: WangHua
 # @Date: 2020-10-23 11:02:44
 # @LastEditTime: 2020-10-23 11:03:08
 # @LastEditors: WangHua
 # @Description: 
 # @FilePath: \php-encoder\tools\build.sh
 # @
### 
rm encode
make
