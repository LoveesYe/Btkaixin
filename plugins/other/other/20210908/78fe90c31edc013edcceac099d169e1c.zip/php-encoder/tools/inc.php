<? 
if(is_cli()){
echo "\033[33m<INCLUDE>\033[0m\n";
}else{
echo "<INCLUDE>";    
}
