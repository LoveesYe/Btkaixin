#include "include/md5.h"
#include "libutils/csha256.c"
#include "libutils/csha1.h"
#include "libutils/csha1.c"
#include "libutils/try.h"
#include "include/aes.c"
#include "include/aes_crypt.c"
#include "include/file.c"
#include "include/string.c"

#ifndef DOMARK
#define DOMARK 0
#endif

char *_key;
char *SafeKey;
uint8_t key[256];

char *encode_mode;
char *encode_key_mode;
char digest[128];


void getkey(uint8_t *_encodekeystr)
{
    static char *encode_key="FwWpZKxH7twCAG4JQMO1";
    int len= strlen(encode_key);
    bzero(_encodekeystr,sizeof(_encodekeystr));
    memset(_encodekeystr, 0, len);
    memcpy(_encodekeystr, encode_key, len);
}
char *_encodekey(char *text)
{
    if (DEBUG)
    {
        printf("ENCODE_MODE:%s\n", encode_mode);
    }
    if (strncmp(encode_mode, "sha256", 6) == 0)
    {
        bzero(digest, sizeof(digest));
        return csha256_hash(digest, text, NULL);
    }
    else if (strncmp(encode_mode, "sha1", 4) == 0)
    {
        bzero(digest, sizeof(digest));
        return csha1_hash(digest, text, 0, NULL); //0,1,31,56,64
    }
    else
    {
        return md5(text);
    }
}
char *encodekey(char *text)
{
    char *datap = _encodekey(text);
    //无特征模式
    if (strncmp(encode_mode, "0", 1) == 0)
    {
        return datap;
    }

    int datalen = strlen(datap);
    static uint8_t _encodekeystr[128];
    getkey(_encodekeystr);
    code_aes(1, datap, datalen,_encodekeystr , &datalen);
    return datap;
}


char mark[300];
char *getmark()
{
    sprintf(mark, "MARK%sMARK", STR2(CAKEY));
    sprintf(mark, "<?php if(!defined('%s')) {define('%s','%s');}?>\n", STR2(APPNAME), STR2(APPNAME), encodekey(mark));
    return mark;
}