#define CAKEY FwWpZKxH7twCAG4JQMO1
#define STRICT_MODE_ERROR_MESSAGE Access Denied By PHP Encoder
#define STRICT_MODE 0
// 无特征模式
#define ENCODE_KEY_MODE 0
#define DOMARK 0
//md5/sha1/sha256
#define ENCODE_MODE md5
//密钥长度8-128
#define KEYLEN 32
const int maxBytes = 1024 * 1024 * 2;
//版本
#define VERSION 1.3.6
//名称
#define APPNAME PHP Encoder
#define SITE  www.hkingsoft.cn
#define EMAIL hkingsoft@qq.cn
//调试模式
#define DEBUG 0
#define STR1(R) #R
#define STR2(R) STR1(R)
