#!/usr/bin/python
# coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: xxx <xxxx@qq.com>
# +-------------------------------------------------------------------

#+--------------------------------------------------------------------
#|   宝塔第三方应用开发a_site_click
#+--------------------------------------------------------------------
import sys,os,json,time,shutil,random


#设置运行目录
os.chdir("/www/server/panel")



#添加包引用位置并引用公共包
sys.path.append("class/")
import public,crontab


#在非命令行模式下引用面板缓存和session对象
if __name__ != '__main__':
    from BTPanel import cache,session,redirect

    import re,requests
    from lxml import etree
    #设置缓存(超时10秒) cache.set('key',value,10)
    #获取缓存 cache.get('key')
    #删除缓存 cache.delete('key')

    #设置session:  session['key'] = value
    #获取session:  value = session['key']
    #删除session:  del(session['key'])


class a_site_click_main:
    __plugin_path = "/www/server/panel/plugin/a_site_click/"
    __config = {"task_Status":False,'last_domain':"",'last_scan_type':"",'last_web_url':"",'site_data':[],'mip_push':False,'is_analyse':False,'speed_push':False,'push_new':False}
    __data_path=__plugin_path+'site_data/'
    __list_href = __die_url =set()
    __web_url=__domain=''
    config_file = __plugin_path + 'config.json'
    __header={
    "User-Agent":"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 UBrowser/6.2.4098.3 Safari/537.36"
    }

    #构造方法
    def  __init__(self): #初始化配置
        self.__set_config()
        if not os.path.exists(self.__plugin_path+'site_data'):
            os.mkdir(self.__plugin_path+'site_data')
        if os.path.exists("/www/server/panel/pyenv/bin/python"):
            self.pypath="/www/server/panel/pyenv/bin/python"
        else:
            self.pypath="python"

    def create_del_update(self,args):
        tmp={}
        type=args.b_type
        web_url=args.web_url.strip()
        token=args.token.strip()
        remark=args.remark.strip()
        sm_url=args.sm_url.strip()
        site_data=self.__get_config('site_data',force=True)
        if type =='1': #创建或更新
            tmp['web_url'] = web_url
            tmp['token'] = token
            tmp['remark'] = remark
            tmp['sm_url'] = sm_url
            msg = '添加成功'
            if site_data:
                flag=True
                for index,value in enumerate(site_data):
                    if value['web_url'] == web_url:#更新
                        site_data[index]=tmp
                        msg = '更新成功'
                        flag=False
                if flag:site_data.append(tmp)
            else:   #创建
                site_data.append(tmp)
        elif type == '2': #删除
            msg = '删除成功'
            for index,value in enumerate(site_data):
                if value['web_url'] == web_url:
                    del site_data[index]
        self.__set_config('site_data',site_data)
        return {'status':True,'msg':msg}

    def create_site_url(self,args):
        web_url=args.web_url
        if not web_url.endswith('/'):
            web_url=web_url+"/"
        total_num = int(args.total_num)
        char_num = int(args.char_num)
        int_num = int(args.int_num)
        suffix = args.suffix
        sort = args.sort
        url_list=""
        for i in range(total_num):
            if sort=='1':
                url_list+=(web_url+self.get_random('char',char_num)+self.get_random('int',int_num)+suffix+"\n")
            else:
                url_list+=(web_url+self.get_random('int',int_num)+self.get_random('char',char_num)+suffix+"\n")
        public.WriteFile("/tmp/.url_list.txt",url_list)
        return {"status":True,"file":"/tmp/.url_list.txt"}
    #访问/a_site_click/index.html时调用的默认方法，需要在templates中有index.html，否则无法正确响应模板
    def index(self,args):
        return self.get_logs(args)
    def check_site_analyse(self,args):
        domain=args.domain
        kw_file = '%s%s/kw.config' % (self.__data_path,domain)
        if os.path.exists(kw_file):
            return {"status": True, "data": ""}
        else:
            return {"status":False,"data":""}

    def get_site_data(self,args):
        site_data=self.__get_config('site_data')
        return {"status":True,'data':site_data}
    def get_task(self,args):
        tmp = self.__get_config()
        if os.path.exists(self.config_file):
            taskStatus=self.__get_config('task_Status')
            last_domain = self.__get_config('last_domain')
            error=self.__get_config('error')
            if error:
                tmp['error']=error
                return tmp
            if taskStatus:  #任务正在运行
                tmp['status']=True
                tmp['data']=last_domain
                return tmp
            else:  #无任务或者任务运行完而且不能有报错
                if last_domain:#上次完成的任务数据传过去
                    try:
                        for file in os.listdir(self.__data_path+last_domain):
                            file=self.__data_path+last_domain+'/'+file
                            if re.search('%s1\.txt'%last_domain,file):
                                tmp['txt_path']=file
                                tmp['txt_data']=public.ReadFile(file)
                            elif re.search('lost',file):
                                tmp['die_path']=file
                                tmp['die_data']=public.ReadFile(file)
                            elif re.search('.*\.xml',file):
                                tmp['xml_path']=file
                                tmp['xml_data']=public.ReadFile(file)
                        return tmp
                    except Exception as e: #文件被删除
                        return tmp

                else:
                    tmp['msg']='任务不存在'
                    return tmp
        else:
            return {'status':False,'msg':"配置文件不存在"}

    def get_seo_weight(self,args):
        table_obj={}
        if sys.version_info[0] == 2:
            from urlparse import urlparse
        else:
            from urllib.parse import urlparse
        site_data=self.__get_config('site_data')
        for item in site_data:
            try:
                web_url=item["web_url"]
                domain = urlparse(web_url).netloc
                if domain not in table_obj:
                    result = requests.get("https://www.aizhan.com/seo/%s"%domain, headers=self.__header)
                    html_obj = etree.HTML(result.text)
                    weight = html_obj.xpath("//table//tr[2]/td")[0]
                    tmp = etree.tostring(weight,encoding="utf-8").decode("utf-8")
                    table_obj[domain]=tmp
            except Exception as e:
                return  {"status":False,'msg':"未知错误"}
        return {"status":True,'data':table_obj}
    def get_random(self,typed,num):
        ret = ""
        if typed == 'int':
            for i in range(num):
                ret += str(random.randint(0,9))
        elif typed == 'char':
            for i in range(num):
                ret += "".join(random.sample('abcdefghijklmnopqrstuvwxyz',1))
        return ret

    def get_history_detail(self,args):
        ret={"status":True,"data":[]}
        if len(os.listdir(self.__data_path))>0:
            for site_name in os.listdir(self.__data_path):
                tmp={}
                domain_path=self.__data_path+site_name
                if os.path.isdir(domain_path):
                    for item in os.listdir(domain_path):
                        file_path=domain_path+"/"+item
                        if re.search('%s1\.txt' % site_name,item):
                            tmp['txt_path'] = file_path
                        elif re.search('lost', file_path):
                            tmp['die_path'] = file_path
                        elif re.search('.*\.xml', file_path):
                            tmp['xml_path'] = file_path
                file_time=time.strftime("%Y-%m-%d %H:%M:%S",time.localtime(os.path.getmtime(domain_path)))
                tmp['name']=site_name
                tmp['file_time']=file_time
                ret['data'].append(tmp)
        return ret
    def get_extend_file(self,args):
        ret = {"status": True, "data": []}
        domain=args.domain
        num = public.ExecShell("ps -aux|grep '%s site_kw'|grep -v grep|wc -l"%domain)[0].strip()
        ret['num']=int(num)
        site_path=self.__data_path+domain
        if os.path.exists(site_path):
            for file_name in os.listdir(site_path):
                tmp = {}
                file_path=site_path+"/"+file_name
                if os.path.isfile(file_path) and re.search("extend_kw_(\d+).txt",file_name):
                    tmp['name']=file_name
                    tmp['file_path']=file_path
                    tmp['file_time']=time.strftime("%Y-%m-%d %H:%M:%S",time.localtime(os.path.getctime(file_path)))

                    ret['data'].append(tmp)
        else:
            ret['status']=False
        return ret
    def get_task_log(self,args):
        data=public.ReadFile("%s"%self.__plugin_path+'debug.log')
        return {"status":True,'data':data}

    def get_site_kw(self,args):
        if not 'p' in args: args.p = 1
        if not 'rows' in args: args.rows = 100
        if not 'callback' in args: args.callback = ''
        args.p = int(args.p)
        args.rows = int(args.rows)
        kw_file='%s%s/kw.config'%(self.__data_path,args.domain)
        data=json.loads(public.ReadFile(kw_file))
        data = sorted(data.items(), key=lambda kv: (kv[1], kv[0]), reverse=True)
        count = len(data)
        page_data = public.get_page(count,args.p, args.rows, args.callback)
        data=data[args.p*args.rows-args.rows:args.p*args.rows]
        return {"status":True,"page":page_data['page'],'data':data,"rows":args.rows}
    def get_version(self,args):
        import platform
        data=json.loads(public.ReadFile(self.__plugin_path+"info.json"))
        data['pyversion']=platform.python_version()
        return data

    #获取面板日志列表
    #传统方式访问get_logs方法：/plugin?action=a&name=a_site_click&s=get_logs
    #使用动态路由模板输出： /a_site_click/get_logs.html
    #使用动态路由输出JSON： /a_site_click/get_logs.json
    def get_logs(self,args):
        #处理前端传过来的参数
        if not 'p' in args: args.p = 1
        if not 'rows' in args: args.rows = 12
        if not 'callback' in args: args.callback = ''
        args.p = int(args.p)
        args.rows = int(args.rows)
        #取日志总行数
        count = public.M('logs').where('type=?',(u'site管理',)).count()
        #获取分页数据
        page_data = public.get_page(count,args.p,args.rows,args.callback)
        #获取当前页的数据列表
        log_list = public.M('logs').where('type=?',(u'site管理',)).order('id desc').limit(page_data['shift'] + ',' + page_data['row']).field('id,type,log,addtime').select()
        #返回数据到前端
        return {'data': log_list,'page':page_data['page'] }

    def set_scan_task(self,args):
        taskStatus = self.__get_config('task_Status')
        if taskStatus:return {"status":False,'msg':'任务已运行'}
        task_url=args.task_url
        try:
            find = re.match('(\w+:\/\/)([^/:]+)(:\d*)?',task_url)
            web_url = find.group()
        except Exception as e:
            return {'status':False,'msg':"网址匹配错误",'error':str(e)}
        scan_type=args.scan_type
        self.__set_config('last_web_url',web_url)
        self.__set_config('last_scan_type',scan_type)
        ret=public.ExecShell('''nohup %s %ssite_task.py "%s" %s &'''%(self.pypath,self.__plugin_path,web_url,scan_type))
        return {"status":True,'msg':'任务运行中','ret':ret}

    def set_push_task(self,args):
        p_id = args.p_id
        web_url = args.web_url
        script_path=self.__plugin_path+'web_push.py'
        p_token = ""
        sm_url=""
        push_new = self.__get_config('push_new')
        for item in self.__get_config('site_data'):
            if item['web_url'].find(web_url) != -1:
                p_token=item['token']
                sm_url=str(item["sm_url"])
        if not p_token:
            return {"status": False, 'msg': "未发现站点token，请手动添加"}
        if p_id == 'create-push':
            self.create_site_url(args)
            self.write_logs('随机生成推送%s条' % args.total_num)
            error = public.ExecShell('''nohup %s %s %s "%s" "%s" %s %s &''' % (self.pypath,script_path,'/tmp/.url_list.txt',p_token,web_url,"False","test"))[1]
            if error:
                ret = {"status": False, 'msg': error}
            else:
                ret = {"status": True, 'msg': "推送成功"}
            return ret
        task = {'type':'day'}
        task_name = "[网站优化插件][定时每日]推送[%s]"%web_url
        for file in os.listdir(self.__data_path + web_url):
            file = self.__data_path + web_url + '/' + file
            if push_new:
                if re.search('new_html', file):
                    txt_path = file
            else:
                if re.search('%s1\.txt' % web_url, file):
                    txt_path = file
        if p_id=='auto-push' and p_token and txt_path:
            task['name']='定时推送网站:%s'%web_url
            task['sBody']='''%s %s %s "%s" "%s" "%s"'''%(self.pypath,script_path,txt_path,p_token,web_url,sm_url)
            ret = self.crontab_task(task_name,task)
            self.write_logs('添加定时任务每天推送%s'%web_url)
        elif p_id=='active-push':
            error = public.ExecShell('''nohup %s %s %s %s "%s" "%s" &'''%(self.pypath,script_path,txt_path,p_token,web_url,sm_url))[1]
            self.write_logs('手动推送%s' % web_url)
            if error:
                ret={"status":False,'msg':error}
            else:
                ret={"status":True,'msg':"推送成功"}
        else:
            return {"status":False,'msg':"参数错误"}
        return ret

    def set_val(self,args):
        val_list= ['mip_push','speed_push','push_new']
        for item in val_list:
            try:
                if args.__getitem__(item) == '0':
                    self.__set_config(item, False)
                else:
                    self.__set_config(item, True)
            except Exception as e:
                continue
        return {"status":True,'msg':'设置成功'}

    def crontab_task(self,task_name,task_list):
        cronInfo = public.M('crontab').where('name=?',(task_name,)).getField ('id')
        if cronInfo:
            return {"status":False,'msg':"任务已存在"}
        else:
            task_obj = crontab.crontab()
            task={}
            task['name']=task_name
            task['type']='day'
            task['where1']=""
            task['hour']="23"
            task['minute']="30"
            task['week']=""
            task['sType']="toShell"
            task['sBody']=""
            task['sName']=""
            task['backupTo']="backupTo"
            task['save']=""
            task['urladdress']="undefined"
            if "type" in task_list:
                task['type']=task_list['type']
            if "week" in task_list:
                task['week'] = task_list['week']
            if "sBody" in task_list:
                task['sBody']= task_list['sBody']
            if "where1" in task_list:
                task['where1']=task_list['where1']
            ret = task_obj.AddCrontab(task)
            return ret

    def set_analyse(self,args):
        is_analyse=args.status
        if is_analyse=='0':
            self.__set_config("is_analyse",False)
        else:self.__set_config("is_analyse",True)
        return {"status":True,'msg':"设置成功"}

    # def set_shenma_mip(self,args):
    #     sm_mip=args.sm_mip
    #     if sm_mip =="0":
    #         self.__set_config("sm_mip",False)
    #     else:
    #         self.__set_config("sm_mip",True)
    #     return {"status": True, 'msg': '设置成功'}

    def scan_all_data(self,args):
        tmp={'status':True,'data':[]}
        if len(os.listdir(self.__data_path))>0:
            for site_name in os.listdir(self.__data_path):
                tmp['data'].append(site_name)
        else:
            tmp['status']=False
        return tmp

    def scan_site_data(self,args):
        tmp = {'status': True, 'data': []}
        data=self.__get_config('site_data',force=True)
        if len(data)>0:
            for i in data:
                tmp['data'].append(i)
        return tmp

    def extend_kw(self,args):#python版本中文编码注意
        word_list = args.words
        domain=args.domain.strip()
        kw_file= "site_kw_%s"%self.get_random('char',5)
        public.WriteFile("/tmp/"+kw_file,word_list)
        script_path=self.__plugin_path+"extend_tools.py"
        script='''nohup %s %s '%s' '%s' &'''%(self.pypath,script_path,domain,kw_file)
        os.system(script)
        return {"status":True,'msg':"后台任务已启动，任务完成后可在扩展记录查询，请勿重复推送！",'debug':script,'words':word_list}
    def kill_task(self,args):
        site_name=args.site_name
        self.__set_config('task_Status',False)
        public.ExecShell("kill -9 $(ps aux|grep 'site_task.py'|grep -v grep|awk '{print $2}')")
        self.write_logs('终止扫描%s'%site_name)
        return {"status":True,'msg':"取消成功"}

    def delete_extend_data(self,args):
        ret = {"status": True, 'msg': '删除成功'}
        file_path=args.file_path
        if os.path.exists(file_path):
            os.remove(file_path)
        else:
            ret['msg']="文件不存在"
            ret['status']=False
        return ret
    def delete_site_data(self,args):
        file_path=self.__data_path+args.file_name
        ret={"status":True,'msg':'删除成功'}
        if os.path.exists(file_path):
            shutil.rmtree(file_path)
            self.write_logs('删除站点%s扫描数据'%args.file_name)
        else:
            ret['status']=False
            ret['msg']='删除失败'
        return ret


    def del_log(self,args):
        ret=public.M('logs').where('type=?', (u'site管理',)).delete()
        return public.returnMsg(True, '清理成功')

    def write_logs(self,logstr):
        public.WriteLog('site管理',logstr)


    #读取配置项(插件自身的配置文件)
    #@param key 取指定配置项，若不传则取所有配置[可选]
    #@param force 强制从文件重新读取配置项[可选]
    def __get_config(self,key=None,force=False):
        #判断是否从文件读取配置
        if not self.__config or force:
            if not os.path.exists(self.config_file): return None
            f_body = public.ReadFile(self.config_file)
            if not f_body: return None
            self.__config = json.loads(f_body)

        #取指定配置项
        if key:
            if key in self.__config: return self.__config[key]
            return None
        return self.__config

    #设置配置项(插件自身的配置文件)
    #@param key 要被修改或添加的配置项[可选]
    #@param value 配置值[可选]
    def __set_config(self,key=None,value=None):

        #是否需要初始化配置项
        if os.path.exists(self.config_file):
            f_body = public.ReadFile(self.config_file)
            self.__config = json.loads(f_body)

        #是否需要设置配置值
        if key:
            self.__config[key] = value

        #写入到配置文件

        public.WriteFile(self.config_file,json.dumps(self.__config))
        return True

