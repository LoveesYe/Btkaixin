# -*- coding:utf-8 -*-
#Author:xf
import requests
import json
import os
import sys
import re
import logging.handlers
import logging
import io
import time
import random
import threading
import threadpool
if sys.version_info[0] == 2:
    reload(sys)
    sys.setdefaultencoding('utf8')


headers = [{'User-Agent': 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_8; en-us) AppleWebKit/534.50 (KHTML, like Gecko) Version/5.1 Safari/534.50'}, {'User-Agent': 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-us) AppleWebKit/534.50 (KHTML, like Gecko) Version/5.1 Safari/534.50'}, {'User-Agent': 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0;'}, {'User-Agent': 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.0; Trident/4.0)'}, {'User-Agent': 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0)'}, {'User-Agent': 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1)'}, {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1'}, {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:2.0.1) Gecko/20100101 Firefox/4.0.1'}, {'User-Agent': 'Opera/9.80 (Macintosh; Intel Mac OS X 10.6.8; U; en) Presto/2.8.131 Version/11.11'}, {'User-Agent': 'Opera/9.80 (Windows NT 6.1; U; en) Presto/2.8.131 Version/11.11'}, {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_0) AppleWebKit/535.11 (KHTML, like Gecko) Chrome/17.0.963.56 Safari/535.11'}, {'User-Agent': 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; Maxthon 2.0)'}, {'User-Agent': 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; TencentTraveler 4.0)'}, {'User-Agent': 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1)'}, {'User-Agent': 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; The World)'}, {'User-Agent': 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; Trident/4.0; SE 2.X MetaSr 1.0; SE 2.X MetaSr 1.0; .NET CLR 2.0.50727; SE 2.X MetaSr 1.0)'}, {'User-Agent': 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; 360SE)'}, {'User-Agent': 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; Avant Browser)'}, {'User-Agent': 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1)'}]


class Logging():
    __flag = None
    def __new__(cls, *args, **kwargs):
        if not cls.__flag:
            cls.__flag = super().__new__(cls)
        return cls.__flag
    def __init__(self):
        if 'logger' not in self.__dict__:
            logger = logging.getLogger()
            logger.setLevel(level=logging.INFO)
            handler = logging.handlers.RotatingFileHandler('/www/server/panel/plugin/a_site_click/extend.log',mode="a", maxBytes=1024 * 1024 * 2,backupCount=2, encoding="utf-8")
            console = logging.StreamHandler()
            formatter = logging.Formatter('%(asctime)s - %(module)s - %(levelname)s - %(message)s',"%Y/%m/%d-%H:%M:%S")
            handler.setFormatter(formatter)
            console.setFormatter(formatter)
            logger.addHandler(handler)
            logger.addHandler(console)
            self.logger = logger

    def Write_error_log(self,msg):
        logging.error(str(msg),exc_info = True)
    def Write_info_log(self,msg):
        logging.info(str(msg))

class kw_main():
    def __init__(self):
        self.total=""
        self.word_list=[]
    def get_baidu_pc(self,word):
        pc_url = 'https://sp0.baidu.com/5a1Fazu8AA54nxGko9WTAnF6hhy/su?wd=%s&sugmode=2&json=1&p=3&sid=1427_21091_21673_22581&req=2&pbs=%%E5%%BF%%AB%%E6%%89%%8B&csor=2&pwd=%%E5%%BF%%AB%%E6%%89%%8B&cb=jQuery11020924966752020363_1498055470768&_=1498055470781' % word
        r = requests.get(pc_url,headers=random.sample(headers,1)[0],timeout=30)
        ret = r.text[41:-2]  # 获取返回的内容
        pc_kw = json.loads(ret)  # json格式转换
        return pc_kw['s']  # 返回关键词列表

    def get_baidu_mip(self,word):
        mip_url = "http://m.baidu.com/su?pre=1&p=3&ie=utf-8&json=1&wd=%s" % word
        r = requests.get(mip_url,headers=random.sample(headers,1)[0],timeout=30)
        mip_kw = r.text.replace("window.baidu.sug(", "").replace(");", "")
        mip_kw = json.loads(mip_kw)
        return mip_kw['s']

    def get_more_sug(self,word):
        tmp=[]
        log_obj.Write_info_log("%s - 当前关键词%s" % (domain, word))
        for i in 'abcdefghijklmnopqrstuvwxyz':
            for j in "abcdefghijklmnopqrstuvwxyz":
                log_obj.Write_info_log('当前多少个%s'%len(tmp))
                if len(tmp) > (100*len(self.word_list)):
                    log_obj.Write_info_log('采集个数超过限制,退出')
                    break
                try:
                    tmp += self.get_baidu_pc(word + i + j)
                    tmp += self.get_baidu_mip(word + i + j)
                    tmp = list(set(tmp))
                except Exception as e:
                    log_obj.Write_error_log("错误！")
            else:
                continue
            break
        ret = "\n".join(list(set(tmp)))
        self.total+=ret
    def run(self,filename):
        kw_path='/tmp/%s'%kw_file
        with io.open(kw_path,'r',encoding='utf-8')as g:
            word_list=g.readlines()
            self.word_list = word_list
        log_obj.Write_info_log('当前关键词个数%s'%(len(self.word_list)))
        pool = threadpool.ThreadPool(4)
        requests = threadpool.makeRequests(self.get_more_sug,word_list)
        for req in requests:
            pool.putRequest(req)
        pool.wait()
        with io.open(filename,'w+',encoding='utf-8')as f:
            f.write(self.total)
        os.remove(kw_path)

if __name__ =="__main__":
    log_obj=Logging()
    domain = sys.argv[1]
    kw_file = sys.argv[2]
    try:
        path = "/www/server/panel/plugin/a_site_click/site_data/" +domain
        log_obj.Write_info_log(path)
        index=0
        if os.path.exists(path):
            os.chdir(path) #切换路径
            file_list=os.listdir(path)
            for file in file_list:
                ret = re.search("extend_kw_(\d+).txt",file)
                file_index= int(ret.group(1)) if ret else 0
                if file_index > index:
                    index=file_index
            index+=1
            file_name="extend_kw_%s.txt"%str(index)
            obj=kw_main()
            obj.run(file_name)
            result_file=path+"/"+file_name
            if not os.path.getsize(result_file):
                log_obj.Write_info_log('扩展文件内容为空，删除扩展文件')
                os.remove(result_file)
        else:
            log_obj.Write_info_log("文件结构不正确")
    except Exception as e:
        log_obj.Write_error_log("!!!")
        os.remove("/tmp/" + kw_file)
