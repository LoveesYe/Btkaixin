# -*- coding: utf-8 -*-



headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.121 Safari/537.36"
}


def WriteFile(filename,s_body=None,mode='w+'):
    """
    写入文件内容
    @filename 文件名
    @s_body 欲写入的内容
    return bool 若文件不存在则尝试自动创建
    """
    try:
        fp = open(filename, mode)
        if s_body:
            fp.write(s_body)
        return fp
    except:
        try:
            fp = open(filename, mode,encoding="utf-8",errors='ignore')
            if s_body:
                fp.write(s_body)
            return fp
        except:
            return fp

class site_manager:
    def __init__(self,domain,is_analyse):
        self.domain=domain
        self.n = 1
        self.is_analyse=is_analyse
        self.date=time.strftime('%Y-%m-%d',time.localtime())
        self.site_data='/www/server/panel/plugin/a_site_click/site_data/'+self.domain
        if not os.path.exists(self.site_data):
            os.makedirs(self.site_data)

    def name(self,c):
        opxml = WriteFile('%s/%s%s.xml' % (self.site_data,self.domain,c),'''<?xml version="1.0" encoding="utf-8"?>
<urlset>\n''')
        return opxml
    def zhizuo(self,urllist):
        print('开始写入文件')
        xmldata = self.name(self.n)
        m = 0
        for i in urllist:
            i = i.strip()
            m += 1
            sitemaps = '''    <url>
        <loc>''' + str(i) + '''</loc>
        <lastmod>''' + self.date + '''</lastmod>
        <priority>0.8</priority>
    </url>\n'''
            xmldata.write(sitemaps)
            if m == 50000:
                self.n += 1
                xmldata.write('</urlset>\n')
                xmldata = self.name(self.n)
                m = 0
            else:
                pass
        self.n=1
        xmldata.write('</urlset>\n')
        self.writetxt(urllist)
    def writetxt(self,urllist):
        tmp=''
        if len(urllist)<50000:
            f = WriteFile('%s/%s%s.txt' % (self.site_data, self.domain, self.n))
            for k in urllist:
                tmp=tmp +k+"\n"
            f.write(tmp)
        else:
            m=0
            for i in urllist:
                i = i.strip()
                m += 1
                tmp=tmp+i+'\n'
                if m == 50000:
                    f = WriteFile('%s/%s%s.txt' % (self.site_data, self.domain, self.n))
                    f.write(tmp)
                    f.close()
                    m=0
                    tmp=''
                    self.n+=1
            self.n =1
    def writetxt404(self,urllist):
        tmp2=''
        if len(urllist)<50000 and len(urllist)>0:
            f = WriteFile('%s/%slost%s.txt' % (self.site_data, self.domain, self.n))
            for k in urllist:
                tmp2=tmp2 +k+"\n"
            f.write(tmp2)
        else:
            m=0
            for i in urllist:
                i = i.strip()
                m += 1
                tmp2=tmp2+i+'\n'
                if m == 50000:
                    f = WriteFile('%s/%s%s.txt' % (self.site_data, self.domain, self.n))
                    f.write(tmp2)
                    f.close()
                    m=0
                    tmp2=''
                    self.n+=1
            self.n =1
    def write_kw(self,kw_dic):
        f=WriteFile("%s/kw.config"%self.site_data,mode='w+')
        f.write(json.dumps(kw_dic))
        f.close()

def get_ele_obj(data,ele=True):
    if type(data).__name__ == 'unicode':
        data = data.encode("utf-8",'ingore')
    if type(data).__name__!='str':
        codding = chardet.detect(data)['encoding']
        data = data.decode(codding,'ignore')
    if ele:
        data = etree.HTML(data)
    return data

def get_href_li(url):
    global is_analyse
    try:
        s=requests.session()
        response=s.get(url,headers=headers,timeout=time_out)
        if response.status_code == 404:
            die_url.add(url)
            print(url,'404')
        if response.status_code !=200:
            return [],response.status_code
        source_obj=get_ele_obj(response.text)
        if is_analyse:
            set_kw(response.text)
        urls_li = list(set(source_obj.xpath("//a/@href")))
    except Exception as e:
        die_url.add(url)
        print(str(e)+"==="+url)
        return [],str(str(e)+"===="+url)
    return urls_li,response.text

def set_kw(html):
    global kw_dic
    kw_tmp=analyse.textrank(html,topK=10, withWeight=False)
    for item in kw_tmp:
        if item in kw_dic:
            kw_dic[item]+=1
        else:
            kw_dic[item]=1
def get_loop_url(urls,first=False):   #/news  /product
    global is_analyse
    if sys.version_info[0] == 2:
        if len(list_href)>200:
            return
        # print(list_href,'每次循环',num)
        for url in urls:
            urls_li,resp = get_href_li(url)
            complete_url=check_replace_url(urls_li,abs_url=url)
            if not first:
                complete_url=complete_url-list_href
            if len(complete_url)>1:
                get_loop_url(complete_url)
    else:
        print('python3')
        from s_tools import spider_main
        obj = spider_main()
        obj.run(urls)
        for key in obj.result:
            try:
                source_obj = get_ele_obj(key[1])
            except Exception as e:
                continue
            if not source_obj:
                continue
            if is_analyse:
                set_kw(key[1])
            urls_li = list(set(source_obj.xpath("//a/@href")))
            complete_url = check_replace_url(urls_li,abs_url=key[2])
            if not first:
                complete_url = complete_url - list_href
            if len(complete_url) > 1:
                get_loop_url(complete_url)
        if obj.die_url:
            die_url.update(obj.die_url)

def check_new_html(set_url):
    set_url= set(set_url)
    old_data=set()
    site_data_path= plugin_path + '/site_data/'+domain
    print(site_data_path)
    file_names = glob.glob('%s/%s?.txt'%(site_data_path,domain))
    if len(file_names)>0:
        for file_name in file_names:
            try:
                datas = open(file_name,'r').readlines()
                for data in datas:
                    old_data.add(data.strip())
            except Exception as e:
                print(str(e),"=====")
        print(old_data)
        print(set_url)
        new_data = set_url - old_data
        if len(new_data)>0:
            new_txt = "\n".join(new_data)
            f = WriteFile("%s/%s"%(site_data_path,"new_html.txt"))
            f.write(new_txt)
            f.close()
def check_replace_url(urls_li,abs_url=""):
    global num,site_type,second_domain
    tmp=set()
    for item in urls_li:
        if re.match('^/.*[^/]$',item): #匹配不完全路径/开头路径
            tmp.add(web_url+item)
        elif re.search('%s'%domain,item): #匹配主域名url
            tmp.add(item)
        elif re.search('^(?!(index)).*\.(html|xml|php)$',item):  #匹配相对路径
            tmp.add(abs_url+'/'+item)
        elif site_type=='3' and re.search('%s'%second_domain,item):
            tmp.add(item)

    list_href.update(tmp)
    num+=1
    return tmp
def get_first_url(url,site_type):
    urls_li,resp=get_href_li(url)
    if len(urls_li)<1:
        raise Exception('【获取地址错误，请查看是否有防火墙】'+str(resp))
    complete_url=check_replace_url(urls_li,abs_url=url)
    for url in complete_url:
        if check_404(url):list_href.remove(url)
    if site_type == '1':  #全站扫描
        get_loop_url(complete_url,first=True)
    print(die_url,'404')
def check_404(url):
    try:
        req=requests.get(url,headers=headers,timeout=time_out)
        if req.status_code == 404:
            die_url.add(url)
            return True
        else:
            return False
    except requests.Timeout as e:
        timeout_url.add(url)
        return True
    except Exception as e:
        return True

def write_logs(logstr):
    public.WriteLog('site管理',logstr)
def set_config(key=None,value=None):
    global __config
    config_file = '/www/server/panel/plugin/a_site_click/config.json'
    #是否需要初始化配置项
    if os.path.exists(config_file):
        f_body = public.ReadFile(config_file)
        __config = json.loads(f_body)
    #是否需要设置配置值
    if key:
        __config[key] = value
    #写入到配置文件

    public.WriteFile(config_file,json.dumps(__config))
    return True

def get_config(key):
    if os.path.exists('/www/server/panel/plugin/a_site_click/config.json'):
        f_body = public.ReadFile('/www/server/panel/plugin/a_site_click/config.json')
        data=json.loads(f_body)[key]
    else:
        data=None
    return data

if __name__ =='__main__':
    import requests, json
    from lxml import etree
    import chardet, re
    import glob
    import time, sys, os, shutil
    # 添加包引用位置并引用公共包
    sys.path.append("/www/server/panel/class/")
    import public
    try:
        import jieba.analyse as analyse
        chose_type = {"1": "全站扫描", '2': "单页扫描","3":"包含二级域名扫描"}
        plugin_path = os.path.abspath(os.path.dirname(__file__))  # /www/server/panel/plugin/a_site_click
        __config = {}
        num = 0
        list_href = set()
        die_url = set()
        timeout_url = set()
        kw_dic = {}
        time_out = 5
        url= sys.argv[1]
        site_type=sys.argv[2]
        find = re.match('(\w+:\/\/)([^/:]+)(:\d*)?', url)
        web_url = find.group()
        domain = find.group(2)
        second_domain = ".".join(domain.split('.')[1:])
        print(domain)
        is_analyse=get_config("is_analyse")
        set_config('task_Status',True)
        set_config('last_domain',domain)
        set_config('error',"")
        write_logs('开始扫描%s==>>扫描类型%s==>%s'%(domain,chose_type[site_type],is_analyse))
        get_first_url(url,site_type)
        p = site_manager(domain,is_analyse)
        list_href=list_href-die_url
        list_href = sorted(list(list_href))
        die_url=sorted(list(die_url))
        check_new_html(list_href)
        p.zhizuo(list_href)
        p.writetxt404(die_url)
        if len(kw_dic)>0:
            print("关键词结果",kw_dic)
            p.write_kw(kw_dic)
        set_config('task_Status',False)
        write_logs('扫描完成%s' % domain)
        set_config('error',"")
        print(timeout_url,'timeout')
    except Exception as e:  #处理报错
        set_config('task_Status',False)
        set_config('error',str(e))


