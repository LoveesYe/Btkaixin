#!/bin/bash
PATH=/www/server/panel/pyenv/bin:/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH

#配置插件安装目录
install_path=/www/server/panel/plugin/a_site_click

#安装
Install()
{

	python -m pip install -r requirement.txt -i http://mirrors.aliyun.com/pypi/simple/ --trusted-host mirrors.aliyun.com  > /tmp/install.log 2>&1

    if [ -f "/www/server/panel/pyenv/bin/python" ];then
        /www/server/panel/pyenv/bin/python  -m pip install -r requirement.txt -i http://mirrors.aliyun.com/pypi/simple/ --trusted-host mirrors.aliyun.com  > /tmp/install.log 2>&1
        /www/server/panel/pyenv/bin/python  -m pip install aiohttp asyncio -i http://mirrors.aliyun.com/pypi/simple/ --trusted-host mirrors.aliyun.com
    else
    echo "文件不存在"
    fi
	cp -rf $install_path/icon.png "/www/server/panel/BTPanel/static/img/soft_ico/ico-a_site_click.png"
	echo '正在安装...'
	#==================================================================
	#依赖安装开始


	#依赖安装结束
	#==================================================================

	echo '================================================'
	echo '安装完成'
}

#卸载
Uninstall()
{
	rm -rf $install_path
}

#操作判断
if [ "${1}" == 'install' ];then
	Install
elif [ "${1}" == 'uninstall' ];then
	Uninstall
else
	echo 'Error!';
fi
