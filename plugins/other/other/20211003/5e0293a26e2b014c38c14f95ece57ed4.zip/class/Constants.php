<?php

 /**
 * 描述参数，下一版本完善
 * @QQ：285219785
 * @author 大贤
 * @copyright 广州飞梦信息技术有限公司
 * @date 2021-05-19
 * 
 * */

class Constants
{
    //addTask
    const ERR_TIPS = ' - 如正常操作仍出现问题，请联系开发者QQ:285219785';
    
    const COMP_FOLDER_NOT_EXIST = '压缩文件夹[0]不存在';
    const COMP_FOLDER_DISABLE = '压缩文件夹不能为空、根目录/、当前目录./、上层目录../';
    const PATH_UNREADABLE = '压缩文件夹[0]不可读！';
    
    const SKIP_FOLDER_NOT_EXIST = '排除文件夹[0]不存在';
    const SKIP_FOLDER_DISABLE = '排除文件夹不能为空、根目录/、当前目录./、上层目录../';
    const SKIP_FOLDER_NOT_COMP  = '排除文件夹[0]不能与压缩文件夹相同！';    
    
    const SIZE_TOO_LOW = '限制尺寸必须大于10KB';
    const SIZE_TOO_HEIGHT = '限制尺寸必须小于5000KB';
    
    const MAXWIDTH_TOO_LOW = '压缩宽度不能小于30像素';
    const MAXWIDTH_TOO_HIGH = '压缩宽度不能大于3000像素';
    
    const MAXHEIGHT_TOO_LOW = '压缩高度不能小于30像素';
    const MAXHEIGHT_TOO_HIGH = '压缩高度不能大于3000像素';
    
    const WATERMARK_UNREADABLE = '水印文件不可读';
    const SAVEPATH_UNWRITEABLE = '覆盖目录不可写';
    const BACKUPATH_UNWRITEABLE = '备份目录不可写';
    
    const TASKNAME_EMPTY = '任务名不能为空';
    const FULLPATH_UNWRITEABLE = '压缩文件录不可写，无法保存';
    const NO_PICTURE_FOUND = '没有找到符合压缩条件的图片，请降低压缩条件再试';
    const FORCE_STOP = '被系统强制停止执行，请检查配置是否强制停止状态。';
    
    //index
    const GET_DATA_SUCCESS = '获取数据成功';
    
    const DELETE_ID_NOTEMPTY = '删除ID不能为空';
    const DELETE_TASK_SUCCESS = '删除成功，如刷新后记录仍未删除，请联系开发者。';
    const DELETE_TASK_FAILISE = '移除任务失败';
    const DELETE_QUEUE_FAILSE = '移除压缩队列失败';
    const DELETE_LOG_FAILSE = '删除日志失败，请手工删除';
    const GET_LIST_SUCCESS = '获取列表完毕';
    const OPERATE_SUCCESS = '操作成功';
    const OPERATE_FAILSE = '操作失败';
    const TASK_RUNNING = '此任务已经在运行';
    
    const TASK_ID_NOTEMPTY = '没有指定任务ID';
    const CREATE_TASK_FAILSE = '创建任务失败';
    const CANNOT_FOUND_IMAGE = '没有找到可压缩的图片';
    const CREATE_TASK_SUCCESS = '创建任务成功';
    
    const WATERMASK_NOT_EXIST = '水印文件不存在';
    const WATERMARK_ONLY_PNG = '水印文件只支持png文件';
    const WATERMARK_PARA_EMPTY = '水印位置参数不正确';
    const MAKE_DEMO_SUCCESS = '生成demo文件成功';
    const WATERMARK_FONT_EMPTY = '水印文字不能为空';
    
    const GET_CONFIG_SUCCESS = '获取配置成功';
    
    //imageTask
    const BACKUP_FAILSE = '备份文件失败';
    const UPDATE_TASK_FAILSE = '更新任务记录失败';
    
    const CREATE_BACKUPATH_FAILSE = '创建备份目录失败';
    const CREATE_SAVEPATH_FAILSE = '创建保存目录失败';
    
}



?>