<?php
 
 /**
 * 任务数据操作类
 * @QQ：285219785
 * @author 大贤
 * @copyright 广州飞梦信息技术有限公司
 * @date 2021-05-19
 * 
 * */


class DataTask extends Data
{
    public function __construct()
    {
        parent::getInstance();
    }
    
    public function createTask($taskname, $rules)
    {
        return parent::$db -> table('task') -> insert(array(
            'name'  => $taskname,
            'rules' => serialize($rules),
            'createtime' => time()
        ));
    }
    
    /**
     * 移除任务
     * 
     * 
     * */
    public function delTask($taskID)
    {
        return parent::$db  -> table('task')
                            -> delete()
                            -> where('taskID', $taskID)
                            -> rows(null,null);
    }
    
    /**
     * 获取任务
     * 
     * */
    public function getTaskInfo($taskID)
    {
        return parent::$db  -> table('task')
                            -> select()
                            -> where('taskID',$taskID)
                            -> row();
    }
    
    /**
     * 更新任务
     * 
     * */
    public function updateTaskData($taskID, $updateColumn)
    {
        $update = parent::$db -> table('task')
                              -> update(implode(',',array_keys($updateColumn)))
                              -> where('taskID', $taskID)
                              -> set(array_values($updateColumn));
        return $update -> rows(null,null);
    }

    /**
     * 获取列表
     * 
     * 
     * */
    public function getTaskList($params = [])
    {
        $table = parent::$db -> table('task') -> select();
        if( !empty($params['taskID']) && count($taskIDList = explode(',',$params['taskID'])) > 0 )
        {
            $table -> where('taskID', $taskIDList, 'IN');
        }
        
        $table = $table -> orderBy('createtime', 'DESC');
        if( isset($params['offset']) && isset($params['limit']) )
        {
            $result = $table -> rows(intval($params['limit']), intval($params['offset']));
        }
        else
        {
            $result = $table -> rows();
        }
        
        return $result;        
    }
    
    
    public function getTotal($params = [])
    {
        $table = parent::$db -> table('task') -> select();
        if( !empty($params['taskID']) && count($taskIDList = explode(',',$params['taskID'])) > 0 )
        {
            $table -> where('taskID', $taskIDList, 'IN');
        }
        return $table -> count();
    }
    
    
    /**
     * 
     * 
     * 
     * */
    public function getRunningTask()
    {
        $runningTask = parent::$db  -> table('task') 
                                    -> select('taskID')
                                    -> where('status',1)
                                    -> row();
        if( empty($runningTask) )
        {
            return 0;
        }
        return $runningTask['taskID'];
    }
    
    /**
     * 
     * 
     * */
    public function getStandByTask()
    {
        return parent::$db  -> table('task')
                            -> select()
                            -> where('status',2)
                            -> row();
    }
    
    /**
     * 把任务设置为待执行
     * 
     * */
    public function setTaskPause($taskID)
    {
        return parent::$db  -> table('task')
                            -> update(['status'])
                            -> where('taskID', $taskID)
                            -> set(['3'])
                            -> rows(null,null);
    }
    
    /**
     * 任务异常终止
     * 
     * */
    public function setTaskError($taskID)
    {
        return parent::$db  -> table('task')
                            -> update(['status'])
                            -> where('taskID', $taskID)
                            -> set(['4'])
                            -> rows(null,null);
    }
    
    /**
     * 把未开始的任务设置为“待办”
     * 
     * 
     * */
    public function setStandByTask($taskID)
    {
        return parent::$db  -> table('task')
                            -> update(['status'])
                            -> where('taskID', $taskID)
                            -> where('status',1,'!=')
                            -> set(['2'])
                            -> rows(null,null);
    }
    
    /**
     * 设置任务状态为“进行中”
     * 
     * 
     * */   
    public function setRuningTask($taskID)
    {
       return parent::$db   -> table('task')
                            -> update(['status'])
                            -> where('taskID',$taskID)
                            -> set(['1'])
                            -> rows(null,null);
    }
    
}


?>