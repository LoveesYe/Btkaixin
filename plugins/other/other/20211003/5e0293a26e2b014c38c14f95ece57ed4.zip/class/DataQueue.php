<?php

 
 /**
 * 队列数据操作类
 * @QQ：285219785
 * @author 大贤
 * @copyright 广州飞梦信息技术有限公司
 * @date 2021-05-19
 * 
 * */

class DataQueue extends Data
{
    
    public function createQueue( $queueData )
    {
        return parent::insertIgnoreData('queue', $queueData);
    }
    
    /**
     * 
     * 
     * */
    public function updateQueue($queueID, $updateColumn)
    {
        $update = parent::$db -> table('queue')
                              -> update(implode(',',array_keys($updateColumn)))
                              -> where('queueID', $queueID)
                              -> set(array_values($updateColumn));
        return $update -> rows(null,null);
    }
    
    /**
     * 删除队列数据
     * 
     * 
     * */
    public function delQueueByTaskID($taskID)
    {
        return parent::$db  -> table('queue')
                            -> delete()
                            -> where('taskID', $taskID)
                            -> rows(null,null);
    }
    
    /**
     * 
     * 
     * 
     * */
    public function getQueueList($taskID)
    {
        $result = parent::$db   -> table('queue')
                                -> select()
                                -> where('taskID', $taskID)
                                -> where('status',0)
                                -> rows(1000,0);
        return $result;
    }
    
    /**
     * 
     * 
     * */
    public function getNewQueue($taskID)
    {
        $result = parent::$db -> table('queue')
                -> select()
                -> where('taskID', $taskID)
                -> where('status', 0)
                -> row();
        return $result;    
    }
    
    /**
     * 
     * 
     * 
     * */
    public static function getQueueInfo($taskID)
    {
        $result = parent::$db   -> table('queue')
                                -> select()
                                -> where('status',0)
                                -> where('taskID',$taskID)
                                -> count();
                                
        return $result;
    }
    
    /**
     * 获取当前进度 //SELECT COUNT(*),status,taskID  FROM "queue" WHERE  GROUP BY status,taskID
     * 
     * */
    public static function getQueueProcess($taskID)
    {
        $result = parent::$db -> table('queue')
                              -> select('COUNT(*) AS num,status,taskID')
                              -> where('taskID',array($taskID),'IN')
                              -> groupBy('status,taskID')
                              -> rows();

        $tmpResult = array();
        $array = array(0=>'ready',1=>'finished',2=>'failse');
        foreach($result as $val)
        {
            $tmpResult[$val['taskID']][$array[$val['status']]] = $val['num'];
            !isset($tmpResult[$val['taskID']]['total']) && $tmpResult[$val['taskID']]['total'] = 0;
            $tmpResult[$val['taskID']]['total'] += intval($val['num']);
        }
        $tmpResult = array_values($tmpResult)[0];
        
        return $tmpResult;
    }
    
    /**
     *
     * 
     * 
     * */
    public function getLastRunTime($taskID)
    {
        return parent::$db  -> table('queue')
                            -> select('completetime')
                            -> where('taskID', $taskID)
                            -> where('status', 2)
                            -> orderBy('completetime', 'DESC')
                            -> row();
    }
}



?>