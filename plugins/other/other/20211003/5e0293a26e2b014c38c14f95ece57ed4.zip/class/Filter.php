<?php
 
  /**
 * 图片处理类，包括图片过滤，图片检查等
 * @QQ：285219785
 * @author 大贤
 * @copyright 广州飞梦信息技术有限公司
 * @date 2021-05-19
 * 
 * */

class Filter
{
    public static $filterType = 'jpg|png';
    public static $filterSize = 0;
    public static $filterFolder = [];
    
    /**
     * 过滤尺寸及目录
     * 
     * 
     * */
    public static function filterSizeAndPath($current, $key, $iterator)
    {
        $folderBool = true;
        if( count(self::$filterFolder) > 0 )
        {
            $folderBool = !folderCompare($current->getPathInfo()->getPathname(), self::$filterFolder);
        }
        return  $folderBool && !((self::$filterSize*1024) > $current->getSize());
    }
    
    /**
     * 
     * 
     * 
     * */
    public static function getImageFiles($path,$loopath)
    {
        $filterRegex = new RegexIterator(new RecursiveIteratorIterator(new RecursiveDirectoryIterator($path),$loopath ? RecursiveIteratorIterator::SELF_FIRST : RecursiveIteratorIterator::CATCH_GET_CHILD), '/^.+\.('.self::$filterType.')$/i');
        return $filterRegex;
    }
    
    /**
     * 
     * 
     * 
     * */
    public static function filterImageFiles($regexObject)
    {
        $filterObject = new CallbackFilterIterator($regexObject,__CLASS__.'::filterSizeAndPath');
        return iterator_to_array($filterObject);
    }
    
    /**
     * 
     * 
     * 
     * */    
    public static function filterAllImageFiles($path,$loopath=0)
    {
        return self::filterImageFiles(self::getImageFiles($path, $loopath));
    }
    
}


?>