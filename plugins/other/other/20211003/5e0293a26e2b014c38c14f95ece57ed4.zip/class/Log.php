<?php
 
 /**
 * 日志记录类
 * @QQ：285219785
 * @author 大贤
 * @copyright 广州飞梦信息技术有限公司
 * @date 2021-05-19
 * 
 * */

class Log
{
    public static $fileName;
    public static $fileHandle;
    public static $instance;
    public static $taskID;
    public static $queueID;
    
    public function __construct(){}

    public static function i($taskID)
    {
        return self::getInstance($taskID); 
    }
    
    public static function e($taskID)
    {
        $dataTask = new DataTask();
        $dataTask -> setTaskError($taskID);
        return self::getInstance($taskID); 
    }

    /**
     * 
     * 
     * 
     * */    
    public static function getInstance($taskID)
    {
        if(@!(self::$instance[$taskID] instanceof self))
        {
            self::$instance[$taskID] = new self;
            self::$instance[$taskID]->taskID = $taskID;
            self::$instance[$taskID]->fileName = PLUGIN_PATH . '/log/processlog_'.$taskID.'.log';
            self::$instance[$taskID]->fileHandle = fopen(self::$instance[$taskID]->fileName, "a+");
            if( !self::$instance[$taskID]->fileHandle )
            {
                throw new Exception("无法写入日志文件");
            }   
        }
        return self::$instance[$taskID];
    }
    
    
    /**
     * 写入日志记录
     * 
     * 
     * */
    public function write($content, $queueID = 0)
    {
        $strLog  = date("Y-m-d H:i:s").'：';
        if( $queueID > 0 )
        {
            $strLog .= '(TaskID:'. $this->taskID.',QueueID:'.$queueID.')';
        }
        $strLog .=  $content . "\r\n";
        fwrite($this->fileHandle, $strLog);
    }
    
    /**
     * 
     * 
     * */
    public function del()
    {
        if( file_exists($this->fileName) )
        {
            $result = @unlink($this->fileName);
            return $result;
        }
        return true;
    }
}
?>