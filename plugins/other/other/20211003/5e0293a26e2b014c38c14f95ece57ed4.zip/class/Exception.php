<?php

 /**
 * 异常类，下一版本完善
 * @QQ：285219785
 * @author 大贤
 * @copyright 广州飞梦信息技术有限公司
 * @date 2021-05-19
 * 
 * */
 
 class Exception
 {
     
 }



?>