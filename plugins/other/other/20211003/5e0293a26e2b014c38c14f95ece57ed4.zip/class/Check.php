<?php

 /**
 * 图片检查
 * 检查用户输入的参数是否正确。
 * @QQ：285219785
 * @author 大贤
 * @copyright 广州飞梦信息技术有限公司
 * @date 2021-05-19
 * 
 * */
 
class Check
{
    public function __construct(){}
    
    static function __checkTaskName($taskname)
    {
        if( empty($taskname) )
        {
            Response::error(Constants::TASKNAME_EMPTY);
        }
    }
    
    /**
     * 检查图片路径是否正确
     * @pathList array 图片路径
     * 
     * */
    static function __checkImagePath($addpath)
    {
        foreach(explode(';',$addpath) as $val )
        {
            if( in_array(trim($val), array('','/','./','../')) )
            {
                Response::error(Constants::COMP_FOLDER_DISABLE, array($val));
            }
            elseif( !file_exists( $val ) )
            {
                Response::error(Constants::COMP_FOLDER_NOT_EXIST);
            }
            elseif( !is_readable($val) )
            {
                Response::error(constant::PATH_UNREADABLE, array($val));
            }
        }
    }
    
    /**
     * 检查路径是否正常
     * 
     * 
     * */
    static function __checkSkipaths($skipaths, $fullpath )
    {
        foreach( explode(';',$skipaths) as $val )
        {
            if( in_array(trim($val), array('','/','./','../')) )
            {
                Response::error(Constants::SKIP_FOLDER_DISABLE, array($val));
            }
            elseif( !file_exists( $val ) )
            {
                Response::error(Constants::SKIP_FOLDER_NOT_EXIST);
            }
            elseif( in_array($val, explode(';',$fullpath)) )
            {
                Response::error(Constants::SKIP_FOLDER_NOT_COMP,array($val));
            }
        }
    }
    
    /**
     * 检查水印文件
     * 
     * */
    static function __checkWaterMark($wminfo)
    {
        $wmData = wmStr2Array($wminfo);
        if($wmData['type'] == 1 && !is_readable(PLUGIN_PATH.'/'.Configures::$waterMarkPathName.'/'.$wmData['file']) )
        {
            Response::error(Constants::WATERMARK_UNREADABLE);
        }
    }
    
    /**
     * 检查覆盖目录
     * 
     * */
    static function __checkSavePath($savepath, $fullpath)
    {
        if( !empty($savepath) )
        {
            if( !is_writable($savepath) )
            {
                Response::error(Constants::SAVEPATH_UNWRITEABLE);
            }
        }
        else
        {
            foreach( explode(';', $fullpath) as $val )
            {
                if( !is_writable($val) )
                {
                    Response::error(Constants::FULLPATH_UNWRITEABLE);
                }
            }
        }
    }

    /**
     * 检查备份目录
     * 
     * */
    static function __checkBackupPath($backupath)
    {
        if( !is_writable($backupath) )
        {
            Response::error(Constants::BACKUPATH_UNWRITEABLE);
        }
    }
    
}



?>