<?php

 /**
 * 图片队列处理
 * @QQ：285219785
 * @author 大贤
 * @copyright 广州飞梦信息技术有限公司
 * @date 2021-05-19
 * 
 * */
 
class ImageQueues
{
    public function __construct(){}

    /**
     * 
     * 
     * 
     * */
    public function createQueue($taskID, $rules)
    {
        //扫描图片，入库
        Filter::$filterType = $rules['handletype'];
        Filter::$filterFolder = skipbar(explode(';',$rules['skipaths']??''));
        Filter::$filterSize = intval($rules['sizelimit']);
        
        $dataQueue = new DataQueue();
        foreach(explode(';',$rules['fullpath']) as $val)
        {
            foreach(Filter::filterAllImageFiles($val,$rules['loopath']) as $ikey => $ival)
            {
                //是否覆盖原图
                if( !empty($rules['savepath']) )
                {
                    $savepath = $rules['savepath'] . substr($ikey,strlen($val),strlen($ikey));
                }
                
                if( !empty($rules['backupath']) )
                {
                    $backupath = $rules['backupath'] . substr($ikey,strlen($val),strlen($ikey));
                }
                $imageRecID = $dataQueue -> createQueue(array(
                    'taskID'    => $taskID,    
                    'fullpath'  => $ikey,
                    'filename'  => $ival -> getFilename(),
                    'filesize'  => $ival -> getSize(),
                    'hash'      => md5_file($ikey),
                    'savepath'  => $savepath??'',
                    'backupath' => $backupath??'',
                    'createtime'=> time()
                ));
                $imageRecID && $imgCount = ($imgCount??0) + 1;
            }
        }
        
        //没有图片
        if( !isset($imgCount) || !$imgCount )
        {
            $dataTask = new DataTask();
            $dataTask -> delTask($taskID);
            //报错
            Response::error(Constants::NO_PICTURE_FOUND);
        }
        
        //更新状态
        $dataTask = new DataTask();
        $dataTask -> updateTaskData($taskID, array('totals'=>$imgCount));
        
        return $imgCount;
    }
}



?>