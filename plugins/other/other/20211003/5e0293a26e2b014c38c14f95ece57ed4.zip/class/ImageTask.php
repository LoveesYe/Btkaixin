<?php
 
 /**
 * 图片任务类
 * @QQ：285219785
 * @author 大贤
 * @copyright 广州飞梦信息技术有限公司
 * @date 2021-05-19
 * 
 * */
 

use JBZoo\Image\Image;

class ImageTask
{
    
    public function __construct(){}
    
    public function doTask()
    {
        $dataTask = new DataTask();
        $runTaskID = $dataTask -> getRunningTask();
        
        //如果已有在跑的任务，不要跑
        if( !empty($runTaskID) )
        {
            //超时重跑
            $dataQueue = new DataQueue();
            $lastRunTime = $dataQueue -> getLastRunTime($runTaskID);
            
            $lastUpdate = $lastRunTime['completetime']??0;
            
            if( empty($lastUpdate) || time() - $lastUpdate > SYSTEM_CONFIGS['overtime'] )
            {
                $this->runTask($runTaskID);
            }
        }
        else
        {
            $this->runTask($runTaskID);
        }
    }
    
    /**
     * 压缩代码
     * 
     * 
     * */
    public function runTask($taskID)
    {
        Log::i($taskID)->write('开始执行压缩！');
        $dataTask = new DataTask();
        $configArr = (new DataConfig()) -> getAllConfigs();
        if( $configArr['run'] == 1 )
        {
            Log::i($taskID)->write(Constants::FORCE_STOP);
            $dataTask -> setTaskPause($taskID);
            exit;
        }
        
        //获取任务规则
        $taskInfo = $dataTask -> getTaskInfo($taskID);
        Log::i($taskID)->write('获取任务信息...');
        
        
        //如果此任务已经被暂停或改变为其他状态
        if( empty($taskInfo) || !in_array($taskInfo['status'],array(1,4)) )
        {
            $runTaskID = $dataTask -> getRunningTask();
            if( !$runTaskID )
            {
                Log::i($taskID)->write(print_r($taskInfo,true));
                Log::i($taskID)->write('任务异常或任务或用户暂停...');
                exit;
            }
            $taskID = $runTaskID;
            $taskInfo = $dataTask -> getTaskInfo($taskID);
            
        }
        $taskRules = unserialize($taskInfo['rules']);
        Log::i($taskID)->write('获取任务规则...');
 
        //检查备份目录
        if( !empty($taskRules['savepath']))
        {
            Check::__checkSavePath($taskRules['savepath'],$taskRules['fullpath']);
        }
        
        //检查保存目录        
        if( !empty($taskRules['backupath']) )
        {
            Check::__checkBackupPath($taskRules['backupath']);
        }
        
        //检查水印文件
        // if( $taskRules['wminfo']['watermark'] == 1 )
        // {
        //     ImageCheck::__checkWaterMarkFile($taskRules['wminfo']['wmfile']);
        // }
 
        //获取任务内容
        $dataQueue = new DataQueue();
        $newQueue = $dataQueue -> getNewQueue($taskID);//$dataQueue -> getQueueList($taskID);

        //如果已经完成该任务的所有数据执行
        if( !empty($newQueue) )
        {
            Log::i($taskID)->write('获取一条任务记录，记录ID：'.$newQueue['queueID'].'，压缩文件：'.$newQueue['fullpath']);
            if( !file_exists($newQueue['fullpath']) )
            {
                Log::e($taskID)->write('压缩错误，没有找到压缩文件，请检查文件是否存在：'.$newQueue['fullpath']);
                $dataQueue->updateQueue($val['queueID'], array(
                    'status' => 2
                ));
            }
            else
            {
                
                //$imgInfo = getimagesize($newQueue['fullpath']);
                //var_dump($imgInfo);
                //exit;
                //try
                //{
                    //备份文件
                if(!empty($newQueue['backupath']))
                {
                    Log::i($taskID)->write('正在备份文件...');
                    //检查文件夹是否存在
                    $backupath = pathinfo($newQueue['backupath']);
                    $backupdir = $backupath['dirname'];
                    //文件夹不存在，创建之
                    if( !file_exists($backupdir) )
                    {
                        $mkdirResult = mkdir($backupdir,0755, true);
                        if( !$mkdirResult )
                        {
                            Log::e($taskID)->write('创建备份文件夹失败，请检查文件夹权限或执行权限。'.$backupath, $newQueue['queueID']);
                            //Response::error(Constants::BACKUP_FAILSE,[]);
                        }
                    }
                    //$backupath = $taskRules['backupath'].'/'.$newQueue['filename'];
                    
                    if(!copy($newQueue['fullpath'], $newQueue['backupath']))
                    {
                        Log::e($taskID)->write('备份文件失败！ - '.$newQueue['backupath'], $newQueue['queueID']);
                        //Response::error(Constants::CREATE_BACKUPATH_FAILSE,[]);
                    }
                    Log::i($taskID)->write('备份文件成功 - '.$newQueue['backupath'], $newQueue['queueID']);
                }
            
                //保存路径，留空代表覆盖！
                if( empty($newQueue['savepath']) )
                {
                    $savepath = $newQueue['fullpath'];
                }
                else
                {
                    //不留空，需要创建文件夹
                    //检查文件夹是否存在
                    $savepath = pathinfo($newQueue['savepath']);
                    $savepathdir = $savepath['dirname'];
                    if( !file_exists($savepathdir) )
                    {
                        $mkdirResult = mkdir($savepathdir,0755, true);
                        if( !$mkdirResult )
                        {
                            Log::e($taskID)->write('创建保存文件夹失败，请检查文件夹权限或执行权限。'.$backupath, $newQueue['queueID']);
                            //Response::error(Constants::CREATE_SAVEPATH_FAILSE,[]);
                        }
                    }
                    $savepath = $newQueue['savepath'];
                }
                Log::i($taskID)->write('保存路径...'.$savepath);
                
                //导出类型
                if( $taskRules['exportfile'] != '' )
                {
                    $filePaths = explode('.',$savepath);
                    $filePaths[count($filePaths)-1] = $taskRules['exportfile'];
                    $savepath = implode('.',$filePaths);
                }
                
                $imgInfo = getimagesize($newQueue['fullpath']);
                Log::i($taskID)->write('导出文件 - '.$savepath, $newQueue['queueID']);
                $t1 = microtime(true);
                $usedTime = 0;
                try{
                    @$imageObj = new Image($newQueue['fullpath']);
                    
                    //尺寸压缩
                    $tmpWidthSize = intval($taskRules['maxwidth']) < 1 ? $imgInfo[0] : intval($taskRules['maxwidth']);
                    $tmpHeightSize = intval($taskRules['maxheight']) < 1 ? $imgInfo[1] : intval($taskRules['maxheight']);
                    
                    if( $tmpWidthSize > 0 && $tmpHeightSize > 0 )
                    {
                        $imageObj -> bestFit($tmpWidthSize, $tmpHeightSize);
                        
                        //选择质量
                        $imageObj -> setQuality(intval($taskRules['quality']));
                        //水印
                        if( isset($taskRules['wminfo']) )
                        {   
                            $wminfo = wmStr2Array($taskRules['wminfo']);
                            if( $wminfo['type'] == 1 )
                            {
                                $imageObj -> overlay(PLUGIN_PATH.'/'.Configures::$waterMarkPathName.'/'.$wminfo['file'], $wminfo['position'], $wminfo['tran'], 0, 0); 
                            }
                        }
    
                        //保存
                        if( !$imageObj -> saveAs($savepath) )
                        {
                            Log::e($taskID)->write('压缩图片失败！请确保图片是否有写入权限', $newQueue['queueID']);
                            //Response::error("压缩图片失败！请确保图片是否有写入权限",[]);
                        }
                        
                        $t2 = microtime(true);
                        $usedTime = round($t2 - $t1,3) * 1000;
                        Log::i($taskID)->write('压缩保存成功，用时'.$usedTime.'毫秒', $newQueue['queueID']);
                        $rstatus = 1;
                    }
                    else
                    {
                        Log::e($taskID)->write('获取照片尺寸失败！执行异常', $newQueue['queueID']);
                        $rstatus = 2;
                    }

                }
                catch(exception $e)
                {
                    $rstatus = 2;
                    Log::e($taskID)->write('图片存在异常！'.$e->getMessage(), $newQueue['queueID']);
                }
                
                $updateInfo = array('completetime' => time(),
                                    'usedtime' => $usedTime,
                                    'savepath' => $savepath,
                                    'backupath' => $backupath??'',
                                    'status' => $rstatus
                );
                Log::e($taskID)->write('更新文件压缩状态为'.$rstatus, $newQueue['queueID']);
                
                
                $result = $dataQueue -> updateQueue($newQueue['queueID'], $updateInfo);
                if( !$result )
                {
                    Log::e($taskID)->write('更新数据状态失败。', $newQueue['queueID']);
                }
                else
                {
                    Log::i($taskID)->write('更新数据状态成功。', $newQueue['queueID']);
                }
                //var_dump($imageObj);
                //exit;
                    //sleep(10);
                //}
                //catch( Execption $e)
                //{
                //    Log::e($taskID)->write('未指定的错误：'.print_r($e,true), $newQueue['queueID']);
                //    exit;
                //}
            }
            //执行间隔时间
            if( SYSTEM_CONFIGS['waiting'] > 0 )
            {
                usleep(SYSTEM_CONFIGS['waiting'] * 1000);    
            }
            $this -> runTask($taskID);
        }
        else
        {
            Log::i($taskID)->write('没有找到可执行的记录，更新任务状态，本任务结束。');
            $updateResult = $dataTask -> updateTaskData($taskID, array('status' => 9,'finishtime' => time()));
            if( !$updateResult )
            {
                Log::i($taskID)->write('更新任务记录失败！');
                Response::error(Constants::UPDATE_TASK_FAILSE,[]);
            }
            else
            {
                //获取下一个任务
                $newTask = $dataTask->getStandByTask();
                if( $newTask )
                {
                    //设置为正在执行的任务
                    Log::i($newTask['taskID'])->write('获取到新的任务记录');
                    $dataTask -> setRuningTask($newTask['taskID']);
                    $this -> runTask($newTask['taskID']);
                }
            }
        }
        
    }    
    
    /**
     * 获取任务列表
     * @param int $page
     * 
     * */
    public function getTaskList()
    {
        $taskList = ImageData::getInstance()->getTaskList();
        return $taskList;
    }
    
    /**
     * 扫描，计算数量，入库
     * @param int $taskID 任务ID
     * @param array $rules 压缩规则
     * 
     * */
    // public function createQueue(int $taskID, array $rules):bool
    // {
    //     extract($rules);
    //     //扫描图片，入库
    //     Filter::$filterType = $handle_type;
    //     //$skipathlist = $skipathlist??[];
    //     Filter::$filterFolder = explode(';',$skipathlist??'');
    //     Filter::$filterSize = intval($skipsmall);
    //     foreach(explode(';',$addpath) as $val)
    //     {
    //         foreach(Filter::filterAllImageFiles($val) as $ikey => $ival)
    //         {
    //             $imageRecID = ImageData::getInstance()->insertIgnoreData('queue', array(
    //                 'taskID' => $taskID,
    //                 'fullpath' => $ikey,
    //                 'filename' => $ival->getFilename(),
    //                 'filesize' => $ival->getSize(),
    //                 'hash' => md5_file($ikey),
    //                 'createtime' => time()
    //             ));
    //             $imageRecID && $imgCount = ($imgCount??0) + 1;
    //         }
    //     }
        
    //     //没有图片
    //     if( !isset($imgCount) || !$imgCount )
    //     {
    //         //报错
    //         Response::error(Constants::NO_PICTURE_FOUND);
    //     }
        
    //     //更新状态
    //     ImageData::getInstance()->updateTaskData($taskID, array('totals'=>$imgCount));
        
    //     //事务？
        
    //     return $imgCount;
    // }
    
    /**
     * 
     * 
     * 
     * */
    public function getQueueInfo(int $taskID)
    {
        return ImageData::getQueueInfo($taskID);
    }
    

}


?>