<?php
 
 /**
 * 配置操作类
 * @QQ：285219785
 * @author 大贤
 * @copyright 广州飞梦信息技术有限公司
 * @date 2021-05-19
 * 
 * */
 

class DataConfig extends Data
{

    /**
     * 
     * 
     * */
    public function getConfig($key=null , $fields='*')
    {
        $table = parent::$db -> table('config') -> select($fields);
        if( $key )
        {
            $table -> where('key', $key);
        }
        $result = $table -> rows();
        return $result;
    }

    /**
     * 
     * 
     * */
    public function updateConfig($key, $value)
    {
        $update = parent::$db -> table('config')
                              -> update('value')
                              -> where('key', $key)
                              -> set(array($value));
        return $update -> rows(null,null);
    }


    public function getAllConfigs()
    {
        $configures = $this -> getConfig(null,'key,value');
        $tmpConfigs = [];
        foreach($configures as $key => $val)
        {
            $tmpConfigs[$val['key']] = $val['value'];
        }
        return $tmpConfigs;
    }

}


?>