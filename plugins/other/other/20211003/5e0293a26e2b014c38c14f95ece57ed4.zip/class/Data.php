<?php

 /**
 * 数据类
 * @QQ：285219785
 * @author 大贤
 * @copyright 广州飞梦信息技术有限公司
 * @date 2021-05-19
 * 
 * */
 

class Data
{
    public static $instance;
    public static $db;
    
    /**
     * 
     * 
     * 
     * */
    public function __construct()
    {
        self::$db = \Ufee\Sqlite3\Sqlite::database(Configures::$dbName);
    }    
    
    /**
     * 数据库单例
     * 
     * 
     * */
    public static function getInstance()
    {
        if(!(self::$instance instanceof self))
        {
            self::$instance = new self;
        }
        return self::$instance;
        
    }

    
    /**
     * 插入数据
     * 
     * 
     * */
    public function insertData($table, $data)
    {
        return self::$db->table($table)->insert($data);
    }
    

    
    /**
     * 
     * 
     * 
     * */
    public function insertIgnoreData($table, $data)
    {
        return self::$db->table($table)
                        ->insert(implode(',',array_keys($data)))
                        ->orIgnore()
                        ->row(array_values($data));
    }
    

    
    

    
}


?>