<?php

 /**
 * 配置参数
 * @QQ：285219785
 * @author 大贤
 * @copyright 广州飞梦信息技术有限公司
 * @date 2021-05-19
 * 
 * */

class Configures
{
    //sqlite文件名
    public static $dbName = 'db.php';
    //任务状态
    public static $taskStatus = array( 0 => '未开始', 1 => '进行中', 2 => '等待执行', 3 => '用户暂停', 4 => '坏图异常', 9 => '已完成');
    //导出类型，废弃，下一版本删除
    public static $exportfile = array(0 => '', 1 => 'jpg', 2 => 'png');
    //配置文件
    public static $configfile = './config.ini';
    //水印路径目录
    public static $waterMarkPathName = 'watermark';
    //水印demo初始图片文件名
    public static $demoPath = 'demo.jpg';
    //生成的水印文件名
    public static $userDemoPath = 'userdemo.jpg';

}


?>