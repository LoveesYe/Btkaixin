<?php

/**
 * 错误返回类
 * @QQ：285219785
 * @author 大贤
 * @copyright 广州飞梦信息技术有限公司
 * @date 2021-05-19
 * 
 * */
 


class Response
{
    
    function __construct(){}
    
    /**
     * 
     * 
     * 
     * */
    static function success(string $msg, array $result = [])
    {
        $response = array(
            'error' => 0,
            'msg' => $msg,
            'result' => $result
        );
        exit(json_encode($response));
    }
    
    /**
     * 
     * 
     * 
     * */
    static function error(string $msg, array $param = []):string
    {
        for( $i = 0 ; $i < count($param) ; $i ++ )
        {
            $msg = str_replace("[$i]", $param[$i], $msg);
        }
        $msg .= Constants::ERR_TIPS;
        exit(json_encode(array('error' => 1, 'msg' => $msg)));
    }
    
}






?>