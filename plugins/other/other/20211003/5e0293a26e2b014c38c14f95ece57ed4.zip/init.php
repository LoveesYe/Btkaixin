<?php

 /**
 * 本页面主要是设置一些初始信息，还有公用函数
 * @QQ：285219785
 * @author 大贤
 * @copyright 广州飞梦信息技术有限公司
 * @date 2021-05-19
 * 
 * */

set_time_limit(0);
ignore_user_abort(true);
ini_set("memory_limit",-1);
date_default_timezone_set('PRC');
define('PLUGIN_PATH',dirname(__FILE__));
spl_autoload_register('loadClass');

//获取系统全局配置
define('SYSTEM_CONFIGS',(new DataConfig()) -> getAllConfigs());

/**
 * 公共函数
 * 
 * 
 * */
function loadClass($class)
{
    $classFile = str_replace('\\','/',PLUGIN_PATH . '/class/' . $class . '.php');
    file_exists($classFile) ? require($classFile) : die("糟了，类文件".$classFile."不存在！");
}

/**
 * 公共函数
 * 
 * 
 * */
function intArrayFilter($array)
{
    if( count($array) < 1 )
    {
        return [];
    }
    
    $tmpArray = [];
    foreach($array as $val)
    {
        if( intval($val) > 0 )
        {
            $tmpArray[] = intval($val);
        }
    }
    
    return $tmpArray;
}

/**
 * 水印数据专用函数
 * 
 * */
function wmStr2Array($wmString)
{
    $wminfo = explode(';',$wmString);
    //图片水印
    $wmDataArr = array();
    foreach( $wminfo as $val )
    {
        $tmpinfo = explode('=',$val);
        $wmDataArr[$tmpinfo[0]] = $tmpinfo[1];
    }
    return $wmDataArr;
}


/**
 * 去掉文件夹后面的斜杠
 * 
 * 
 * */
function skipbar($patharr)
{
    foreach( $patharr as $key => $val )
    {
        $patharr[$key] = preg_replace('#/$#','',$val);
        if(empty($val))
        {
            unset($patharr[$key]);
        }
    }
    
    return $patharr;
}

/**
 * 目录对比
 * 
 * */
function folderCompare($compareFolder, $folderArr)
{
    $folderArr = skipbar($folderArr);
    //把文件夹拆开
    $folderNames = explode('/', $compareFolder);
    foreach( $folderArr as $folder )
    {
       $tmpFolders = explode('/', $folder);
       if(empty(array_diff($tmpFolders,$folderNames)))
       {
           return true;
       }
    }
    return false;
}





?>