<?php

 /**
 * 执行文件
 * @QQ：285219785
 * @author 大贤
 * @copyright 广州飞梦信息技术有限公司
 * @date 2021-05-19
 * 
 * */

require_once('init.php');

$imageTask = new ImageTask();
$imageTask -> doTask();


?>