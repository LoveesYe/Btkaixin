<?php

 /**
 * 图片处理
 * @QQ：285219785
 * @author 大贤
 * @copyright 广州飞梦信息技术有限公司
 * @date 2021-05-19
 * 
 * */



require_once('init.php');

use JBZoo\Image\Image;
use Ufee\Sqlite;


class bt_main{
    
    private $all_direct = [];
    private $file_log;
    
    public function __construct(){}
    
    public function showLog()
    {
        $taskID = _post('taskID');
        $logContent = nl2br(file_get_contents(Log::i($taskID)->fileName));
        Response::success(Constants::GET_DATA_SUCCESS,array('content'=>$logContent));
    }
    
    /**
     * 
     * 
     * */
    public function delWatermark()
    {
        $fileName = _post('filename');
        if( !@unlink(PLUGIN_PATH.'/watermark/'.$fileName) )
        {
            Response::error('移除水印文件失败');
        }
        Response::success('移除水印文件成功');
    }
    
    /**
     * 上传水印文件
     * 
     * 
     * */
    public function uploadWatermark()
    {
        $fileName = _post('filename');
        $filePath = PLUGIN_PATH.'/watermark/'.$fileName;
        if( file_exists($filePath) )
        {
            Response::error('水印文件已存在。');
        }
        $matchImage = preg_match('/^(data:\s*image\/(\w+);base64,)/', _post('image'), $result);
        if(!$matchImage)
        {
            Response::error('水印文件解析错误。');
        }
        $base64Image = str_replace($result[1], '', _post('image'));
        $fileContent = base64_decode($base64Image);
        $fileType = $result[2];
        
        if( strtolower($fileType) != 'png' )
        {
            Response::error('水印只能上传PNG格式文件。');
        }
        //写入文件
        $result = file_put_contents($filePath,$fileContent);
        if( !$result )
        {
           Response::error('保存水印文件错误。'); 
        }
        Response::success('上传水印成功');
    }
    
    /**
     * 获取水印文件
     * 
     * 
     * */
    public function getWatermarkList()
    {
        $pngfiles = glob(PLUGIN_PATH.'/watermark/*.png');
        $tmpFiles = array();
        foreach( $pngfiles as $key => $png )
        {
            preg_match('/([^\/]+\.[png])[^\/]*$/', $png , $match);
            //$pngfiles[$key] = $match[0];
            $tmpFiles[] = array('filename'=>$match[0],'fullpath'=>$png);
        }
        
        Response::success('获取水印列表成功',$tmpFiles);
    }
    
    /**
	 * 获取当前进度
	 * @return void
     */
    public function getProcess()
    {
        $dataTask = new DataTask();
        $request = _post();
        $taskIDList = $request['taskID'];
        //获取当前任务列表
        if( empty($taskIDList) )
        {
            //不允许为空
            Response::error(Constants::TASK_ID_NOTEMPTY);
        }
        
        $taskListArr = $dataTask -> getTaskList(array('taskID' => $taskIDList));
        $tmpTaskInfo = array();
        foreach( $taskListArr as $val )
        {
            $tmpTask = array();
            $tmpTask['taskID'] = $val['taskID'];
            $tmpTask['status'] = Configures::$taskStatus[$val['status']];
            $tmpTask['nstatus'] = $val['status'];
            $tmpTask['process'] = DataQueue::getQueueProcess($val['taskID']);
            $tmpTaskInfo[] = $tmpTask;
        }
        
        Response::success(Constants::GET_DATA_SUCCESS,$tmpTaskInfo);
    }

    /**
	 * 读取配置
	 * @return json
     */        
    public function getSysConfig()
    {

        $dataConfig = new DataConfig();
        $configList = $dataConfig -> getConfig([],'key,value,tips,type');
        $tmpConfigs = array();
        foreach( $configList as $val )
        {
            $tmpConfigs[$val['key']] = $val;
        }
        Response::success(Constants::GET_CONFIG_SUCCESS, $tmpConfigs);
    }    
    
    /**
	 * 修改配置
	 * @return json
     */    
    public function setSysConfig()
    {
        $run = _post('run');
        $waiting = _post('waiting');
        $overtime = _post('overtime');
        
        //更新配置内容
        $updateArr = array('run','waiting','overtime');
        $dataConfig = new DataConfig();
        
        foreach( $updateArr as $val )
        {
            $result = $dataConfig -> updateConfig($val,$$val);
            if( !$result )
            {
                Response::error(Constants::OPERATE_FAILSE);
            }
        }
        
        Response::success(Constants::OPERATE_SUCCESS);
    }
    
    /**
	 * 开始跑任务
	 * @return json
     */     
    public function runTask()
    {
        $taskID = _post('taskID');
        $state = _post('state');

        if( SYSTEM_CONFIGS['run'] == 1 )
        {
            Log::i($taskID)->write(Constants::FORCE_STOP);
            Response::error(Constants::FORCE_STOP);
        }

        if( intval($taskID) < 1 )
        {
            Response::error(Constants::TASK_ID_NOTEMPTY);
        }
    
        //检查当前有没有正在跑的任务
        $dataTask = new DataTask();
        $runTaskID = $dataTask -> getRunningTask();        
        if( in_array($state, array(1,3)))
        {
            //点击运行按钮
            if( empty($runTaskID) )
            {
                //没有在跑任务，设置为起跑任务
                $dataTask -> setRuningTask($taskID);
                //异步执行压缩
                @popen('php ./do.php &','r');     
                //$imageTask = new ImageTask();
                //$imageTask -> doTask();
            }
            elseif( $runTaskID == $taskID )
            {
                Response::success(Constants::TASK_RUNNING, []);
            }
            else
            {
                //已有在跑任务，设为待执行
                $dataTask -> setStandByTask($taskID);
            }
        }
        elseif( $state == 2 )
        {
            //暂停执行
            $dataTask -> setTaskPause($taskID);
        }
        Response::success(Constants::OPERATE_SUCCESS, []);
    }    
    
    /**
     * 移除任务
     * @params $taskID 要移除的任务ID
     * 
     * */
    public function delTask()
    {
        $request = _post();
        $taskIDArr = intArrayFilter(explode(',',$request['taskID']));
        if( empty($taskIDArr) )
        {
            Response::error(Constants::DELETE_ID_NOTEMPTY);
        }
        
        $dataTask = new DataTask();
        $dataQueue = new DataQueue();
        foreach( $taskIDArr as $taskID )
        {
            !$dataTask->delTask($taskID); //&& Response::error(Constants::DELETE_TASK_FAILISE); 
            !$dataQueue->delQueueByTaskID($taskID); //&& Response::error(Constants::DELETE_QUEUE_FAILSE);
            !Log::i($taskID)->del(); //&& Response::error(Constants::DELETE_LOG_FAILSE);
        }
        Response::success(Constants::DELETE_TASK_SUCCESS);
    }
    
    /**
     * 获取任务列表
     * 
     * 
     * */
    public function getTaskList()
    {
        $page = _post('page');
        $dbTask = new DataTask();
        $pageSize = 10;
        $totalRecord = $dbTask -> getTotal();
        $pageCount = round($totalRecord/$pageSize,0);
        $offset = $pageSize * ($page-1);
        $taskList = $dbTask -> getTaskList(array('limit'=>$pageSize,'offset' =>$offset));
        
        $taskData = array();
        foreach($taskList as $key => $val)
        {
            //获取当前任务情况
            $tmpTaskData = [];
            $tmpTaskData['id'] =  $val['taskID'];
            $tmpTaskData['name'] = $val['name'];
            $tmpTaskData['create'] = date('Y-m-d H:i:s', $val['createtime']);
            $tmpTaskData['status'] = Configures::$taskStatus[$val['status']];
            $tmpTaskData['feedback'] = $val['feedback'];
            $tmpTaskData['totals'] = $val['totals'];
            $rulesArr = unserialize($val['rules']);
            
            $outputHtml  = '压缩目录：'.$rulesArr['fullpath'].'<br />';
            $outputHtml .= '循环目录：'. ($rulesArr['loopath'] == 1?'是':'否') .'<br />';
            if( $rulesArr['loopath'] == 1 )
            {
                $outputHtml .= '排除目录：'.$rulesArr['skipaths'].'<br />';
            }
            $outputHtml .= '压缩质量：'.$rulesArr['quality'].'%<br />';
            //限制大小
            if( empty($rulesArr['sizelimit']) )
            {
                $outputHtml .= '限制大小：不限制<br />';
            }
            else
            {
                $outputHtml .= '限制大小：'.$rulesArr['sizelimit'].'KB<br />';
            }

            $outputHtml .= '处理类型：'.$rulesArr['handletype'].'<br />';
            $outputHtml .= '最大宽度：'.$rulesArr['maxwidth'].'像素<br />';
            $outputHtml .= '最大高度：'.$rulesArr['maxheight'].'像素<br />';
        
            if( $rulesArr['wminfo'] )
            {
                $wminfo = wmStr2Array($rulesArr['wminfo']);
                if( $wminfo['type'] == 0 )
                {
                    $outputHtml .= '水印内容：无水印<br />';
                }
                elseif( $wminfo['type'] == 1 )
                {
                    $outputHtml .= '水印内容：图片水印，'.$wminfo['file'].'，'.$wminfo['position'].'，'.$wminfo['tran'].'%<br />';
                }
                
            }
            
            $outputHtml .= '导出类型：'. (empty($rulesArr['exportfile'])?'不变化':$rulesArr['exportfile'])  .'<br />';
            //保存路径
            if( empty($rulesArr['savepath']) )
            {
                $outputHtml .= '保存路径：覆盖本地<br />';
            }
            else
            {
                $outputHtml .= '保存路径：'.$rulesArr['savepath'].'<br />';
            }
            
            //备份目录
            if( empty($rulesArr['backupath']) )
            {
                $outputHtml .= '备份目录：不备份<br />';
            }
            else
            {
                $outputHtml .= '备份目录：'.$rulesArr['backupath'].'<br />';
            }

            $tmpTaskData['rules'] = '<span class=f14>'.$outputHtml.'</span>';
            
            $taskData[] = $tmpTaskData;
        }
        Response::success(Constants::GET_LIST_SUCCESS, array('currPage' => $page, 'totalRecord' => $totalRecord, 'pageCount' => $pageCount, 'data' => $taskData));
    }
        
    /**
     * 添加任务
     * 
     * 
     * */
    public function addTask()
    {   
        extract(_post());
        //检查上传参数
        Check::__checkTaskName($taskname);
        Check::__checkImagePath($fullpath);
        !empty($skipaths) && Check::__checkSkipaths($skipaths,$fullpath);
        Check::__checkWaterMark($wminfo);
        Check::__checkSavePath($savepath, $fullpath);
        $backupath && Check::__checkBackupPath($backupath);

        //记录队列信息
        $dataTask = new DataTask();
        $taskID = $dataTask->createTask($taskname, _post());
        
        if( !$taskID )
        { 
            Response::error(Constants::CREATE_TASK_FAILSE);
        }
        Log::i($taskID)->write('生成任务记录成功！');
        
        //创建队列
        $imageQueues = new ImageQueues();
        $imgCounts = $imageQueues->createQueue($taskID, _post());
        
        //没有找到符合要求的图片
        if( $imgCounts < 1 )
        {
            $dataTask -> delTask($taskID);
            Response::error(Constants::CANNOT_FOUND_IMAGE);
        }
        Log::i($taskID)->write("已获取".$imgCounts."条记录。");
        
        Response::success(Constants::CREATE_TASK_SUCCESS, array('total'=>$imgCounts,'rules'=>_post()));

    }
    
    //生成水印demo图片
    public function makeDemo()
    {
        
        $request = _post();
        if( $request['wmsel'] == 1 )
        {
            $wmFile = PLUGIN_PATH.'/'. Configures::$waterMarkPathName .'/'.$request['wmfile'];
            if( !file_exists($wmFile) )
            {
                Response::error(Constants::WATERMASK_NOT_EXIST);
            }
            //检查文件类型
            $fileInfo = new SplFileInfo($wmFile);
            $fileExt = $fileInfo -> getExtension();
            if( $fileExt != 'png' )
            {
                Response::error(Constants::WATERMARK_ONLY_PNG);
            }
            
            //水印位置
            $wmPosition = $request['wmposition'];
            if( !in_array($wmPosition,array('center','top','left','bottom','right','top left','top right','bottom left','bottom right')) )
            {
                Response::error(Constants::WATERMARK_PARA_EMPTY);
            }
            //水印透明度
            $wmTran = $request['wmtran']/100;
            $imgObject = new Image(Configures::$waterMarkPathName.'/'.Configures::$demoPath);
            //生成图片
            $imgObject -> overlay($wmFile, $wmPosition, $wmTran, 0, 0);
            $imgObject -> saveAs(Configures::$waterMarkPathName.'/'.Configures::$userDemoPath);            
            Response::success(Constants::MAKE_DEMO_SUCCESS,array('demopath'=>PLUGIN_PATH.'/'.Configures::$waterMarkPathName.'/'.Configures::$demoPath,'userdemopath'=>PLUGIN_PATH.'/'.Configures::$waterMarkPathName.'/'.Configures::$userDemoPath));
        }
        //暂时不支持文字水印
        // elseif( $request['wmsel'] == 2 )
        // {
        //     $wmFont = $request['wmfont'];
        //     if( empty($wm_font) )
        //     {
        //         Response::error(Constants::WATERMARK_FONT_EMPTY);
        //     }
        // }
    }

}

?>