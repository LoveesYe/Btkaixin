#!/usr/bin/python
# coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: xxx <xxxx@qq.com>
# +-------------------------------------------------------------------

#+--------------------------------------------------------------------
#|   宝塔第三方应用开发free_promotion
#+--------------------------------------------------------------------
import sys,os,json

#设置运行目录
# os.chdir("/www/server/panel")
basedir = os.path.abspath(os.path.dirname(__file__))
try:
    os.chdir("/www/server/panel")
except :
    os.chdir(os.path.join(basedir, '..', '..'))
#添加包引用位置并引用公共包
sys.path.append("class/")
import public,random
import requests

if __name__ != '__main__':
    from BTPanel import cache,session,redirect


class free_promotion_main:
    __plugin_path = "/www/server/panel/plugin/free_promotion/"
    try:
        os.chdir("/www/server/panel")
    except :
        os.chdir(os.path.join(basedir, '..', '..'))
        __plugin_path = basedir.rstrip('/')+'/'


    #构造方法
    def  __init__(self):
        self.S = requests.session()

    def _check(self,args):

        return True

    def index(self,args):
        return self.get_site(args)

    def get_site(self,args):
        if not 'p' in args: args.p = 1
        if not 'rows' in args: args.rows = 12
        if not 'callback' in args: args.callback = ''
        args.p = int(args.p)
        args.rows = int(args.rows)
        count = public.M('sites').count()
        page_data = public.get_page(count,args.p,args.rows,args.callback)
        site_list = public.M('sites').order('id desc').limit(page_data['shift'] + ',' + page_data['row']).field('id,name,addtime').select()
        return {'data': site_list,'page':page_data['page'] }
    def get_domain(self,args):
        domain_list = public.M('domain').where('pid=?',(args.site_id,)).order('id asc').field('id,pid,name,port,addtime').select()
        return {'status':0,'data': domain_list}

    def push_domain(self,args):
        # https://tool.tag.gg/e/ShowKey/?v=info
        if 'enews' not in args:
            data=public.dict_obj()
            data['url']='https://tool.tag.gg/e/ShowKey/?v=info'
            if not self.get_code(data):
                return 0
            return 1

        data={
            'enews': args.enews,
            'id': args.id,
            'filepass': args.filepass,
            'mid': args.mid,
            'ecmsfrom': args.ecmsfrom,
            'title': args.title,
            'ftitle': args.ftitle,
            'keyboard': args.keyboard,
            'titlepicfile': args.titlepicfile,
            'url': args.url,
            'classid': args.classid,
            'newstext': args.newstext,
            'key': args.key,
        }
        #data=args.data
        html=self.S.post(args.posturl,data=data)
        return html
        
        
        
    def get_code(self,args):

        html=self.S.get(args.url)    
        with open(self.__plugin_path+'static/code.jpg','wb') as f:
            f.write(html.content)
        return {'status':0,'num': random.randint(0,100)}

    def check_web(self,args):
        data={
            'domain':args.domain,
            'token':'tag.gg'
        }
        try:
            html=requests.post(args.url,data=data)
            if html.status_code==200:
                return json.loads(html.text)
        except:
            return {'code':500,'msg': '请求错误'}

