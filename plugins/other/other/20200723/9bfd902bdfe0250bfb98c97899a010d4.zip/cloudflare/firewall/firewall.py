import os
import mod
import json
from collections import Counter

def write_log(filename,log_content):
    f = open("/www/server/panel/plugin/cloudflare/firewall/%s"%filename,"a+")
    f.write("\n" + log_content)
    f.close()
    return "ok"
def read_json(jsonfile):
    f = open("/www/server/panel/plugin/cloudflare/config/%s"%jsonfile, 'r')
    content = f.read()
    content = json.loads(content)
    f.close()
    return content
def write_json(jsonfile,data):
    f = open("/www/server/panel/plugin/cloudflare/config/%s"%jsonfile, 'w')
    data = json.dumps(data)
    f.write(data)
    f.close()
    return "ok"
def write_ip(jsonfile,data):
    f = open("/www/server/panel/plugin/cloudflare/firewall/%s"%jsonfile, 'w')
    data = json.dumps(data)
    f.write(data)
    f.close()
    return "ok"
def read_ip(jsonfile):
    f = open("/www/server/panel/plugin/cloudflare/firewall/%s"%jsonfile, 'r')
    content = f.read()
    content = json.loads(content)
    f.close()
    return content
def commands(command): 
    result = os.popen(command)
    res = result.read()
    return res
def fensuo(mode):
    if(mode == "ip"):
        result = commands("netstat -ntu | grep tcp | awk '{print $5}' | cut -d: -f1")
        res = result.split("\n")
        res = Counter(res).most_common()
        x = 0
        ips = []
        for ip in res :
            if(ip[1] >=100):
                ips.append(ip)
                commands("sudo iptables -I INPUT -s %s -j DROP"%ip[0])
                x += 1
        write_ip("iplists.json",ips)
        x = str(x)
        write_log("log.txt" , "封锁了%s个IP"%x)
    elif(mode == "port"):
        config = read_json("config.json")
        portfensuo = config['port'].split(",")
        for port in portfensuo:
            commands("sudo bash /www/server/panel/plugin/cloudflare/firewall/fensuo.sh "+ port)
        
        #write_log("log.txt" , "已封锁%s端口"%port)
    

def jiefen():
    iplists = read_ip("iplists.json")
    if(iplists != []):
        for ip in iplists:
            commands("sudo iptables -D INPUT -s %s -j DROP"%ip)

#    result = commands("netstat -ntu | grep tcp | awk '{print $5}' | cut -d: -f1")
#    res = result.split("\n")
#    commands("iptables -F")
#    write_log("log.txt" , "IP全部解封了")
    config = read_json("config.json")
    portfensuo = config['port'].split(",")
    for port in portfensuo:
        commands("sudo bash /www/server/panel/plugin/cloudflare/firewall/jiefen.sh "+ port)
        
        #write_log("log.txt" , "已解封%s端口"%port)

fuzai = commands("uptime").split("load average: ")[1]
write_log("log.txt" , "当前负载: %s"%fuzai)
fuzai = fuzai.split(", ")
fuzai[-1] = fuzai[-1][:-1]
nowfuzia = fuzai[0]
config = read_json("config.json")
status = config['status']
firewall_mode = config['firewall_mode']
maxfuzai = int(config['max'])
if(float(fuzai[0]) >= maxfuzai):
    write_log("log.txt" , "负载大于最大负载:%s，防火墙触发"%maxfuzai)
    fensuo(firewall_mode)
    config['status'] = "5min"
elif(float(fuzai[1]) <= maxfuzai and status == "5min"):
    fivefuzai = fuzai[1]
    write_log("log.txt" , "5分钟内，负载已经下降到%s，待观察"%fivefuzai)
    config['status'] = "15min"
elif(float(fuzai[2]) <= maxfuzai and status == "15min"):
    fiffuzai = fuzai[1]
    write_log("log.txt" , "15分钟内，负载已经下降到%s，防火墙关闭"%fiffuzai)
    config['status'] = "none"
    jiefen()
else:
    #write_log("log.txt" , "负载正常，持续监控")
    pass
write_json("config.json",config)
