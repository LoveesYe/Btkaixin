import os
def fensuo(port):
    port = int(port)
    os.system("screen iptables -I INPUT -p tcp --dport %d -j DROP"%port)
def jiefen(port):
    port = int(port)
    os.system("screen iptables -I INPUT -p tcp --dport %d -j ACCEPT"%port)