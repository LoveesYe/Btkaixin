from flask import Flask
from flask import render_template
from flask import request
import os
import json

def read_file(filepath):
    f = open(filepath,"r")
    content = f.read()
    f.close()
    return content
def read_json(jsonfile):
    f = open("/www/server/panel/plugin/cloudflare/config/%s"%jsonfile, 'r')
    content = f.read()
    content = json.loads(content)
    f.close()
    return content
def write_json(jsonfile,data):
    f = open("/www/server/panel/plugin/cloudflare/config/%s"%jsonfile, 'w')
    data = json.dumps(data)
    f.write(data)
    f.close()
    return "ok"
app = Flask(__name__)


@app.route("/read_log")
def read_log():
    try:
        content = read_file("/www/server/panel/plugin/cloudflare/firewall/log.txt")
    except:
        content = "当前没有日志"
    return content

@app.route("/firewall_config",methods=['GET'])
def firewall_config():
    method = request.args.get('method')
    sncode = request.args.get('sncode')
    config = read_json("config.json")
    sncode_cor = config['sncode']
    if(sncode == sncode_cor):
        pass
    else:
        return "Sncode error"
    if(method == "get"):
        configs = json.dumps(config)
        return configs
    elif(method == "state"):
        if(config['firewall'] == "on"):
            os.system("sudo rm /www/server/panel/plugin/cloudflare/firewall/firewall")
            if(config['remote'] == "on"):
                os.system("echo \"*/5 * * * * python3 /www/server/panel/plugin/cloudflare/firewall/remote.py\" > /www/server/panel/plugin/cloudflare/firewall/firewall")
                os.system("sudo crontab /www/server/panel/plugin/cloudflare/firewall/firewall")
                #os.system("echo \"*/1 * * * * python3 /www/server/panel/plugin/cloudflare/firewall/firewallgo.py\" > /www/server/panel/plugin/cloudflare/firewall/firewall")
            else:
                #os.system("echo \"*/5 * * * * python3 /www/server/panel/plugin/cloudflare/firewall/firewallgo.py\" > /www/server/panel/plugin/cloudflare/firewall/firewall")
                pass
            config['firewall'] = "off"
        else:
            
            os.system("sudo rm /www/server/panel/plugin/cloudflare/firewall/firewall")
            if(config['remote'] == "on"):
                os.system("echo \"*/5 * * * * python3 /www/server/panel/plugin/cloudflare/firewall/remote.py\" > /www/server/panel/plugin/cloudflare/firewall/firewall")
                os.system("echo \"*/1 * * * * python3 /www/server/panel/plugin/cloudflare/firewall/firewallgo.py\" >> /www/server/panel/plugin/cloudflare/firewall/firewall")
                
                
            else:
                os.system("echo \"*/5 * * * * python3 /www/server/panel/plugin/cloudflare/firewall/firewallgo.py\" > /www/server/panel/plugin/cloudflare/firewall/firewall")
                
            os.system("sudo crontab /www/server/panel/plugin/cloudflare/firewall/firewall")
            
            config['firewall'] = "on"
        
        write_json("config.json",config)
        return "success"
    elif(method == "set"):
        maxfuzai = request.args.get("maxfuzai")
        fensuoport = request.args.get("port")
        if("，" in fensuoport):
            return "Ports type error"
        config['max'] = maxfuzai
        config['port'] = fensuoport
        write_json("config.json",config)
        return "success"




@app.route("/delete_log",methods=['GET'])
def delete_log():
    sncode = request.args.get("sncode")
    config = read_json("config.json")
    sncode_cor = config['sncode']
    if(sncode == sncode_cor):
        os.system("rm /www/server/panel/plugin/cloudflare/firewall/log.txt")
    else:
        return "Sncode error"
    
    return "success"



if __name__ == "__main__":
    app.run(host="0.0.0.0",port=33199,debug=True)