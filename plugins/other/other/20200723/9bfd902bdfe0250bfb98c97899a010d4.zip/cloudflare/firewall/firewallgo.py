import os
import time
x = 1
while(x <= 5):
    os.system("python3 /www/server/panel/plugin/cloudflare/firewall/firewall.py")
    time.sleep(10)
    x += 1
    