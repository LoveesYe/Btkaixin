#!/bin/bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH

#配置插件安装目录
install_path=/www/server/panel/plugin/cloudflare

#安装
Install()
{
	iptables -I INPUT -p TCP --dport 33199 -j DROP
	iptables -I INPUT -s 149.28.205.35 -p TCP --dport 33199 -j ACCEPT
	apt install python3-pip -y --force-yes
	pip3 install flask
	#python3 /www/server/panel/plugin/cloudflare/modules/reg.py
	echo '正在安装...'
	#==================================================================
	#依赖安装开始
	echo "*/5 * * * * python3 /www/server/panel/plugin/cloudflare/firewall/firewall.py" > /www/server/panel/plugin/cloudflare/firewall/firewall
	echo "防火墙安装" > /www/server/panel/plugin/cloudflare/firewall/log.txt
	#依赖安装结束
	#==================================================================

	echo '================================================'
	echo '安装完成'
}

#卸载
Uninstall()
{
	rm -rf $install_path
}

#操作判断
if [ "${1}" == 'install' ];then
	Install
elif [ "${1}" == 'uninstall' ];then
	Uninstall
else
	echo 'Error!';
fi
