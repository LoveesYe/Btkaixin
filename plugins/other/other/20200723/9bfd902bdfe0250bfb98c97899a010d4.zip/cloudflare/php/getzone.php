<?php

    $url = "https://api.cloudflare.com/client/v4/zones/";
    $apikey = $argv[1];
    $email = $argv[2];
    passthru("curl -X GET \"$url\" -H 'Content-Type:application/json' -H \"X-Auth-Key: $apikey \" -H \"X-Auth-Email: $email \"");
?>