import os
import json

def commands(command): 
    result = os.popen(command)
    res = result.read()
    return res
def read_json(jsonfile):
    f = open("/www/server/panel/plugin/cloudflare/config/%s"%jsonfile, 'r')
    content = f.read()
    content = json.loads(content)
    f.close()
    return content
def write_json(jsonfile,data):
    f = open("/www/server/panel/plugin/cloudflare/config/%s"%jsonfile, 'w')
    data = json.dumps(data)
    f.write(data)
    f.close()
    return "ok"


sn = commands("curl http://plugin.bsot.cn/apps/reg.php?plugin=cloudflare")
config = read_json("config.json")
config['sncode'] = sn
write_json("config.json",config)