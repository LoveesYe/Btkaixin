import os
import json
def commands(command): 
    result = os.popen(command)
    res = result.read()
    return res
fuzai = commands("uptime").split("load average: ")[1]
fuzai = fuzai.split(", ")
fuzai[-1] = fuzai[-1][:-1]
fuzai = json.dumps(fuzai)
print(fuzai)