<?php
//宝塔Linux面板插件demo for PHP
//@author 阿良<287962566@qq.com>

//必需面向对象编程，类名必需为bt_main
//允许面板访问的方法必需是public方法
//通过_get函数获取get参数,通过_post函数获取post参数
//可在public方法中直接return来返回数据到前端，也可以任意地方使用echo输出数据后exit();
//可在./php_version.json中指定兼容的PHP版本，如：["56","71","72","73"]，没有./php_version.json文件时则默认兼容所有PHP版本，面板将选择 已安装的最新版本执行插件
//允许使用模板，请在./templates目录中放入对应方法名的模板，如：test.html，请参考插件开发文档中的【使用模板】章节
//支持直接响应静态文件，请在./static目录中放入静态文件，请参考插件开发文档中的【插件静态文件】章节
class bt_main{
	//不允许被面板访问的方法请不要设置为公有方法
    private function _postgo($url,$method="GET",$data="") {
		$apikey = $this -> apikey;
		$email = $this -> email;
		$headers = array(
			'Content-Type: ' . "application/json" ,
			"X-Auth-Key: " . "$apikey" ,
			"X-Auth-Email: " . "$email"
		);
		$ch = curl_init();
		curl_setopt( $ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_TIMEOUT, 60); //设置超时
		if(0 === strpos(strtolower($url), 'https')) {
			//https请求
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0); //对认证证书来源的检查
			curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0); //从证书中检查SSL加密算法是否存在
		}
		curl_setopt( $ch, CURLOPT_POST, false);
		if($method == "DELETE"){
			curl_setopt ($ch, CURLOPT_CUSTOMREQUEST, "DELETE");
		}
		if($method == "POST"){
			curl_setopt( $ch, CURLOPT_POST, true);
			curl_setopt( $ch, CURLOPT_POSTFIELDS, json_encode($data));
		}
		//curl_setopt( $ch, CURLOPT_POSTFIELDS, $data);
		curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt( $ch, CURLOPT_HTTPHEADER, $headers );
		$resp = curl_exec ( $ch );
		curl_close ( $ch );
		return $resp;
	}

    function readfile_content($filepath){
        $filesizeof = filesize(rtrim($filepath));
        if($filesizeof == 0){
            return "";
        }
        else{
            $f = fopen("$filepath","r");
			$content = fread($f,$filesizeof);
			fclose($f);
            return $content;
        }
	}
	function read_json($filepath){
        $filesizeof = filesize(rtrim("/www/server/panel/plugin/cloudflare/config/$filepath"));
        if($filesizeof == 0){
            return "";
        }
        else{
            $f = fopen("/www/server/panel/plugin/cloudflare/config/$filepath","r");
			$content = fread($f,$filesizeof);
			fclose($f);
            return json_decode($content,true);
        }
	}
	function write_json($filepath,$content){
		$content = json_encode($content);
		$f = fopen("/www/server/panel/plugin/cloudflare/config/$filepath","w");
		fwrite($f,$content);
		fclose($f);
		return "ok";
	}
    function writefile($filepath,$content){
		$f = fopen("$filepath","w");
		fwrite($f,$content);
		fclose($f);
		return "ok";
	}
    function __construct(){
		$apikey = $this -> readfile_content("config/apikey.txt");
		$email = $this -> readfile_content("config/email.txt");
		$this -> email = $email;
        $this -> apikey = $apikey;
    }
    
	public function returninfo(){
		//_post()会返回所有POST参数，要获取POST参数中的username参数，请使用 _post('username')
		//可通过_version()函数获取面板版本
		//可通过_post('client_ip') 来获取访客IP

		//常量说明：
		//PLU_PATH 插件所在目录
		//PLU_NAME 插件名称
		//PLU_FUN  当前被访问的方法名称
		return array(
			_get(),
			_post(),
			_version(),
			PLU_FUN,
			PLU_NAME,
			PLU_PATH
		);
	}
	function tocurl($url, $header){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        curl_setopt($ch, CURLOPT_POST, false);
        //curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($content));
        $response = curl_exec($ch);
        if($error=curl_error($ch)){
            die($error);
        }
        curl_close($ch);
        return $response;
    }
	function getzone(){
		$url = "https://api.cloudflare.com/client/v4/zones/";
		$response = $this -> _postgo($url);
		return $response;
	}
	public function get_index(){
		$apikey = $this -> apikey;
		$email = $this -> email;
	    $html = "
	    
	        <div class='mdui-textfield'>
	        
	            <label class='mdui-textfield-label'>Cloudflare API Key</label>
	            <input class='mdui-textfield-input' value='$apikey' id='apikey'></input>
	        
			</div>
			<div class='mdui-textfield'>
	        
	            <label class='mdui-textfield-label'>Cloudflare邮箱账户</label>
	            <input class='mdui-textfield-input' value='$email' id='email'></input>
	        
	        </div>
	        <button class='mdui-btn mdui-ripple' onclick='apply_settings()'>应用设置</button>
	    
	    ";
	    return $html;
	}
	public function auto_firewall(){
		
		$html = "
		";
		echo($html);
	}
	public function get_dns_list(){
		$apikey = $this -> apikey;
		$email = $this -> email;
		
		$url = "https://api.cloudflare.com/client/v4/zones/";
		//$postthings = array();
		//$aHeader = array('Content-Type: ' . "application/json" , "X-Auth-Key: " . "$apikey" , "X-Auth-Email: " . "$email");
		$domaininfo = $this -> getzone();
		$domaininfo = json_decode($domaininfo,true)['result'];
		$html = "
		<table class=\"layui-table\">
		<thead>
		<tr>
		<th width='165'>域名</th>
		<th width='120' style='text-align:right;'>操作</th>
		<tr>
		</thead>
		<tbody>
		";
		if($domaininfo == ""){

		}
		else{
			foreach($domaininfo as $domain){
				$domainname = $domain["name"];
				$html .= "<tr>
				<td>$domainname</td>
				<td style='text-align:right;'><a class='btlink' onclick='mg_domain(\"$domainname\")'>管理</td>
				</tr>";
			}
			$html .= "</tbody></table>";
			return $html;
		}
	}
	function get_id_by_name($domainname){
		$domaininfo = $this -> getzone();
		$domaininfo = json_decode($domaininfo,true)['result'];
		foreach($domaininfo as $domain){
			$domainname_this = $domain['name'];
			if($domainname_this == $domainname){
				$domainid = $domain['id'];
				return $domainid;
			}
		}
		return "notfound";
	}
	function get_dns_records_by_id($domainid){
		$url = "https://api.cloudflare.com/client/v4/zones/$domainid/dns_records?per_page=100";
		$response = $this -> _postgo($url);
		return $response;
	}
	public function mg_domain(){
		$postdata = $this -> returninfo()[1];
		$domainname = $postdata['domainname'];
		$domainid = $this -> get_id_by_name($domainname);
		$dns_records = $this -> get_dns_records_by_id($domainid);
		$dns_records = json_decode($dns_records,true)['result'];
		$html = "
		<button class='mdui-btn mdui-ripple mdui-color-green' onclick='add_dns_record(\"$domainid\",\"$domainname\")'>添加解析</button>
		<table class=\"layui-table\">
		<thead>
		<tr>
		<th width='60'>类型</th>
		<th width='165'>记录</th>
		<th width='150'>记录值</th>
		<th width='40'>代理</th>
		<th width='120' style='text-align:right;'>操作</th>
		<tr>
		</thead>
		<tbody>
		";
		if($dns_records == ""){
			$html = "未找到解析";
		}
		else{
			foreach($dns_records as $dns_record){
				$dnstype = $dns_record['type'];
				$dnsname = $dns_record['name'];
				$content = $dns_record['content'];
				$dnsid = $dns_record['id'];
				$isproxy = $dns_record['proxied'];
				switch($isproxy){
					case true:
						$proxys = "是";
					break;
					case false:
						$proxys = "否";
					break;
				}
				$html .= "<tr>
				<td>$dnstype</td>
				<td>$dnsname</td>
				<td>$content</td>
				<td>$proxys</td>
				<td style='text-align:right;'><!--<a class='btlink' onclick='cloudflare.mg_dns(\"$dnsid\",\"$domainname\",\"$domainid\")'>管理</a>-->
				<a class='btlink' onclick='del_dns(\"$dnsid\",\"$domainname\",\"$domainid\")'>删除</a></td>
				</tr>";
			}
			$html .= "</tbody></table>";
			
		}
		return $html;
	}
	public function apply_settings(){
		$postdata = $this -> returninfo()[1];
		$apikey = $postdata['apikey'];
		$email = $postdata['email'];
		$this -> writefile("config/apikey.txt","$apikey");
		$this -> writefile("config/email.txt","$email");
		return "suc";
	}
	public function get_add_page(){
		$postdata = $this -> returninfo()[1];
		$domainid = $postdata['domainid'];
		$domainname = $postdata['domainname'];
		$html = "
		解析类型
		<select class=\"mdui-select\" id='dns_type'>
			<option value=\"A\" selected>A</option>
			<option value=\"AAAA\">AAAA</option>
			<option value=\"CNAME\">CNAME</option>
			<option value=\"TXT\">TXT</option>
			<option value=\"SRV\">SRV</option>
			<option value=\"LOC\">LOC</option>
			<option value=\"MX\">MX</option>
			<option value=\"NS\">NS</option>
			<option value=\"SPF\">SPF</option>
			<option value=\"SERT\">SERT</option>
			<option value=\"DNSKEY\">DNSKEY</option>
			<option value=\"DS\">DS</option>
			<option value=\"NAPTR\">NAPTR</option>
			<option value=\"SMIMEA\">SMIMEA</option>
			<option value=\"SSHFP\">SSHFP</option>
			<option value=\"TLSA\">TLSE</option>
			<option value=\"URI\">URI</option>
			
		</select><br />
		记录名: <input class='bt-input-text' type='text' id='dns_record' style='width:100px' />.$domainname<br />
		记录值:
		<input class='bt-input-text' type='text' id='content_dns' style='width:300px' /><br />";
		$html .= "
		<label class=\"mdui-checkbox\">
			<input type=\"checkbox\" id='isproxy'/>
			<i class=\"mdui-checkbox-icon\" value='yes'></i>
			走Cloudflare
		</label><br />
		<button class='mdui-btn mdui-ripple' onclick='add_dns_go(\"$domainid\",\"$domainname\")'>添加解析</button>
		";
		return $html;
	}
	public function add_dns_record(){
		$postdata = $this -> returninfo()[1];
		$dns_name = $postdata['dns_name'];
		$domianname = $postdata['domainname'];
		$domainid = $postdata['domainid'];
		$isproxy = $postdata['isproxy'];
		if($isproxy == "true"){
			$isproxy = true;
		}
		else{
			$isproxy = false; 
		}
		$dns_type = $postdata['dns_type'];
		$content_dns = $postdata['content_dns'];
		$url = "https://api.cloudflare.com/client/v4/zones/$domainid/dns_records";
		$postdatas = array("name"=>"$dns_name".".$domianname","content"=>"$content_dns","type"=>"$dns_type","proxied"=>$isproxy,"ttl"=>1);
		$response = $this -> _postgo($url,$method="POST",$postdatas);
		$response = json_decode($response,true)['success'];
		if($response == true){
			return "suc";
		}
		else{
			return "err";
		}
		
	}
	public function del_dns(){
		$postdata = $this -> returninfo()[1];
		$dnsid = $postdata['dnsid'];
		$domainid = $postdata['domainid'];
		$url = "https://api.cloudflare.com/client/v4/zones/$domainid/dns_records/$dnsid";
		$response = $this -> _postgo($url,"DELETE");
		$response = json_decode($response,true)['success'];
		if($response == true){
			return "suc";
		}
		else{
			return "error";
		}
	}
	/*public function get_firewall_list(){
		$loglist = scandir('/www/wwwlogs/*');
		$loglist = glob("/www/wwwlogs/*.log");
		$html = "
		<label class=\"mdui-checkbox\">
			<input type=\"checkbox\" id='firewallswith'/>
			<i class=\"mdui-checkbox-icon\" value='yes'></i>
			防火墙总开关
		</label><br />
		<button class='mdui-btn mdui-ripple' onclick='firewallswitchsetting()'>应用</button>
		";
		return $html;
	}
	public function apply_firewall(){
		$postdatas = $this -> returninfo()[1];
		$firewallswich = (bool)$postdatas['firewallswich'];
		if($firewallswich){
			$this -> writefile("config/firewall.txt","on");
			include("firewall.php");
		}
		else{
			$this -> writefile("config/firewall.txt","off");
		}
	}
	public function firewalltest(){
		require_once("firewall.php");
		$logs = get_log();
		return $logs;
	}*/
	//Firewall start
	public function firewall_get_index(){
		
		$fuzai = shell_exec("python3 modules/fuzai.py");
		$fuzai = json_decode($fuzai,true);
		$fuzai1 = (int)($fuzai[0]);
		$dudu1 = 0 - $fuzai1*360/100 -45;
		$fuzai2 = (int)($fuzai[1]);
		$dudu2 = 0 - $fuza2*360/100 - 45;
		$fuzai3 = (int)($fuzai[2]);
		$dudu3 = 0 - $fuza3*360/100 -45;
		$html = "
		<h3>现在负载:</h3><span>$fuzai1</span><br />
		<h3>5分钟负载:</h3><span>$fuzai2</span><br />
		<h3>15分钟负载:</h3><span>$fuzai3</span><br />
		<div id=\"app\">
			<h3>当前负载</h3>
			<canvas id=\"canvas1\" width=\"262\" height=\"262\"></canvas>
		</div>
		<script>

		var my_canvas = document.getElementById(\"canvas1\");
		var gauge = new Gauge({
			\"canvas\": my_canvas
		})

		// 绘制初始仪表盘初始值0%
		gauge.render();
		setTimeout(function () {
			gauge.update($fuzai1);
		}, 2000)
	</script>
		
		";
		//$r_data = $btapi -> systeminfo();
		//输出JSON数据到浏览器
		return $html;
		//return json_encode($r_data);
	}
	public function firewall_get_config(){
		$config = $this -> read_json("config.json");
		$maxfuzai = $config['max'];
		$portfensuo = $config['port'];
		$state = $config['firewall'];
		$firewall_mode = $config['firewall_mode'];
        if($state == "on"){
            $result = "<span style=\"color: green; margin-left: 3px;\" class=\"glyphicon glyphicon-play\"></span>";
			$state = "开启";
		}
        else{
            $result = "<span style=\"color: red; margin-left: 3px;\" class=\"glyphicon glyphicon-pause\"></span>";
			$state = "关闭";
		}
        $html = "
        
            <div class=\"soft-man-con bt-form\">
                <p class=\"status\">状态:$state $result</p>
                
            </div>
            <div class=\"sfm-opt\">
                <button class=\"btn btn-default btn-sm\" onclick=\"cloudflare_firewall.start()\">启动服务</button>
                <button class=\"btn btn-default btn-sm\" onclick=\"cloudflare_firewall.stop()\">停止服务</button>
            </div>
			<br><br>
			<div class=\"soft-man-con bt-form\">
			负载阈值:      <input class=\"bt-input-text mr5\" id=\"fuzaiset\"  value=\"$maxfuzai\" /><br />
			封锁端口:      <input class=\"bt-input-text mr5\" id=\"portfensuo\"  value=\"$portfensuo\" />* 可以设置多个端口，用,(英文)隔开<br />
			
			
			</div>
			<div class=\"sfm-opt\">
				<button class=\"btn btn-default btn-sm\" onclick=\"cloudflare_firewall.save_setting()\">保存配置</button>
				<button class=\"btn btn-default btn-sm\" onclick=\"cloudflare_firewall.set_firewall_mod('$firewall_mode')\">防御模式</button>
			</div>
        
        
        
		";
		
        return $html;
	}
	public function firewall_set_mode(){
		$postdata = $this -> returninfo()[1];
		$config = $this -> read_json("config.json");
		$firewall_mode = $postdata['firewall_mode'];
		$config['firewall_mode'] = $firewall_mode;
		$this -> write_json("config.json",$config);
		return "ok";
	}
	public function firewall_state(){
		$postdata = $this -> returninfo()[1];
		$config = $this -> read_json("config.json");
		$doit = $postdata['do'];
		if($doit == "start"){
			$config['firewall'] = "on";
			shell_exec("rm /www/server/panel/plugin/cloudflare/firewall/firewall");
			shell_exec("echo \"*/1 * * * * python3 /www/server/panel/plugin/cloudflare/firewall/firewallgo.py\" > /www/server/panel/plugin/cloudflare/firewall/firewall");
			if($config['remote'] == "on"){
				shell_exec("echo \"*/1 * * * * python3 /www/server/panel/plugin/cloudflare/firewall/remote.py\" >> /www/server/panel/plugin/cloudflare/firewall/firewall");
			}
			shell_exec("crontab /www/server/panel/plugin/cloudflare/firewall/firewall");
		}
		else{
			$config['firewall'] = "off";
			shell_exec("crontab -r");
			shell_exec("rm /www/server/panel/plugin/cloudflare/firewall/firewall");
			if($config['remote'] == "on"){
				shell_exec("echo \"*/1 * * * * python3 /www/server/panel/plugin/cloudflare/firewall/remote.py\" > /www/server/panel/plugin/cloudflare/firewall/firewall");
				shell_exec("crontab /www/server/panel/plugin/cloudflare/firewall/firewall");
			}
		}
		$this -> write_json("config.json",$config);
		return $doit . "e";
	}
	public function firewall_save_setting(){
		$postdata = $this -> returninfo()[1];
		$config = $this -> read_json("config.json");
		$maxfuzai = $postdata['maxfuzai'];
		$portfensuo = $postdata['portfensuo'];
		$config['max'] = $maxfuzai;
		$config['port'] = $portfensuo;
		$this -> write_json("config.json",$config);
		return $maxfuzai;
	}
	public function firewall_get_log(){
		$content = $this -> readfile_content("/www/server/panel/plugin/cloudflare/firewall/log.txt");
		return "<textarea readonly style='margin: 0px;width:500px;height: 520px;background-color: #333;color:#fff; padding:0 5px'>".$content."</textarea>";
	}
	public function sn_page(){
		$config = $this -> read_json("config.json");
		$sncode = $config['sncode'];
		if($sncode == ""){
			shell_exec("python3 /www/server/panel/plugin/cloudflare/modules/reg.py");
		}
		$state = $config['remote'];
        if($state == "on"){
            $result = "<span style=\"color: green; margin-left: 3px;\" class=\"glyphicon glyphicon-play\"></span>";
			$state = "开启";
		}
        else{
            $result = "<span style=\"color: red; margin-left: 3px;\" class=\"glyphicon glyphicon-pause\"></span>";
			$state = "关闭";
		}
		$html = "
        
            <div class=\"soft-man-con bt-form\">
                <p class=\"status\">状态:$state $result</p>
                
            </div>
            <div class=\"sfm-opt\">
                <button class=\"btn btn-default btn-sm\" onclick=\"cloudflare_remote.start()\">启动服务</button>
                <button class=\"btn btn-default btn-sm\" onclick=\"cloudflare_remote.stop()\">停止服务</button>
            </div>
			<br><br><br>
			<h4>SN码:$sncode</h4>
			
        
        
        
		";
		return $html;
		
	}
	public function remote_state(){
		$postdata = $this -> returninfo()[1];
		$config = $this -> read_json("config.json");
		$doit = $postdata['do'];
		if($doit == "start"){
			$config['remote'] = "on";
			shell_exec("rm /www/server/panel/plugin/cloudflare/firewall/firewall");
			shell_exec("echo \"*/5 * * * * python3 /www/server/panel/plugin/cloudflare/firewall/remote.py\" > /www/server/panel/plugin/cloudflare/firewall/firewall");
			if($config['firewall'] == "on"){
				shell_exec("echo \"*/5 * * * * python3 /www/server/panel/plugin/cloudflare/firewall/firewallgo.py\" >> /www/server/panel/plugin/cloudflare/firewall/firewall");
			}
			
			shell_exec("crontab /www/server/panel/plugin/cloudflare/firewall/firewall");
		}
		else{
			$config['remote'] = "off";
			shell_exec("crontab -r");
			shell_exec("rm /www/server/panel/plugin/cloudflare/firewall/firewall");
			
			if($config['firewall'] == "on"){
				shell_exec("echo \"*/1 * * * * python3 /www/server/panel/plugin/cloudflare/firewall/firewallgo.py\" > /www/server/panel/plugin/cloudflare/firewall/firewall");
				shell_exec("crontab /www/server/panel/plugin/cloudflare/firewall/firewall");
			}
		}
		$this -> write_json("config.json",$config);
		return $doit . "e";

	}
	public function about(){
		$html = "
		<div class=\"plugin_about\">
                <img src=\"https://cdn.jsdelivr.net/gh/soxft/cdn@master/team/team.png\" width=\"500px\" alt=\"XUSOFT\">
                <p><b>插件名称：</b>Cloudflare</p>
                <p><b>版本：v2.1.0</b></p><b>
                <p><b>使用说明：</b>CC/DDOS负载盾，让你的服务器被C一秒恢复青春，使用CX插件平台享受便捷管理插件，Cloudflare解析</p>
				<p><b>官网：</b><a class=\"btlink\" href=\"https://blog.bsot.cn\" target=\"_blank\">https://blog.bsot.cn</a></p>
				<p><b>CX插件操作平台：</b><a class=\"btlink\" href=\"http://plugin.bsot.cn\" target=\"_blank\">http://plugin.bsot.cn</a></p>
                <p><b>插件作者：</b>cxbsoft</p>
                <p><b>Telegram：</b><a class=\"btlink\" href=\"https://t.me/cxbsoft\">@cxbsoft</a></p>
                
                <p><b>Email：</b><a class=\"btlink\" href=\"mailto:cxbsoft@bsot.cn\">cxbsoft@bsot.cn</a></p>
            </b></div>
		<style>.plugin_about {
			padding: 15px 30px;
			line-height: 26px;
			background: #f0f0f1;
			border-radius: 5px;
			border: 1px solid #ffffff;
		}</style>
		

		";
		return $html;
	}
}
?>