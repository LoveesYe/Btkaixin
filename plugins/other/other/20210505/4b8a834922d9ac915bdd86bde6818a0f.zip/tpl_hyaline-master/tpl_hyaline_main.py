#!/usr/bin/python
# coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: 猪在天上飞 <root@bug-maker.com>
# +-------------------------------------------------------------------

#+--------------------------------------------------------------------
#|   宝塔第三方应用开发猪在天上飞
#+--------------------------------------------------------------------
import sys,os,json

#设置运行目录
os.chdir("/www/server/panel")

#添加包引用位置并引用公共包
sys.path.append("class/")
import public

#在非命令行模式下引用面板缓存和session对象
if __name__ != '__main__':
    from BTPanel import cache,session,redirect


class tpl_hyaline_main:
    __plugin_path = "/www/server/panel/plugin/tpl_hyaline/"
    __tpl_path = "/www/server/panel/BTPanel/templates/"
    __static_path = "/www/server/panel/BTPanel/static/tpl_hyaline"
    __sys_static_path = "/www/server/panel/BTPanel/static/"
    __config = None

    #构造方法
    def  __init__(self):
        pass

    #访问/tpl_hyaline/index.html时调用的默认方法，需要在templates中有index.html，否则无法正确响应模板
    def index(self,args):
        return {'code':0, 'msg': "设置成功"}

    #获取模板检查默认模板
    def get_tpl(self,args):
        data = []
        main_tpl = public.GetConfigValue("template")
        for target in os.listdir(self.__tpl_path):
            one_data = {"status": "selected" if target==main_tpl else "","name":target}
            data.append(one_data)
            pass
        return {'code':0, 'data':data}

    def set_tpl(self,args):
        # public.SetConfigValue("template","default")
        if "tpl" in args:
            tpl = args['tpl']
        else:
            tpl = "default"
        return {'code':0,'status':public.SetConfigValue("template",tpl),'msg':'设置成功,更换模板需要重启面板以及Ctrl+F5'}

    def reset_tpl2(self,args):
        import shutil,re
        if os.path.exists(self.__static_path):
            shutil.rmtree(self.__static_path)
        shutil.copytree(self.__plugin_path + '/tpl',self.__static_path)
        
        if os.path.exists(self.__tpl_path+"/tpl_hyaline"):
            shutil.rmtree(self.__tpl_path+"/tpl_hyaline")
        shutil.copytree(self.__tpl_path+"/default",self.__tpl_path+"/tpl_hyaline")

        content = public.ReadFile(self.__tpl_path+"/tpl_hyaline/layout.html")

        # 插入css
        #str_rp = '<link href="{{g.cdn_url}}/css/site.css?20191127={{g[\'version\']}}" rel="stylesheet" />\n<link href="/static/tpl_hyaline/css/site.css?20191127={{g[\'version\']}}" rel="stylesheet" />'
        #content = content.replace('<link href="./css/site.css?20191127={{g[\'version\']}}" rel="stylesheet" />',str_rp)
        res = re.split('<link href="(.*)/css/site.css?(.*)" rel="stylesheet" />',content)
        if len(res) == 4:
            content = res[0] + '<link href="'+res[1]+'/css/site.css?'+res[2]+'" rel="stylesheet" />\n<link href="/static/tpl_hyaline/css/site.css?'+res[2]+'" rel="stylesheet" />' + res[3]

        # 插入js
        #str_rp = '<script src="{{g.cdn_url}}/js/jquery-1.10.2.min.js"></script><script src="/static/tpl_hyaline/js/index.js?20191127={{g[\'version\']}}"></script>'
        #content = content.replace('<script src="{{g.cdn_url}}/js/jquery-1.10.2.min.js"></script>',str_rp)
        res = re.split('<script src="(.*)/js/jquery-([0-9.]*).min.js"></script>',content)
        if len(res) == 4:
            content = res[0] + '<script src="'+res[1]+'/js/jquery-'+res[2]+'.min.js"></script>\n<script src="/static/tpl_hyaline/js/index.js?version='+res[2]+'"></script>' + res[3]

        # 插入背景图
        str_rp = '<div class="tpl_hyaline_bg"></div><div class="tpl_hyaline_bg"></div>\n    <div class="bt-warp">'
        content = content.replace('<div class="bt-warp bge6">',str_rp)
        
        if not public.WriteFile(self.__tpl_path+"/tpl_hyaline/layout.html",content):
            return {'code':1,'msg':"重置失败，请联系作者"}
        
        return {'code':0,'msg':"重置成功","content":content}
        
    def reset_tpl(self,args):
        import shutil,re
        if os.path.exists(self.__static_path):
            shutil.rmtree(self.__static_path)
        shutil.copytree(self.__plugin_path + '/tpl',self.__static_path)
        
        if os.path.exists(self.__tpl_path+"/tpl_hyaline"):
            shutil.rmtree(self.__tpl_path+"/tpl_hyaline")
        shutil.copytree(self.__tpl_path+"/default",self.__tpl_path+"/tpl_hyaline")

        content = public.ReadFile(self.__tpl_path+"/tpl_hyaline/layout.html")

        # 插入背景图
        str_rp = '<div class="tpl_hyaline_bg"></div><div class="tpl_hyaline_bg"></div><div class="bt-warp">'
        content = content.replace('<div class="bt-warp bge6">',str_rp)
        
        jq = re.search("jquery-(.*).min.js",content);
        
        tpl = '<link href="/static/tpl_hyaline/css/site.css" rel="stylesheet"/><script src="{{g.cdn_url}}/js/jquery-' + jq.group(1) + '.min.js"></script><script src="/static/tpl_hyaline/js/index.js"></script></head>'
        
        if content.find(tpl) == -1:
            res = content.replace('</head>',tpl)
            if not public.WriteFile(self.__tpl_path+"/tpl_hyaline/layout.html",res):
                return {'code':1,'msg':"删除失败，请联系作者"}
        
        return {'code':0,'msg':"重置成功","data":jq.group(1)}

    def get_images(self,args):
        if os.path.isfile(self.__static_path+"/js/images.json"):
            data = json.loads(public.ReadFile(self.__static_path+"/js/images.json"))
            return {'code':0,'data':data}
        else:
            return {'code':1,'msg':"重置面板方可配置！"}

    def image_add(self,args):
        data = json.loads(public.ReadFile(self.__static_path+"/js/images.json"))
        data['list'].append(args['data'])
        if public.WriteFile(self.__static_path+"/js/images.json",json.dumps(data)):
            return {'code':0,'data':data,"msg":"添加成功"}
        else:
            return {'code':1,'msg':"添加失败"}

    def image_remove(self,args):
        data = json.loads(public.ReadFile(self.__static_path+"/js/images.json"))
        data['list'].pop(data['list'].index(args['data']))
        if public.WriteFile(self.__static_path+"/js/images.json",json.dumps(data)):
            return {'code':0,'data':data,"msg":"删除成功"}
        else:
            return {'code':1,'msg':"删除失败"}

    def image_save(self,args):
        data = json.loads(public.ReadFile(self.__static_path+"/js/images.json"))
        if "type" in args:
            data['type'] = args['type']
        if "time" in args:
            data['time'] = args['time']
        if "speed" in args:
            data['speed'] = args['speed']

        if public.WriteFile(self.__static_path+"/js/images.json",json.dumps(data)):
            return {'code':0,'data':data,"msg":"设置成功"}
        else:
            return {'code':1,'msg':"设置失败"}

    def setting_get(self,args):
        setting = public.ReadFile(self.__plugin_path+"/setting.json")
        if setting is False:
            setting = {"tpl_hyaline_transparency" : 50,"tpl_hyaline_blurriness":0}
        else:
            setting = json.loads(setting)

        return {'code':0,"data":setting}

    def setting_save(self,args):
        # {{transparency}} 整体透明度
        setting = public.ReadFile(self.__plugin_path+"/setting.json")
        if setting is False:
            setting = {}
        else:
            setting = json.loads(setting)
            
        data = public.ReadFile(self.__plugin_path+"/source/site.css")
        if "tpl_hyaline_transparency" in args:
            setting['tpl_hyaline_transparency'] = int(args['tpl_hyaline_transparency'])
            data = data.replace('{{transparency}}',str(int(args['tpl_hyaline_transparency'])/100))
        
        if "tpl_hyaline_blurriness" in args:
            setting['tpl_hyaline_blurriness'] = int(args['tpl_hyaline_blurriness'])
            data = data.replace('{{blurriness}}',args['tpl_hyaline_blurriness'])

        if public.WriteFile(self.__static_path+"/css/site.css",data):
            public.WriteFile(self.__plugin_path+"setting.json",json.dumps(setting))
            return {'code':0,'data':data,"msg":"保存成功"}
        else:
            return {'code':1,'msg':"保存失败"}
            
    def l2d_injection(self,args):
        # tpl = args['tpl']
        if "tpl" in args:
            tpl = args['tpl']
        else:
            tpl = "default"
        
        content = public.ReadFile(self.__tpl_path+"/"+tpl+"/layout.html")
        l2d_html = '<script src="https://eqcn.ajz.miesnfu.com/wp-content/plugins/wp-3d-pony/live2dw/lib/L2Dwidget.min.js"></script><script src="https://eqcn.ajz.miesnfu.com/wp-content/plugins/wp-3d-pony/live2dw/lib/L2Dwidget.0.min.js"></script><script src="/static/js/l2d_config.js"></script><script>L2Dwidget.init(l2d_config);</script></body>'
        
        if content.find(l2d_html) == -1:
            res = content.replace('</body>',l2d_html)
            if not public.WriteFile(self.__tpl_path+"/"+tpl+"/layout.html",res):
                return {'code':1,'msg':"注入失败，请联系作者"}
        
        #写入js文件
        l2d_file = self.__sys_static_path+"/js/l2d_config.js"
        data = {"model":{"jsonPath":"https://unpkg.com/live2d-widget-model-chitose@1.0.5/assets/chitose.model.json","scale":1 },"display":{"position":"left","width":100,"height":100,"hOffset":0,"vOffset":-20},"mobile":{"show":"true","scale":0.5},"react":{"opacityDefault":0.7, "opacityOnHover":0.2}}
        if not public.WriteFile(l2d_file,"var l2d_config="+json.dumps(data)):
            return {'code':1,'msg':"配置文件保存失败，请联系作者"}
        
        return {'code':0,'msg':"L2D注入成功!请重启宝塔面板使用！"}
        
    def l2d_delete(self,args):
        # tpl = args['tpl']
        if "tpl" in args:
            tpl = args['tpl']
        else:
            tpl = "default"
        
        content = public.ReadFile(self.__tpl_path+"/"+tpl+"/layout.html")
        l2d_html = '<script src="https://eqcn.ajz.miesnfu.com/wp-content/plugins/wp-3d-pony/live2dw/lib/L2Dwidget.min.js"></script><script src="https://eqcn.ajz.miesnfu.com/wp-content/plugins/wp-3d-pony/live2dw/lib/L2Dwidget.0.min.js"></script><script src="/static/js/l2d_config.js"></script><script>L2Dwidget.init(l2d_config);</script></body>'
        
        if content.find(l2d_html) != -1:
            res = content.replace(l2d_html,'</body>')
            if not public.WriteFile(self.__tpl_path+"/"+tpl+"/layout.html",res):
                return {'code':1,'msg':"删除失败，请联系作者"}
            
        return {'code':0,'msg':"L2D删除成功!请重启宝塔面板使用！"}

    def l2d_setting(self,args):
        l2d_file = self.__sys_static_path+"/js/l2d_config.js"
        if os.path.isfile(l2d_file):
            content = public.ReadFile(l2d_file)
            data = json.loads(content.replace("var l2d_config=",''))
            return {'code':0,'data':data}
        else:
            return {'code':1,'msg':"注入l2d方可配置"}
            
    def l2d_save(self,args):
        l2d_file = self.__sys_static_path+"/js/l2d_config.js"
        data = {"model":{"jsonPath":args['model'],"scale":1 },"display":{"position":args['position'],"width":args['width'],"height":args['height'],"hOffset":args['hOffset'],"vOffset":args['vOffset']},"mobile":{"show":"true","scale":0.5},"react":{"opacityDefault":args['opacityDefault'], "opacityOnHover":0.2}}
        if not public.WriteFile(l2d_file,"var l2d_config="+json.dumps(data)):
            return {'code':1,'msg':"保存失败，请联系作者"}
        return {'code':0,'msg':"L2D配置保存成功"}