$(".tpl_hyaline_bg").eq(1).fadeOut()
$.ajax({
    url: "/static/tpl_hyaline/js/images.json",
    dataType: "json",
    success: function(res){
    	let data = res;
        // let data = eval(res);
        if(data.list.length == 1){
            $(".tpl_hyaline_bg").eq(0).css("background-image","url('"+data.list[0]+"')");
            return true;
        }
        if(data.type == "random"){
            let num_f = Math.floor(Math.random()*data.list.length+1);;
            $(".tpl_hyaline_bg").eq(0).css("background-image","url('"+data.list[num_f-1]+"')");
            $(".tpl_hyaline_bg").eq(1).css("background-image","url('"+data.list[num_f-1]+"')");
            let mynum = 0;
            setInterval(function(){
                let num = Math.floor(Math.random()*data.list.length+1);;
                let image_url = data.list[num-1];
                let mynum1 = mynum%2;
                let mynum2 = (mynum+1)%2;

                console.log(num,image_url);
                $(".tpl_hyaline_bg").eq(mynum1).fadeOut(data.speed);
                $(".tpl_hyaline_bg").eq(mynum2).css("background-image","url('"+image_url+"')");
                $(".tpl_hyaline_bg").eq(mynum2).fadeIn(data.speed);
                mynum++;
            },data.time);
        }else{
            $(".tpl_hyaline_bg").eq(0).css("background-image","url('"+data.list[0]+"')");
            $(".tpl_hyaline_bg").eq(1).css("background-image","url('"+data.list[1]+"')");
            let mynum = 2;
            setInterval(function(){
                let num = mynum%data.list.length;
                let mynum1 = mynum%2;
                let mynum2 = (mynum+1)%2;
                console.log(num,mynum1,mynum2)
                $(".tpl_hyaline_bg").eq(mynum1).fadeOut(data.speed)
                $(".tpl_hyaline_bg").eq(mynum1).css("background-image","url('"+data.list[num]+"')");
                $(".tpl_hyaline_bg").eq(mynum2).fadeIn(data.speed)
                mynum++;
            },data.time);
        }
    },
    error: function(){
        $(".tpl_hyaline_bg").css("background-image","url('/static/tpl_hyaline/image/bg-1.jpg')");
    }
})