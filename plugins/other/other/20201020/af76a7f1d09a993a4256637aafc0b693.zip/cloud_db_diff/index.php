<?php
/**
 * QQ402735251
 *
 * @author 四川云速科技工作室
 * @url http://cloud.52meishan.com/
 */
require_once 'function.php';

class bt_main{
	//不允许被面板访问的方法请不要设置为公有方法
	public function sync(){
		$data = [];
		foreach(_post() as $k=>$v){
			$data[$k] = trim($v);
		}
		$ini1 = ['host'=>$data['host1'],'user'=>$data['username1'],'pass'=>$data['pass1'],'dbname'=>$data['dbl']];
		$ini2 = ['host'=>$data['host2'],'user'=>$data['username2'],'pass'=>$data['pass2'],'dbname'=>$data['db2']];
		$db1 = Mysqli($ini1);
		$db2 = Mysqli($ini2);
		$db_list = table_list($db2);
		$schemas = [];
		foreach ($db_list as $item) {
			$local = db_table_schema_ab($db1,$item['tablename']);
			unset($item['increment']);
			unset($local['increment']);
			$sql_list = db_table_fix_sql_ab($local, $item);
			if(is_array($sql_list)){
				foreach($sql_list as $val){
					$schemas[] = $val;
				}
			}
		}
		if(count($schemas) <= 0){
			show_json(-1,'所有字段类型一致，无需检验');
		}
		if($data['show_sql'] == 1){
			$sql = implode(';',$schemas);
			show_json(1,'获取成功',['sql'=>$sql]);
		}
		$arr = [];
		foreach($schemas as $sql){
			 $db1->query($sql);
			 $arr[] = $sql;
		}
		show_json(1,'操作成功',$arr);
	}
	
}


?>