<?php
/**
 * QQ402735251
 *
 * @author 四川云速科技工作室
 * @url http://cloud.52meishan.com/
 */
class pdo_mysql
{
	private $mysqli;
	private $result;
	private $tablepre;
	private static $dbcon = false;
    /**
     * 数据库连接
     * @param $config 配置数组
     */
    public function __construct($param = array())
    {
		error_reporting(0);
		$this->tablepre = '';  //数据库前缀
		$this->mysqli = new mysqli($param['host'],$param['user'],$param['pass'],$param['dbname']);
		if($this->mysqli->connect_error){
			echo json_encode(['status'=>-1,'msg'=>'数据库' . $param['dbname'] . "连接失败！"]);
			exit;
		}
    }
	//根据返回结果集
	public function fetch($sql){
		$result = $this->query($sql);
		$row = mysqli_fetch_assoc($result);
		mysqli_free_result($result);
		return $row;
	}
	//根据返回全部结果集
	public function fetchall($sql,$where = []){
		$result = $this->query($sql);
		$resp = mysqli_fetch_all($result,MYSQLI_ASSOC); 
		mysqli_free_result($result);
		return $resp;
	}
	//执行sql语句
	public function query($sql){
		$result = mysqli_query($this->mysqli,$sql);
		if($result){
			return $result;
		}
	}
		//更新数据
	    public function update($table, $data, $where)
    {
		$table = $this->tablepre . $table;
		if(count($data) <= 0 || count($where) <= 0){
			return false;
		}
         $fileds = [];
		foreach ($data as $key => $val) {
			$fileds[] = $key . " = '" . $this->check_filed($val) . "'";
		}
         $fileds = implode(',', $fileds);
		$wh = [];
		foreach($where as $k=>$v){
			$wh[] = $k . " = '" . $this->check_filed($v) . "'";
		}
		$wh = (count($where) >= 1)?' where ' . implode(' and ', $wh):'';
         $sql = "UPDATE {$table} SET {$fileds} {$wh}";
         return $this->query($sql);
    }
	
	//根据返回结果集
	public function get($table, $where = [], $filed = []){
		$filed = (count($filed) >= 1)?implode(',', $filed):'*';
		$wh = [];
		foreach($where as $k=>$v){
			$wh[] = $k . " = '" . $this->check_filed($v) . "'";
		}
		$wh = (count($where) >= 1)?' where ' . implode(' and ', $wh):'';
		$sql = 'select '.$filed. ' from ' .$this->tablepre . $table . $wh;
		return $this->fetch($sql);
	}
	
		//根据返回结果集
	public function getall($table, $where = [], $filed = []){
		$filed = (count($filed) >= 1)?implode(',', $filed):'*';
		$wh = [];
		foreach($where as $k=>$v){
			$wh[] = $k . " = '" . $this->check_filed($v) . "'";
		}
		$wh = (count($where) >= 1)?' where ' . implode(' and ', $wh):'';
		$sql = 'select '.$filed. ' from ' .$this->tablepre . $table . $wh;
		return $this->fetchall($sql);
	}
         /**
     * 插入数据
     * @param $table 数据表
     * @param $data 数据数组
     */
	public function insert($table, $data){
		$table = $this->tablepre . $table;
		foreach ($data as $key => $value) {
			$data[$key] = $value;
		}
		$keys = '`' . implode('`,`', array_keys($data)) . '`';
		$values = '\'' . implode("','", array_values($data)) . '\'';
		$sql = "INSERT INTO $table($keys)VALUES($values)";
		$this->query($sql);
		return mysqli_insert_id($this->mysqli);
    }
	
	         /**
     * 删除数据
     * @param $table 数据表
     * @param $data 数据数组
     */
	public function del($table, $data = array()){
		$table = $this->tablepre . $table;
		if(count($data) < 1){
			return false;
		}
		$wh = [];
		foreach($data as $k=>$v){
			$wh[] = $k . " = '" . $this->check_filed($v) . "'";
		}
		$wh = (count($data) >= 1)?implode(' and ', $wh):'';
		$sql = 'delete from ' . $table . ' where ' . $wh;
		return $this->query($sql);
    }
	
		    //字符串过滤
    public function check_filed($str)
    {
		$str = addslashes($str);
		$str = str_replace("_", "\\_", $str);
		$str = str_replace("%", "\\%", $str);
		$res_str = eregi('select|insert|and|or|update|delete|\'|\\/\\*|\\*|\\.\\.\\/|\\.\\/|union|into|load_file|outfile', $str);
		if (!empty($res_str)) {
			return false;
		}
         return $str;
    }

}
?>