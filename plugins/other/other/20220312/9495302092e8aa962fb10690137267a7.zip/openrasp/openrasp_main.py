#!/usr/bin/python
# coding: utf-8
# -----------------------------
# Name: OpenRasp 管理器
# OpenRasp:https://rasp.baidu.com/
# Author: print("")
# -----------------------------
# date 2020-01-03
import sys, os
if sys.version_info[0] == 2:
    reload(sys)
    sys.setdefaultencoding('utf-8')
os.chdir('/www/server/panel')
sys.path.append("class/")
import public,time,json,re

class openrasp_main:
    __down_path='/var/tmp/rasp-php-linux.tar.bz2'
    __openrasp='/var/tmp/rasp-php-2022-01-28'
    __install_path='/opt/rasp'
    __php_path='/www/server/php/'
    __office="/www/server/panel/plugin/openrasp/official.js"
    __php_version=['53','54','55','56','70','71','70','72','73','74']
    def __init__(self):
        pass

    #下载OpenRasp
    def down_rasp(self,get):
        if not os.path.exists(self.__openrasp+'/install.php'):
            public.ExecShell('rm -rf /var/tmp/rasp-php-*')
            public.ExecShell('cd /var/tmp && wget https://packages.baidu.com/app/openrasp/release/1.3.7/rasp-php-linux.tar.bz2 && tar jxvf rasp-php-linux.tar.bz2 && chattr -R +i /var/tmp/rasp-php-2021-02-07')
            return public.returnMsg(True,'下载成功')
        else:
            return public.returnMsg(True,'已经存在')

    def get_check_rasp(self):
        if not os.path.exists(self.__openrasp + '/install.php'):
            return False
        else:
            return True

    #获取PHP安装的版本
    def get_php_version(self,get):
        return_list=[]
        for i in self.__php_version:
            if os.path.exists(self.__php_path+i+"/etc/php.ini"):
                return_list.append(i)
        return list(set(return_list))

    #检验是否安装了了openrasp
    def check_openrasp(self,version):
        if os.path.exists(self.__install_path+version):
            if os.path.exists(self.__php_path+version+'/etc/php.ini'):
                file_data=public.ReadFile(self.__php_path+version+'/etc/php.ini')
                if re.search(self.__install_path+version,file_data):
                    data=public.ReadFile(self.__php_path+version+'/etc/php.ini')
                    if re.search('openrasp.so',data):return True
        return False

    #是否开启
    def get_status_openrasp(self,version):
        if os.path.exists(self.__install_path+version+'/plugins/official.js'):
            data=public.ReadFile(self.__install_path+version+'/plugins/official.js')
            if re.findall('all_log:\s+?(.+),', data)[0]=='false':
                data=public.ReadFile(self.__php_path+version+'/etc/php.ini')
                if re.search('openrasp.so',data):return True
            else:
                return False
        return False
            

    #查看哪些版本已经安装了openrasp
    def get_openrasp(self,get):
        php_version=self.get_php_version(get)
        if len(php_version)==0:return []
        data=[]
        for i in php_version:
            data2={}
            data2['version']=i
            data2['openrasp']=self.check_openrasp(i)
            data2['openrasp_open'] = self.get_status_openrasp(i)
            data.append(data2)
        return {"php":data,"check_rasp":self.get_check_rasp()}



    def get_filter_so(self, v):
        vfs = {
            '52': '/www/server/php/52/lib/php/extensions/no-debug-non-zts-20060613',
            '53': '/www/server/php/53/lib/php/extensions/no-debug-non-zts-20090626',
            '54': '/www/server/php/54/lib/php/extensions/no-debug-non-zts-20100525',
            '55': '/www/server/php/55/lib/php/extensions/no-debug-non-zts-20121212',
            '56': '/www/server/php/56/lib/php/extensions/no-debug-non-zts-20131226',
            '70': '/www/server/php/70/lib/php/extensions/no-debug-non-zts-20151012',
            '71': '/www/server/php/71/lib/php/extensions/no-debug-non-zts-20160303',
            '72': '/www/server/php/72/lib/php/extensions/no-debug-non-zts-20170718',
            '73': '/www/server/php/73/lib/php/extensions/no-debug-non-zts-20180731',
            '74': '/www/server/php/74/lib/php/extensions/no-debug-non-zts-20190902'
        }
        if v in vfs.keys():
            if not os.path.exists(vfs[v]):
                os.makedirs(vfs[v])
            return vfs[v] + '/openrasp.so'
        return None


    def rasp_ini(self,type,phppath,php_v):
        phpini = public.readFile(phppath)
        if type=='start':
            if phpini.find('extension=openrasp.so') == -1:
                #如果不存在的时候才去处理
                phpini += '''
; BEGIN OPENRASP

[openrasp]
extension=openrasp.so
openrasp.root_dir=/opt/rasp{}

; 远程管理配置，不需要不用配置
; openrasp.backend_url=
; openrasp.app_id=
; openrasp.app_secret=
; openrasp.remote_management_enable=1

; END OPENRASP
'''.format(php_v)
                public.writeFile(phppath, phpini)

        if type=='stop':
            if phpini.find('extension=openrasp.so') != -1:
                #存在的时候才处理
                rep = r"; BEGIN OPENRASP.+; END OPENRASP"
                erro_data = re.search(rep, phpini, re.I | re.S)
                if erro_data:
                    tttt = erro_data.group(0)
                    phpinfo=phpini.replace(tttt, "")
                    public.writeFile(phppath, phpinfo)

    #卸载openrasp
    def uninstall_openrasp(self,get):
        version = get.version.strip()
        if not version in self.__php_version: return public.returnMsg(False, '只支持PHP5.3到PHP7.4')
        if not os.path.exists(self.__install_path + version): return public.returnMsg(False, '你未安装当前PHP版本')
        #修改配置文件
        php_ini_file = os.path.join(self.__php_path, version, 'etc/php.ini')
        if not os.path.exists(php_ini_file):return public.returnMsg(False, '你未安装当前PHP版本')
        self.rasp_ini("stop",php_ini_file,version)
        public.ExecShell('/etc/init.d/php-fpm-%s restart' % get.version.strip())
        return public.returnMsg(True, '卸载成功')

    def install_openrasp(self,get):
        self.down_rasp(get)
        php_v = get.version.strip()
        php_ini_file = os.path.join(self.__php_path, php_v, 'etc/php.ini')
        if not php_v in self.__php_version:return public.returnMsg(False,'只支持PHP5.3到PHP7.4')
        if not os.path.exists(self.__php_path+php_v):return public.returnMsg(False,'你未安装当前PHP版本')
        if not os.path.exists("/opt/rasp{}/plugins".format(php_v)):
            os.system("mkdir -p %s && chmod 777 -R %s" % ("/opt/rasp{}/plugins".format(php_v), "/opt/rasp{}/".format(php_v)))
        openphpath=self.__openrasp+"/php/linux-php%s-x86_64/openrasp.so"%".".join(php_v)
        #获取php extension_dir
        php_ext_so=self.get_filter_so(php_v)
        if not os.path.exists(php_ext_so):
            public.ExecShell("cp -a -r %s %s "%(openphpath,php_ext_so))
        self.rasp_ini("start",php_ini_file,php_v)
        #js文件
        if not os.path.exists("/opt/rasp{}/plugins/official.js".format(php_v)):
            if os.path.exists(self.__office):
                if os.path.getsize(self.__office)>50:
                    public.ExecShell("cp -a -r %s %s " % (self.__office, "/opt/rasp{}/plugins/".format(php_v)))
                else:
                    public.ExecShell("cp -a -r %s %s " % (self.__openrasp + "/plugins/official.js", "/opt/rasp{}/plugins/".format(php_v)))
            else:
                public.ExecShell("cp -a -r %s %s " % (self.__openrasp+"/plugins/official.js", "/opt/rasp{}/plugins/".format(php_v)))
        self.start_openrasp(get)
        public.ExecShell('/etc/init.d/php-fpm-%s restart'%get.version.strip())
        return public.returnMsg(True, '安装成功')

    # 开启OpenRsap
    def start_openrasp(self,get):
        version=get.version.strip()
        if not 'is_dev' in get:get.is_dev='false'
        if not version in self.__php_version: return public.returnMsg(False, '只支持PHP5.3到PHP7.4')
        if not os.path.exists(self.__install_path+version): return public.returnMsg(False, '你未安装当前PHP版本')
        if os.path.exists(self.__install_path+version+'/plugins/official.js'):
            data=public.ReadFile(self.__install_path+version+'/plugins/official.js')
            data2 = re.sub('all_log:\s+?(.+),', 'all_log: false,', data)
            if not get.is_dev=='false':
                data2 = re.sub('is_dev:\s+?(.+),', 'is_dev: true,', data2)
            public.WriteFile(self.__install_path+version+'/plugins/official.js', data2)
        public.ExecShell('/etc/init.d/php-fpm-%s restart'%get.version.strip())
        return public.returnMsg(True, '开启成功')

    #关闭OpenRasp
    def stop_openrasp(self,get):
        version=get.version.strip()
        if not version in self.__php_version: return public.returnMsg(False, '只支持PHP5.3到PHP7.3')
        if not os.path.exists(self.__install_path+version): return public.returnMsg(False, '你未安装当前PHP版本')
        if os.path.exists(self.__install_path+version+'/plugins/official.js'):
            data=public.ReadFile(self.__install_path+version+'/plugins/official.js')
            data2 = re.sub('all_log:\s+?(.+),', 'all_log: true,', data)
            public.WriteFile(self.__install_path+version+'/plugins/official.js', data2)
            public.ExecShell('/etc/init.d/php-fpm-%s restart' % get.version.strip())
        return public.returnMsg(True, '关闭成功')


    #自定义拦截页面
    def set_lan_html(self,get):
        pass

    #防护日志
    def get_logs(self,get):
        version = get.version.strip()
        if not version in self.__php_version: return public.returnMsg(False, '只支持PHP5.3到PHP7.3')
        if not os.path.exists(self.__install_path + version): return public.returnMsg(False, '你未安装当前PHP版本')
        pass


    #

