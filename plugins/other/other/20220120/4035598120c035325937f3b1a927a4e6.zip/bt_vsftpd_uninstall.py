
import os,json,sys
#设置运行目录
os.chdir("/www/server/panel")

#添加包引用位置并引用公共包
sys.path.append("class/")
import public


if os.path.exists("/www/server/panel/pyenv/bin/python"):
    pythonshell = "/www/server/panel/pyenv/bin/python"
else:
    pythonshell = "python"

virtualuser = json.loads(public.ReadFile("/www/server/panel/plugin/bt_vsftpd/conf/virtualuser.json"))
_virtualuser = virtualuser
for p in virtualuser:
    user = virtualuser[p]
    # 虚拟磁盘、删除用户数据
    if user["diskstatus"] != "local-disk":
        shell = "cd www/server/panel/plugin/bt_vsftpd/ && "+pythonshell+" bt_vsftpd_disk.py -m del -u " + user["userid"]
        public.ExecShell(shell)

