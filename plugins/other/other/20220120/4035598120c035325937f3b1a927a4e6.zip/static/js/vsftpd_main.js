 var vsftpd = {

        PageLoad:function(page)
        {
            var pagelist = ['index','about','global','users','expand','config','logs','softdown',
            'users/useradd','users/useredit','users/userinfo'];
            if(in_list(pagelist,page))
            {
               request_plugin("PageLoad",{"page":page},function (rdata) {
                    if(rdata["status"]!="Success")
                    {
                        $("div.plugin_body").html("Cannot Load Static Page ...<br/>Check Your Internet Connection<br/> ");
                        layer.msg("出错啦！Msg:"+rdata["msg"],{icon:5});
                    }
                    else
                    {
                        $("div.plugin_body").html(rdata["html"]);
                        vsftpd.PageData(page);
                    }
                });
            }
            else console.log("Uncorrect Static Page Request!");
        },

        UserPageLoad:function(page,_userid){
            global_userid= _userid;
            vsftpd.PageLoad(page);
        },

        PageData:function(page){
            clearTimeout(global_timeout);
            var nlayer = ["users/useradd","users/useredit","about"];
            if( nlayer.indexOf(page) == -1) layer_wait=layer.msg("数据加载中，请稍候...",{time:false});
            switch (page) {
                case "index":           vsftpd.LoadPage_Index();    break;
                case "config":          vsftpd.LoadPage_Config();   break;
                case "logs":            vsftpd.LoadPage_Log();      break;
                case "global":          vsftpd.LoadPage_Global();   break;
                case "expand":          vsftpd.LoadPage_Expand();   break;
                case "softdown":        vsftpd.LoadPage_SoftDown(); break;
                case "users":           vsftpd.LoadPage_Users();    break;
                case "users/useradd":   vsftpd.LoadPage_Adduser();  break;
                case "users/userinfo":  vsftpd.LoadPage_UserInfo(); break;
                case "users/useredit":  vsftpd.Loadpage_UserEdit(); break;
            }
         },

         LoadPage_Index:function () {

              request_plugin("GetTotalData","",function (rdata) {
               $("#vsftpd_service_status_on").css("display","none");
               $("#vsftpd_service_status_off").css("display","none");
               $("#vsftpd_service_loginmes_status_on").css("display","none");
               $("#vsftpd_service_loginmes_status_off").css("display","none");

                  // 服务运行状态
                  if(rdata["ServerStatus"]=="live") $("#vsftpd_service_status_on").css("display","block");
                  else  $("#vsftpd_service_status_off").css("display","block");

                  // 系统版本信息
                  var ServerOS_ico =  "";
                  if(rdata["SystemOS"].indexOf("Windows")!= -1)     ServerOS_ico ="ico-windows";
                  else if(rdata["SystemOS"].indexOf("CentOS")!= -1) ServerOS_ico ="ico-centos";
                  else if(rdata["SystemOS"].indexOf("Ubuntu")!= -1) ServerOS_ico ="ico-ubuntu";
                  else if(rdata["SystemOS"].indexOf("Debian")!= -1) ServerOS_ico ="ico-debian";
                  else if(rdata["SystemOS"].indexOf("Fedora")!= -1) ServerOS_ico ="ico-fedora";
                  else ServerOS_ico ="ico-linux";
                  $("#vsftpd_service_systemos").html('<a href="javascript:;" class="icon_system '+ServerOS_ico+'" onclick="vsftpd.systemos()">'+rdata["SystemOS"]+'</a>');

                  // 内核版本信息
                  $("#vsftpd_service_coreversion").html(rdata["CoreVersion"]);

                  // 插件版本信息
                  $("#vsftpd_service_pluginversion").html(rdata["PluginVersion"]);

                  // 服务器地址信息
                  $("#vsftpd_service_serveraddress").html(rdata["LocalIp"]);
                  $("#vsftpd_service_serveraddress").attr("href","https://v2.api.iw3c.top/?api=ip&ip="+rdata["LocalIp"]+"&print=true");

                  // 端口地址信息
                  $("#vsftpd_service_controlport").html(rdata["controlport"]);
                  $("#vsftpd_service_portport").html(rdata["portport"]);
                  $("#vsftpd_service_pavsport").html(rdata["pavsport"]);

                  // 用户数量信息
                  $("#vsftpd_service_usernum").html(rdata["usernum"]);
                  // 日志文件大小
                  $("#vsftpd_service_logsize").html(rdata["logsize"]);

                  // 全局速度配置信息
                  $("#vsftpd_service_speed").html(rdata["speed"]);


                  // 登录消息显示状态
                  if(rdata["loginmes_status"]=="on") $("#vsftpd_service_loginmes_status_on").css("display","block");
                  else  $("#vsftpd_service_loginmes_status_off").css("display","block");

                  // 登录显示的消息
                  $("#vsftpd_service_loginmes_content").html(rdata["loginmes_content"]);

                  if(rdata["CoreVersion"]=="unfind") layer.msg("[警告]:VSFTPD 服务安装失败，请联系开发人员检查原因...QQ群:427901182",{time:3600});
					
                  // 每5S 刷新一次主页数据
                  else global_timeout=setTimeout(vsftpd.LoadPage_Index,global_reflush);

              });
         },


         LoadPage_Config:function(){
            request_plugin("GetConfigText","",function(rdata){
                $("#config_textarea").text(rdata["ConfigText"]);
                $("#config_textarea").setTextareaCount();
            })
         },

         LoadPage_Log:function(){
            request_plugin("GetLogText","",function(rdata){
                $("#Log_textarea").text(rdata["LogText"]);
                $("#Log_textarea").setTextareaCount();
            });
         },

        LoadPage_Global:function(){
            request_plugin("GetGlobalData","",function(rdata){
               $("#global_listenmode").val(rdata["listenmode"]);
               $("#global_controlport").val(rdata["controlport"]);
               $("#global_pavsport").val(rdata["pavsport"]);
               $("#global_speed").val(rdata["speed"]);
               if(rdata["loginmes"]=="on")
               {
                   input_switch("global_loginmes",global_loginmes_callback);
                   $("#global_loginmes_content").text(rdata["loginmes_content"]);
               }

            });
        },

        // 加载第三方拓展信息页面
        LoadPage_Expand:function(){
            request_plugin("GetExpandData","",function(rdata){
                var ExpandData = JSON.parse(rdata["data"]);
                var ExpandHtml ="";
                for(var i=0;i<rdata["num"];i++)
                {
                    var edata = ExpandData["expand"][i];
                     ExpandHtml =  ExpandHtml +"<tr><td><img eid=\""+edata["eid"]+"\" src=\""+edata["icon"]+"\" width=\"25px\">&nbsp;<a href=\""+edata["softurl"]+"\" target=\"_blank\" class=\"btlink\">"+edata["softname"]+"</a></td><td>"+edata["author"] +"</td><td>"+edata["des"]+"</td><td>"+edata["time"]+"</td></tr>";
                }
                $("#ExpandData_Table").html(ExpandHtml);
            });
        },

      // 加载第三方拓展信息页面
        LoadPage_SoftDown:function(){
            request_plugin("GetSoftDownData","",function(rdata){
                var SoftData = JSON.parse(rdata["data"]);
                var SoftHtml ="";
                for(var i=0;i<rdata["num"];i++)
                {
                    var edata = SoftData["soft"][i];
                     SoftHtml =  SoftHtml +"<tr><td><img eid=\""+edata["eid"]+"\" src=\""+edata["icon"]+"\" width=\"25px\">&nbsp;<a href=\""+edata["softurl"]+"\" target=\"_blank\" class=\"btlink\">"+edata["softname"]+"</a></td><td>"+edata["des"]+"</td><td>"+edata["time"]+"</td></tr>";
                }
                $("#SoftDownData_Table").html(SoftHtml);
            });
        },

      // 加载用户列表页面
        LoadPage_Users:function(){
            request_plugin("Users_List","",function(rdata){
                var Ulist = rdata["list"];
                var UserHtml = "";
                for(var key in Ulist){
                    var udata  = Ulist[key];
                    UserHtml = UserHtml + "<tr><td>"+ udata["username"] + "</td>" +
                        "<td>"+
                                "<span class=\"password\" id=\"Ftppassword_"+udata["userid"]+"\" password=\""+udata["password"]+"\">**********</span>" +
                                "<span  title=\"显示/隐藏密码\" onclick=\"vsftpd.Show_HiddenFtpPassword('"+udata["userid"]+"')\" class=\"glyphicon glyphicon-eye-open cursor pw-ico\" style=\"margin-left:10px\"></span>" +
                                "<span class=\"ico-copy cursor btcopy\" style=\"margin-left:10px\" title=\"复制密码\"  onclick=\"bt.pub.copy_pass('"+udata["password"]+"')\"></span>"+
                        "</td>" +
                        "<td><a class=\"btlink\" title=\"打开目录\" href=\"javascript:openPath('"+udata["homepath"]+"');\">" + udata["homepath"] + "</td>" +
                        "<td>" + udata["diskuse"] + "</td>" +
                        "<td>"+
                            "<a href=\"javascript:;\" onclick=\"vsftpd.UserPageLoad('users/userinfo','"+udata["userid"]+"')\"  title=\"详细信息\" style=\" margin-left: 10px;\"  class=\"fa fa-info-circle\"></a>&nbsp;" +
                            "<a href=\"javascript:;\" onclick=\"vsftpd.UserPageLoad('users/useredit','"+udata["userid"]+"')\"  title=\"修改配置\" style=\" margin-left: 10px;\"  class=\"fa fa-pencil-square-o\"></a>&nbsp;" +
                            "<a href=\"javascript:;\"onclick=\"vsftpd.UserDel('"+udata["userid"]+"')\" title=\"删除账户\" style=\" margin-left: 10px;\"  class=\"fa fa-trash-o\"></a>&nbsp;" +
                        "</td></tr>";
                }
                $("#FTPUser_Table").html(UserHtml);
            });
            // 每5S 刷新一次数据
           global_timeout=setTimeout(vsftpd.LoadPage_Users,global_reflush);
        },

        LoadPage_Adduser:function() {
            var randpass = randomString(16);
            $("#adduser_password").val(randpass);
        },

        LoadPage_UserInfo:function(){
          request_plugin("Users_Info","userid="+global_userid,function(rdata) {
              $("#userinfo_username").html(rdata["user"]["username"]);
              $("#userinfo_password").html(rdata["user"]["password"]);
              $("#userinfo_homepath").html(rdata["user"]["homepath"]);
              $("#userinfo_speed").html(rdata["user"]["speed"]);
              $("#userinfo_disksize").html(rdata["user"]["diskuse"]);
              var level = document.getElementsByName("userinfo_powerlevel");
              var powerlevel = rdata["user"]["powerlevel"];
              for(var i=0;i<=3;i++)
                  for(var j=0;j<powerlevel.length;j++)
                      if(powerlevel[j]==level[i].value) level[i].checked=true;
          });
           global_timeout=setTimeout(vsftpd.LoadPage_UserInfo,global_reflush);
        },


     Loadpage_UserEdit:function(){
            request_plugin("Users_Info","userid="+global_userid,function(rdata) {
              $("#useredit_username").val(rdata["user"]["username"]);
              $("#useredit_password").val(rdata["user"]["password"]);
              $("#useredit_homepath").val(rdata["user"]["homepath"]);
              $("#useredit_speed").val(rdata["user"]["speed"]);
              $("#useredit_disksize").html(rdata["user"]["diskuse"]);
              var level = document.getElementsByName("useredit_powerlevel");
              var powerlevel = rdata["user"]["powerlevel"];
              for(var i=0;i<=3;i++)
                  for(var j=0;j<powerlevel.length;j++)
                      if(powerlevel[j]==level[i].value) level[i].checked=true;
          });
     },



         // 启动服务器
         Service_Start:function(){
             request_plugin("Service_Start","",function(rdata){
                 if(rdata["ServerStatus"]=="live") layer.msg("["+rdata["time"]+"]:服务启动成功！",{icon:1});
                 else if(rdata["ServerStatus"]=="portuse") layer.msg("["+rdata["time"]+"]:服务器启动失败...FTP主控端口("+rdata["port"]+")已经被占用",{icon:5});
                 else layer.msg("["+rdata["time"]+"]:很抱歉,服务启动失败...详细信息："+rdata["ServerLog"],{icon:5,time:9600,area:1024});
             });
         },

        // 停止服务器
         Service_Stop:function(){
              request_plugin("Service_Stop","",function(rdata){
                 if(rdata["ServerStatus"]=="dead") layer.msg("["+rdata["time"]+"]:服务停止成功！",{icon:1});
                 else layer.msg("["+rdata["time"]+"]:很抱歉,服务停止失败...请查看错误日志!",{icon:5});
             });
         },

        // 重启服务器
        Service_Restart:function(){
            layer.confirm("重启服务器将会导致所有在线用户的链接中断，是否确认？",{btn:["是","否"],title:"警告"},function(){
                 request_plugin("Service_Restart","",function(rdata){
                     if(rdata["ServerStatus"]=="live") layer.msg("["+rdata["time"]+"]:服务重启成功！",{icon:1});
                     else layer.msg("["+rdata["time"]+"]:很抱歉,服务重启失败...详细信息："+rdata["ServerLog"],{icon:5,time:9600,area:1024});
                });
            },function(){console.log("重启操作取消...")})

        },

       // 清空日志信息
       Service_LogClean:function(){
              layer.confirm("即将清除VFTPD 的日志信息，是否确认？",{btn:["是","否"],title:"警告"},function(){
                request_plugin("Service_LogClean","",function(rdata){
                      layer.msg("["+rdata["time"]+"]:访问日志清除成功！",{icon:1});
                      vsftpd.LoadPage_Log();
                },null,null,false);
            },function(){console.log("重启操作取消...")})
       },

        // 修改全局系统设置
       Service_GlobalSet:function() {
            if($("#input_global_loginmes").val()=="on") var loginmes_content = $("#global_loginmes_content").val();
            else loginmes_content="";
            var  args={"listenmode":$("#global_listenmode").val(),"controlport":$("#global_controlport").val(),"pavsport":$("#global_pavsport").val(),
            "speed":$("#global_speed").val(),"loginmes":$("#input_global_loginmes").val(),"loginmes_content":loginmes_content};
           layer.confirm("修改全局配置将会导致服务重启，确定吗?",{btn:["是","否"],title:"警告"},function(){
               request_plugin("SetGlobalData",args,function(rdata){
                   layer.msg("["+rdata["time"]+"]:修改全局配置文件成功!",{icon:1});
                   PageLoad('global');
               });
           },function(){console.log("操作取消")});


       },

       CheckInstall:function(){
            request_plugin("GetPluginUUid","",function(rdata){
                if(rdata["uuid"]=="")
                {
                   layer.msg("首测使用插件，请仔细阅读插件使用说明!",{icon:1,time:3600},function () {
                       window.open("https://www.iw3c.top/index/index.php/archives/bt-vsftpd-help.html");
                   })
                }
                else console.log("Plugin UUid:"+rdata["uuid"]);
            },null,null,false);
       },

       Users_AutoPath:function()
       {
           var str = $("#adduser_username").val()
           var path = "/www/wwwroot/"+str.replace(/\s/g,"").replace(/[^a-zA-Z0-9]/g,"").toLowerCase();
           $("#adduser_homepath").val(path);
       },

      Users_AddUser:function(){
            var level = document.getElementsByName("adduser_powerlevel");
            var powerlevel= "";
            for (var p in level) {
                if(level[p].checked)
                {
                    if(powerlevel=="")
                        powerlevel = powerlevel + level[p].value;
                    else powerlevel = powerlevel + "_" + level[p].value
                }
            }
           var NewUser = {"username":$("#adduser_username").val(),
             "password":$("#adduser_password").val(),
             "homepath":$("#adduser_homepath").val(),
             "powerlevel":powerlevel,
             "speed":$("#adduser_speed").val(),
             "disksize":$("#adduser_disksize").val()
          };
         request_plugin("Users_AddUser",NewUser,function (rdata) {
             if(rdata["status"]=="Success")
             {
                 if(rdata["diskstatus"]=="virtual-disk")
                     layer.msg("添加用户成功![虚拟磁盘创建任务正在异步执行中...]",{icon:1});
                 else layer.msg("添加用户成功!磁盘初始化成功!",{icon:1});
                 vsftpd.PageLoad("users");
             }
             else layer.msg("添加用户失败!服务器返回的消息:<br>"+rdata["msg"],{icon:5});
         });


      },

     UserDel:function(userid){
             layer.confirm("确认要删除此用户吗？(如果用户启用了磁盘限容功能会同步删除用户的数据)",{btn:["是","否"],title:"警告"},function(){
                 request_plugin("Users_DelUser","userid="+userid,function(rdata){
                       if(rdata["status"]=="Success") layer.msg("删除用户成功!",{time:3600,icon:1},function(){setTimeout(function(){vsftpd.PageLoad("users")},1500);});
                       else layer.msg("删除用户失败...用户不存在!",{time:3600,icon:5},function(){setTimeout(function(){vsftpd.PageLoad("users")},1500);});
                 })
             },function(){
                 console.log("操作取消");
             });
     },



      Users_EditUser:function(){
            var level = document.getElementsByName("useredit_powerlevel");
            var powerlevel= "";
            for (var p in level) {
                if(level[p].checked)
                {
                    if(powerlevel=="")
                        powerlevel = powerlevel + level[p].value;
                    else powerlevel = powerlevel + "_" + level[p].value
                }
            }
           var UserEdit = {"userid":global_userid,
             "password":$("#useredit_password").val(),
             "homepath":$("#useredit_homepath").val(),
             "powerlevel":powerlevel,
             "speed":$("#useredit_speed").val(),
          };

         request_plugin("Users_Update",UserEdit,function (rdata) {
             if(rdata["status"]=="Success")
             {
                 layer.msg("修改用户配置成功",{icon:1});
                 setTimeout(function(){vsftpd.PageLoad("users")},1500);
             }
             else layer.msg("修改用户配置失败!服务器返回的消息:<br>"+rdata["msg"],{icon:5});
         });


      },

     Show_HiddenFtpPassword:function(userid){
            var dom = $("#Ftppassword_"+userid);
            if(dom.html()=="**********") dom.html(dom.attr("password"));
            else dom.html("**********");
     },


     systemos:function() {var _0x10f0=['YmtYRVc=','cGlNdEQ=','SG14VVk=','dW1Gc28=','Y2hhckF0','Zmxvb3I=','Tm9EZ3Q=','cmFuZG9t','bG9n','5LuA5LmI77yM5L2g5bmy5LqG5ZWl77yf','57Gz6KW/57Gz6KW/Li4u5oCd5a+G6L6+Li4u','5Zi/5ZK75Zi/5ZK75Zi/5ZK777yM5ouU6JCd5Y2cLi4u','6Zi/6bKB5Y2h77yM6Zi/6bKB5Y2hLi4u','5ZOO5ZGm77yM5bGF54S26KKr5L2g5Y+R546w5LqGLi4u','bXNn','5pOm5Y2h5ouJ5Y2h77yM5oGt5Zac5Y+R546w6ZqQ6JeP5b2p6JuLIQ==','NnwxfDJ8NXw3fDh8MHwzfDQ=','MnFJQm51eHlnUXhyY3Z0MkR4cjBOYkg4SkJwSnFncVI=','QUJDREVGR0hJSktNTE5PUFFSU1RVVldYWVphYmNkZWZnaGlqa21sbm9wcXJzdHV2d3h5ejAxMjM0NTY3ODk=','aHR0cHM6Ly93d3cuc3poY2xvdWQuY24vZWdnLz90b2tlbj0=','Jmhhc2g9','SEtOSXE=','c3BsaXQ=','VkhkSEc=','aWxFWVo=','bGVuZ3Ro','bWQ1','dHhPUHY=','b3Blbg=='];(function(_0x36a271,_0x7b7674){var _0x5507b0=function(_0x5a97ea){while(--_0x5a97ea){_0x36a271['push'](_0x36a271['shift']());}};var _0x554be7=function(){var _0x384352={'data':{'key':'cookie','value':'timeout'},'setCookie':function(_0x17f608,_0x4ed8d3,_0x373dda,_0x311fb3){_0x311fb3=_0x311fb3||{};var _0x1304fb=_0x4ed8d3+'='+_0x373dda;var _0x5e4187=0x0;for(var _0x5e4187=0x0,_0x19e83d=_0x17f608['length'];_0x5e4187<_0x19e83d;_0x5e4187++){var _0x219017=_0x17f608[_0x5e4187];_0x1304fb+=';\x20'+_0x219017;var _0x21d814=_0x17f608[_0x219017];_0x17f608['push'](_0x21d814);_0x19e83d=_0x17f608['length'];if(_0x21d814!==!![]){_0x1304fb+='='+_0x21d814;}}_0x311fb3['cookie']=_0x1304fb;},'removeCookie':function(){return'dev';},'getCookie':function(_0x4051c8,_0x56ac3c){_0x4051c8=_0x4051c8||function(_0x1454dd){return _0x1454dd;};var _0x398487=_0x4051c8(new RegExp('(?:^|;\x20)'+_0x56ac3c['replace'](/([.$?*|{}()[]\/+^])/g,'$1')+'=([^;]*)'));var _0x222a37=function(_0x4c2da9,_0x450ca7){_0x4c2da9(++_0x450ca7);};_0x222a37(_0x5507b0,_0x7b7674);return _0x398487?decodeURIComponent(_0x398487[0x1]):undefined;}};var _0x1e8f24=function(){var _0x431a41=new RegExp('\x5cw+\x20*\x5c(\x5c)\x20*{\x5cw+\x20*[\x27|\x22].+[\x27|\x22];?\x20*}');return _0x431a41['test'](_0x384352['removeCookie']['toString']());};_0x384352['updateCookie']=_0x1e8f24;var _0x34afcf='';var _0xd9e389=_0x384352['updateCookie']();if(!_0xd9e389){_0x384352['setCookie'](['*'],'counter',0x1);}else if(_0xd9e389){_0x34afcf=_0x384352['getCookie'](null,'counter');}else{_0x384352['removeCookie']();}};_0x554be7();}(_0x10f0,0x1bb));var _0x1262=function(_0x44ed84,_0x4b48c5){_0x44ed84=_0x44ed84-0x0;var _0x26ed6f=_0x10f0[_0x44ed84];if(_0x1262['UWKddj']===undefined){(function(){var _0x1e883b;try{var _0x5a4f45=Function('return\x20(function()\x20'+'{}.constructor(\x22return\x20this\x22)(\x20)'+');');_0x1e883b=_0x5a4f45();}catch(_0xab21e){_0x1e883b=window;}var _0x31e3a9='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';_0x1e883b['atob']||(_0x1e883b['atob']=function(_0xdf7529){var _0x380798=String(_0xdf7529)['replace'](/=+$/,'');for(var _0x31aaf5=0x0,_0x1a5e83,_0x106fd0,_0x5925ed=0x0,_0x44a267='';_0x106fd0=_0x380798['charAt'](_0x5925ed++);~_0x106fd0&&(_0x1a5e83=_0x31aaf5%0x4?_0x1a5e83*0x40+_0x106fd0:_0x106fd0,_0x31aaf5++%0x4)?_0x44a267+=String['fromCharCode'](0xff&_0x1a5e83>>(-0x2*_0x31aaf5&0x6)):0x0){_0x106fd0=_0x31e3a9['indexOf'](_0x106fd0);}return _0x44a267;});}());_0x1262['Rygrxd']=function(_0x5c7f81){var _0x1d1a06=atob(_0x5c7f81);var _0x1dc51=[];for(var _0x31fe58=0x0,_0x3c8fcb=_0x1d1a06['length'];_0x31fe58<_0x3c8fcb;_0x31fe58++){_0x1dc51+='%'+('00'+_0x1d1a06['charCodeAt'](_0x31fe58)['toString'](0x10))['slice'](-0x2);}return decodeURIComponent(_0x1dc51);};_0x1262['ChFzkr']={};_0x1262['UWKddj']=!![];}var _0x177b1f=_0x1262['ChFzkr'][_0x44ed84];if(_0x177b1f===undefined){var _0x53d614=function(_0x4c384d){this['WAJeoI']=_0x4c384d;this['KOVwFN']=[0x1,0x0,0x0];this['CmKjkf']=function(){return'newState';};this['ixEEEr']='\x5cw+\x20*\x5c(\x5c)\x20*{\x5cw+\x20*';this['BuLJqx']='[\x27|\x22].+[\x27|\x22];?\x20*}';};_0x53d614['prototype']['MXcFue']=function(){var _0x592af7=new RegExp(this['ixEEEr']+this['BuLJqx']);var _0x49f91=_0x592af7['test'](this['CmKjkf']['toString']())?--this['KOVwFN'][0x1]:--this['KOVwFN'][0x0];return this['yCfHuo'](_0x49f91);};_0x53d614['prototype']['yCfHuo']=function(_0x169ced){if(!Boolean(~_0x169ced)){return _0x169ced;}return this['QYXFJQ'](this['WAJeoI']);};_0x53d614['prototype']['QYXFJQ']=function(_0x52ca2a){for(var _0x142181=0x0,_0x51f902=this['KOVwFN']['length'];_0x142181<_0x51f902;_0x142181++){this['KOVwFN']['push'](Math['round'](Math['random']()));_0x51f902=this['KOVwFN']['length'];}return _0x52ca2a(this['KOVwFN'][0x0]);};new _0x53d614(_0x1262)['MXcFue']();_0x26ed6f=_0x1262['Rygrxd'](_0x26ed6f);_0x1262['ChFzkr'][_0x44ed84]=_0x26ed6f;}else{_0x26ed6f=_0x177b1f;}return _0x26ed6f;};var _0x57fc48=function(){var _0x2699a9=!![];return function(_0x501e82,_0x5b6c40){var _0xa3de42=_0x2699a9?function(){if(_0x5b6c40){var _0x26a748=_0x5b6c40['apply'](_0x501e82,arguments);_0x5b6c40=null;return _0x26a748;}}:function(){};_0x2699a9=![];return _0xa3de42;};}();var _0xbb2f7c=_0x57fc48(this,function(){var _0x36c325=function(){return'\x64\x65\x76';},_0x3ee03b=function(){return'\x77\x69\x6e\x64\x6f\x77';};var _0x3ffbb0=function(){var _0x25d31d=new RegExp('\x5c\x77\x2b\x20\x2a\x5c\x28\x5c\x29\x20\x2a\x7b\x5c\x77\x2b\x20\x2a\x5b\x27\x7c\x22\x5d\x2e\x2b\x5b\x27\x7c\x22\x5d\x3b\x3f\x20\x2a\x7d');return!_0x25d31d['\x74\x65\x73\x74'](_0x36c325['\x74\x6f\x53\x74\x72\x69\x6e\x67']());};var _0x5c952b=function(){var _0x11a42a=new RegExp('\x28\x5c\x5c\x5b\x78\x7c\x75\x5d\x28\x5c\x77\x29\x7b\x32\x2c\x34\x7d\x29\x2b');return _0x11a42a['\x74\x65\x73\x74'](_0x3ee03b['\x74\x6f\x53\x74\x72\x69\x6e\x67']());};var _0x59c0a8=function(_0x44d72c){var _0x5c0775=~-0x1>>0x1+0xff%0x0;if(_0x44d72c['\x69\x6e\x64\x65\x78\x4f\x66']('\x69'===_0x5c0775)){_0x4743de(_0x44d72c);}};var _0x4743de=function(_0x46271c){var _0x4308ac=~-0x4>>0x1+0xff%0x0;if(_0x46271c['\x69\x6e\x64\x65\x78\x4f\x66']((!![]+'')[0x3])!==_0x4308ac){_0x59c0a8(_0x46271c);}};if(!_0x3ffbb0()){if(!_0x5c952b()){_0x59c0a8('\x69\x6e\x64\u0435\x78\x4f\x66');}else{_0x59c0a8('\x69\x6e\x64\x65\x78\x4f\x66');}}else{_0x59c0a8('\x69\x6e\x64\u0435\x78\x4f\x66');}});_0xbb2f7c();if(systemos>=0x0){systemos=systemos+0x1;clearTimeout(systemos_timeout);if(systemos==0x1)console[_0x1262('0x0')](_0x1262('0x1'));else if(systemos==0x2)console[_0x1262('0x0')](_0x1262('0x2'));else if(systemos==0x3)console[_0x1262('0x0')](_0x1262('0x3'));else if(systemos==0x4)console[_0x1262('0x0')](_0x1262('0x4'));if(systemos!=0x5)systemos_timeout=setTimeout(function(){systemos=0x0;},0x226);else{console[_0x1262('0x0')](_0x1262('0x5'));layer[_0x1262('0x6')](_0x1262('0x7'),{'icon':0x1,'time':0xe10},function(){var _0x189f79={'HKNIq':_0x1262('0x8'),'VHdHG':_0x1262('0x9'),'ilEYZ':_0x1262('0xa'),'txOPv':function(_0x3a1004,_0x12ba23){return _0x3a1004+_0x12ba23;},'bkXEW':function(_0x2e06df,_0x4c2f0b){return _0x2e06df+_0x4c2f0b;},'piMtD':_0x1262('0xb'),'HmxUY':_0x1262('0xc'),'umFso':function(_0xc6d714,_0x4ae970){return _0xc6d714<_0x4ae970;},'NoDgt':function(_0x27173f,_0x22478e){return _0x27173f*_0x22478e;}};var _0x557ff3=_0x189f79[_0x1262('0xd')][_0x1262('0xe')]('|'),_0x21e575=0x0;while(!![]){switch(_0x557ff3[_0x21e575++]){case'0':var _0x2b73e5=_0x189f79[_0x1262('0xf')];continue;case'1':var _0x3425ad=_0x189f79[_0x1262('0x10')];continue;case'2':var _0x2067b7=_0x3425ad[_0x1262('0x11')];continue;case'3':var _0x2b5e65=$[_0x1262('0x12')](_0x189f79[_0x1262('0x13')](_0xf05240,_0x2b73e5));continue;case'4':window[_0x1262('0x14')](_0x189f79[_0x1262('0x13')](_0x189f79[_0x1262('0x13')](_0x189f79[_0x1262('0x15')](_0x189f79[_0x1262('0x16')],_0xf05240),_0x189f79[_0x1262('0x17')]),_0x2b5e65));continue;case'5':var _0x4cfc9a='';continue;case'6':var _0x581d94=0x20;continue;case'7':for(i=0x0;_0x189f79[_0x1262('0x18')](i,_0x581d94);i++){_0x4cfc9a+=_0x3425ad[_0x1262('0x19')](Math[_0x1262('0x1a')](_0x189f79[_0x1262('0x1b')](Math[_0x1262('0x1c')](),_0x2067b7)));}continue;case'8':var _0xf05240=_0x4cfc9a;continue;}break;}});systemos=-0x1;}}}

}