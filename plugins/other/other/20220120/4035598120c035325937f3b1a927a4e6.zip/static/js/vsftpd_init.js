    //第一次打开窗口时调用
    vsftpd.PageLoad('index');
    vsftpd.CheckInstall();