#!/bin/bash
PATH=/www/server/panel/pyenv/bin:/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH

#配置插件安装目录
install_path=/www/server/panel/plugin/bt_vsftpd

#安装
Install()
{
	
	echo '正在安装...'
	#==================================================================
	#依赖安装开始

  echo "安装环境中，请稍候 ....."
  # centos7 安装方案
  yum install -y pam-devel db4-utils db4 vsftpd
  # 新增centos8 的兼容安装方案
  dbf install -y pam-devel vsftpd
  # ubuntu 等其他系统的安装方案
  sudo apt-get  -y install vsftpd db-util



  echo "开始配置 vsftpd"
  # 创建配置文件 目录
  cd $install_path && mkdir conf/ && mkdir log/
  mkdir data/ && mkdir data/diskimg
  cd conf/
  mkdir openssl
  # 下载默认配置文件
  wget https://download.szhcloud.cn/conf/vsftpd.conf -O vsftpd.conf
  wget https://download.szhcloud.cn/conf/vsftpd_default.conf -O vsftpd_default.conf
  ln -s  /usr/local/sbin/vsftpd $install_path/vsftpd


  # 下载pam 配置文件
  rm -rf vsftpd.pam
  wget https://download.szhcloud.cn/conf/vsftpd.pam
  rm -rf /etc/pam.d/vsftpd && mv vsftpd.pam /etc/pam.d/vsftpd

  # 下载 service 文件
  mv  /lib/systemd/system/vsftpd.service /lib/systemd/system/vsftpd.service.bak
  wget https://download.szhcloud.cn/conf/vsftpd.service && mv vsftpd.service /lib/systemd/system/vsftpd.service
  # 重新载入当前系统的配置文件
  systemctl daemon-reload

  # 新建vsftpd 的宿主用户 并下发权限
  useradd  -d /home/vsftpd-defuser -s /sbin/nologin vsftpd-defuser
  chown vsftpd-defuser:vsftpd-defuser /home/vsftpd-defuser -R


  chmod -R 777 $install_path/vsftpd
	#依赖安装结束
	#==================================================================
	echo '================================================'
	echo '安装完成'
}

#卸载
Uninstall()
{
  cp $install_path/bt_vsftpd_uninstall.py ~/bt_vsftpd_uninstall.py && python ~/bt_vsftpd_uninstall.py
  killall vsftpd
	rm -rf $install_path
	echo "卸载完成，感谢使用。再见！"

}

#操作判断
if [ "${1}" == 'install' ];then
	Install
elif [ "${1}" == 'uninstall' ];then
	Uninstall
else
	echo 'Error!';
fi
