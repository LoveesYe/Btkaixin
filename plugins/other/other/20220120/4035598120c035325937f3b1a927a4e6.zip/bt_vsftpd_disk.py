#!/usr/bin/python
# coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: sudem <sang8052@qq.com>
# +-------------------------------------------------------------------

#+--------------------------------------------------------------------
#|   bt-vsftp 基于vsftp 开发的增强功能的ftp 插件
#|   虚拟磁盘 异步挂载脚本
#+--------------------------------------------------------------------
import sys,os,json,requests,getopt
import logging,warnings
logging.basicConfig(level = logging.INFO,format = '%(asctime)s %(message)s')
logger = logging.getLogger(__name__)
warnings.filterwarnings("ignore")


#设置运行目录
os.chdir("/www/server/panel")

#添加包引用位置并引用公共包
sys.path.append("class/")
import public


datapath = "/www/server/panel/plugin/bt_vsftpd/data/diskimg/"
diskdata = "/www/server/panel/plugin/bt_vsftpd/data/diskdata.json"
logpath = "/www/server/panel/plugin/bt_vsftpd/log/autolog.log"


def Init_VirtualDisk():
    # 创建磁盘文件
    datafile = "VDisk_" + userid + "_" + public.GetRandomString(8) + ".img"
    # 使用 dd 命令 创建文件
    os.system("dd if=/dev/zero ibs=1M count=" + disksize + " of=" + datapath + datafile)
    print ("虚拟磁盘文件[" + datapath + datafile + "] 创建成功!~")

    loopid = 0
    # 寻找可用的loop 设备
    while True:
        popen = os.popen("ls /dev | grep loop" + str(loopid))
        pdata = popen.read()
        popen.close()
        pdata = pdata.split("\n")
        if "loop" + str(loopid) == pdata[0]:
            loopid = loopid + 1
        else:
            break
    loop = "loop" + str(loopid)
    # 对磁盘进行关联
    os.system("losetup /dev/"+loop + " "+datapath + datafile)
    print ("[/dev/"+loop +"]已经成功关联到[" +datapath + datafile +"]!~")
    # 格式化磁盘
    os.system("mkfs.ext3 /dev/"+loop)
    print ("[/dev/"+loop +"]已经成功格式化!~")
    # 挂载磁盘
    os.system("mount -t ext3 /dev/"+loop + " "+homepath)
    print ("[/dev/"+loop +"]已经成功挂载到 [" + homepath + "] 目录下!~" )
    # 设定磁盘文件 写保护
    os.system("chattr +i " + datapath + datafile)
    print("虚拟磁盘文件[" + datapath + datafile + "] 已经写保护~")

    disk = json.loads(public.ReadFile(diskdata))
    disk[userid] = {}
    disk[userid]["userid"] = userid
    disk[userid]["homepath"] = homepath
    disk[userid]["loop"] = loop
    disk[userid]["img"] = datapath +datafile
    disk[userid]["umount"] = "false"
    public.WriteFile(diskdata,json.dumps(disk))


def Del_VirtualDisk(_userid):
    disk = json.loads(public.ReadFile(diskdata))
    print (disk)
    vdisk = disk[_userid]
    # 尝试直接卸载磁盘
    popen = os.popen("umount " + vdisk["homepath"])
    pdata = popen.read()
    popen.close()
    pdata = pdata.split("\n")
    if  pdata[0] != "" and  pdata[0] != "umount " + vdisk["homepath"]+": not mounted":
        print ("[Warning]磁盘["+vdisk["homepath"]+"]卸载失败,服务器重启后将磁盘将再次尝试卸载")
        disk[_userid]["umount"] = "true"
    else:
        os.system("rm -rf " + vdisk["homepath"])
        print("[Warning]磁盘["+vdisk["homepath"]+"]卸载成功")
        disk.pop(_userid)

    # 卸载 loop 设备
    os.system("losetup -d /dev/"+vdisk["loop"])
    # 取消磁盘写保护操作
    os.system("chattr -i "+vdisk["img"])
    # 删除镜像文件
    os.system("rm -rf "+vdisk["img"])
    public.WriteFile(diskdata,json.dumps(disk))


# 系统重启时自动挂载磁盘,
def Auto_RmMountDisk():
    disk = json.loads(public.ReadFile(diskdata))
    for vdiskid in disk:
        vdisk = disk[vdiskid]
        # 尝试重新卸载磁盘
        if vdisk["umount"] == "true":
            # 取消文件写保护
            os.system("chattr -i " + vdisk["img"])
            _userid = vdisk["userid"]
            popen = os.popen("umount " + vdisk["homepath"])
            pdata = popen.read()
            popen.close()
            pdata = pdata.split("\n")
            if pdata[0] != "" and pdata[0] != "umount " + vdisk["homepath"] + ": not mounted":
                print("[Warning]磁盘[" + vdisk["homepath"] + "]卸载失败,服务器重启后将磁盘将再次尝试卸载")
                disk[_userid]["umount"] = "true"
            else:
                print("[Warning]磁盘[" + vdisk["homepath"] + "]卸载成功")
                os.system("rm -rf " + vdisk["homepath"])
                disk.pop(_userid)
                public.WriteFile(diskdata, json.dumps(disk))
            # 重新挂载磁盘
        else:
            homepath = vdisk["homepath"]
            loopid = 0
            # 寻找可用的loop 设备
            while True:
                popen = os.popen("ls /dev | grep loop" + str(loopid))
                pdata = popen.read()
                popen.close()
                pdata = pdata.split("\n")
                if "loop" + str(loopid) == pdata[0]:
                    loopid = loopid + 1
                else:
                    break
            loop = "loop" + str(loopid)
            # 取消文件写保护
            os.system("chattr -i " + vdisk["img"])
            # 初始化虚拟设备
            os.system("losetup /dev/" + loop + " " + vdisk["img"])
            # 挂载磁盘
            os.system("mount -t ext3 /dev/" + loop + " " + homepath)
            # 启用文件写保护
            os.system("chattr +i " + vdisk["img"])
    print("自动挂载/卸载指令执行成功！~")
    globalconfig = json.loads(public.ReadFile("/www/server/panel/plugin/bt_vsftpd/conf/vsftpd.json"))
    uuid = public.md5(globalconfig["uuid"] + public.format_date())
    if os.path.exists(logpath):
        log = public.ReadFile(logpath)
    else:
        log = ""
    log = log + "\n" + json.dumps(
        {"logtime": public.format_date(), "uuid": uuid, "msg": "Start Mount or Unmount Task Success"})
    public.WriteFile(logpath, log)


def Print_Error():
    print('BT-Vsftpd Plugin Virtual Disk Shell , Data Is Very Important For EveryBody ,Please Don\'T Run This Shell By YouSelf To Void Data Lost')
    sys.exit(2)



if __name__ == '__main__':
    argv = sys.argv[1:]
    userid = False
    disksize = False
    homepath = False
    mode = False
    if not os.path.exists(diskdata):
        public.WriteFile(diskdata,"{}")
    try:
        opts, args = getopt.getopt(argv, "hu:s:m:p:")
    except getopt.GetoptError:
        Print_Error()
    for opt, arg in opts:
        if opt == "-h":
            Print_Error()
        elif opt == '-u':
            userid = arg
        elif opt == '-s':
            disksize = arg
        elif opt == "-m":
            mode = arg
        elif opt == "-p":
            homepath = arg
    if mode == "init" and userid and disksize and homepath:
        Init_VirtualDisk()
    elif mode == "del" and userid:
        Del_VirtualDisk(userid)
    elif mode == "auto":
        Auto_RmMountDisk()
    else:
        Print_Error()
















