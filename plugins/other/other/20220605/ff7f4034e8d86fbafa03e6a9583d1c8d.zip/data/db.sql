DROP TABLE IF EXISTS `access_log`;
CREATE TABLE `access_log` (
  `id` int(11) NOT NULL,
  `host` varchar(255) DEFAULT NULL,
  `remote_addr` varchar(255) DEFAULT NULL,
  `remote_user` varchar(255) DEFAULT NULL,
  `time_local` int(11) DEFAULT NULL,
  `request` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `body_bytes_sent` varchar(255) DEFAULT NULL,
  `http_user_agent` varchar(1000) DEFAULT NULL,
  `http_referer` varchar(1000) DEFAULT NULL,
  `ua_type` varchar(255) DEFAULT NULL,
  `http_x_forwarded_for` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `protocol` varchar(255) DEFAULT NULL,
  `method` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

DROP TABLE IF EXISTS `bot`;
CREATE TABLE `bot` (
  `id` int(11) NOT NULL,
  `name` varchar(30) DEFAULT NULL,
  `alias` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

INSERT INTO `bot`(`id`, `name`, `alias`) VALUES (1, 'Baiduspider', '百度');
INSERT INTO `bot`(`id`, `name`, `alias`) VALUES (2, 'bingbot', '必应');
INSERT INTO `bot`(`id`, `name`, `alias`) VALUES (3, 'YisouSpider', '神马');
INSERT INTO `bot`(`id`, `name`, `alias`) VALUES (4, '360Spider', '360搜索');
INSERT INTO `bot`(`id`, `name`, `alias`) VALUES (5, 'PetalBot', '华为搜索');
INSERT INTO `bot`(`id`, `name`, `alias`) VALUES (6, 'Googlebot', '谷歌');
INSERT INTO `bot`(`id`, `name`, `alias`) VALUES (7, 'Applebot', 'Applebot');
INSERT INTO `bot`(`id`, `name`, `alias`) VALUES (8, 'SemrushBot', 'SemrushBot');
INSERT INTO `bot`(`id`, `name`, `alias`) VALUES (9, 'YandexBot', 'YandexBot');
INSERT INTO `bot`(`id`, `name`, `alias`) VALUES (10, 'AhrefsBot', 'AhrefsBot');

DROP TABLE IF EXISTS `web`;
CREATE TABLE `web` (
  `id` int(11) NOT NULL,
  `host` varchar(80) DEFAULT NULL,
  `path` varchar(80) DEFAULT NULL,
  `log_path` varchar(80) DEFAULT NULL,
  `error_log_path` varchar(80) DEFAULT NULL,
  `create_time` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;


ALTER TABLE `access_log`
  ADD PRIMARY KEY (`id`) USING BTREE;

ALTER TABLE `bot`
  ADD PRIMARY KEY (`id`) USING BTREE;

ALTER TABLE `web`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD UNIQUE KEY `web_id_uindex` (`id`) USING BTREE;


ALTER TABLE `access_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `bot`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

ALTER TABLE `web`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;