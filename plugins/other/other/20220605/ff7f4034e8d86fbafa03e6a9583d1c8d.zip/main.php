<?php
require 'vendor/autoload.php';
require 'lib/Time.php';

use think\facade\Db;
use lib\Time;
use UAParser\Parser;
use wenhainan\filecache;
use itbdw\Ip\IpLocation;
define('PLUGIN_PATH',__DIR__);
define('PLU_PATH',__DIR__);
define('RUNTIME_DIR',__DIR__.'/runtime');
define('BR',PHP_EOL);
define('DS',DIRECTORY_SEPARATOR);
define('CRON_TITLE','[熊猫日志任务]');
function get_config()
{
   return include 'config.php';
}
function cache($k,$v = '',$expire = 180){
    $option = [
        'path'=>RUNTIME_DIR,
        'expire'=>1800
    ];
    $cache = new filecache($option);
    if(empty($v)){
        return  $cache->get($k);
    }
    return $cache->set($k,$v,$expire);
}
function get_os(){
    if(PHP_OS == 'WIN32' || PHP_OS == 'WINNT' || PHP_OS == 'Windows'){
        $os = 'windows';
    }else{
        $os = 'linux';
    }
    return $os;
}
function get_php_version(){
    $arr = [
        '71',
        '72',
        '73',
        '74',
        '80'
    ];
    $php_version = '';
    foreach ($arr as $v){
        $cc = PLU_PATH.'/php_cli_'.$v.'.ini';
        if(file_exists($cc)){
            $php_version  =  $v;
            break;
        }
    }
    if(empty($php_version)){
        throw new Exception('请安装php>=7.1');
    }
    return $php_version;
}
function is_cli(){
    return preg_match("/cli/i", php_sapi_name()) ? true : false;
}
function get_real_path(){
    $arr = [
        '71',
        '72',
        '73',
        '74',
        '80'
    ];
    $php_version = '';
    foreach ($arr as $v){
        $cc = PLU_PATH.'/php_cli_'.$v.'.ini';
        if(file_exists($cc)){
            $php_version  =  $v;
            break;
        }
    }
    if(empty($php_version)){
        Json::error('请安装php>=7.1+');
    }
    $os = get_os();
    if($os == 'linux'){
        $php_path = PLU_PATH."/../../../php/$php_version/bin/php";
    }else{
        $php_path = PLU_PATH."/../../../php/$php_version/php.exe";
    }

    return realpath($php_path);
}
function lotus_split_sql($file)
{
    if (file_exists($file)) {
        //读取SQL文件
        $sql = file_get_contents($file);
        $sql = str_replace("\r", "\n", $sql);
        $sql = str_replace("BEGIN;\n", '', $sql);//兼容 navicat 导出的 insert 语句
        $sql = str_replace("COMMIT;\n", '', $sql);//兼容 navicat 导出的 insert 语句
//        $sql = str_replace($defaultCharset, $charset, $sql);
        $sql = trim($sql);
//        //替换表前缀
//        $sql  = str_replace(" `{$defaultTablePre}", " `{$tablePre}", $sql);
        $sqls = explode(";\n", $sql);
        return $sqls;
    }

    return [];
}
function brower_list()
{
    $arr = [
        'Chrome',
        'Chrome Mobile',
        'Chrome Mobile WebView',
        'Chrome Mobile iOS',
        'Edge',
        'Edge Mobile',
        'Firefox',
        'Firefox Mobile',
        'Safari',
        'Mobile Safari',
        'MiuiBrowser',
        'QQ Browser',
        'QQ Browser Mobile',
        'Sogou Explorer',
        'IE',
        'UC Browser',
        'Samsung Internet',
        'webOS Browser',
        'Vivaldi',
        'Vivaldi Mobile',
        'Opera',
        'Opera Mobile',
        'BingPreview'
    ];
    return $arr;
}
/**
 * 获取PHP Version.
 *
 * @return string
 */
function GetPHPVersion()
{
    $p = phpversion();
    if (strpos($p, '-') !== false) {
        $p = substr($p, 0, strpos($p, '-'));
    }

    return $p;
}
function get_location($ip)
{
    $obj = IpLocation::getLocation($ip);
    return $obj['country'].$obj['province'].$obj['city'];
}
function exec_enabled() {
    if(function_exists('exec')) {
        return true;
    }
    return false;
}
class main {
    const  BOT = [
        'Baiduspider',
        'bingbot',
        'Sogou web spider',
        'YandexBot',
        'PetalBot',
        'Googlebot',
        'AhrefsBot',
        'Applebot',
        'SemrushBot'
    ];
    public function __construct()
    {
        @chmod(PLUGIN_PATH.'/config',0777);
        @chmod(PLUGIN_PATH.'/static',0777);
        @chmod(PLUGIN_PATH.'/runtime',0777);
        $config = include PLUGIN_PATH.'/config/database.php';
        Db::setConfig($config);
    }
    public function webserver()
    {
        $webserver = realpath(__DIR__."/../../../apache");
        return file_exists($webserver)?'apache':'nginx';
    }
    public function get_bt_site()
    {
        $web = Db::connect('bt_db')
            ->table('sites')
            ->alias('a')
            ->join('domain b','a.id = b.pid')
            ->field('b.name as host,a.path')
            ->where('status',1)
            ->select()
            ->toArray();
        return $web;
    }
    public function get_bt_db()
    {
        return Db::connect('bt_db');
    }
    public function sync_web($db = 'plugin_db')
    {
        $bt_web = $this->get_bt_site();
        //Db::startTrans();
        $tmp = [];
        foreach ($bt_web as $v){
            $res = Db::connect($db)->table('web')->where('host',$v['host'])->find();
            $host = $v['host'];
            $ext1 = '';
            $ext2 = '';
            $webserver = $this->webserver();
            if( $webserver == 'nginx'){
                $ext1 = $host.'.log';
                $ext2 = $host.'.error.log';
            }
            if($webserver == 'apache'){
                if(get_os() == 'linux' ){
                    $ext1 = $host.'-access_log';
                    $ext2 = $host.'-error_log';
                }else{
                    $ext1 = $host.'-access.log';
                    $ext2 = $host.'-error.log';
                }
            }

            if( get_os() == 'linux'){
                $v['log_path'] = "./../../../../wwwlogs/".$ext1;
                $v['error_log_path'] = "./../../../../wwwlogs/".$ext2;
            }else{
                $v['log_path'] = "./../../../wwwlogs/".$ext1;
                $v['error_log_path'] = "./../../../wwwlogs/".$ext2;
            }
            $v['log_path'] = realpath($v['log_path']);
            $v['error_log_path'] = realpath($v['error_log_path']);
            if(empty($res)
                && file_exists($v['log_path'])
            ){
                $v['create_time'] = time();
                $tmp[] = $v;
            }
        }
        Db::connect($db)->table('web')
            ->limit(50)
            ->insertAll($tmp);
        //Db::commit();
    }
    function get_os(){
        if(PHP_OS == 'WIN32' || PHP_OS == 'WINNT' || PHP_OS == 'Windows'){
            $os = 'windows';
        }else{
            $os = 'linux';
        }
        return $os;
    }
    function get_php_version(){
        $arr = [
            '71',
            '72',
            '73',
            '74',
            '80'
        ];
        $php_version = '';
        foreach ($arr as $v){
            $cc = PLUGIN_PATH.'/php_cli_'.$v.'.ini';
            if(file_exists($cc)){
                $php_version  =  $v;
                break;
            }
        }
        if(empty($php_version)){
            throw new Exception('请安装php>=7.1');
        }
        return $php_version;
    }
    function is_cli(){
        return preg_match("/cli/i", php_sapi_name()) ? true : false;
    }
    function get_info(){
        $sm =  file_get_contents(__DIR__.'/static/sm');
        $sm = intval($sm);
        if($sm<time() && $sm !== 0 ){
            $txt = file_get_contents(__DIR__.'/static/ms');
            echo base64_decode($txt);exit;
        }
    }
    public function get_web_config($host)
    {
        return Db::table('web')->where('host',$host)->find();
    }
    public function get_log_path($host)
    {
        return Db::table('web')->where('host',$host)->value('log_path');
    }
    function sync_one_web_log($name,$line = 180){
        @ini_set('memory_limit', '512M');
        $web = $this->get_web_config($name);
        $filename = $web['log_path'];
        try{
            $arr = $this->tail_log($filename,$line);
        }catch (\Exception $e){
            return $e->getMessage();
        }
        //Db::startTrans();
        $this->insert_log($name,$arr);
        //Db::commit();
        return true;
    }

    /**
     * @param $name
     * @param $arr
     * @throws \UAParser\Exception\FileNotFoundException
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\DbException
     * @throws \think\db\exception\ModelNotFoundException
     */
    function  insert_log($name,$arr)
    {
        $reg = '/^(\d{1,3}.\d{1,3}.\d{1,3}.\d{1,3})\s-\s(.*)\s\[(.*)\]\s"(.*)\"\s(\d{3})\s(\d+)\s"(.*)"\s\"(.*)\"(.*)$/u';
        $tmp = [];
        //Db::startTrans();
        foreach ($arr as $v){
            preg_match($reg,$v,$a_match);
            $parser = Parser::create();
            $ua = $a_match[8];
            $result = $parser->parse($ua);
            $ua_type = $result->ua->family;
            $req_arr = explode(" ",$a_match[4]);
            $location = get_location($a_match[1]);
            $insert_data = [
                "host"=>$name,
                'remote_addr'=>$a_match[1],
                'remote_user'=>$a_match[2],
                'time_local'=>strtotime($a_match[3]),
                'request'=>$a_match[4],
                'status'=>$a_match[5],
                'body_bytes_sent'=>$a_match[6],
                'http_user_agent'=>$a_match[8],
                'http_referer'=>$a_match[7],
                'ua_type'=>$ua_type,
                'method'=>$req_arr[0],
                'url'=>$req_arr[1],
                'protocol'=>$req_arr[2],
                'location'=>$location
                //                'http_x_forwarded_for'=>$a_match[8]
            ];
            $sd = Db::table('access_log')->where([
                'time_local'=>$insert_data['time_local'],
                'host'=>$insert_data['host']
            ])->find();
            $juge_post = $this->juge_post($a_match[4]);
            if(!empty($a_match) && empty($sd) && $juge_post ){
                $tmp[] =  $insert_data;
            }
            if(!empty($sd)){
                break;
            }
        }
        $db_config = include PLUGIN_PATH.'/config/database.php';
        $limit = ($db_config['default'] == 'mysql')?300:50;
        Db::table('access_log')
            ->limit($limit)
            ->insertAll($tmp);
        //Db::commit();
    }
    function juge_post($str)
    {
        $arr = [
            '.css',
            '.js',
            '.png',
            '.jpg',
            '.jpeg',
            '.webp',
            '.json',
            '.woff',
            '.ico',
            '.gif',
            '.bmp',
            '.swf',
            'timthumb.php',
            'wp-cron.php',
            'favicon.ico',
            '.woff',
            'null'
        ];
        foreach ($arr as $v){
            if(preg_match("/$v/",$str)){
                return false;
            }
        }
        return true;
    }
    function tail_log($filename,$n)
    {
        $err_msg = 'no file';
        if(PHP_SAPI == 'cli'){
            $err_msg = "对应日志文件不存在!";
        }
        if(!file_exists($filename)){
            throw new Exception($err_msg);
        }
        $cmd = <<<EOF
tail -n $n $filename
EOF;
        $cmd = escapeshellcmd($cmd);
        try{
            $os = $this->get_os();
            if($os == 'windows'){
                $res = $this->read_file($filename,$n);
            }else{
                @exec($cmd,$res);
            }
        }catch (\Exception $e){
            return $e->getMessage();
        }
        return $res;
    }
    function read_file($file, $lines)
    {
        $handle = fopen($file, "r+");
        $linecounter = $lines;
        $pos = -2;
        $beginning = false;
        $text = array();
        while ($linecounter > 0) {
            $t = " ";
            while ($t != "\n") {
                if(fseek($handle, $pos, SEEK_END) == -1) {
                    $beginning = true; break;
                }
                $t = fgetc($handle);
                $pos --;
            }
            $linecounter --;
            if($beginning) rewind($handle);
            $text[$lines-$linecounter-1] = fgets($handle);
            if($beginning) break;
        }
        //cache('pos'.$file,$pos);
        fclose ($handle);
        return array_reverse($text);
    }
}
function get_info(){
    $sm =  file_get_contents(__DIR__.'/static/sm');
    $sm = intval($sm);
    if($sm<time() && $sm !== 0 ){
        $txt = file_get_contents(__DIR__.'/static/ms');
        echo base64_decode($txt);exit;
    }
}
class Json {
    /**
     * @param string $msg
     * @param array  $data
     */
    static function success($msg  = 'success',array $data = [])
    {
        $data = [
            'code'=>0,
            'msg'=>$msg,
            'data'=>$data
        ];
        echo json_encode($data);exit;
    }
    /**
     * @param string $msg
     */
    static function error($msg = 'error',$code = 1)
    {
        $data = [
            'code'=>$code,
            'msg'=>$msg
        ];
        echo json_encode($data);exit;
    }
}
//class LogModel extends think\Model
//{
//    protected $table = 'access_log';
//    protected $createTime = 'time_local';
//    function  getTimeLocalTextAttr()
//    {
//        return date('m-d H:i:s',$this->getData('time_local'));
//    }
//}
