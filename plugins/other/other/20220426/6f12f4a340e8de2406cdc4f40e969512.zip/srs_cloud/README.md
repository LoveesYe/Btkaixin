# SRS Plugin for BT

To create a plugin for [BT](https://bt.cn).

## Usage

To create a `srs_cloud.zip` by:

```bash
bash auto/zip.sh
```

Upload the zip to BT panel, and install SRS.

