#!/bin/bash
PATH=/www/server/panel/pyenv/bin:/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH

#配置插件安装目录
plugname=""
install_path=$(cd "$(dirname "$0")"; pwd)
pannelpath=$(cd "../../"; pwd)
server=$(cd "../../../"; pwd)
ico_path=$pannelpath/BTPanel/static/img/soft_ico/ico-${plugname}.png


_pubval=""
Config()
{
	_key=$1
	if [ "${_key}" == '' ];then 
		return -1
	fi
	FILE_PATH=$install_path/info.json
	_pubval=$(cat $FILE_PATH|grep -Po $_key'[" :]+\K[^"]+')
	return 0
}

#安装
Install()
{
	
	echo '正在安装...'
	# pip install subprocess
	#==================================================================
	#依赖安装开始
	cp $install_path/icon.png $ico_path
	chmod -R +x *
	if [ ! -d "$apppath" ]; then
		echo "创建服务目录"
		mkdir "$apppath"
	fi
	cfg=$apppath/config.cfg.json
	cfgbak=$apppath/config.cfg.bak
    if [ -f "$cfg" ]; then
		echo "备份配置文件$cfg"
		mv $cfg $cfgbak
	fi
	cp -r ./_dist/* $apppath -f
	if [ -f "$cfbbak" ]; then
		echo "恢复配置文件$cfg"
		mv $cfgbak $cfg
	fi
	cd $apppath
	rm -f $apppath/config.cfg.bak

	if [ -d /etc/init.d/$plugname ]; then
		/etc/init.d/$plugname stop
	fi
	echo "安装服务$plugname"
	$apppath/server-linux install $plugname
	cd $install_path
	echo "安装到"$apppath
	ls $apppath
	#依赖安装结束
	#==================================================================
	echo '================================================'
	echo '安装完成'
}

#卸载
Uninstall()
{
	
	if [ -d /etc/init.d/$plugname ]; then
		/etc/init.d/$plugname stop
		cd $apppath
		$apppath/server-linux uninstall $plugname
		rm -rf /etc/init.d/$plugname
	fi
	# rm -rf $install_path
}


Init()
{
	echo '================================================'
	Config 'title'
	echo "插件名称：$_pubval "
	Config 'ps'
	echo "用途：$_pubval" 
	Config 'name' 
	plugname=$_pubval
	apppath=$server/$plugname
	echo "服务名称:$plugname"

	Config 'versions'
	echo "版本：$_pubval" 

	Config 'author'
	echo "作者：$_pubval" 
	
	echo "安装路径：$apppath"
	echo '================================================'
}

if [ ! "${1}" == '' ];then
	Init
fi
#操作判断
if [ "${1}" == 'install' ];then
	Install
elif [ "${1}" == 'uninstall' ];then

	Uninstall
else 
	echo 'Error!';
fi
