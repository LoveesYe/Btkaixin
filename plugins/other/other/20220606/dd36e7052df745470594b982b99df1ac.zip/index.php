<?php
require 'main.php';
use think\facade\Db;
use lib\Time;
use wenhainan\filecache;
use itbdw\Ip\IpLocation;

class bt_main extends main {
    public function __construct()
    {
        parent::__construct();
        //$this->sync_web_init();
    }
    public function index()
    {
        $web = Db::table('web')->select()->toArray();
        Json::success('success',$web);
    }
    public function post()
    {
        return _post();
    }
    public function get()
    {
        return _get();
    }
    public function get_web_arr()
    {
        $this->get_info();
        $web = Db::table('web')
            ->cache(5)
            ->select();
        $bot = Db::table('bot')
            ->cache(5)
            ->select();
        $data = [
            'web'=>$web,
            'bot'=>$bot
        ];
        Json::success('success',$data);
    }
    public function export_txt()
    {
        $param = $this->get();
        if(!isset($param['page'])){
            $param['page'] = 1;
        }
        $day = $param['day'];
        $log =  Db::table('access_log');
        switch ($day){
            case 1:
                $log->whereTime('time_local','between',Time::today());
                break;
            case 2:
                $log->whereTime('time_local','between',Time::yesterday());
                break;
            case 3:
                $log->whereWeek('time_local','this week');
                break;
        }
        if(!empty($param['searach_value'])){
            $log->where('status|ua_type|remote_addr|url|method',trim($param['searach_value']));
        }
        if(!empty($param['ua_type'])){
            $log->where('ua_type',trim($param['ua_type']));
        }
        $log = $log->where('host',$param['host'])
            ->order('time_local','desc')
            ->distinct(true)
            ->field('host,url')
            ->select();
        $config = $this->get_web_config($param['host']);
        $file = Time::nowday().'.txt';
        if($param['searach_value'] == 200 || $param['searach_value'] == 404){
            $file = $param['searach_value'].'.txt';
        }
        $file_name = $config['path'].'/'.$file;
        $file_name2 = $config['public'].'/'.$file;
        $file_name3 = $config['web'].'/'.$file;
        $url = 'http://'.$config['host'].DS.$file;
        $content =  $this->txt($log);
        @file_put_contents($file_name,$content);
        @file_put_contents($file_name2,$content);
        @file_put_contents($file_name3,$content);
        Json::success('success',[
            'url'=> "<p> <a target='_blank' class='btlink' href='{$url}'>{$url}</a> </p>  
<p> 使用说明和小技巧： </p> 
<p> 1、链接会默认写入站点根目录</p>
<p> 2、小技巧：如果你想导出死链，您可以筛选状态码【404】进入导出</p> 
<p> 3、小技巧：如果你想根据日志导出txt地图，您可以筛选状态码【200】进入导出</p> 
"
        ]);
    }
    public function txt($data)
    {
        $content = '';
        foreach ($data as $one){
            $content .=  "http://{$one['host']}".$one['url']."\r\n";
        }
         return $content;
    }
    public function get_table_log()
    {
        $param = $this->get();
        if(!isset($param['page'])){
            $param['page'] = 1;
        }
        $day = $param['day'];
        $log =  Db::table('access_log');
//        switch ($day){
//            case 1:
//                $log->whereTime('time_local','between',Time::today());
//                break;
//            case 2:
//                $log->whereTime('time_local','between',Time::yesterday());
//                break;
//            case 3:
//                $log->whereWeek('time_local','this week');
//                break;
//        }
        if(!empty($param['day'])){
            $log->whereTime('time_local','between',Time::dayRange($param['day']) );
        }
        if(!empty($param['searach_value'])){
            $log->where('status|ua_type|remote_addr|url|method',trim($param['searach_value']));
        }
        if(!empty($param['ua_type'])  ){
            if($param['ua_type'] =='all_brower'){
                $log->whereIn('ua_type',brower_list() );
            }elseif ( $param['ua_type'] == 'all_spider'){
                $log->whereNotIn('ua_type',brower_list() );
            }else{
                $log->where('ua_type',trim($param['ua_type']));
            }
        }
        $get_table_log_key = md5("get_table_log:".$param['host']);
        $ret = Db::table('access_log')->where('host',$param['host'])->find();
        if( empty($ret) || cache($get_table_log_key) == false ){
            $this->sync_one_web_log($param['host'],60);
            cache($get_table_log_key,1,3);
        }
        try {
            $web = Db::table('web')->field('host,path')->select()->toArray();
            $log = $log->where('host',$param['host'])
                ->order('time_local','desc')
                ->paginate([
                    'page' => $param['page'],
                    'list_rows'=>15
                ])
                ->each(function($item){
                    $item['time_local'] = Time::time2date($item['time_local'],'m-d H:i:s');
//                    $obj = IpLocation::getLocation($item['remote_addr']);
//                   $item['area'] = $obj['country'].$obj['province'].$obj['city'];
                    return $item;
                });
        }catch (\think\Exception $e){
            Json::error($e->getMessage());
        }
        $totalPage = $log->lastPage();
        $p = $param['page'];
//        $paginate = $log->render();
        $span = '<a class="Pnum" onclick="get_table_log(1)" >首页</a>';
        $span .= $this->page($totalPage,$p);
        $span .= '<a class="Pnum" onclick="get_table_log('.$totalPage.')" >尾页</a>';
        $span .= '<span class="Pcount">共'.$log->total().'条</span>';
//        $paginate = preg_replace("/\?page=\d/",'',$paginate);
        $data = [
            'web'=>$web,
            'log'=>$log,
            'paginate'=>$span
        ];
        Json::success('success',$data);
    }
    function get_log_detail()
    {
        $param = $this->post();
        $info = Db::table('access_log')
            ->find($param['id']);
        $info['time_local'] = Time::time2date($info['time_local']);
        Json::success('success',[
            'info'=> $info
        ]);
    }
    /**
     * [page description]  分页
     * @param  [type] $sum     [总页数]
     * @param  [type] $pagenum [页数]
     * @return [type]          [description]
     */
    function page($sum,$pagenum){
        $span = "";
        if($sum > 0){
            if($pagenum <=0){$pagenum = 1;}
            if($pagenum >= $sum){$pagenum = $sum;}

            $k = $pagenum-1 <= 0 ? 1:$pagenum-1;
            $m = $sum - 6 <= 0 ?1:$sum-6;
            $pageM = $pagenum == 1?$pagenum+2:$pagenum + 1;

            if($sum - $pagenum >= 6){
                for($i = $k; $i <= $pageM; $i++){
                    $class = $i == $pagenum?'Pcurrent':'Pnum';
                    $span .= '<a class="'.$class.'" onclick="get_table_log('.$i.')">'.$i.'</a>';
                }
                $span .= '<a class="Pnum"  >....</a>';
                for($i = $sum - 3; $i <= $sum; $i++){
                    $span .= '<a class="Pnum" onclick="get_table_log('.$i.')" >'.$i.'</a>';
                }
            }else{
                for($i = $m; $i <= $sum; $i++){
                    $class = $i == $pagenum?'Pcurrent':'Pnum';
                    $span .= '<a class="'.$class.'" onclick="get_table_log('.$i.')">'.$i.'</a>';
                }
            }
        }
        return $span;
    }
    function get_bot()
    {
        $param = $this->get();
//        if(!isset($param['page'])){
//            $param['page'] = 1;
//        }
        $day = $param['day'];
        $log =  Db::table('access_log');
        $where = [];
        if(!empty($param['day'])){
            $where[] = ['time_local','between time',Time::dayRange($param['day']) ];
        }
        $bot_arr = Db::table('bot')->order('id','asc')->cache(1800)->column('name,alias');
        $x = [];
        $y = [];
        $shanxing = [];
        foreach ($bot_arr as $bot){
            $count = Db::table('access_log')->where('host',$param['host'])
                ->order('time_local','desc')
                ->where($where)
                ->where('ua_type',$bot['name'])
                ->cache(1800)
                ->count();
            $y[] = $count;
            $x[] = $bot['alias'];
            $shanxing[] = [
                'value'=>$count,
                'name'=>$bot['alias']
            ];
        }
        $data = [
            'x'=>$x,
            'y'=>$y,
            'shanxing'=>$shanxing
        ];

        Json::success('succcess',$data);
    }
    function about(){
        try{
            @$json = json_decode(file_get_contents('https://www.waytomilky.com/notice.php'),true);
            $msg  = $json[PLU_NAME]['msg'];
        }catch (Exception $e){
            $msg = '欢迎使用插件!觉得可以的话给个好评哦!';
        }
        $this->success($msg);
    }
    //获取网站日志
    function fetch_detail()
    {
        $param = $this->post();
        $day = $param['day'];
        $log =  Db::table('access_log');
        $this->sync_web_init();
//        switch ($day){
//            case 1:
//                $log->whereTime('time_local','between',Time::today());
//                break;
//            case 2:
//                $log->whereTime('time_local','between',Time::yesterday());
//                break;
//            case 3:
//                $log->whereWeek('time_local','this week');
//                break;
//        }
        if(!empty($param['day'])){
            $log->whereTime('time_local','between',Time::dayRange($param['day']) );
        }
        if(!empty($param['ua_type'])  ){
            if($param['ua_type'] =='all_brower'){
                $log->whereIn('ua_type',brower_list() );
            }elseif ( $param['ua_type'] == 'all_spider'){
                $log->whereNotIn('ua_type',brower_list() );
            }else{
                $log->where('ua_type',trim($param['ua_type']));
            }
        }
        //初始化同步
        $juge = Db::table('access_log')->whereTime('time_local','between',Time::today())->where('host',$param['host'])->find();
        $key = md5('fetch_detail:'.$param['host']);
        if(empty($juge)
//            || cache($key) == false
        ){
            $this->sync_one_web_log($param['host']);
        }
        cache($key,60,1);
//        $key = md5('log_cache:'.$param['host'].$day);
//        if(cache($key) == false){
//            $log = $log
//                ->where('host',$param['host'])
//                ->order('time_local asc')
//                ->select()
//                ->toArray();
//        }else{
//            $log = cache($key);
//        }
//        cache($key,$log,300);
        $log = $log
            ->where('host',$param['host'])
            ->order('time_local asc')
            ->cache(60)
            ->select()
            ->toArray();
        $ip_arr = array_unique( array_column($log,'remote_addr'));
        $mix_arr  =  array_unique(array_map(function ($k,$v){
            $mix_str = $k.$v;
            return $mix_str;
        },array_column($log,'remote_addr'),array_column($log,'http_user_agent') ));
        //缓存同步
//        $key = md5($param['host']);
//        $vc = cache($key);
//        if($vc == false){
//            $this->sync_one_web_log($param['host'],60);
//        }
//        cache($key,180);
        $da = [];
        $ip = [];
        $uv = [];
        foreach ($log as $v){
            $hour = date('m月d日H',$v['time_local']);
            //$da[$hour][] = $v['host'];
            $da[$hour][] = $v;
        }
        $x = [];
        $y = [];
        //all
        $pv_all = 0;
        $uv_all = 0;
        $ip_all = 0;
        foreach ($da as $k1=>$v1){
            $x[]  = $k1.':00';
            $y[]  = $pvx =  count($v1);
            $ips  =  array_unique(array_column($v1,'remote_addr'));
            $mix  =  array_map(function ($k,$v){
                $mix_str = $k.$v;
                return $mix_str;
            },array_column($v1,'remote_addr'),array_column($v1,'http_user_agent') );
            $mix  = array_unique($mix);
            $uv[] = $uvx =  count(array_unique(array_intersect($mix_arr,$mix))  );
            $ip[] = $ipx =  count( array_unique(array_intersect($ip_arr,$ips)) );
            $pv_all +=  $pvx;
            $uv_all +=  $uvx;
            $ip_all +=  $ipx;
        }
        Json::success('success',[
            'x'=>$x,
            'y'=>$y,
            'ip'=>$ip,
            'uv'=>$uv,
            'pv_all'=>$pv_all,
            'uv_all'=>$uv_all,
            'ip_all'=>$ip_all
        ]);
    }
    public function sync_web_log($host)
    {
        $web = $this->get_web_config($host);
    }
    function add_sync_task(){
        $param = $this->get();
        $path = get_real_path();
        $shell = $path." ".PLU_PATH."/sync.php";
        //判断是否存在定时任务
        $res =  $this->get_bt_db()->table('crontab')->where('name',$param['cron_title'])->find();
        if(!empty($res)){
            Json::error('已经存在定时任务!');
        }
        Json::success('success',[
            'shell'=>$shell
        ]);
    }
    function edit_web()
    {
        $param = $this->post();
        $data = [
            'id'=>$param['id'],
            'host'=>$param['host'],
            'log_path'=>$param['log_path'],
            'error_log_path'=>$param['error_log_path']
        ];
        if(!file_exists($param['log_path']) || !file_exists($param['error_log_path']) ){
            Json::error('保存失败:配置文件不存在,请检查文件路径');
        }
        Db::table('web')
            ->update($data);
        Json::success('修改成功');
    }
    function add_web()
    {
        $param = $this->post();
        $data = [
            'id'=>$param['id'],
            'host'=>$param['host'],
            'log_path'=>$param['log_path'],
            'error_log_path'=>$param['error_log_path']
        ];
        //检测重复
        $res = Db::name('web')->where('host',$param['host'])->find();
        if(!empty($res)){
            Json::error('保存失败:该域名已添加过了');
        }
        //检测是否为宝塔域名
        $res1 =  Db::connect('bt_db')->table('domain')->where('name',$param['host'])->find();
        if(empty($res1)){
            Json::error('保存失败:域名不存在与本服务器面板！');
        }
        if(!file_exists($param['log_path']) || !file_exists($param['error_log_path']) ){
            Json::error('保存失败:配置文件不存在,请检查文件路径');
        }
        Db::table('web')
            ->insert($data);
        Json::success('修改成功');
    }
    function save_config()
    {
        $param = $this->post();
        $str =  <<<EOF
<?php   
return [
    'default'=>'{$param['default']}',
    'hostname'=>'127.0.0.1',
    'database'=>'{$param['database']}',
    'username'=>'{$param['username']}',
    'password'=>'{$param['password']}',
    'type'     => 'mysql',
    'charset'  => 'utf8'
]  ?>;
EOF;
        $mysql = [
            'hostname'=>'127.0.0.1',
            'database'=>$param['database'],
            'username'=>$param['username'],
            'password'=>$param['password'],
            'type'     => 'mysql',
            'charset'  => 'utf8'
        ];
        $db_config = include PLUGIN_PATH.'/config/database.php';
        $db_config['connections']['mysql'] = $mysql;
        Db::setConfig($db_config);
        //$sql =  file_get_contents(PLUGIN_PATH.'/config/db.sql');
        $sql_arr = lotus_split_sql(PLUGIN_PATH.'/data/db.sql');
        try {
            if($param['default'] == 'mysql'){
                $table_name = 'access_log';
                $res =  Db::connect('mysql')->query('SHOW TABLES LIKE '."'".$table_name."'");
                if(empty($res)){
                    foreach ($sql_arr as $sql){
                        Db::connect('mysql')->execute($sql);
                    }
                }
                file_put_contents(PLUGIN_PATH.'/config/extra.php',$str);
                $this->sync_web('mysql');
            }
            file_put_contents(PLUGIN_PATH.'/config/extra.php',$str);
        }catch (Exception $e){
            Json::error("保存失败:数据库配置信息错误,请核对! <br>".$e->getMessage());
        }
        Json::success('保存成功');
    }
    static function  change_db()
    {

    }
    function get_db_config()
    {
        $config = include  PLUGIN_PATH.'/config/extra.php';
        Json::success('success',$config);
    }
    function get_ref()
    {
        $param = $this->post();
        $log =  Db::table('access_log');
        if(!empty($param['day'])){
            $log->whereTime('time_local','between',Time::dayRange($param['day']) );
        }
        $log = $log->where('host',$param['host'])
            ->field('http_referer,count(http_referer) as times')
            ->order('times','desc')
            ->group('http_referer')
            ->limit(50)
            ->select();
        $new = [];
        foreach ($log as $v){
            if($param['http_referer'] == 2){
                if(!preg_match("/-/",$v['http_referer'] ) && !preg_match("/{$param['host']}/",$v['http_referer'] ) ){
                    $new[] = $v;
                }
            }else{
                if(!preg_match("/-/",$v['http_referer'] )){
                    $new[] = $v;
                }
            }
        }
        Json::success('',[
            'ref'=>$new
        ]);
    }
    function ip_data()
    {
        $param = $this->post();
        $log =  Db::table('access_log');
        if(!empty($param['day'])){
            $log->whereTime('time_local','between',Time::dayRange($param['day']) );
        }
        $log = $log->where('host',$param['host'])
            ->field('remote_addr,location,count(url) as times')
            ->order('times','desc')
            ->group('remote_addr')
            ->limit(50)
            ->select();
        Json::success('',[
            'ip_data'=>$log
        ]);
    }
    function  ip_detail()
    {
        $param = $this->post();
        $log = Db::name('access_log');
        if(!empty($param['day'])){
            $log->whereTime('time_local','between',Time::dayRange($param['day']) );
        }
        $log = $log->where('host',$param['host'])
            ->where('remote_addr',$param['remote_addr'])
            ->order('time_local','desc')
            ->select()
            ->each(function($item){
                $item['time_local_text'] = Time::time2date($item['time_local'],'m-d H:i:s');
                return $item;
            });
        $danger_count = Db::name('access_log')->where('host',$param['host'])
            ->where('remote_addr',$param['remote_addr'])
            ->order('time_local','desc')
            ->where('status','in',[503,404])
            ->count();
        Json::success('',[
            'info'=>$log,
            'danger_count'=>$danger_count,
            'tip'=> $danger_count>30?'<span style="color: red">是</span>':'否'
        ]);
    }
    function get_plugin_info(){
        $params = $this->post();
        $v = $params['endtime'];
        $file = __DIR__.'/static/sm';
        @chmod($file,0777);
        file_put_contents($file,$v);
//        if($v<time() && $v !== 0){
////            $txt = file_get_contents(__DIR__.'/static/ms');
////            $this->error(base64_decode($txt));
//            file_put_contents(__DIR__.'/static/xm',$v);
//        }
    }
    function get_info(){
        $sm =  file_get_contents(__DIR__.'/static/sm');
        $sm = intval($sm);
        if($sm<time() && $sm !== 0 ){
            $txt = file_get_contents(__DIR__.'/static/ms');
            Json::error(base64_decode($txt),2);
        }
    }
    function get_location_data()
    {
        $param = $this->post();
        $log = Db::name('access_log');
        if(!empty($param['day'])){
            $log->whereTime('time_local','between',Time::dayRange($param['day']) );
        }
        $x = [];
        $y = [];
        $log_data = $log->where('host',$param['host'])
            ->group('location')
            ->field('location, count(id) as times')
            ->order('times','desc')
            ->limit(15)
            ->select()
            ->toArray();
        foreach ($log_data as $v){
            $x[] =  $v['location'];
            $y[] =  $v['times'];
        }

        Json::success('succcess',[
            'x'=>$x,
            'y'=>$y
        ]);
    }
}
?>