SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS `access_log`;
CREATE TABLE `access_log`  (
                               `id` int(11) NOT NULL AUTO_INCREMENT,
                               `host` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
                               `remote_addr` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
                               `remote_user` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
                               `time_local` int(11) NULL DEFAULT NULL,
                               `request` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
                               `status` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
                               `body_bytes_sent` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
                               `http_user_agent` varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
                               `http_referer` varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
                               `ua_type` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
                               `http_x_forwarded_for` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
                               `url` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
                               `protocol` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
                               `method` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
                               `location` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
                               PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

DROP TABLE IF EXISTS `bot`;
CREATE TABLE `bot`  (
                        `id` int(11) NOT NULL AUTO_INCREMENT,
                        `name` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
                        `alias` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
                        PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

DROP TABLE IF EXISTS `web`;
CREATE TABLE `web`  (
                        `id` int(11) NOT NULL AUTO_INCREMENT,
                        `host` varchar(80) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
                        `path` varchar(80) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
                        `log_path` varchar(80) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
                        `error_log_path` varchar(80) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
                        `create_time` int(11) NULL DEFAULT NULL,
                        PRIMARY KEY (`id`) USING BTREE,
                        UNIQUE INDEX `web_id_uindex`(`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;


INSERT INTO `bot`(`id`, `name`, `alias`) VALUES (1, 'Baiduspider', '百度');
INSERT INTO `bot`(`id`, `name`, `alias`) VALUES (2, 'bingbot', '必应');
INSERT INTO `bot`(`id`, `name`, `alias`) VALUES (3, 'YisouSpider', '神马');
INSERT INTO `bot`(`id`, `name`, `alias`) VALUES (4, '360Spider', '360搜索');
INSERT INTO `bot`(`id`, `name`, `alias`) VALUES (5, 'PetalBot', '华为搜索');
INSERT INTO `bot`(`id`, `name`, `alias`) VALUES (6, 'Googlebot', '谷歌');
INSERT INTO `bot`(`id`, `name`, `alias`) VALUES (7, 'Applebot', 'Applebot');
INSERT INTO `bot`(`id`, `name`, `alias`) VALUES (8, 'SemrushBot', 'SemrushBot');
INSERT INTO `bot`(`id`, `name`, `alias`) VALUES (9, 'YandexBot', 'YandexBot');
INSERT INTO `bot`(`id`, `name`, `alias`) VALUES (10, 'AhrefsBot', 'AhrefsBot');

ALTER TABLE `access_log`
    ADD INDEX `idx_url`(`time_local`, `url`) USING BTREE;

ALTER TABLE `web`
    ADD INDEX `idx_host`(`host`) USING BTREE;

ALTER TABLE `access_log`
    ADD INDEX `idx_host`(`host`, `time_local`, `url`) USING BTREE;