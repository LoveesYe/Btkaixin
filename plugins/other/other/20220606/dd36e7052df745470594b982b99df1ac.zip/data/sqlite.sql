/*
 Navicat Premium Data Transfer

 Source Server         : weblog
 Source Server Type    : SQLite
 Source Server Version : 3035005
 Source Schema         : main

 Target Server Type    : SQLite
 Target Server Version : 3035005
 File Encoding         : 65001

 Date: 06/06/2022 21:32:01
*/

PRAGMA foreign_keys = false;

-- ----------------------------
-- Table structure for access_log
-- ----------------------------
DROP TABLE IF EXISTS "access_log";
CREATE TABLE "access_log" (
  "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
  "host" TEXT,
  "remote_addr" TEXT,
  "remote_user" TEXT,
  "time_local" integer(11) COLLATE BINARY,
  "request" TEXT,
  "status" TEXT,
  "body_bytes_sent" TEXT,
  "http_user_agent" TEXT,
  "http_referer" TEXT,
  "ua_type" TEXT,
  "http_x_forwarded_for" TEXT,
  "protocol" TEXT,
  "method" TEXT,
  "url" TEXT,
  "location" TEXT
);

-- ----------------------------
-- Records of access_log
-- ----------------------------

-- ----------------------------
-- Table structure for bot
-- ----------------------------
DROP TABLE IF EXISTS "bot";
CREATE TABLE "bot" (
  "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
  "name" TEXT,
  "alias" TEXT
);

-- ----------------------------
-- Records of bot
-- ----------------------------
INSERT INTO "bot" VALUES (1, 'Baiduspider', '百度');
INSERT INTO "bot" VALUES (2, 'Sogou web spider', '搜狗');
INSERT INTO "bot" VALUES (3, 'YisouSpider', '神马');
INSERT INTO "bot" VALUES (4, '360Spider', '360搜索');
INSERT INTO "bot" VALUES (5, 'PetalBot', '华为搜索');
INSERT INTO "bot" VALUES (6, 'Googlebot', '谷歌');
INSERT INTO "bot" VALUES (7, 'bingbot', '必应');
INSERT INTO "bot" VALUES (8, 'SemrushBot', 'SemrushBot');
INSERT INTO "bot" VALUES (9, 'YandexBot', 'YandexBot');
INSERT INTO "bot" VALUES (10, 'AhrefsBot', 'AhrefsBot');
INSERT INTO "bot" VALUES (11, 'Applebot', 'Applebot');

-- ----------------------------
-- Table structure for sqlite_sequence
-- ----------------------------
DROP TABLE IF EXISTS "sqlite_sequence";
CREATE TABLE "sqlite_sequence" (
  "name",
  "seq"
);

-- ----------------------------
-- Records of sqlite_sequence
-- ----------------------------
INSERT INTO "sqlite_sequence" VALUES ('web', 439);
INSERT INTO "sqlite_sequence" VALUES ('bot', 11);
INSERT INTO "sqlite_sequence" VALUES ('access_log', 1432403);

-- ----------------------------
-- Table structure for web
-- ----------------------------
DROP TABLE IF EXISTS "web";
CREATE TABLE "web" (
  "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
  "host" text,
  "path" TEXT,
  "log_path" TEXT,
  "error_log_path" TEXT,
  "create_time" TEXT
);

-- ----------------------------
-- Records of web
-- ----------------------------

-- ----------------------------
-- Auto increment value for access_log
-- ----------------------------
UPDATE "sqlite_sequence" SET seq = 1432403 WHERE name = 'access_log';

-- ----------------------------
-- Indexes structure for table access_log
-- ----------------------------
CREATE INDEX "idx_host"
ON "access_log" (
  "host" COLLATE BINARY ASC
);
CREATE INDEX "idx_time_local"
ON "access_log" (
  "time_local" COLLATE BINARY ASC
);
CREATE INDEX "idx_ua_type"
ON "access_log" (
  "ua_type" COLLATE BINARY ASC
);

-- ----------------------------
-- Auto increment value for bot
-- ----------------------------
UPDATE "sqlite_sequence" SET seq = 11 WHERE name = 'bot';

-- ----------------------------
-- Auto increment value for web
-- ----------------------------
UPDATE "sqlite_sequence" SET seq = 439 WHERE name = 'web';

-- ----------------------------
-- Indexes structure for table web
-- ----------------------------
CREATE INDEX "web_host"
ON "web" (
  "host" COLLATE BINARY ASC
);
CREATE UNIQUE INDEX "web_id_uindex"
ON "web" (
  "id" ASC
);

PRAGMA foreign_keys = true;
