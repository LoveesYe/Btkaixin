<?php
require 'main.php';
use think\facade\Db;
use lib\Time;
use wenhainan\filecache;

class Sync   extends main {
    function __construct()
    {
        parent::__construct();
        @chmod(RUNTIME_DIR,0777);
        $this->sync_web();
    }
    function sync_log($line = 300)
    {
        echo Time::nowdate()."---同步开始---".BR;
        //@ini_set('memory_limit', '512M');
        $is_first = cache('is_first');
        if($is_first == false){
            $line = 500;
            cache('is_first',1,3600);
        }
        //echo $line."\n";
        $web =  Db::table('web')->field('host,log_path')->select();
        $this->del_log();
        $this->del_web($web);
        foreach ($web as $key => $value) {
            $name = $value['host'];
            $filename = $value['log_path'];
            try{
                $arr = $this->tail_log($filename,$line);
            }catch (\Exception $e){
                echo "同步网站访问记录 ".$name." 失败!".$e->getMessage()." \n";
                continue;
            }
            $this->insert_log($name,$arr);
            echo "同步网站访问记录 ".$name." 成功! \n";
        }
        echo Time::nowdate()."---同步结束---\n";
    }
    function del_log(){
        $key = md5('is_delete');
        $res = Db::table('access_log')->whereTime('time_local','<',Time::daysAgo('15'))->find();
        if(!empty($res) &&  cache($key) == false ){
            Db::table('access_log')->whereTime('time_local','<',Time::daysAgo('15'))->delete();
            echo "清除插件过期数据，提升性能...\n";
            cache($key,1,3600*24);
        }
    }
    function del_web($web_arr)
    {
        $tmp = [];
        foreach($web_arr as $web){
            $res =  Db::connect('bt_db')->table('domain')->where('name',$web['host'])->find();
            if(empty($res)){
                $tmp[] = $web['host'];
            }
        }
        if(!empty($tmp)){
            Db::name('web')->whereIn('host',$tmp)->delete();
            echo '清理已删除的无效站点...'.BR;
        }
    }
    function tail_log($filename,$n)
    {
        $err_msg = 'no file';
        if(PHP_SAPI == 'cli'){
            $err_msg = "对应日志文件不存在!";
        }
        if(!file_exists($filename)){
            throw new Exception($err_msg);
        }
        $cmd = <<<EOF
tail -n $n $filename
EOF;
        $cmd = escapeshellcmd($cmd);
        try{
            $os = get_os();
            if($os == 'windows'){
                $res = $this->read_file($filename,$n);
            }else{
                $exec = exec_enabled();
                if($exec){
                    @exec($cmd,$res);
                }else{
                    $version = 'PHP'.GetPHPVersion();
                    echo "警告:检测到[{$version}]中[exec]函数可能被禁用，请解除限制提高性能".PHP_EOL;
                    $res = $this->read_file($filename,$n);
                }
            }
        }catch (\Exception $e){
             return $e->getMessage();
        }
        return $res;
    }
}
//start
(new Sync())->sync_log();
