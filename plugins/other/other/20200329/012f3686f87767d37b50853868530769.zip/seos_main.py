#!/usr/bin/python
# coding: utf-8
import os
import sys
import json
import requests
from exception import RequestException as Re
import re

try:
    import xml.etree.cElementTree as ET
except ImportError:
    import xml.etree.ElementTree as ET



os.chdir('/www/server/panel')
sys.path.append("class/")
import public

class seos_main(object):
    __path = '/www/server/panel/plugin/seos'

    def get_domains(self, get):
        result = []
        domains = public.M('domain').order('id desc').field('id,name,port,addtime').select()
        if domains is not None:
            for domain in domains:
                try:
                    result.append(domain['name'])
                except BaseException as e:
                    pass
        return seos_main.response(result)

    def get_sites(self, get):
        sites = public.M('sites').order('id desc').field('id,name,path,status,ps').select()
        return seos_main.response(sites)

    def request(self, url, host=''):
        res = requests.get(url, headers={
            'Host': host,
            'Referer': url,
            'Upgrade-Insecure-Requests': '1',
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) '
                          'Chrome/75.0.3770.90 Safari/537.36 '
        }, timeout=20)
        if res.status_code == 200:
            return res.content
        try:
            raise Re.RequestException("获取数据失败，状态码为{}".format(res.status_code))
        except BaseException as e:
            pass

    def save_robots(self, get):
        info = {}
        try:
            info = json.loads(get.info)
        except BaseException as e:
            return seos_main.response(None, -1, '解析robots数据体异常')
        path = info['path']
        disallows = info['disallow']
        sitemaps = info['sitemap']
        time = info['time']
        type = info['type']
        custom = info['custom']
        result = '# robots.txt generated at bt-seos\n'
        if type == 'success':
            result = result + 'User-agent: *\n'
            result = result + 'Disallow: \n'
        elif type == 'fail':
            result = result + 'User-agent: *\n'
            result = result + 'Disallow: /\n'
        else:
            if custom is not None and len(custom) > 0:
                for item in custom:
                    if item['val'] != 0:
                        if item['k'] == 'sogou-spider':
                            item['k'] = 'sogou spider'
                        result = result + 'User-agent: ' + item['k'] + '\n'
                        if item['val'] == 1:
                            result = result + 'Disallow: \n'
                        else:
                            result = result + 'Disallow: /\n'
        if time is not None and time != '':
            result = result + 'Crawl-delay: ' + time + '\n'
        if disallows is not None and len(disallows) > 0:
            for disallow in disallows:
                result = result + 'Disallow: ' + disallow + '\n'
        if sitemaps is not None and len(sitemaps) > 0:
            for sitemap in sitemaps:
                result = result + 'Sitemap: ' + sitemap + '\n'
        try:
            with open(path + '/robots.txt', 'w') as f:
                f.write(result)
            f.close()
            return seos_main.response()
        except:
            return seos_main.response(None, -1, '写入robots.txt失败，请检查目标站点目录是否具存在或开放权限')

    def baidu_url_get_list(self, get):
        file = self.__path + '/baidu_url.json'
        if not os.path.exists(file):
            with open(file, 'w') as f:
                f.write("[]")
            f.close()
            return seos_main.response([])
        else:
            return seos_main.response(json.load(open(file, 'r')))

    def baidu_url_add_domain(self, get):
        domain = get.domain
        file = self.__path + '/baidu_url.json'
        try:
            urls = json.load(open(file, 'r'))
            if urls is not None and len(urls) > 0:
                for url in urls:
                    if url['domain'] == domain:
                        return seos_main.response(None, -1, '{} 已存在'.format(domain))
            else:
                urls = []
            urls.append({'domain': domain, 'auto': False, 'sitemap': '', 'token': ''})
            json.dump(urls, open(file, 'w'))
            return seos_main.response()
        except BaseException as e:
            return seos_main.response(None, -1, '添加至推送列表失败')

    def baidu_url_submit(self, get):
        list = get.list
        domain = get.domain
        return self.baidu_url_submit_exec(domain, list)

    def baidu_url_submit_exec(self, domain, list):
        try:
            file = self.__path + '/baidu_url.json'
            urls = json.load(open(file, 'r'))
            if urls is not None and len(urls) > 0:
                for url in urls:
                    if url['domain'] == domain:
                        if url['token'] == '':
                            return seos_main.response(None, -1, '未配置Token无法进行推送')
                        else:
                            surl = "http://data.zz.baidu.com/urls?site={}&token={}".format(domain, url['token'])
                            resp = requests.post(surl, data=list, headers={'Content-Type': 'text/plain'})
                            if resp.status_code == 200:
                                res_json = json.loads(resp.content)
                                not_valid = 0
                                not_same_site = 0
                                if res_json.has_key('not_valid'):
                                    not_valid = len(res_json['not_valid'])
                                if res_json.has_key('not_same_site'):
                                    not_same_site = len(res_json['not_same_site'])
                                return seos_main.response({'e': "成功推送{}条链接，剩余可推送数目为：{}，非本站链接{}条，不合法URL为{}条".format(
                                    res_json['success'], res_json['remain'], not_same_site, not_valid
                                ), 'res': res_json})
                            else:
                                return seos_main.response(None, -1, '请求百度推送API接口失败：{}'.format(resp.status_code))
            return seos_main.response()
        except BaseException as e:
            return seos_main.response(str(e), -1, '推送链接失败')

    def baidu_url_update_auto(self, get):
        auto = get.auto
        if auto == "true":
            auto = True
        else:
            auto = False
        sitemap = get.sitemap
        domain = get.domain
        cv, t = self.baidu_url_change_attr(domain, 'auto', auto)
        if cv is not True:
            return seos_main.response(None, -1, '更改 {} 自动提交状态失败'.format(domain))
        cv, t = self.baidu_url_change_attr(domain, 'sitemap', sitemap)
        if cv is not True:
            return seos_main.response(None, -1, '更改 {} Sitemap失败'.format(domain))
        if t is not None:
            cron_name = (t['domain'] + '_百度自动提交')
            id = public.M('crontab').where('name =?', (cron_name)).getField('id')
            import crontab
            # 需要添加定时任务
            if auto is True:
                if not id:
                    data = {}
                    data['name'] = cron_name
                    data['type'] = 'day'
                    data['where1'] = ''
                    data['sBody'] = 'python ' + self.__path + '/seos_main.py ' + t['domain']
                    data['backupTo'] = 'localhost'
                    data['sType'] = 'toShell'
                    data['hour'] = '2'
                    data['minute'] = ' 30'
                    data['week'] = ''
                    data['sName'] = ''
                    data['urladdress'] = ''
                    data['save'] = ''
                    crontab.crontab().AddCrontab(data)
            else:  # 无需添加定时任务
                if id:
                    crontab.crontab().DelCrontab({'id': id})  # 删除任务

        return seos_main.response()

    def baidu_url_update_token(self, get):
        token = get.token
        domain = get.domain
        cv, t = self.baidu_url_change_attr(domain, 'token', token)
        if cv is not True:
            return seos_main.response(None, -1, '更改 {} TOKEN失败'.format(domain))
        return seos_main.response()

    def baidu_url_remove(self, get):
        domain = get.domain
        try:
            file = self.__path + '/baidu_url.json'
            urls = json.load(open(file, 'r'))
            if urls is not None and len(urls) > 0:
                for url in urls:
                    if url['domain'] == domain:
                        urls.remove(url)
                        cron_name = (domain + '_百度自动提交')
                        id = public.M('crontab').where('name =?', (cron_name)).getField('id')
                        if id:
                            import crontab
                            crontab.crontab().DelCrontab({'id': id})
            json.dump(urls, open(file, 'w'))
            return seos_main.response()
        except BaseException as e:
            return seos_main.response(None, -1, '删除{}失败'.format(domain))

    def baidu_url_change_attr(self, domain, attr_name, attr_val):
        try:
            file = self.__path + '/baidu_url.json'
            urls = json.load(open(file, 'r'))
            if urls is not None and len(urls) > 0:
                for url in urls:
                    if url['domain'] == domain:
                        url[attr_name] = attr_val
                        json.dump(urls, open(file, 'w'))
                        return True, url
            return False, None
        except BaseException as e:
            return seos_main.response(None, -1, '更改{}配置失败'.format(domain)), None

    @staticmethod
    def response(data=None, code=0, msg=''):
        return {
            'code': code,
            'data': data,
            'msg': msg
        }

    @staticmethod
    def replace_str(val):
        if val is None:
            return None
        return val.encode('utf-8').replace('\r', '').replace('\n', '').replace('\t', '').decode('utf-8')

    @staticmethod
    def is_domain(domain):
        domain_regex = re.compile(
            r'(?:[A-Z0-9_](?:[A-Z0-9-_]{0,247}[A-Z0-9])?\.)+(?:[A-Z]{2,6}|[A-Z0-9-]{2,}(?<!-))\Z',
            re.IGNORECASE)
        return True if domain_regex.match(domain) else False

    def cron_submit(self):
        if len(sys.argv) != 2:
            print ("【失败】无目标主动提交链接域名")
            return
        domain = sys.argv[1]
        submit_url = None
        try:
            file = self.__path + '/baidu_url.json'
            urls = json.load(open(file, 'r'))
            if urls is not None and len(urls) > 0:
                for url in urls:
                    if url['domain'] == domain:
                        submit_url = url
        except BaseException as e:
            print("【失败】读取{}配置信息失败".format(domain))
            return
        if submit_url is None:
            print ("【失败】推送列表未找到域名{}".format(domain))
            return
        if submit_url['token'] == '' or submit_url['sitemap'] == '':
            print("【失败】{}的推送token或自动推送sitemap地址未配置".format(domain))
            return
        resp = requests.get(submit_url['sitemap'])
        if resp.status_code != 200:
            print("【失败】访问Sitemap失败：{}-{}".format(resp.status_code, submit_url['sitemap']))
            return
        root = ET.fromstring(resp.content)
        list = []
        try:
            for child in root:
                for c in child:
                    if 'loc' in c.tag:
                        list.append(c.text)
        except BaseException as e:
            print("【失败】{} XML解析失败".format(domain))
            return
        send_list = "\n".join(list)
        try:
            res = self.baidu_url_submit_exec(domain, send_list)
            if res['code'] == 0:
                print("【成功】{}".format(res['data']['e']))
            else:
                print("【失败】{}".format(res['msg']))
        except BaseException as e:
            print("【失败】{} 提交至百度失败".format(domain))


if __name__ == '__main__':
    s = seos_main()
    s.cron_submit()
