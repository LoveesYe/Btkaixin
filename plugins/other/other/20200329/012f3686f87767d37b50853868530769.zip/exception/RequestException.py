import json


class RequestException(BaseException):
    msg = None

    code = -1

    def __init__(self, msg='request fail', code=-1):
        self.msg = msg
        self.code = code

    def resp(self):
        return {
            'code': self.code,
            'msg': self.msg
        }

    def __str__(self):
        return json.dumps(self.resp())
