#!/bin/bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH

#配置插件安装目录
install_path=/www/server/panel/plugin/mfwatermark

#安装
Install()
{
	
	echo '正在安装...'
    cd $install_path
	#==================================================================
	#依赖安装开始
    tar -xzvf gifsicle-1.92.tar.gz 
    cd gifsicle-1.92 
    ./configure --disable-gifview --disable-gifdiff && make
    cp /www/server/panel/plugin/mfwatermark/gifsicle-1.92/src/gifsicle /www/server/panel/plugin/mfwatermark/gifsicle
	#依赖安装结束
	#==================================================================

	echo '================================================'
	echo '安装完成'
}

#卸载
Uninstall()
{
	rm -rf $install_path
}

#操作判断
if [ "${1}" == 'install' ];then
	Install
elif [ "${1}" == 'uninstall' ];then
	Uninstall
else
	echo 'Error!';
fi
