#!/usr/bin/python
# coding: utf-8
# +-------------------------------------------------------------------
# editor: mufei(ypdh@qq.com tel:15712150708)
'''
牧飞 _ __ ___   ___   ___  / _| ___(_)
| '_ ` _ \ / _ \ / _ \| |_ / _ \ |
| | | | | | (_) | (_) |  _|  __/ |
|_| |_| |_|\___/ \___/|_|  \___|_|
'''

from PIL import Image, ImageFile, ImageDraw, ImageFont, ImageChops, ImageEnhance, ImageSequence
import sys,os,json,re,time,math
ImageFile.LOAD_TRUNCATED_IMAGES = True

#设置运行目录
basedir = "/www/server/panel/plugin/mfwatermark" #os.path.abspath(os.path.dirname(__file__))
plugin_path = basedir

_debug = '--debug' in sys.argv

__all__ = ['IMAGES']

try:
    from gevent import monkey, Greenlet, sleep
    is_threading_patch = monkey.is_module_patched('threading')    
except:
    monkey = Greenlet = sleep = None
    is_threading_patch = False


    
class IMAGES:
    backdir = os.path.join(basedir, 'backups')
    tmpPath = os.path.join(plugin_path,'temp')
    allmaxsize = int(1024*1024*(1024*2*9/10))
    
    @classmethod
    def get_size(cls, file):
        size = os.path.getsize(file)
        return size / 1024

    def backup(cls, fpath, cfg):
        cfg['result']['files'].append(fpath)
            
        if cfg.get('isbackup'):
            if cfg['allmaxsize']> cls.allmaxsize:
                if cfg.get('zfile'):
                    cfg['zfile'].close()
                    cfg.pop('zfile')
            cfg['allmaxsize'] += os.path.getsize(fpath)
            
            if not cfg.get('zfile'):
                #basedir = os.path.abspath(os.path.dirname(__file__))
                if not os.path.isdir(cls.backdir): os.mkdir(cls.backdir)
                t = time.strftime('%Y%m%d%H%M%S')
                zpath = os.path.join(cls.backdir,  "%s.zip"%t)
                import zipfile
                cfg['zfile'] = zipfile.ZipFile(zpath, "w", compression=zipfile.ZIP_DEFLATED)
            
            bf = fpath.replace('\\','/').strip('/')
            cfg['zfile'].write(fpath, bf) 

    @classmethod
    def check(cls, fpath, cfg , checkTemp=1, checkTime=1):
        if not os.path.isfile(fpath):  return
        if fpath.startswith(cls.backdir): return
        
        if checkTemp and fpath.replace('\\', '/').startswith(cls.tmpPath.split(':')[-1].replace('\\', '/')) :
            return
        
        f = os.path.basename(fpath) #fpath.replace('\\','/').split('/')[-1]
        if isinstance(cfg['exts'], str):
            if '*.*' not in cfg['exts']:
                if not re.search(cfg['_exts'], f, flags=re.I): return #match
            ext = True
        else:
            ext = os.path.splitext(f)[1].lower() 
            if ext not in cfg['exts']: return
            
        if not ext: return
        
        utimemode = cfg['utimemode']
        utime = cfg['utime']
        if utimemode and utime and checkTime:
            _utime = time.strftime('%Y-%m-%d %H:%M:%S',time.gmtime(os.path.getmtime(fpath)))
            if   utimemode==1 and _utime>=utime:return
            elif utimemode==2 and _utime<=utime:return
        if cfg.get('minsize'):
            if cls.get_size(fpath) < cfg['minsize']: return
        if cfg.get('minwidth'):
            try:
                if cfg['minwidth'] > Image.open(fpath.replace('\\','/')).size[0]: return
            except:
                #print   1111,fpath.replace('\\','/')
                return
        if cfg.get('isprotect') and cfg['maskmode']!=1:
            msk = open(fpath,'rb').read()[-5:]
            if msk==b"Amask": return True
            if msk[1:]==b"mask": return
        if cfg.get('isaprotect') :
            msk = open(fpath,'rb').read()[-5:]
            if msk==b"Amask": return 
            
        return True

    @classmethod
    def compress(cls, fpath, cfg, im=None, iscount=1):
        if not cfg.get('iscompress') and cfg['maskmode']!=1:
            return im
        state = 0
        try:
            im = im or Image.open(fpath)
        except:
            return
        x, y = im.size
        ImageFile.MAXBLOCK = x * y
        optimize = cfg.get('optimize', 0)
        
        yswidth,ysheight = cfg.get('yswidth'),cfg.get('ysheight')
        if yswidth or ysheight:
            
            if yswidth and ysheight: pass
            else:
                if yswidth:
                    ysheight = int(y * yswidth / x)
                else:
                    yswidth = int(x*ysheight / y)
            if yswidth>=x and ysheight>=y:
                pass
            elif yswidth<=x and ysheight<=y:
                im = im.resize((yswidth, ysheight), Image.ANTIALIAS)
                #print '=============',
                state = 1
            else:
                if cfg['maskmode']==1:
                    return 
                #return im

        tmpPath = cfg.get('tmpPath') or './temp'
        if not os.path.isdir(tmpPath):
            os.mkdir(tmpPath)
        #print 'tmpPath:', tmpPath, cfg.get('tmpPath')
        infile = tmpPath+'/infile.'+fpath.split('.')[-1]
        
        try:
            im.save(infile)
        except:
            im = im.convert('RGB')
            im.save(infile)
            state = 1
        
        ctrsize = cfg.get('ctrsize')
        quality = cfg.get('quality') or 100
        if 0<quality<100:
            o_size = start_size = cls.get_size(infile)
            outfile = tmpPath+'/outfile.'+fpath.split('.')[-1]
            
            if ctrsize:
                if o_size<=ctrsize : pass
                else:
                    step = 10
                    while o_size > ctrsize and quality>0:
                        #print(o_size , fpath, quality, ctrsize)
                        im.save(outfile, quality=quality, optimize=optimize)
                        if quality - step <= 0 :
                            if quality>0:
                                step -= int(step/2)
                            if quality <=1 :
                                break
                        quality -= step
                        o_size = cls.get_size(outfile)
                    
                    if(start_size>o_size):
                        state = 1
                        im = Image.open(outfile)
            else:
                im.save(outfile, quality=quality, optimize=optimize)
                o_size = cls.get_size(outfile)
                if(start_size>o_size):
                    im = Image.open(outfile)
                    state = 1
                
                
        
        if iscount and state: cfg['result']['compresscount'] += 1
        if cfg['maskmode']==1 and state==0:
            return
        return im

    def watermark_word(cls, fpath, cfg, im=None, iscount=1):
        #文件水印
        try:
            im = im or Image.open(fpath)
        except:
            return 
        text = cfg['masktext']
        try:
            text = unicode(text,'UTF-8')
        except:
            pass
        #font = ImageFont.truetype(r'/Windows/Fonts/simfang.ttf', 36)
        font = ImageFont.truetype(cfg['fontttf'], cfg.get('fontsize') or 36) #50, int(20 / 1.5)
        
        new_img = Image.new('RGBA', (im.size[0] * 3, im.size[1] * 3), (0, 0, 0, 0))
        new_img.paste(im, im.size) # 添加背景
     
        font_len = len(text) # 添加水印
        rgba_image = new_img.convert('RGBA')
        text_overlay = Image.new('RGBA', rgba_image.size, (255, 255, 255, 0))
        image_draw = ImageDraw.Draw(text_overlay)

        v = int(40*(cfg.get('fontsize') or 36)/36)
        for i in range(0, rgba_image.size[0], font_len*v): #40, 100):
            for j in range(0, rgba_image.size[1], 200): #200
                image_draw.text((i, j), text, font=font,
                                #fill=(0, 0, 0, 50),
                                fill=cfg.get('rgba') or '#00000080' #字体颜色
                                )
        text_overlay = text_overlay.rotate(-45)
        image_with_text = Image.alpha_composite(rgba_image, text_overlay)
     
        im = image_with_text.crop((im.size[0], im.size[1], im.size[0] * 2, im.size[1] * 2)) # 裁切图片
        if iscount: cfg['result']['maskcount'] += 1
        #im.show()
        
            
        return im


    def watermark_pic(cls, fpath, cfg, im=None, iscount=1):
        try:
            im = im or Image.open(fpath)
        except:
            return 
        
        image_x, image_y = im.size
        
        mark = Image.open(cfg['maskimgPath'])
        watermark_x, watermark_y = mark.size
        scale = cfg.get('maskscale')
        if scale:
            _scale = max(im.size[0] / (scale * mark.size[0]), im.size[1] / (scale * mark.size[1]))
            if _scale>0:
                new_size = (int(mark.size[0] * _scale), int(mark.size[1] * _scale))
                mark = mark.resize(new_size, resample=Image.ANTIALIAS)
                watermark_x, watermark_y = new_size
            
        opacity = (cfg.get('maskopacity') or 0)/100.0 #0.80
        if 0<opacity<0.99: # 透明度 0<=opacity<=1
            alpha = mark.split()[3]
            alpha = ImageEnhance.Brightness(alpha).enhance(opacity)
            mark.putalpha(alpha)
        im = im.convert('RGBA')
        layer =Image.new('RGBA', im.size, (0, 0, 0, 0))
        
        markpos = cfg.get('markpos', '')
        marginx = cfg.get('marginx') or 0
        marginy = cfg.get('marginy') or 0
        if markpos in ('','rightbottom'): #右下角
            pos = (image_x - watermark_x - marginx, image_y - watermark_y - marginy)
        elif markpos=='leftbottom': #左下角
            pos = (marginx, image_y - watermark_y - marginy) 
        elif markpos=='lefttop': #左上角
            pos = (marginx, marginy)
        elif markpos=='righttop':#右上角
            pos = (image_x - watermark_x - marginx, marginy)
        elif markpos=='center':#水平居中
            pos = (image_x/2 - watermark_x/2 - marginx, image_y/2 - watermark_y/2 - marginy)
                
        layer.paste(mark, pos)
        im = Image.composite(layer,im,layer)
        if iscount: cfg['result']['maskcount'] += 1
        return im

    def gifsicle(self, fpath, cfg):
        "/gifsicle timg.gif -O3 --colors 256  --lossy=20  > timg2.gif"
        if _debug: print(fpath, 'start')
        path2 = "/www/server/panel/plugin/mfwatermark/tmp.gif"
        
        size1 = os.path.getsize(fpath)
        cmd = "/www/server/panel/plugin/mfwatermark/gifsicle %s -%s --colors %s --lossy=%s > %s"
        cmd = cmd%(fpath, cfg['gif_qty'], 2**cfg['gif_color'],  cfg['gif_loss'], path2)
        #print(cmd)
        os.popen(cmd)
        size2 = os.path.getsize(path2)
        if 0<size2<size1:
            self.backup(fpath, cfg)
            
            fname, path = self.get_save_path(fpath, cfg)
            f = open(path,'wb')
            f.write(open(path2,'rb').read())
            if cfg['maskmode']==1:
                f.write(b'Amask')
            else:
                f.write(b'Bmask')
                
            f.close()
            cfg['result']['compresscount'] += 1
            if _debug: print(fpath, 'done')
        
        

    @classmethod
    def get_save_path(cls, fpath, cfg):
        fname = os.path.basename(fpath)
        if cfg.get('outpath'):
            pths = fpath.replace(cfg['folder'], '').replace('\\', '/').strip('/').split('/')
            if len(pths)>1:
                opDir = os.path.join(cfg['outpath'], *pths[:-1])
                if not os.path.isdir(opDir):
                    os.makedirs(opDir)
                path = os.path.join(opDir, fname)
            else:
                path = os.path.join(cfg['outpath'], fname)
        else:
            path = fpath
        return fname, path
    
    @classmethod
    def save(cls, fpath, cfg, im):
        if not im: return
        fname, path = cls.get_save_path(fpath, cfg)
        optimize = cfg.get('optimize', 0)
        if cfg.get('clearexif'):
            data = list(im.getdata())
            im2 = Image.new(im.mode, im.size)
            im2.putdata(data)
            im = im2
                    
        if fpath.lower().endswith('.png'):
            if optimize:
                im = im.convert('RGB').convert('P', palette=Image.ADAPTIVE,colors=256)
            elif cfg.get('isopaque'):
                im = im.convert('RGB')
            try:
                im.save(path, optimize=optimize)
            except:
                im.save(path)
        else:
            try:
                im.save(path, optimize=optimize)
            except :
                im=im.convert('RGB')
                im.save(path)
                
        
        f = open(path,'ab+')
        if cfg['maskmode']==1:
            f.write(b'Amask')
        else:
            f.write(b'Bmask')
        f.close()
        if _debug: print(path, 'done')


    def doing(self, fpath, cfg, use_check=1, use_back=1):
        
        if use_check and not self.check(fpath, cfg): return
        if _debug: print(fpath,'start', '.')
        if use_back: self.backup(fpath, cfg)
        
        im = self.compress(fpath, cfg)
        #if cfg['maskmode']>1 and not im:
        #    im = Image.open(fpath)
        
        if cfg['maskmode'] == 2:
            im = self.watermark_word(fpath,cfg, im)
        elif cfg['maskmode'] == 3:
            im = self.watermark_pic(fpath,cfg, im)
        if im: self.save(fpath,cfg, im)
        
    def doing_gif(self, fpath, cfg, mode='jpg'):
        "gif操作"
        if not self.check(fpath, cfg): return
        try:
            im = Image.open(fpath)
        except:
            return
        try:
            is_animated = im.is_animated #防止.png/.jpg改名为.gif
        except: #AttributeError
            is_animated = 0
            
        if not is_animated:
            return self.doing(fpath, cfg, use_check=0)

        if cfg.get('isgifsicle') and cfg['maskmode']==1:
            return self.gifsicle(fpath, cfg)
            

        size0 = os.path.getsize(fpath)
        self.backup(fpath, cfg)
        duration = (im.info)['duration']
        
        

        """
        imageios = []
        print im.info
        mypalette = im.getpalette()
        lastframe   = "" #im.convert('RGBA')
        i = 0
        while 1:
            #im2 = im.copy()
            im.putpalette( mypalette )
            new_im  = Image.new("RGB", im.size)
            if lastframe : new_im.paste( lastframe )
            new_im.paste( im )
            tpath = os.path.join(self.tmpPath, "src%s.png"%i)
            #new_im.save(tpath, 'PNG', quality=80)
            new_im.save(tpath, 'PNG')
            lastframe = new_im
            print i
            i += 1
            im.seek(im.tell() + 1 )
            if i>3:break
        """

        if _debug: print(fpath,'start','..')
        
        index = 0
        images = []
        ai, bi = 0, 0
        for frame in ImageSequence.Iterator(im):
            frame = frame.copy()
            index = index + 1
            if mode=="jpg":
                tpath = os.path.join(self.tmpPath, "src%s.jpg"%index)
                RGB = 'RGB'
            else:
                tpath = os.path.join(self.tmpPath, "src%s.png"%index)
                RGB = 'RGBA'
                
            try:
                frame = frame.convert(RGB).convert('P', palette=Image.ADAPTIVE,colors=256)
                frame.save(tpath, optimize=True)
            except IOError:
                #print (frame, IOError)
                frame = frame.convert(RGB)
                frame.save(tpath, optimize=True)
            
            iscount = 1 if index==1 else 0
            tim = self.compress(tpath, cfg, im=frame, iscount=iscount)
            
            if cfg['maskmode'] == 2:
                tim = self.watermark_word(tpath,cfg, tim, iscount=iscount)
            elif cfg['maskmode'] == 3:
                tim = self.watermark_pic(tpath,cfg, tim, iscount=iscount)
            if tim:
                tim = tim.convert(RGB) 
                
            tim = (tim or frame).convert(RGB).convert('P', palette=Image.ADAPTIVE,colors=256)
            
            images.append(tim or frame)

        path2 = "/www/server/panel/plugin/mfwatermark/tmp.gif"
        images[0].save(path2, 'gif', save_all=True, append_images=images[1:], loop=0, duration=duration,
                       optimize=True
                       )
        size2 = os.path.getsize(path2)
        if cfg['maskmode'] == 1 and size2>=size0:
            return
        
        fname, path = self.get_save_path(fpath, cfg)
        
        try:
            if os.path.isfile(path):
                os.remove(path)
        except:
            pass
        f = open(path,'wb')
        f.write(open(path2,'rb').read())
        f.close()
        
        #print help(images[0])
        #convert(self, mode=None, matrix=None, dither=None, palette=0, colors=256)
        #imageio.mimsave('c001.gif', images, duration = dur)
        #images2gif.writeGif(targetGifFilePath, images, duration=1, nq=0.1)
        
        
        f = open(path,'ab+')
        if cfg['maskmode']==1:
            f.write(b'Amask')
        else:
            f.write(b'Bmask')
            
        f.close()
        
    def enpath(self, path):
        try:
            os.path.getsize(path)
        except :
            try:
                os.path.getsize(path.decode('utf-8'))
                path = path.decode('utf-8')
            except:
                path = ""
        return path
        
    def execute(self, cfg):
        cfg.setdefault('allmaxsize', 0)
        
        if not os.path.isdir(self.tmpPath):
            os.makedirs(self.tmpPath)
            
        folder = cfg['folder']
        if cfg.get('subfold'):
            for root, dirs, files in os.walk(folder, True, None, False): 
                for f in files:
                    fpath = os.path.join(root,f)
                    fpath = self.enpath(fpath)
                    if not fpath: continue
                    try:
                        if fpath.lower().endswith('.gif'):
                            self.doing_gif(fpath, cfg)
                        else:
                            self.doing(fpath, cfg)
                    except:
                        print(fpath, 'error')
                        if cfg.get('jumperr'): continue
                        
                        raise
                    if is_threading_patch: sleep(0)    
                    
        else:
             for f in os.listdir(folder):
                fpath = os.path.join(folder,f)
                fpath = self.enpath(fpath)
                if not fpath: continue
                try:
                    if fpath.lower().endswith('.gif'):
                        self.doing_gif(fpath, cfg)
                    else:
                        self.doing(fpath, cfg)
                except:
                    print(fpath, 'error')
                    if cfg.get('jumperr'): continue
                    raise
                if is_threading_patch: sleep(0)       

        if cfg.get('zfile'):
            cfg['zfile'].close()
            cfg.pop('zfile')
        return cfg

    def save_db(self, d):
        path = os.path.join(basedir, 'mfwatermark.sqlite3')
        import sqlite3
        conn = sqlite3.connect(path)
        init_cmd='''
            CREATE TABLE IF NOT EXISTS image_logs
            (
            ctime INT,
            folder CHAR,
            flags INT,
            maskcount INT,
            compresscount INT,
            second INT,
            records TEXT );
            '''
        conn.execute(init_cmd)
        ctime = int(d['result']['ctime'])
        folder = d['folder']
        flags = d['maskmode']
        maskcount = d['result']['maskcount']
        compresscount = d['result']['compresscount']
        if not compresscount and not maskcount:
            return
        
        second = int(time.time() - ctime)
        d = json.dumps(d)
        
        cur = conn.cursor()
        sql = "insert into image_logs(ctime,folder, flags,maskcount,compresscount,second, records) values (?, ?, ?, ?, ?, ?, ?)"
        cur.execute(sql, (ctime,folder, flags,maskcount,compresscount,second, d))
        conn.commit()
        conn.close()





