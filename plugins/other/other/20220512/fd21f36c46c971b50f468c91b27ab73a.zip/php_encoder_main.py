#!/usr/bin/python
# coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: 麦乐 <1327444968@qq.com>
# +-------------------------------------------------------------------

#+--------------------------------------------------------------------
#|   PHP Encoder
#+--------------------------------------------------------------------
from typing import TYPE_CHECKING
import panelTask
import platform
import public
import sys
import os
import json
from data import data as Data
from ajax import ajax as Ajax
#设置运行目录
# os.chdir("/www/server/panel")

#添加包引用位置并引用公共包
sys.path.append("class/")
# from flask import send_file #引用文件发送对象
# import  libs.subprocess as subprocess
# import ConfigParser

#from common import dict_obj
#get = dict_obj();

#在非命令行模式下引用面板缓存和session对象
if __name__ != '__main__':
    from BTPanel import cache, session, redirect

    #设置缓存(超时10秒) cache.set('key',value,10)
    #获取缓存 cache.get('key')
    #删除缓存 cache.delete('key')

    #设置session:  session['key'] = value
    #获取session:  value = session['key']
    #删除session:  del(session['key'])


class php_encoder_main:
    __allow_version = ['53', '54', '55', '56', '70', '71', '72', '73', '74']
    __root = os.getcwd().replace("panel", "").replace("\\", "/")  # 面板根目录
    __php_root_path = __root + "php/"  # PHP存放目录
    __php_config = "/etc/php.ini"  # PHP配置文件
    __plugin_path = __root + "panel/plugin/php_encoder/"  # 插件目录
    __encode_command = __plugin_path + "tools/phpencode"  # 加密命令行
    __make_command = __plugin_path + "install.sh"  # 编译命令行
    __config = None
    #构造方法

    def __init__(self):
        self.os = platform.system()
        if (self.os == "Windows"):
            self.__php_config = "/php.ini"
            self.__encode_command = self.__plugin_path + "tools/encode.exe"
        elif (self.os == "Linux"):
            self.__php_config = "/etc/php.ini"
        pass

    # 获取SO文件
    def sofile(self, ver):
        sopath = self.__php_root_path+ver+"/lib/php/phpencoder/"
        if (self.os == "Windows"):
            return sopath + "php_encoder"+ver + ".dll"
        else:
            return sopath + "php_encoder"+ver + ".so"

    # 获取KEYFILE文件
    def keyfile(self):
        return self.__plugin_path + "php-encoder/php_encoder.h"
   # 获取KEYFILE文件备份
    def keyback_file(self):
        return self.__php_root_path + "php_encoder.bak"

    # 获取SO文件
    def sofilename(self, ver):
        if (self.os == "Windows"):
            return "php_encoder" + ver + ".dll"
        else:
            return "php_encoder" + ver + ".so"

    #自定义访问权限检查
    #一但声明此方法，这意味着可以不登录面板的情况下，直接访问此插件，由_check方法来检测是否有访问权限
    #如果您的插件必需登录后才能访问的话，请不要声明此方法，这可能导致严重的安全漏洞
    #如果权限验证通过，请返回True,否则返回 False 或 public.returnMsg(False,'失败原因')
    #示例未登录面板的情况下访问get_logs方法： /demo/get_logs.json  或 /demo/get_logs.html (使用模板)
    #可通过args.fun获取被请求的方法名称
    #可通过args.client_ip获取客户IP
    def _check(self, args):
        #token = '123456'
        #limit_addr = ['192.168.1.2','192.168.1.3']
        #if args.token != token: return public.returnMsg(False,'Token验证失败!')
        #if not args.client_ip in limit_addr: return public.returnMsg(False,'IP访问受限!')
        #return redirect('/login')
        return True

    def get_list(self, args):
        return self.get_logs(args)

    #访问/demo/index.html时调用的默认方法，需要在templates中有index.html，否则无法正确响应模板
    def get_index(self, args):
        return self.get_logs(args)

    # 获取站点列表
    def get_sites(self, args):
        pub_data=Data()
        data= pub_data.getData(args)
        count = public.M('sites').count()
        page_data = public.get_page(count,int(args.p),int(args.limit),args.callback,result='1,2,3,4,5,8')
        data["page"]=page_data["page"]
        i=0
        for item in data["data"]:
            args.ver=item["php_version"].replace(".","")
            data["data"][i]["php_ver"]=args.ver
            data["data"][i]["is_encode"]=self.encodestate(item["path"],0,True)
            data["data"][i]["is_noencode"]=self.noencodestate(item["path"])
            data["data"][i]["sostatus"]=self.checkenable(args)
            if(data["data"][i]["sostatus"]!=1 and data["data"][i]["is_encode"] =="1" ):
                 data["data"][i]["status"]=99
            i=i+1
        return data
    # 获取PHP环境列表
    def get_phplist(self, args):
        if not 'callback' in args:
            args.callback = ''
        #获取php列表数据
        list = os.listdir(self.__php_root_path)
        list.sort()
        data = []
        index = 0
        for item in list:
            index = index+1
            if item in self.__allow_version:
                args.ver=item
                data.append({
                    "index": index,
                    "name": "php" + item,
                    "ver": item,
                    "os": platform.system(),
                    "state": self.checkenable(args),
                    "path": self.phpconfig(item),
                    "sopath": self.sofile(item)
                })
        return {'data': data, "msg": "获取成功"}

    # 检测是否启用php加密
    def checkenable(self, args):
        ver=args.ver
        args.php_version=ver
        configfile = self.phpconfig(ver)
        sofile = self.sofile(ver)
        if (not os.path.exists(sofile)):
            # so不存在 
            return 2
        if (not os.path.exists(configfile)):
             # php.ini不存在 
            return 3
        conf = public.ReadFile(configfile, mode='r').split('\n')
        for item in conf:
            if sofile in item:
                # _ajax=Ajax()
                # return _ajax.php_info(args)
                # 组件正常
                return 1
        return 0

    # 获取PHP配置文件
    def phpconfig(self, ver):
        php_ini = (self.__php_root_path + ver + "/" + self.__php_config).replace("//", "/")
        # if not os.path.exists('/etc/redhat-release'):
        #    php_ini=(self.__php_root_path + ver + "/" + "litespeed/php.ini").replace("//", "/")
        return php_ini

    # 设置安全KEY
    def set_so_config(self, args):
        if not 'so_cakey' in args:
            args.so_cakey = ''
        if not 'so_only_php' in args:
            args.so_only_php = 0
        if not 'so_defined_message' in args:
            args.so_defined_message = 'ACCESS DENIED'

        keyfile = self.keyfile()
        conf = public.ReadFile(keyfile, mode='r').split('\n')

        if args.so_cakey == '' or args.so_only_php == '' or args.so_defined_message == '':
            return {'data': conf, 'msg': 'Error', "code": -1}

        so_cakey = args.so_cakey
        so_only_php = args.so_only_php
        so_defined_message = args.so_defined_message

        so_encode_mode = args.so_encode_mode
        so_encode_key = args.so_encode_key
        so_key_len = args.so_key_len
        so_version = args.so_version
        so_appname = args.so_appname
        so_defined_strict_file = args.so_defined_strict_file

        conf[self._get_index(conf, "CAKEY")] = '#define CAKEY '+so_cakey
        conf[self._get_index(conf, "STRICT_MODE")
             ] = '#define STRICT_MODE '+so_only_php
        conf[self._get_index(conf, "STRICT_MODE_ERROR_MESSAGE")
             ] = '#define STRICT_MODE_ERROR_MESSAGE '+so_defined_message
             
        conf[self._get_index(conf, "STRICT_FILE")
             ] = '#define STRICT_FILE '+so_defined_strict_file

        conf[self._get_index(conf, "ENCODE_MODE")] = '#define ENCODE_MODE '+so_encode_mode
        conf[self._get_index(conf, "ENCODE_KEY_MODE")] = '#define ENCODE_KEY_MODE '+so_encode_key
        conf[self._get_index(conf, "KEYLEN")] = '#define KEYLEN '+so_key_len
        conf[self._get_index(conf, "VERSION")] = '#define VERSION '+so_version
        conf[self._get_index(conf, "APPNAME")] = '#define APPNAME '+so_appname

        # result=[self._get_index(conf,"CAKEY"),self._get_index(conf,"STRICT_MODE"),self._get_index(conf,"STRICT_MODE_ERROR_MESSAGE")]
        result = public.WriteFile(keyfile, "\n".join(conf), mode='w')
        result = public.WriteFile(self.keyback_file(), "\n".join(conf), mode='w')
        
        self.log("设置 %s(ver:%s) 密钥长度:%s、密钥:%s、加密方式：%s"%(so_appname,so_version,so_key_len,so_cakey,so_encode_mode))
        return {'data': conf, 'result': result, "code": 0}

    # 获取安全KEY
    def get_so_config(self, args):
       [key,so_key_len,so_encode_mode,so_encode_key,so_only_php,so_appname,so_version,so_defined_message,so_defined_strict_file]=self.getCKE()
       return {'data': {"so_cakey": key, "so_appname": so_appname, "so_version": so_version, "so_encode_mode": so_encode_mode,"so_encode_key": so_encode_key, "so_key_len": so_key_len, "so_only_php": so_only_php, "so_defined_message": so_defined_message,"so_defined_strict_file":so_defined_strict_file}, "code": 0}
    
     #获取key,so_key_len,so_encode_mode,so_only_php,so_appname,so_version,so_defined_message
    def getCKE(self):
       keyfile = self.keyfile()
       conf = public.ReadFile(keyfile, mode='r').split('\n')
       key = self._get_cakey(conf, 'CAKEY')
       so_key_len = self._get_cakey(conf, 'KEYLEN')
       so_encode_mode = self._get_cakey(conf, 'ENCODE_MODE')
       so_encode_key = self._get_cakey(conf, 'ENCODE_KEY_MODE')
       
       so_only_php = self._get_cakey(conf, 'STRICT_MODE')
       so_appname = self._get_cakey(conf, 'APPNAME')
       so_version = self._get_cakey(conf, 'VERSION')
       so_defined_message = self._get_cakey(conf, 'STRICT_MODE_ERROR_MESSAGE')
       so_defined_strict_file = self._get_cakey(conf, 'STRICT_FILE')

       return [key,so_key_len,so_encode_mode,so_encode_key,so_only_php,so_appname,so_version,so_defined_message,so_defined_strict_file]

    def _get_cakey(self, conf, key):
        flag = '#define '+key + ' '
        for item in conf:
            if flag in item:
                val = item.replace(flag, '').strip()
                return val
        return ""

    def _get_index(self, arr, key):
        flag = '#define '+key + ' '
        i = 0
        for item in arr:
            if flag in item:
                return i
            i = i+1
        return -1

    # 启用禁用加密
    def enable(self, args):
        if not 'ver' in args:
            args.ver = ''
        if not 'state' in args:
            args.state = '1'
        if not 'callback' in args:
            args.callback = ''
        args.ver=args.ver.replace(".","")
        # 配置文件路径
        configfile = self.phpconfig(args.ver)
        sofile = self.sofile(args.ver)
        conf = public.ReadFile(configfile, mode='r').split('\n')
        for item in conf:
            if self.sofilename(args.ver) in item:
                conf.remove(item)
                self.log("禁用"+self.sofilename(args.ver)+"组件成功!")

        if (args.state == '1'):
            conf.append("extension=" + sofile+"\n")
            self.log("启用"+self.sofilename(args.ver)+"组件成功!")

        result = public.WriteFile(configfile, "\n".join(conf), mode='w')
       
        isreload = public.phpReload(args.ver)
            
            # public.ServiceReload()
        return {
            'conf': conf[len(conf) - 1],
            'data': result,
            'isreload': isreload,
            'sofile': self.sofilename(args.ver),
            "state": args.state,
            "configfile": configfile,
            "sofile": sofile
        }
    # 创建排除文件配置

    def noencode(self, args):
        if not 'path' in args:
            args.path = ''
        if(args.path == ''):
            return {
                'code': -1,
                'msg': "error path",
            }
        path = args.path+"/.noencode"
        if(not os.path.exists(path)):
            file = open(path, 'w')
            file.writelines("#请把不需要加密的目录或文件放面下面一行一个")
            file.close()
        return {"code": 0, "path": path, "msg": "ok"}

    def noencodestate(self, path):
        if(path == ''):
            return {
                'code': -1,
                'msg': "error path",
            }
        path = path+"/.noencode"
        if(os.path.exists(path)):
            file = open(path, 'r')
            lines=file.readlines()
            file.close()
            for line in lines:
                if "#" not in line and line.strip() !="":
                    return 1
        return 0
    # 加密解密代码

    def encode(self, args):
        if not 'state' in args:
            args.state = '1'
        if not 'path' in args:
            args.path = ''
        key,keylen,encode_mode,encode_key_mode,*_=self.getCKE()

        cmd="ulimit -n 99999&&"
        cmd = cmd+self.__encode_command + " -c -f " + args.path+"/" + \
            " -p "+key + " -n " + keylen + " -e "+encode_mode + " -I " 
        if (args.state == '0'):
            cmd = cmd + " -d"
            self.log("加密%s代码成功!"%(args.path))
        else:
            self.log("解密%s代码成功!"%(args.path))

        if(encode_key_mode=='1'):
          cmd =cmd+" -w"
        data = self.exec(cmd)
        self.encodestate(args.path,args.state,False)
        
        return {'data': data, "cmd": cmd, "code": 0}

   

    #加密状态
    def encodestate(self,_path,state,isget=True):
        path = _path+"/.isencode"
        if(isget==False):
            file = open(path, 'w')
            file.writelines(state)
            file.close()
        else:
            if(not os.path.exists(path)): 
                key,keylen,encode_mode,*_=self.getCKE()
                cmd=self.__encode_command +" -k -c -f "+_path +\
                    " -p "+key + " -n " + keylen + " -e "+encode_mode + " -I "
                data=self.exec(cmd).replace("\n","").replace("Crypted:","").strip()
                data=1 if (data == "True") else 0
                return data
            file = open(path, 'r')
            flag=file.readline()
            file.close()
            return flag
    #检测目录加密状态
    def checkencode(self,args):
        if not 'path' in args: args.path = ''
        path = args.path
        key,keylen,encode_mode,*_=self.getCKE()
        cmd="ulimit -n 99999&&"
        cmd=cmd+self.__encode_command +" -ak -c -f "+path +\
            " -p "+key + " -n " + keylen + " -e "+encode_mode + " -I "
        data=self.exec(cmd)
        return {'code': 1, "msg": "检测成功","data":data}

    #恢复备份到网站
    def restore(self,args):
        if not 'rarpath' in args: args.rarpath = ''
        if not 'path' in args: args.path = ''
        if(args.path=="" or args.rarpath==""):
            return {'code': -1, "msg": "恢复备份%s文件失败"%(args.rarpath)}
        cmd="unzip -o %s -d %s"%(args.rarpath,args.path)
        data=self.exec(cmd)
        return {'code': 0, "msg": "恢复备份%s文件成功"%(args.rarpath),"data":data,"cmd":cmd}

    #获加密状态
    def getencodestate(self,args):
        if not 'id' in args: args.id = ''
        if not 'path' in args: args.path = ''
        if args.path=='' : return {"code":-1,"msg":"error"}
        path = args.path
        isencode=self.encodestate(path,0,True)
        return {"code":0,"msg":"error","isencode":isencode,"path":path,"id":args.id}
    # 编译SO
    def make(self, args):
        if not 'ver' in args:
            args.ver = ''
        args.ver=args.ver.replace(".","")
        if (args.ver == ''):
            cmd = self.__make_command + " make"
            self.log("编译所有版本组件成功!") 
        else:
            cmd = self.__make_command + " make " + args.ver
            self.log("编译"+self.sofilename(args.ver) +"成功!")
        canmake=self.canmake(args)
        if canmake == True:
            data = self.exec(cmd)
        else:
            return {"code":-1,"data":"还有未解密站点(%s),请先解密后再编译"%(canmake["name"])}
        return {
            'data': data,
            "cmd": cmd,
            "code": 0,
            "msg": "编译组件(" + args.ver + ")成功"
        }
     # 判断是否可以编译
    def canmake(self, args):
        args.table="sites"
        pub_data=Data()
        data= pub_data.getData(args)
        i=0
        for item in data["data"]:
            args.ver=item["php_version"].replace(".","")
            data["data"][i]["is_encode"]=int(self.encodestate(item["path"],0,True))
            data["data"][i]["sostatus"]=int(self.checkenable(args))
            if(data["data"][i]["is_encode"] ==1 ):
                 return data["data"][i]
            i=i+1
        return True
    def log(self,msg):
         public.WriteLog('PHP_ENCODER', msg)
    ##下载SO文件
    def downfile(self, args):
        if not 'ver' in args:
            args.ver = ''
        file = "php_encoder.tar.gz"
        sofile = self.__plugin_path+file
        if os.path.exists(sofile):
            self.log("下载"+file +"成功")
            return {'code': 0, "msg": "下载文件", "file": "/download?filename="+sofile}
        return {'code': -1, "msg": "没有可用的工具包，请先点击【重新编译】"}
    # 执行命令

    def exec(self, cmd):
        data=public.ExecShell(cmd)
        if(isinstance(data,str)):
            return data
        elif(isinstance(data,tuple) and len(data)>1):
            return data[0]

        # return os.popen(cmd).read()
        # return os.system(cmd)

    #获取面板日志列表
    #传统方式访问get_logs方法：/plugin?action=a&name=demo&s=get_logs
    #使用动态路由模板输出： /demo/get_logs.html
    #使用动态路由输出JSON： /demo/get_logs.json
    def get_logs(self, args):
        #处理前端传过来的参数
        if not 'p' in args:
            args.p = 1
        if not 'rows' in args:
            args.rows = 12
        if not 'callback' in args:
            args.callback = ''
        args.p = int(args.p)
        args.rows = int(args.rows)
        where="type like '%PHP_ENCODER%'"
        #取日志总行数
        count = public.M('logs').where(where,()).count()
        #获取分页数据
        page_data = public.get_page(count, args.p, args.rows, args.callback)
        #获取当前页的数据列表
        log_list = public.M('logs').where(where,()).order('id desc').limit(
            page_data['shift'] + ',' +
            page_data['row']).field('id,type,log,addtime').select()
        #返回数据到前端
        return {'data': log_list, 'page': page_data['page']}

    #读取配置项(插件自身的配置文件)
    #@param key 取指定配置项，若不传则取所有配置[可选]
    #@param force 强制从文件重新读取配置项[可选]
    def __get_config(self, key=None, force=False):
        #判断是否从文件读取配置
        if not self.__config or force:
            config_file = self.__plugin_path + 'config.json'
            if not os.path.exists(config_file):
                return None
            f_body = public.ReadFile(config_file)
            if not f_body:
                return None
            self.__config = json.loads(f_body)

        #取指定配置项
        if key:
            if key in self.__config:
                return self.__config[key]
            return None
        return self.__config

    #设置配置项(插件自身的配置文件)
    #@param key 要被修改或添加的配置项[可选]
    #@param value 配置值[可选]
    def __set_config(self, key=None, value=None):
        #是否需要初始化配置项
        if not self.__config:
            self.__config = {}

        #是否需要设置配置值
        if key:
            self.__config[key] = value

        #写入到配置文件
        config_file = self.__plugin_path + 'config.json'
        public.WriteFile(config_file, json.dumps(self.__config))
        return True
