gcc encode.c -o encode
./encode -c -f ./ -p ABCD -n 64 -e md5 -I  -w 