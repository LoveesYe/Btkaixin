<?php

// Start of pdo_sqlite v.7.0.0-dev
// End of pdo_sqlite v.7.0.0-dev
