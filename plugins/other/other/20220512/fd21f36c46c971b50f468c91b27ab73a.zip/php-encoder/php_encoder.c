
#include "php.h"
#include "php_ini.h"
#include "ext/standard/file.h"
#include "ext/standard/info.h"
// #include "./include/TSRM.h"
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <stdint.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include "core.c"

// #ifndef TSRMLS_FETCH
// #define TSRMLS_FETCH() void ***tsrm_ls = (void ***)ts_resource_ex(0, NULL)
// #endif
// #ifndef TSRMLS_FETCH_FROM_CTX
// #define TSRMLS_FETCH_FROM_CTX(ctx) void ***tsrm_ls = (void ***)ctx
// #endif
// #ifndef TSRMLS_SET_CTX
// #define TSRMLS_SET_CTX(ctx) ctx = (void ***)tsrm_ls
// #endif

// #ifndef TSRMG
// #define TSRMG(id, type, element) (((type)(*((void ***)tsrm_ls))[TSRM_UNSHUFFLE_RSRC_ID(id)])->element)
// #endif

// #ifndef TSRMLS_D
// #define TSRMLS_D void ***tsrm_ls
// #endif
// #ifndef TSRMLS_DC
// #define TSRMLS_DC , TSRMLS_D
// #endif
// #ifndef TSRMLS_C
// #define TSRMLS_C tsrm_ls
// #endif
// #ifndef TSRMLS_CC
// #define TSRMLS_CC , TSRMLS_C
// #endif



//初始化module时运行
PHP_MINIT_FUNCTION(php_encoder);
//当module被卸载时运行
PHP_MSHUTDOWN_FUNCTION(php_encoder);
//当一个REQUEST请求初始化时运行
PHP_RINIT_FUNCTION(php_encoder);
//当一个REQUEST请求结束时运行
PHP_RSHUTDOWN_FUNCTION(php_encoder);
//这个是设置phpinfo中这个模块的信息
PHP_MINFO_FUNCTION(php_encoder);
//初始化全局变量时
// PHP_GINIT_FUNCTION(php_encoder);
//释放全局变量时
// PHP_GSHUTDOWN_FUNCTION(php_encoder);
static int _STRICT_MODE = (int)STRICT_MODE;

char *assert_inc(char *text)
{
  // int pos1=strpos(text,"include");
  return text;
}

FILE *phpencoder_ext_fopen(FILE *fp, char *fname, zend_file_handle *file_handle)
{

  // write_log("%s\n", "is running");
  struct stat stat_buf;
  char *datap, *newdatap;
  int len = keylen * 2;
  char lenBuf[keylen];
  int datalen, newdatalen = 0;
  int i;
  uint8_t enTag[keylen];
  // encode_mode = STR2(ENCODE_MODE);
  // encode_key_mode = STR2(ENCODE_KEY_MODE);
  _key = encodekey(SafeKey);

  if (DEBUG)
    printf("\n_key:%s\n", _key);

  memset(key, 0, sizeof(key));
  memcpy(key, _key, len); //设置KEY
  memcpy(enTag, key, keylen);
  memset(lenBuf, 0, keylen);

  fstat(fileno(fp), &stat_buf);
  datalen = stat_buf.st_size;
  datap = (char *)malloc(datalen);
  memset(datap, 0, sizeof(datap));
  fread(datap, datalen, 1, fp);
  fclose(fp);

  if (DEBUG)
  {
    printf("\nkey:%s\n", key);
    printf("\ndatalen:%d\n", datalen);
    printf("\nenTag:%s\n", enTag);
    printf("\nkeylen:%d\n", keylen);
  }
  // char *buf;
  // size_t size;
  // zend_stream_fixup(file_handle, &buf, &size);
  
  if (memcmp(datap, enTag, keylen) == 0)
  {
    for (i = keylen; i < datalen; i++)
    {
      if (i < len)
        lenBuf[i - keylen] = datap[i];
      else
        datap[i - len] = datap[i];
    }
    code_aes(0, datap, datalen, key, &datalen);
    datalen = atoi(lenBuf);
    // assert_inc(datap);
    // printf("\n#######\nFILE TYPE: %d  FILE NAME: %s CONTENT: %s\n#######\n", (*file_handle).type, (*file_handle).filename, datap);
  }
  else if (_STRICT_MODE)
  {
    // assert_inc(datap);
    datalen = 0;
    // printf("\n#######\nFILE TYPE: %d  FILE NAME: %s CONTENT: %s\n#######\n", (*file_handle).type, (*file_handle).filename, buf);
  }
//  printf("\n#######\nFILE TYPE: %d  FILE NAME: %s CONTENT: %s\n#######\n", (*file_handle).type, (*file_handle).filename, datap);
  fp = tmpfile();
  if (datalen > 0)
  {
    fwrite(datap, datalen, 1, fp);
  }
  else
  {
    char msg[1];
    if(STRICT_FILE)
    {
      sprintf(msg, "%s %s FILE:%s ", STR2(STRICT_MODE_ERROR_MESSAGE), fname,(*file_handle).filename);
    }else{
      sprintf(msg, "%s %s", STR2(STRICT_MODE_ERROR_MESSAGE), fname);
    }
    fwrite(msg, strlen(msg), 1, fp);
  }



  free(datap);
  rewind(fp);
  return fp;
}

ZEND_API zend_op_array *(*org_compile_file)(zend_file_handle *file_handle, int type TSRMLS_DC);

ZEND_API zend_op_array *php_encode_compile_file(zend_file_handle *file_handle, int type TSRMLS_DC)
{
  FILE *fp;
  char fname[32];
  if (!file_handle || !file_handle->filename || strstr(file_handle->filename, ".phar") || strstr(file_handle->filename, "phar://"))
  {
    return org_compile_file(file_handle, type);
  }

  memset(fname, 0, sizeof fname);

  if (zend_is_executing(TSRMLS_C))
  {
    if (get_active_function_name(TSRMLS_C))
    {
      strncpy(fname, get_active_function_name(TSRMLS_C), sizeof fname - 2);
    }
  }
  if (fname[0])
  {
    if (strcasecmp(fname, "show_source") == 0 || strcasecmp(fname, "highlight_file") == 0)
    {
      return NULL;
    }
  }

  fp = fopen(file_handle->filename, "rb");
  if (!fp)
  {
    fp = zend_fopen(file_handle->filename, &file_handle->opened_path);
    if (!fp)
    {
      return org_compile_file(file_handle, type);
    }
  }

  if (file_handle->type == ZEND_HANDLE_FP)
    fclose(file_handle->handle.fp);
#ifdef ZEND_HANDLE_FD
  if (file_handle->type == ZEND_HANDLE_FD)
    close(file_handle->handle.fd);
#endif
  file_handle->handle.fp = phpencoder_ext_fopen(fp, fname, file_handle);
  file_handle->type = ZEND_HANDLE_FP;

  return org_compile_file(file_handle, type);
}

zend_module_entry php_encoder_module_entry = {
#if ZEND_MODULE_API_NO >= 20010901
    STANDARD_MODULE_HEADER,
#endif
    STR2(APPNAME),
    NULL,
    PHP_MINIT(php_encoder),
    PHP_MSHUTDOWN(php_encoder),
    NULL,
    NULL,
    PHP_MINFO(php_encoder),
#if ZEND_MODULE_API_NO >= 20010901
    "1.5.0", /* Replace with version number for your extension 20100525 20010901*/
#endif
    STANDARD_MODULE_PROPERTIES};

ZEND_GET_MODULE(php_encoder);

PHP_MINFO_FUNCTION(php_encoder)
{
  php_info_print_table_start();
  php_info_print_table_header(2, "support", "enabled");
  php_info_print_table_header(2, "version", STR2(VERSION));

  if (DEBUG)
  {
    php_info_print_table_header(2, "debug", STR2(DEBUG));
    php_info_print_table_header(2, "mode", STR2(ENCODE_MODE));
    php_info_print_table_header(2, "secrect length", STR2(KEYLEN));
    php_info_print_table_header(2, "strict mode", STR2(STRICT_MODE));
    php_info_print_table_header(2, "strict message", STR2(STRICT_MODE_ERROR_MESSAGE));
  }

  php_info_print_table_header(2, "site", STR2(SITE));
  php_info_print_table_header(2, "email", STR2(EMAIL));
  php_info_print_table_end();
}

PHP_MINIT_FUNCTION(php_encoder)
{
  // printf("PHP_MINIT_FUNCTION");
  CG(compiler_options) |= ZEND_COMPILE_EXTENDED_INFO;
	// CG(compiler_options) |= ZEND_COMPILE_HANDLE_OP_ARRAY;
	// CG(compiler_options) |= ZEND_COMPILE_DELAYED_BINDING;
	// CG(compiler_options) |= ZEND_COMPILE_NO_CONSTANT_SUBSTITUTION;
  org_compile_file = zend_compile_file;
  zend_compile_file = php_encode_compile_file;
  if (DEBUG)
    printf("PHP_MINIT_FUNCTION");
  return SUCCESS;
}

PHP_MSHUTDOWN_FUNCTION(php_encoder)
{
  // printf("PHP_MSHUTDOWN_FUNCTION");
  CG(compiler_options) |= ZEND_COMPILE_EXTENDED_INFO;
  zend_compile_file = org_compile_file;
  return SUCCESS;
}

// 当一个REQUEST请求初始化时运行
PHP_RINIT_FUNCTION(php_encoder)
{
  // printf("PHP_RINIT_FUNCTION");
}
// 当一个REQUEST请求结束时运行
PHP_RSHUTDOWN_FUNCTION(php_encoder)
{
  // printf("PHP_RSHUTDOWN_FUNCTION");
}
