#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#include "csha1.h"

#define FAIL(str, line) {                       \
  printf("Fail on line %d: [%s]\n", line, str); \
  return str;                                   \
}

#define ASSERT(expr) {                  \
  static_num_tests++;                   \
  if (!(expr)) FAIL(#expr, __LINE__);   \
}

#define RUN_TEST(test) {        \
    const char *msg = test();   \
    if(msg)                     \
        return msg;             \
}


static int static_num_tests = 0;


const char *test_csha1() {

	char digest[41];
	bzero(digest, sizeof(digest));

	ASSERT(strcmp(csha1_hash(digest, "", 0, NULL),"da39a3ee5e6b4b0d3255bfef95601890afd80709") == 0);
	ASSERT(strcmp(csha1_hash(digest, "1", 1, NULL),"356a192b7913b04c54574d18c28d46e6395428ab") == 0);
	ASSERT(strcmp(csha1_hash(digest, "1111111111111111111111111111111", 31, NULL),"2809c70d0161be859f0d7d56d277964c83d7941b") == 0);
	ASSERT(strcmp(csha1_hash(digest, "11111111111111111111111111111111111111111111111111111111", 56, NULL),"b8e49fda8515cc13b4d6bf80d97fca7a24732514") == 0);
	ASSERT(strcmp(csha1_hash(digest, "1111111111111111111111111111111111111111111111111111111111111111", 64, NULL),"07a1a50a6273e6bc2eb94d647810cdc5b275b924") == 0);
	
    return NULL;
}


static const char *run_all_tests(void) {
    RUN_TEST(test_csha1);
    return NULL;
}


int main(void) {
    const char *fail_msg = run_all_tests();
    printf("%s, tests run: %d\n", fail_msg ? "FAIL" : "PASS", static_num_tests);

    return fail_msg == NULL ? 0 : -1;
}

