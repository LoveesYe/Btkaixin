#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "cdefs.h"
#include "cstr.h"


int cstr_empty(const char *str)
{
    return (str == NULL || strlen(str) == 0);
}

char *cstr_copy(char *dest, const char *src, size_t n)
{
	CHECK(dest == NULL, NULL);
	CHECK(src == NULL, dest);

	if(n > 0)
	{
	    strncpy(dest,src,n-1);
	    dest[n-1]='\0';
	}
    return dest;
}

char *cstr_rtrim(char *str)
{
	char *p;
	
	CHECK(str == NULL, NULL);
	
    p = strchr(str, '\0');
    while(p>str && isspace(p[-1]))
        p--;
    *p = '\0';
    return str;
}

char *cstr_ltrim(char *str)
{
	char *p, *s;
	
	CHECK(str == NULL, NULL);
	
    p = str, s = str;
    while(isspace(p[0]))
        p ++;
    while((*s++ = *p++));
    return str;
}

char *cstr_trim(char *str)
{
	CHECK(str == NULL, NULL);
	
    cstr_rtrim(str);
    cstr_ltrim(str);
    return str;
}

char *cstr_lower(char *str)
{
	char *p;
	
	CHECK(str == NULL, NULL);

	for(p = str; *p != '\0'; p++)
	{
		*p = tolower(*p);
	}
	return str;
}

char *cstr_upper(char *str)
{
	char *p;
	
	CHECK(str == NULL, NULL);

	for(p = str; *p != '\0'; p++)
	{
		*p = toupper(*p);
	}
	return str;
}



/**
*�ָ��ַ���,ֱ���޸�ԭ�ַ���
*@param delim �ָ��ַ�����һ�������ַ�
*@param array��Ž��������
*@param array_size��Ž������Ĵ�С
*@return �ɹ����طָ�����ַ�������
*/
int cstr_split(char *str, char *delim, char **array, int array_size)
{
    int count = 0;
    int i, l;
    char  *s, *p;

	CHECK(str == NULL, 0);
	CHECK(delim == NULL, 0);
	CHECK(array == NULL, 0);

	l = strlen(delim);
    if(array_size > 0)
    {
        p = str;
        for(s = p; count < array_size-1 && p[0] != '\0'; p++)
        {
            for(i = 0; i < l; i ++)
            {
                if(p[0] == delim[i])
                {
                    p[0] = '\0';
                    array[count++] = s;
                    s = p + 1;
                }
            }
        }

        array[count++] = s;
    }

    return count;
}

/**
*����һ��������start��end(������)���Ӵ�
*@return �ɹ������Ӵ�,ʧ�ܷ���NULL
*
*@note ���ɵ��Ӵ�,�ɵ�����free
*/
char *cstr_substring(char *str, int start, int end)
{
    char *s = NULL;
    int len, slen;

	CHECK(str == NULL, NULL);
	
    if(start > end)
    {
        //����
        start = start ^ end;
        end = start ^ end;
        start = start ^ end;
    }
	
    len = strlen(str);
    start = MAX(start, 0);
    end = MIN(end, len);

    slen = end - start;
    s = malloc(slen + 1);
    if(s)
    {
        memcpy(s, str+start, slen);
        s[slen] = '\0';
    }

    return s;
}

/**
*ֱ���޸�ԭ�ַ���,�����Ӵ�
*@return �ɹ������Ӵ�
*/
char *cstr_substr(char *str, int start, int end)
{
    int len;

	CHECK(str == NULL, NULL);
	
    if(start > end)
    {
        //����
        start = start ^ end;
        end = start ^ end;
        start = start ^ end;
    }
    len = strlen(str);
    start = MAX(start, 0);
    end = MIN(end, len);

	str[end] = '\0';

    return str + start;
}


/**
*�����ִ�
*@return �ҵ������Ӵ���ʼλ��ָ��,���򷵻�NULL
*/
const char *cstr_str(const char *str, const char *substr, size_t n)
{
    size_t len;
	size_t i;
	
	CHECK(str == NULL, NULL);
	CHECK(substr == NULL, NULL);
	
    len = strlen(substr);

	if(n >= len) {
		for(i = 0; i <= n - len; i++) {
			if(memcmp(str+i, substr, len) == 0) {
				return str+i;
			}
		}
	}

    return NULL;
}

