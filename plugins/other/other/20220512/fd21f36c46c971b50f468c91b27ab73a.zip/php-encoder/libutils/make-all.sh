#!/bin/sh
make.sh

cd libexp
make.sh

cd liboci
make.sh

cd libsql
make.sh

cd libnet
make.sh

cd libiso8583
make.sh

cd libxml
make.sh

cd libini
make.sh
