#!/bin/bash
valgrind --tool=memcheck --leak-check=full --show-reachable=yes --vex-iropt-register-updates=allregs-at-mem-access --vex-iropt-register-updates=allregs-at-each-insn --log-file=mem.log test_cmd5&
