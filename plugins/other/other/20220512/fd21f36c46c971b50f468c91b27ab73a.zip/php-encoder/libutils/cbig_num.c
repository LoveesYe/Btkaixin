#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "cdefs.h"
#include "cbig_num.h"


#define u32_to_bytes(n, a)  {   \
    (a)[0] = (n >> 24) & 0xff;  \
    (a)[1] = (n >> 16) & 0xff;  \
    (a)[2] = (n >> 8)  & 0xff;  \
    (a)[3] = (n >> 0)  & 0xff;  \
}


static unsigned int hexb[] = {
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 1, 2, 3, 4, 5, 6, 7,
    8, 9, 0, 0, 0, 0, 0, 0,
    0, 10, 11, 12, 13, 14, 15, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 10, 11, 12, 13, 14, 15, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0
};

static uint64_t CBIG_NUM_MASK = 0x0ffffffff;



int cbig_num_cmp(cbig_num_t a, cbig_num_t b) {

    int i;

    for(i = 0; i < CBIG_NUM_SIZE; i++) {
        if(a.d[i] > b.d[i]) {
            return 1;
        } else if(a.d[i] < b.d[i]) {
            return -1;
        }
    }

    return 0;
}

int cbig_num_length(cbig_num_t *a) {
    int i;
    //����ǰ0
    for(i = 0; i < CBIG_NUM_SIZE-1; i++) {
        if(a->d[i] != 0) {
            break;
        }
    }

    return CBIG_NUM_SIZE - i;
}

//ע�����b���ΪCBIG_NUM_MASK+1
cbig_num_t cbig_num_add(cbig_num_t a, uint64_t b) {
    cbig_num_t c;

    int i, length;
    uint64_t carry = b, t;

    bzero(&c, sizeof(c));
    length = CBIG_NUM_SIZE - cbig_num_length(&a) - 1; //�н�λ

    for(i = CBIG_NUM_SIZE-1; i >= length; i--) {
        t = carry + a.d[i];
        if(t <= CBIG_NUM_MASK) {
            c.d[i] = t;
            carry = 0;
        } else {
            c.d[i] = t - CBIG_NUM_MASK - 1;
            carry = 1;
        }
    }

    return c;
}

cbig_num_t cbig_num_add2(cbig_num_t a, cbig_num_t b) {
    cbig_num_t c;
    int i, length;
    uint64_t carry = 0, t;

    bzero(&c, sizeof(c));
    length = CBIG_NUM_SIZE - MAX(cbig_num_length(&a), cbig_num_length(&b)) - 1; //�н�λ

    for(i = CBIG_NUM_SIZE - 1; i >= length; i--) {
        t = carry + a.d[i] + b.d[i]; //ע��
        if(t <= CBIG_NUM_MASK) {
            c.d[i] = t;
            carry = 0;
        } else {
            c.d[i] = t - CBIG_NUM_MASK - 1;
            carry = 1;
        }
    }

    return c;
}

cbig_num_t cbig_num_sub(cbig_num_t a, cbig_num_t b) {
    cbig_num_t c;
    int i, length;
    uint64_t borrow = 0;

    bzero(&c, sizeof(c));
    length = CBIG_NUM_SIZE - MAX(cbig_num_length(&a), cbig_num_length(&b));

    if(b.d[0] == CBIG_NUM_MASK) {
    } else {
        for(i = CBIG_NUM_SIZE - 1; i >= length; i--) {
            if(a.d[i] >= b.d[i] + borrow) {
                c.d[i] = a.d[i] - b.d[i] - borrow;
                borrow = 0;
            } else {
                c.d[i] = (CBIG_NUM_MASK + 1) + a.d[i] - b.d[i] - borrow;
                borrow = 1;
            }
        }
    }

    return c;
}

//ע�����b���ΪCBIG_NUM_MASK+1
cbig_num_t cbig_num_mul(cbig_num_t a, uint64_t b) {
    cbig_num_t c;

    int i, length;
    uint64_t carry = 0, t;

    bzero(&c, sizeof(c));
    length = CBIG_NUM_SIZE - cbig_num_length(&a) - 1; //�н�λ

    for(i = CBIG_NUM_SIZE - 1; i >= length; i--) {
        t = a.d[i] * b + carry;
        c.d[i] = t % (CBIG_NUM_MASK + 1);
        carry = t / (CBIG_NUM_MASK + 1);
    }

    return c;
}


cbig_num_t cbig_num_mul2(cbig_num_t a, cbig_num_t b) {
    cbig_num_t c;

    int i, length;

    bzero(&c, sizeof(c));
    length = CBIG_NUM_SIZE - MAX(cbig_num_length(&a), cbig_num_length(&b)) - 1; //�н�λ

    for(i = CBIG_NUM_SIZE - 1; i >= length; i--) {
        c = cbig_num_add2(c, cbig_num_mul(a, b.d[i]));
        a = cbig_num_mul(a, CBIG_NUM_MASK + 1);
    }

    return c;
}

cbig_num_t cbig_num_div(cbig_num_t a, uint64_t b) {
    cbig_num_t c;
    int i, length;
    uint64_t borrow = 0, t;

    bzero(&c, sizeof(c));
    length = CBIG_NUM_SIZE - cbig_num_length(&a);

    for(i = length; i < CBIG_NUM_SIZE; i++) {
        t = (borrow << 32) + a.d[i];
        c.d[i] = t / b;
        borrow = t % b;
    }

    return c;
}


cbig_num_t cbig_num_div2(cbig_num_t a, cbig_num_t b) {
    cbig_num_t c, t, count;
    int tl, bl, len;
    uint64_t div, num;

    bzero(&c, sizeof(c));

    t = a;
    while(cbig_num_cmp(t, b) > 0) {
        tl = cbig_num_length(&t);
        bl = cbig_num_length(&b);
        len = tl - bl;


        div = t.d[CBIG_NUM_SIZE-tl];
        num = b.d[CBIG_NUM_SIZE-bl];

        if(div <= num && len > 0) {
            len --;
            div = (div << 32) + t.d[CBIG_NUM_SIZE-tl+1];
        }

        div = div / (num + 1);

        bzero(&count, sizeof(count));
        count.d[CBIG_NUM_SIZE-1] = div;
        while(len -- > 0) {
            count = cbig_num_mul(count, CBIG_NUM_MASK+1);
        }

        t = cbig_num_sub(t, cbig_num_mul2(b, count));
        c = cbig_num_add2(c, count);
    }

    if(cbig_num_cmp(t, b) == 0) {
        t = cbig_num_sub(t, b);
        c = cbig_num_add(c, 1);
    }

    return c;
}


cbig_num_t cbig_num_mod(cbig_num_t a, cbig_num_t b) {
    cbig_num_t c, t, count;
    int tl, bl, len;
    uint64_t div, num;

    bzero(&c, sizeof(c));

    t = a;
    while(cbig_num_cmp(t, b) > 0) {
        tl = cbig_num_length(&t);
        bl = cbig_num_length(&b);
        len = tl - bl;

        div = t.d[CBIG_NUM_SIZE-tl];
        num = b.d[CBIG_NUM_SIZE-bl];

        if(div <= num && len > 0) {
            len --;
            div = (div << 32) + t.d[CBIG_NUM_SIZE-tl+1];
        }

        div = div / (num + 1);

        bzero(&count, sizeof(count));
        count.d[CBIG_NUM_SIZE-1] = div;
        while(len -- > 0) {
            count = cbig_num_mul(count, CBIG_NUM_MASK+1);
        }

        t = cbig_num_sub(t, cbig_num_mul2(b, count));
        c = cbig_num_add2(c, count);
    }

    if(cbig_num_cmp(t, b) == 0) {
        t = cbig_num_sub(t, b);
        c = cbig_num_add(c, 1);
    }

    return t;
}


cbig_num_t cbig_num_parse(char *s, int system) {
    cbig_num_t a;
    int i;
    size_t sl = strlen(s);

    bzero(&a, sizeof(a));

    for(i = 0; i < sl; i++) {
        a = cbig_num_mul(a, system);
        a = cbig_num_add(a, hexb[(int)s[i]]);
    }

    return a;
}


int cbig_num_to_bin(cbig_num_t *a, char *buf, size_t buf_size) {
    int i, length = CBIG_NUM_SIZE - cbig_num_length(a);
    int buf_offset = 0;
	
    for(i = length; i < CBIG_NUM_SIZE && buf_offset+4 <= buf_size; i++,buf_offset+=4) {
        u32_to_bytes(a->d[i], buf+buf_offset);
    }

	return buf_offset;
}


void cbig_num_print(cbig_num_t a, char *info) {
    int i;
    //����ǰ0
    for(i = 0; i < CBIG_NUM_SIZE-1; i++) {
        if(a.d[i] != 0) {
            break;
        }
    }

    fprintf(stderr, "%s[", info == NULL ? "" : info);
    for(; i < CBIG_NUM_SIZE; i++) {
        fprintf(stderr, "%08x", a.d[i]);
    }
    fprintf(stderr, "]\n");
    fflush(stderr);
}

