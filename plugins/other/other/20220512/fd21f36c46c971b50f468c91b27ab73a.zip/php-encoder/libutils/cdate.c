#include <time.h>

#include "cdefs.h"

struct tm cdate_now()
{
	time_t tt;
	struct tm local_time;

	time(&tt);
	localtime_r(&tt, &local_time);

	return local_time;
}

void cdate_strftime(struct tm *t, char *format, char *buf, size_t buf_size)
{
	CHECK(t == NULL, );
	CHECK(format == NULL, );
	CHECK(buf == NULL, );
	CHECK(buf_size <= 0, );
	
	buf[0] = '\0';
	strftime(buf, buf_size, format, t);
}

void cdate_now_date(char *buf, size_t buf_size)
{
    struct tm now = cdate_now();
	cdate_strftime(&now, "%Y%m%d", buf, buf_size);
}

void cdate_now_datetime(char *buf, size_t buf_size)
{
    struct tm now = cdate_now();
	cdate_strftime(&now, "%Y/%m/%d %H:%M:%S", buf, buf_size);
}

