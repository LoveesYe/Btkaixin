
#include "php_encoder.h"
#include "include/confighelper.h"
#include "include/md5.h"
#include "libutils/csha256.c"
#include "libutils/csha1.h"
#include "libutils/csha1.c"
#include "libutils/try.h"
#include "include/aes.c"
#include "include/aes_crypt.c"
#include "include/file.c"
#include "include/string.c"

#ifndef DOMARK
#define DOMARK 0
#endif

#define CAKEY2 DSFSDFSDFSCSDFDSFDF

char *_key;
char *SafeKey = STR2(CAKEY);
char *encode_mode = STR2(ENCODE_MODE);
int encode_key_mode = (int)ENCODE_KEY_MODE;
char digest[128];
int keylen = (int)KEYLEN;
uint8_t key[256];
char *_encodekey(char *__key)
{

    if (DEBUG)
    {
        printf("ENCODE_MODE:%s\n", encode_mode);
        printf("ENCODE_KEY_MODE:%d\n", encode_key_mode);
    }

    if (strncmp(encode_mode, "sha256", 6) == 0)
    {
        bzero(digest, sizeof(digest));
        return csha256_hash(digest, __key, NULL);
    }
    else if (strncmp(encode_mode, "sha1", 4) == 0)
    {
        bzero(digest, sizeof(digest));
        return csha1_hash(digest, __key, 0, NULL); // 0,1,31,56,64
    }
    // else if(encode_key_mode==1)
    // {
    //      bzero(digest, sizeof(digest));
    //      return csha1_hash(digest, __key, 0, NULL); // 0,1,31,56,64
    // }
    else
    {
        return md5(__key);
    }
}
int char2uint(char *input, uint8_t *output)
{
    for (int i = 0; i < 24; i++)
    {
        output[i] &= 0x00;
        for (int j = 1; j >= 0; j--)
        {
            char hb = input[i * 2 + 1 - j];
            if (hb >= '0' && hb <= '9')
            {
                output[i] |= (uint8_t)((hb - '0') << (4 * j));
            }
            else if (hb >= 'a' && hb <= 'f')
            {
                output[i] |= (int8_t)((hb - 'a' + 10) << (4 * j));
            }
            else if (hb >= 'A' && hb <= 'F')
            {
                output[i] |= (int8_t)((hb - 'A' + 10) << (4 * j));
            }
            else
            {
                return -1;
            }
        }
    }
    return 0;
}
int getkey(uint8_t *_encodekeystr, int len)
{
    char *encode_key = STR2(CAKEY2);
    bzero(_encodekeystr, len);
    memset(_encodekeystr, 0, len);
    memcpy(_encodekeystr, encode_key, len);
   
    if (DEBUG)
    {
        printf("_encodekeystr:%s\n", _encodekeystr);
        printf("len:%d\n", len);
        printf("SafeKey:%s\n", SafeKey);
    }
    return len;
}

char *encodekey(char *__key)
{
    char *datap = _encodekey(__key);
    //判断是否是无特征模式
    if (encode_key_mode == 0)
    {

        if (DEBUG)
        {
            printf("特征模式:%s\n", datap);
        }
        return datap;
    }

    // //无特征模式
    // uint8_t _encodekeystr[128];
    // int datalen = sizeof(datap);
    // getkey(_encodekeystr, sizeof(_encodekeystr));
    // code_aes(1, datap, datalen, _encodekeystr, &datalen);
    // if (DEBUG)
    // {
    //     printf("无特征模式:%s", _encodekeystr);
    // }
    //  printf("%s", _encodekeystr);
    return datap;
}

char mark[300];
char *getmark()
{
    sprintf(mark, "MARK%sMARK", STR2(CAKEY));
    sprintf(mark, "<?php if(!defined('%s')) {define('%s','%s');}?>\n", STR2(APPNAME), STR2(APPNAME), encodekey(mark));
    return mark;
}
