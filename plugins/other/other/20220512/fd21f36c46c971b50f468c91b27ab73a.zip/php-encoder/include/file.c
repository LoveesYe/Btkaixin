#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <time.h>
typedef struct Config
{
    long size;
    char *item[10];
} Config;

Config nofiles;
Config readtext(const char *filename)
{
    long ret, i = 0;
    FILE *stream;
    Config cfg;
    if ((stream = fopen(filename, "r")) == NULL)
        printf("The file %s was not opened\n", filename);
    else
    {
        char buf[100];
        while ((ret = fscanf(stream, "%s", buf) != EOF))
        {
            if (strncmp(buf, "#", 1) != 0)
            {

                // *cfg.item = (char*)malloc((i + 1) * sizeof(char));
                cfg.item[i] = (char *)malloc(sizeof(buf));
                sprintf(cfg.item[i], "%s", buf);
                // printf("%d %s %d %d \n",i, cfg.item[i], strlen(cfg.item[i]), ret);
                i++;
            }
        }
        fclose(stream);
        fflush(stream);
    }
    cfg.size = i;
    return cfg;
}

int write_log (const char *format, ...) {
    va_list arg;
    int done;
    FILE* pFile;
    pFile = fopen("/logs.log", "a");
    va_start (arg, format);
    //done = vfprintf (stdout, format, arg);
    time_t time_log = time(NULL);
    struct tm* tm_log = localtime(&time_log);
    fprintf(pFile, "%04d-%02d-%02d %02d:%02d:%02d ", tm_log->tm_year + 1900, tm_log->tm_mon + 1, tm_log->tm_mday, tm_log->tm_hour, tm_log->tm_min, tm_log->tm_sec);

    done = vfprintf (pFile, format, arg);
    va_end (arg);

    fflush(pFile);
    return done;
}