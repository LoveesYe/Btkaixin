#include <stdio.h>
#include <string.h>
int strpos(char *haystack, const char *needle)
{
    char *p;
    p = strstr(haystack, needle);
    if (p)
    {
        return p - haystack;
    }
    return -1;
}

int substr(char *haystack, int start, int len, char *out)
{
    int i;
    for (i = 0; i < len; i++)
    {
        out[i] = haystack[start + i];
    }
    return 0;
}

char * replace (const char *str, const char *src, const char *dst)
{
const char* pos = str;
int count = 0;
while ((pos = strstr (pos, src))) {
count ++;
pos += strlen(src);
}

size_t result_len = strlen(str) + (strlen(dst) - strlen(src)) * count + 1;
char *result = (char *)malloc(result_len);
memset (result, 0, result_len);

const char *left = str;
const char *right = NULL;

while ((right = strstr(left, src))) {
strncat (result, left, right - left);
strcat (result, dst);
right += strlen(src);
left = right;
}
strcat(result, left);
return result;
}