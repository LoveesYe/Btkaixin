var php_plugs = {
    backup_site_view: function (config, callback) {
        bt_tools.open({
            title: '备份站点&nbsp;-&nbsp;[&nbsp;' + config.name + '&nbsp;]',
            area: '720px',
            btn: false,
            skin: 'bt_backup_table',
            content: '<div id="bt_backup_table" class="pd20" style="padding-bottom:40px;"></div>',
            success: function () {
                var backup_table = bt_tools.table({
                    el: '#bt_backup_table',
                    url: '/data?action=getData',
                    param: {
                        table: 'backup',
                        search: config.id,
                        type: '0'
                    },
                    default: "[" + config.name + "] 站点备份列表为空", //数据为空时的默认提示
                    column: [{
                            type: 'checkbox',
                            class: '',
                            width: 20
                        },
                        {
                            fid: 'name',
                            title: '文件名',
                            width: 320,
                            fixed: true
                        },
                        {
                            fid: 'size',
                            title: '文件大小',
                            width: 80,
                            type: 'text',
                            template: function (row, index) {
                                return bt.format_size(row.size);
                            }
                        },
                        {
                            fid: 'addtime',
                            width: 150,
                            title: '备份时间'
                        },
                        {
                            title: '操作',
                            type: 'group',
                            width: 160,
                            align: 'right',
                            group: [{
                                title: '下载',
                                template: function (row, index, ev, key, that) {
                                    return '<a target="_blank" class="btlink" href="/download?filename=' + row.filename + '&amp;name=' + row.name + '">下载</a>';
                                }
                            }, {
                                title: '恢复',
                                template: function (row, index, ev, key, that) {
                                    return '<a target="_self" class="btlink" href="javascript:plugs.restore(\'' + row.name + '\',\'' + row.filename + '\',\'' + config.path + '\');">恢复</a>';
                                }
                            },{
                                title: '删除',
                                event: function (row, index, ev, key, that) {
                                    that.del_site_backup({
                                        name: row.name,
                                        id: row.id
                                    }, function (rdata) {
                                        bt_tools.msg(rdata);
                                        if (rdata.status) {
                                            // site_table.$modify_row_data({
                                            //     backup_count: site_table.event_rows_model.rows.backup_count - 1
                                            // });
                                            plugs.get_sites();
                                            that.$refresh_table_list();
                                        }
                                    });
                                }
                            }]
                        }
                    ],
                    methods: {
                        /**
                         * @description 删除站点备份
                         * @param {object} config 
                         * @param {function} callback
                         */
                        del_site_backup: function (config, callback) {
                            bt.confirm({
                                title: '删除站点备份',
                                msg: '删除站点备份[' + config.name + '],是否继续？'
                            }, function () {
                                bt_tools.send('site/DelBackup', {
                                    id: config.id
                                }, function (rdata) {
                                    if (callback) callback(rdata);
                                }, true);
                            });
                        }
                    },
                    success: function () {
                        if (callback) callback();
                        $('.bt_backup_table').css('top', (($(window).height() - $('.bt_backup_table').height()) / 2) + 'px');
                    },
                    tootls: [{ // 按钮组
                        type: 'group',
                        positon: ['left', 'top'],
                        list: [{
                            title: '备份站点',
                            active: true,
                            event: function (ev, that) {
                                bt.site.backup_data(config.id, function (rdata) {
                                    bt_tools.msg(rdata);
                                    if (rdata.status) {
                                        // site_table.$modify_row_data({
                                        //     backup_count: site_table.event_rows_model.rows.backup_count + 1
                                        // });
                                        plugs.get_sites();
                                        that.$refresh_table_list();
                                    }
                                });
                            }
                        }]
                    }, {
                        type: 'batch',
                        positon: ['left', 'bottom'],
                        config: {
                            title: '删除',
                            url: '/site?action=DelBackup',
                            paramId: 'id',
                            load: true,
                            callback: function (that) {
                                bt.confirm({
                                    title: '批量删除站点备份',
                                    msg: '是否批量删除选中的站点备份，是否继续？',
                                    icon: 0
                                }, function (index) {
                                    layer.close(index);
                                    that.start_batch({}, function (list) {
                                        var html = '';
                                        for (var i = 0; i < list.length; i++) {
                                            var item = list[i];
                                            html += '<tr><td><span class="text-overflow" title="' + item.name + '">' + item.name + '</span></td><td><div style="float:right;"><span style="color:' + (item.request.status ? '#20a53a' : 'red') + '">' + item.request.msg + '</span></div></td></tr>';
                                        }
                                        backup_table.$batch_success_table({
                                            title: '批量删除站点备份',
                                            th: '文件名',
                                            html: html
                                        });
                                        backup_table.$refresh_table_list(true);
                                        plugs.get_sites();
                                        // site_table.$modify_row_data({
                                        //     backup_count: site_table.event_rows_model.rows.backup_count - list.length
                                        // });
                                    });
                                });
                            }
                        } //分页显示
                    }, {
                        type: 'page',
                        positon: ['right', 'bottom'], // 默认在右下角
                        pageParam: 'p', //分页请求字段,默认为 : p
                        page: 1, //当前分页 默认：1
                        numberParam: 'limit',
                        //分页数量请求字段默认为 : limit
                        number: 10,
                        //分页数量默认 : 20条
                    }]
                });
            }
        });
    },
}