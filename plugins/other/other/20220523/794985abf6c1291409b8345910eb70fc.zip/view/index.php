<select class="bt-input-text" style="width: 200px">
    <option>333</option>
    <option>2</option>
    <option><?php echo 555; ?></option>
</select>
