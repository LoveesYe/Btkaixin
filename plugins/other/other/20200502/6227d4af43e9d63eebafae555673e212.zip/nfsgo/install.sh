#!/bin/bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH
install_tmp='/tmp/bt_install.pl'
public_file='/www/server/panel/install/public.sh'
download_Url='http://bt.02988.com'
pluginPath='/www/server/panel/plugin/nfsgo'

Install()
{
	
	echo '正在安装...'
	#==================================================================
	if [ -f "/usr/bin/yum" ] && [ -f "/usr/bin/rpm" ]; then
	    isInstall=`rpm -qa |grep nfs-utils`
		if [ "$isInstall" == "" ];then
		   yum install nfs-utils -y
		fi
	elif [ -f "/usr/bin/apt-get" ]; then
	  	isInstall=`dpkg -l|grep nfs`
		if [ "$isInstall" == "" ];then
		  sudo apt-get install  nfs-common -y
		fi
	   
	   
	fi
	#依赖安装结束
	#==================================================================
	wget -O ${pluginPath}/index.html $download_Url/nfsgo/index.html -T 5
	wget -O ${pluginPath}/info.json $download_Url/nfsgo/info.json -T 5
	wget -O ${pluginPath}/nfsgo_main.py $download_Url/nfsgo/nfsgo_main.py -T 5
	wget -O ${pluginPath}/icon.png $download_Url/nfsgo/icon.png -T 5
    wget -O ${pluginPath}/install.sh $download_Url/nfsgo/install.sh -T 5

	\cp -a -r ${pluginPath}/icon.png /www/server/panel/BTPanel/static/img/soft_ico/ico-nfsgo.png
	echo '================================================'
	echo '安装完成'
}

Uninstall()
{
	rm -rf $pluginPath
}

#操作判断
if [ "${1}" == 'install' ];then
	Install
elif [ "${1}" == 'uninstall' ];then
	Uninstall
else
	echo 'Error!';
fi
