# coding: utf-8
# 云文件服务NFS NAS CFS挂载
# Author: linuxxp
import sys, os
import time
if sys.version_info[0] == 2:
    reload(sys)
    sys.setdefaultencoding('utf-8')
os.chdir('/www/server/panel');
sys.path.append("class/")
import  public, json,re

class nfsgo_main(object):
    __path='/www/server/panel/plugin/nfsgo'
    __path_sh='/www/server/panel/plugin/nfsgo/nfsgo.sh'
    __nfs_list =__path+'/nfslist.json'
    __nfsall=[]
    # 填写信息
    def GetUser(self,get):
        nfsadd=get.nfsadd.strip()
        nfsdir=get.nfsdir.strip()
        nfstype=get.nfstype.strip()
        path = get.path.strip()
        uid=public.ExecShell('id -u www')[0].replace("\n","")
        gid=public.ExecShell('id -g www')[0].replace("\n","")
        if not uid or not gid:return public.returnMsg(False,'www用户不存在，请安装web服务')
        if not nfsadd or not nfsdir or  not path:return public.returnMsg(False,'请填写完整信息')
        pathcheck=self.Check_Dir(path)
        if pathcheck[0]==0:
            return  public.returnMsg(False,pathcheck[1])
        mcheck=self.Check_Dir(path)
        data=self.ReadConfig(self)
        for i in range(len(data)):
            if (data[i]["nfsadd"]==nfsadd and data[i]["nfsdir"]==nfsdir):return public.returnMsg(False,'该NFS已经添加')
        ret=self.Mount(nfsadd,nfsdir,nfstype,path)
        return ret

    
    def Check_Dir(self,inpath):
       if inpath in('/,/run,/root,/boot,/usr,/bin,/etc,/proc,/var,/sys,/sbin,/lib,/lib64,/mnt,/media,/dev,/srv,/tmp,/run,/patch'):
       	   return 0,"不可挂载系统目录"
       if not os.path.exists(inpath):
           return 0,'挂载目录不存在'
       if os.listdir(inpath):
          return 0,'挂载目录必须有空，请移除相关内容'
       temp = public.ExecShell("df -h -P|grep '/'|grep -v tmpfs")[0];
       if inpath in (temp):
       	   return 0,'%s目录已经挂载' % inpath
       bosBody = self.ReadConfig(self)
       for i in range(len(bosBody)):
            if bosBody[i]["path"]==inpath:return 0,'%s目录已添加' % inpath
       return 1,'scuess'
    
    def Mount(self,nadd,ndir,ntype,path):
        if not os.path.exists(path):
            public.ExecShell("mkdir %s" % path)
            public.ExecShell("chmod 777 %s" % path)
            public.ExecShell("chown www:www %s" % path)
        ret=self.Check_nfsgo()
        if not ret:return ret
        retc='mount -t nfs -o %s %s:%s %s'%(ntype,nadd,ndir,path);
        public.ExecShell(retc)
        check=self.CheckMount(path)
        if not check:
            return public.returnMsg(False,'挂载失败')
        else:
            data=self.ReadConfig(self)
            nfs_info = {
                "nfsadd": nadd,
                "nfsdir": ndir,
                "nfstype": ntype,
                "path": path,
            }
            if not os.path.exists(self.__path_sh):
                public.writeFile(self.__path_sh, '#!/bin/sh')
                public.ExecShell('chown www:www %s'%self.__path_sh)
            ShBody = public.readFile(self.__path_sh)
            public.ExecShell('chmod +x %s'%self.__path_sh)
            if not ShBody: ShBody = '#!/bin/sh'
            retcall="%s\n%s"%(ShBody,retc)
            public.writeFile(self.__path_sh,retcall)
            data.append(nfs_info)
            public.writeFile(self.__nfs_list,json.dumps(data))
            self.ChekcInit()
            return public.returnMsg(True,'挂载%s成功'%path)

    # 开机自启动
    def ChekcInit(self):
        if  os.path.exists(self.__path_sh):
            if not os.path.exists("/etc/rc.local"):
            	public.ExecShell("echo '#!/bin/bash' >>/etc/rc.local")
            rc_local='/etc/rc.local';
            public.ExecShell("chmod +x /etc/rc.local")
            rcinit=public.readFile(rc_local)
            ret=self.__path_sh
            check_local=re.findall(ret,rcinit)
            if not check_local:
                public.ExecShell("echo 'bash %s'>>/etc/rc.local"%ret)

    # 卸载的时候去掉
    def Delsh(self):
        if os.path.exists('/etc/rc.local'):
           strartde = public.ReadFile('/etc/rc.local')
           Newstrart =''
           host = strartde.split("\n")
           for _host in host:
                    if _host not in('bash %s'%self.__path_sh): Newstrart=Newstrart+_host+"\n"
           public.WriteFile('/etc/rc.local',Newstrart)

    # 验证是否挂载成功
    def CheckMount(self,path):
        temp = public.ExecShell("df -h -P|grep '/'|grep -v tmpfs")[0];
        tempdisk = temp.split('\n');
        for tmp in tempdisk:
            if tmp!='':	
         	     disk=tmp.split(); 
         	     if disk[5]==path:return True;
        return False

    # 状态
    def GetStatus(self,get):
        info=self.GetBosInfo(get)
        return info

    # 查看nfsgo 是否安装
    def Check_nfsgo(self):
        ret=public.ExecShell('rpm -qa |grep nfs-utils')[0]
        if "nfs-utils" not in(ret):return public.returnMsg(False,'未安装NFS插件')
        return True

    # 卸载
    def Umount(self,get):
        if not os.path.exists(self.__nfs_list):
            return public.returnMsg(False,'未配置相关挂载信息')
        inpath= get.diskid.strip()
        data=self.ReadConfig(self)
        for i in range(len(data)):
        	  if data[i]["path"]==inpath:
            	   path=data[i]["path"]
            	   nfsdir=data[i]["nfsdir"]
            	   ntype=data[i]["nfstype"]
            	   nadd=data[i]["nfsadd"]
            	   delindex=i
        del (data[delindex])
        retc='mount -t nfs -o %s %s:%s %s'%(ntype,nadd,nfsdir,path);
        if len(data) <1:self.Delsh()
        public.writeFile(self.__nfs_list,json.dumps(data))
        if os.path.exists(self.__path_sh):
            shde = public.ReadFile(self.__path_sh)
            Newsh = ""
            shall = shde.split("\n")
            for _host in shall:
                if  retc not in(_host) and _host!='' : Newsh=Newsh+"\n"+_host
            public.WriteFile(self.__path_sh,Newsh)
        
        if path=='':
            return public.returnMsg(False,'未挂载')
        public.ExecShell('fusermount -u %s'%path)
        public.ExecShell('umount %s'%path)
        check=self.CheckMount(path)
        if not check:return public.returnMsg(True,'卸载成功')
        if check: return public.returnMsg(False,'卸载失败，磁盘被占用,检查磁盘后尝试：例如:lsof /bdnfs')
        return public.returnMsg(True,'卸载成功')

    # 查看信息
    def GetBosInfo(self,get):
        if not os.path.exists(self.__nfs_list):
            return public.returnMsg(False, '')
        bos_info = json.loads(public.readFile(self.__nfs_list))
        for i in range(len(bos_info)):
            disksta=self.CheckMount(bos_info[i]["path"])
            if disksta :bos_info[i]["status"]=1
            else:bos_info[i]["status"]=0
        
        
        return bos_info

    def FlushDisk(self,get):
        if not os.path.exists(self.__path_sh):
            return public.returnMsg(False, '无挂载对象')
        flumes=public.ExecShell(self.__path_sh)[0]
        return public.returnMsg(True, '重新挂载完毕')

        # 读取配置
    def ReadConfig(self,get):
        if not os.path.exists(self.__nfs_list):
            public.writeFile(self.__nfs_list, '[]')
        bosBody = public.readFile(self.__nfs_list)
        if not bosBody: bosBody = '[]'
        data=json.loads(bosBody)
        return data
