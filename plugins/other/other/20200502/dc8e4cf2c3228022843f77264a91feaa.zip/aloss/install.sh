#!/bin/bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH
install_tmp='/tmp/bt_install.pl'
public_file='/www/server/panel/install/public.sh'
download_Url='http://bt.02988.com'
pluginPath='/www/server/panel/plugin/aloss'

Install()
{
	
	echo '正在安装...'
	#==================================================================
	#依赖安装开始
    if [ -f "/usr/local/bin/ossfs" ] || [ -f "/usr/bin/ossfs" ];then
       echo '环境已经安装...' > $install_tmp
    else
       echo '正在安装脚本文件...' > $install_tmp
	   mkdir -p ${pluginPath}
	   egrep -i "debian" /etc/issue /proc/version >/dev/null && SysName='Debian';
	   egrep -i "ubuntu" /etc/issue /proc/version >/dev/null && SysName='Ubuntu';
	   whereis -b yum | grep -q '/yum' && SysName='CentOS';
	   if [ "$SysName" == 'CentOS' ]; then
                wget http://gosspublic.alicdn.com/ossfs/ossfs_1.80.6_centos7.0_x86_64.rpm;
	        sudo yum -y localinstall ossfs_1.80.6_centos7.0_x86_64.rpm;
	        rm -fr ossfs_1.80.6_centos7.0_x86_64.rpm
	   else
	       wget http://gosspublic.alicdn.com/ossfs/ossfs_1.80.6_ubuntu18.04_amd64.deb
	       sudo apt-get -y update
               sudo apt-get -y install gdebi-core
               sudo dpkg -i ossfs_1.80.6_ubuntu18.04_amd64.deb
	       rm -fr ossfs_1.80.6_ubuntu18.04_amd64.deb
	   fi;
       echo '安装完成' > $install_tmp
   fi
	#依赖安装结束
	#==================================================================
	wget -O ${pluginPath}/index.html $download_Url/aloss/index.html -T 5
	wget -O ${pluginPath}/info.json $download_Url/aloss/info.json -T 5
	wget -O ${pluginPath}/aloss_main.py $download_Url/aloss/aloss_main.py -T 5
	wget -O ${pluginPath}/icon.png $download_Url/aloss/icon.png -T 5
        wget -O ${pluginPath}/install.sh $download_Url/aloss/install.sh -T 5
	\cp -a -r ${pluginPath}/icon.png /www/server/panel/BTPanel/static/img/soft_ico/ico-aloss.png
	echo '================================================'
	echo '安装完成'
}

Uninstall()
{
	rm -rf $pluginPath
}

#操作判断
if [ "${1}" == 'install' ];then
	Install
elif [ "${1}" == 'uninstall' ];then
	Uninstall
else
	echo 'Error!';
fi
