# coding: utf-8
# 阿里云存储对象OSS挂载
# Author: linuxxp
import sys, os
import time
if sys.version_info[0] == 2:
    reload(sys)
    sys.setdefaultencoding('utf-8')
os.chdir('/www/server/panel');
sys.path.append("class/")
import  public, json,re

class aloss_main(object):
    __path='/www/server/panel/plugin/aloss'
    __path_sh='/www/server/panel/plugin/aloss/aloss.sh'
    __oss_list =__path+'/uboslist.json'
    __ossall=[]
    # 填写信息
    def GetUser(self,get):
        '''
        传入三个值:
        my-bucket (这个是oss的一个Backet名称)
        :my-access-key-id  (这个是OSS 的key_id)
        :my-access-key-secret (这个是oss的 key)
        :path 需要挂载的目录
        :registy 挂载的一个url

        :param get:
        :return:
        '''
        backet=get.backet.strip()
        access_id=get.access_id.strip()
        access_key=get.access_key.strip()
        path = get.path.strip()
        registy = get.registy.strip()
        uid=public.ExecShell('id -u www')[0].replace("\n","")
        gid=public.ExecShell('id -g www')[0].replace("\n","")
        if not uid or not gid:return public.returnMsg(False,'www用户不存在，请安装web服务')
        comd=public.ExecShell('ossfs')[0]
        if not comd :return public.returnMsg(False,'插件未安装成功，请卸载插件，重新安装再试')
        if not backet or not access_id or not access_key or not path:return public.returnMsg(False,'请填写完整信息')
        if "http" in registy:return public.returnMsg(False,'域名填写错误，不需要http及bucket')
        pathcheck=self.Check_Dir(path)
        if pathcheck[0]==0:
            return  public.returnMsg(False,pathcheck[1])
        data=self.ReadConfig(self)
        for de in data:
            if de['backet']==backet:return public.returnMsg(False,'%s 该Bucket已经添加' % backet)
        ret=self.Mount(backet,path,registy,access_id,access_key)
        return ret

    
    def Check_Dir(self,inpath):
       if inpath in('/,/run,/root,/boot,/usr,/bin,/etc,/proc,/var,/sys,/sbin,/lib,/lib64,/mnt,/media,/dev,/srv,/tmp,/run,/patch'):
       	   return 0,"不可挂载系统目录"
       if not os.path.exists(inpath):
           return 0,'挂载目录不存在'
       if os.listdir(inpath):
          return 0,'挂载目录必须有空，请移除相关内容'
       temp = public.ExecShell("df -h -P|grep '/'|grep -v tmpfs")[0];
       if inpath in (temp):
       	   return 0,'%s目录已经挂载' % inpath
       bosBody = self.ReadConfig(self)
       for i in range(len(bosBody)):
            if bosBody[i]["path"]==inpath:return 0,'%s目录已添加' % inpath
       return 1,'scuess'
    
    def Mount(self,backet,path,oss_path,aid,akey):
        if not os.path.exists(path):
            return public.returnMsg(False,'挂载目录不存在')
        ret=self.Check_aloss()
        if not ret:return ret
        uid=public.ExecShell('id -u www')[0].replace("\n","")
        gid=public.ExecShell('id -g www')[0].replace("\n","")
        public.ExecShell('echo %s:%s:%s > /root/.passwd-%s'%(backet,aid,akey,backet))
        public.ExecShell('chmod 600 /root/.passwd-%s'%(backet))
        retc='ossfs %s %s -o allow_other -o uid=%s,umask=000,gid=%s -o passwd_file=/root/.passwd-%s -o url=http://%s'%(backet,path,uid,gid,backet,oss_path);
        public.ExecShell(retc)
        time.sleep(1)
        check=self.CheckMount(path)
        if not check:
            return public.returnMsg(False,'挂载失败')
        else:
            data=self.ReadConfig(self)
            user_info = {
                "backet": backet,
                "access_id": aid,
                "access_key": akey,
                "path": path,
                "registy": oss_path
            }
            if not os.path.exists(self.__path_sh):
                public.writeFile(self.__path_sh, '#!/bin/sh')
                public.ExecShell('chmod +x %s'%self.__path_sh)
                public.ExecShell('chown www:www %s'%self.__path_sh)
            ShBody = public.readFile(self.__path_sh)
            if not ShBody: ShBody = '#!/bin/sh'
            retcall="%s\n%s"%(ShBody,retc)
            public.writeFile(self.__path_sh,retcall)
            data.append(user_info)
            public.writeFile(self.__oss_list,json.dumps(data))
            self.ChekcInit()
            return public.returnMsg(True,'挂载%s成功'%path)

    # 开机自启动
    def ChekcInit(self):
        if  os.path.exists(self.__path_sh):
            rc_local='/etc/rc.local'
            public.ExecShell("chmod +x /etc/rc.local")
            rcinit=public.readFile(rc_local)
            ret=self.__path_sh
            check_local=re.findall(ret,rcinit)
            if not check_local:
                public.ExecShell("echo 'bash %s'>>/etc/rc.local"%ret)

    # 卸载的时候去掉
    def Delsh(self):
        strartde = public.ReadFile('/etc/rc.local')
        Newstrart = ""
        host = strartde.split("\n")
        for _host in host:
          if _host not in('bash %s'%self.__path_sh): Newstrart=Newstrart+_host+"\n"
        print (Newstrart)
        public.WriteFile('/etc/rc.local',Newstrart)

    # 验证是否挂载成功
    def CheckMount(self,path):
        temp = public.ExecShell("df -h -P|grep '/'|grep -v tmpfs")[0];
        tempdisk = temp.split('\n');
        for tmp in tempdisk:
            if tmp!='':	
         	     disk=tmp.split(); 
         	     if disk[5]==path:return True;
        return False

    # 状态
    def GetStatus(self,get):
        info=self.GetBosInfo(get)
        return info

    # 查看aloss 是否安装
    def Check_aloss(self):
        ret=int(public.ExecShell('which ossfs |grep ossfs|wc -l')[0])
        if ret==0:return public.returnMsg(False,'未安装aloss')
        return True

    # 卸载
    def Umount(self,get):
        if not os.path.exists(self.__oss_list):
            return public.returnMsg(False,'未配置相关挂载信息')
        backet= get.diskid.strip()
        data=self.ReadConfig(self)
        for i in range(len(data)):
        	  if data[i]["backet"]==backet:
            	   path=data[i]["path"]
            	   delindex=i
        del (data[delindex])
        if len(data) <1:self.Delsh()
        if os.path.exists("/root/.passwd-%s" %backet):os.remove("/root/.passwd-%s" %backet)
        public.writeFile(self.__oss_list,json.dumps(data))
        if os.path.exists(self.__path_sh):
            shde = public.ReadFile(self.__path_sh)
            Newsh = ""
            shall = shde.split("\n")
            checksh='ossfs %s %s' % (backet,path)
            for _host in shall:
                if _host!="":
                    if  checksh not in(_host) : Newsh=Newsh+"\n"+_host
            public.WriteFile(self.__path_sh,Newsh)
        
        if path=='':
            return public.returnMsg(False,'未挂载')
        public.ExecShell('fusermount -u %s'%path)
        public.ExecShell('umount %s'%path)
        check=self.CheckMount(path)
        if not check:return public.returnMsg(True,'卸载成功')
        if check: return public.returnMsg(False,'卸载失败，磁盘被占用,检查磁盘后尝试：例如:lsof /bdoss')
        return public.returnMsg(True,'卸载成功')

    # 查看信息
    def GetBosInfo(self,get):
        if not os.path.exists(self.__oss_list):
            return public.returnMsg(False, '')
        bos_info = json.loads(public.readFile(self.__oss_list))
        for i in range(len(bos_info)):
            disksta=self.CheckMount(bos_info[i]["path"])
            if disksta :bos_info[i]["status"]=1
            else:bos_info[i]["status"]=0
        
        
        return bos_info

    def FlushDisk(self,get):
        if not os.path.exists(self.__path_sh):
            return public.returnMsg(False, '无挂载对象')
        flumes=public.ExecShell(self.__path_sh)[0]
        return public.returnMsg(True, '重新挂载完毕')

        # 读取配置
    def ReadConfig(self,get):
        if not os.path.exists(self.__oss_list):
            public.writeFile(self.__oss_list, '[]')
        bosBody = public.readFile(self.__oss_list)
        if not bosBody: bosBody = '[]'
        data=json.loads(bosBody)
        return data