#!/usr/bin/python
# coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# editor: mufei(ypdh@qq.com tel:15712150708)
'''
牧飞 _ __ ___   ___   ___  / _| ___(_)
| '_ ` _ \ / _ \ / _ \| |_ / _ \ |
| | | | | | (_) | (_) |  _|  __/ |
|_| |_| |_|\___/ \___/|_|  \___|_|
'''
#+--------------------------------------------------------------------
#|   宝塔第三方应用开发 mfftpdev
#+--------------------------------------------------------------------
import re
import os
import sys
import time
import logging
import json
import shutil
import traceback
import stat

#设置运行目录
basedir = os.path.abspath(os.path.dirname(__file__))
if ':' in basedir:
    basedir = basedir.split(':')[1].replace('\\','/').rstrip('/')
logfile = os.path.join(basedir, 'logs', 'mfftpdev.log')
logging.basicConfig(
    level = logging.INFO,
    format = '%(asctime)s %(filename)s[line:%(lineno)d] %(levelname)s %(message)s',
    datefmt = '%a, %d %b %Y %H:%M:%S',
    filename = logfile,
    filemode = 'a+'
)

try:
    import fcntl 
except:
    fcntl = None


def ExecShell(cmdstring, cwd=None, timeout=None, shell=True):
    a = ''
    e = ''
    try:
        #通过管道执行SHELL
        
        import datetime
        import subprocess
        
        cmdstring_list = cmdstring
        
        if timeout:
            end_time = datetime.datetime.now() + datetime.timedelta(seconds=timeout)
        sub = subprocess.Popen(cmdstring_list, cwd=cwd, stdin=subprocess.PIPE,shell=shell,bufsize=4096,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        while sub.poll() is None:
            time.sleep(0.1)
            if timeout:
                if end_time <= datetime.datetime.now():
                    raise Exception("Timeout：%s"%cmdstring)
        a,e = sub.communicate()
        try:
            if type(a) == bytes: a = a.decode('utf-8')
            if type(e) == bytes: e = e.decode('utf-8')
        except:pass
    except:
        if not a:
            a = os.popen(cmdstring).read()

    return a,e


def main(conf, src="", folder=""):
    
    
    for  k in conf['list']:
        if src and not folder:
            if k!=src: continue
        try:
            d = conf['list'][k].get('backupconf')
            if d:
                backfiles(d, conf['list'][k])
                logging.info(k+' finished')
        except:
            err = traceback.format_exc()
            logging.error(err)
            print(err)  

def fpath(f, isdir=0):
    if f[0]!='/':
        f=os.path.join(basedir, f)
    if isdir:
        f = f.rstrip('/')+'/'
    return f.replace('\\','/')
    
        
def backfiles(cfg, fscfg):
    
    src = cfg['srcPth'].replace('\\','/')
    backPth = cfg['backPth'].replace('\\','/')
    if not src or src=='/' and src[0]!='/':
        logging.error("srcPth:%s"%src)
        return 
    if not backPth or backPth=='/' and backPth[0]!='/':
        logging.error("backPth:%s"%backPth)
        return 
    if src==backPth or src.startswith(backPth.rstrip('/')+'/'):
        logging.error("backPth in srcPth:%s"%backPth)
        return

    _src = cfg['srcPth'].replace('\\','/').replace('/', '_').replace(' ', '')
    t = time.strftime('%Y%m%d%H%M%S',time.localtime())
    backdir = _src+'_'+t
    backjson = 'mfftpdev.'+t+'.json'
    #print backdir,backjson
    if not os.path.isdir(backPth):
        print(backPth+' path error')
        
        if not len(os.listdir(fscfg['local_dev'])):
            print (fscfg)
            if fscfg['serv_host'] not in ('0','0.0.0.0', ''):
                if fscfg['method'] == "ftp":
                    s = "curlftpfs -o codepage=utf8 ftp://%(serv_user)s:%(serv_pwd)s@%(serv_host)s%(serv_pth)s %(local_dev)s"%fscfg
                elif fscfg['method'] == "ssh":
                    fscfg['serv_host'] = fscfg['serv_host'].split(':')[0]
                    s = "sshfs -o ssh_command='sshpass -p %(serv_pwd)s ssh' -o cache=yes,allow_other %(serv_user)s@%(serv_host)s:%(serv_pth)s %(local_dev)s"%fscfg
                 
                err = ExecShell(s)
                print(s,err)
                if err[0]: 
                    logging.error(err[0])
                    return
            


    L = [k for k in os.listdir(backPth) if '_' in k ]
    L.sort(reverse=True)
    
    utime = 0
    for k in L:
        if not os.path.isdir(os.path.join(backPth, k)) : continue
        _t = k.split('_')[-1]
        _backjson = 'mfftpdev.'+_t+'.json'
        f = os.path.join(backPth, k, _backjson)
        if os.path.isfile(f):
            utime = time.strptime(_t, '%Y%m%d%H%M%S')
            utime = time.mktime(utime)
            break

    #print utime,L
        
    backdir = os.path.join(backPth, backdir)
    if not utime:
        shutil.copytree(src, backdir)
        os.chmod(backdir, stat.S_IRWXU+stat.S_IRWXG+stat.S_IRWXO)
        backjson = os.path.join(backdir, backjson)
        json.dump({},open(backjson,'w'))
        return 
    os.mkdir(backdir.replace('\\','/'))
    os.chmod(backdir, stat.S_IRWXU+stat.S_IRWXG+stat.S_IRWXO)
    
    exclude = cfg['exclude']
    excludes = {'path':[],'file':[], 're':[]}
    for line in exclude.split('\n'):
        f = line.split('#')[0].strip()
        if f:
            if '*' not in f:
                if '.' in f:
                    excludes['file'].append(fpath(f))
                else:
                    excludes['path'].append(fpath(f,1))
            else:
                f = f.replace('*','(.*)')
                if '.' in f:
                    excludes['re'].append(fpath(f))
                else:
                    excludes['re'].append(fpath(f,1))
    if cfg.get('is_maxsize') and cfg['maxsize']>0:
        fsize = cfg['maxsize']*1024*1024
    else:
        fsize = 0
    excludes['path'] = tuple(excludes['path'])
    
    
    n = 0
    for root, dirs, files in os.walk(src, True, None, False):
        
        for f in files:
            
            path = os.path.join(root,f).replace('\\','/')
            if not os.path.isfile(path): continue
            if utime and os.path.getmtime(path)<=utime: continue
            
            size = os.path.getsize(path)
            if size>=fsize>0: continue
            if excludes['file'] and path in  excludes['file']: continue
            elif excludes['path'] and path.startswith(excludes['path']): continue
            elif excludes['re']:
                a = 0
                for k in excludes['re']:
                    if re.match(k, path): a=1;break
                if a: continue
            n += 1
            _f = path.split(src, 1)[1].strip('/')
            file_dir = os.path.join(backdir, _f).rstrip('/')
            if '/' in _f and not os.path.isdir(os.path.dirname(file_dir)):
                os.makedirs(os.path.dirname(file_dir))
                os.chmod(os.path.dirname(file_dir), stat.S_IRWXU+stat.S_IRWXG+stat.S_IRWXO)
            shutil.copy(path,file_dir)
        
    if n==0:
        os.removedirs(backdir)
        logging.info("no update files:%s"%src)
    else:
        backjson = os.path.join(backdir, backjson)
        json.dump({},open(backjson,'w'))
            
if __name__ == '__main__':
    
    cfgfile = os.path.join(basedir, 'config.json')
    if not os.path.isfile(cfgfile):
        open(logfile,'a+').write('config error! %s\n'%time.ctime())
        sys.exit(1)
    conf = json.load(open(cfgfile))
    
    if fcntl:  
        fli = os.path.join(basedir,'mfftpdev.lock')
        fl = open(fli, "w")
        try:
            fcntl.flock(fl, fcntl.LOCK_EX | fcntl.LOCK_NB) #写锁
            fl.write(str(os.getpid()))
            fl.flush()
        except IOError:
            open(logfile,'a+').write('mfftpdev lock error! %s\n'%time.ctime())
            sys.exit(1)
                    
    
    if len(sys.argv)>1:
        src = sys.argv[1]
    else:
        src = ''
    #logging.error(str(sys.argv))
    main(conf, src)

    
    #if "--nolog" in sys.argv:
    

    if fcntl: 
        fcntl.flock(fl, fcntl.LOCK_UN | fcntl.LOCK_NB)
        fl.close()
        os.remove(fli)
        
    
    sys.exit(1)
    
    

