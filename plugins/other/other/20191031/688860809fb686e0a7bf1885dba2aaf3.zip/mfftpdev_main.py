#!/usr/bin/python
# coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# editor: mufei(ypdh@qq.com tel:15712150708)
'''
牧飞 _ __ ___   ___   ___  / _| ___(_)
| '_ ` _ \ / _ \ / _ \| |_ / _ \ |
| | | | | | (_) | (_) |  _|  __/ |
|_| |_| |_|\___/ \___/|_|  \___|_|
'''
#+--------------------------------------------------------------------
#|   宝塔第三方应用开发 mfftpdev
#+--------------------------------------------------------------------

__all__ = ['mfftpdev_main']

import sys,os,json,re,time,math

try:
    from urllib.parse import unquote
except:
    from urllib import unquote

#设置运行目录
basedir = os.path.abspath(os.path.dirname(__file__))
plugin_path = basedir

try:
    import platform
    inSystem = platform.system()
    
except:
    inSystem = ""
    

if __name__ != '__main__':
    #添加包引用位置并引用公共包
    sys.path.append("class/")
    import public
    from BTPanel import cache,session

    #设置缓存(超时10秒) cache.set('key',value,10)
    #获取缓存 cache.get('key')
    #删除缓存 cache.delete('key')

    #设置session:  session['key'] = value
    #获取session:  value = session['key']
    #删除session:  del(session['key'])
    


import codecs
 



class mfftpdev_main:
    __plugin_path = plugin_path
    __config = None
    __fs_pro_shell = "ps -ef |grep mfftpdev.py |grep -v grep | awk '{print $2}'"

    #构造方法
    def  __init__(self):
        ""
        self.__config = self.__get_config() or {'list':{}}


    def get_fs_pro(self):
        L = public.ExecShell(self.__fs_pro_shell)
        L = L[0].strip(),L[1]
        print(L)
        return L
    

    def set_backup(self,args):
        local_dev =  args.local_dev.strip()
        #print self.__config['list'][local_dev]
        return {'local_dev':local_dev, 'conf':self.__config['list'][local_dev]}
        
    #
    
    def SetFtpConfig(self, args):
        serv_host = args.serv_host.strip()
        serv_user = args.serv_user.strip()
        serv_pwd = args.serv_pwd.strip()
        serv_pth = '/'+args.serv_pth.strip().strip('/')
        local_dev = args.local_dev.strip()
        method = args.method.strip()
        assert method in ('ssh', 'ftp','smb', '0')
        
        if not local_dev or local_dev in self.__config.get('list',[]):
            return {"msg":"挂载路径有误或已挂载","status":0}
            
        if serv_host not in ('0','0.0.0.0', ''):
            if not local_dev or not os.path.isdir(local_dev)  or  os.listdir(local_dev) or local_dev[0]!='/':
                return {"msg":"挂载路径要求必须为存在的空目录","status":0}
            if method == "ftp":
                s = "curlftpfs -o codepage=utf8 ftp://%s:%s@%s%s %s"%(serv_user,serv_pwd,  serv_host, serv_pth, local_dev)
            elif method == "ssh":
                #s1 = "sudo groupadd fuse"
                #s2 = "sudo usermod -a -G fuse %s"%serv_user
                s = "sshfs -o ssh_command='sshpass -p %s ssh' -o cache=yes,allow_other %s@%s:%s %s"%(serv_pwd, serv_user, serv_host.split(':')[0], serv_pth, local_dev)
            err = public.ExecShell(s)
            #print(s)
            if err[1]:
                try:
                    error = err[1].decode('GBK')
                except:
                    error = err[1]
                return {"msg":error}
            
        self.__set_config(local_dev, {'serv_host':serv_host,
                                      'serv_user':serv_user,
                                      'serv_pwd':serv_pwd,
                                      'serv_pth':serv_pth,
                                      'local_dev':local_dev,
                                      'method':method,
                                      }
                          )

        return {"msg":"挂载成功，刷新中。。。","status":1}
        
        


    def SetBackupConfig(self, args):
        ""
        local_dev = args.local_dev.strip()
        is_devback = int(args.is_devback)
        is_zip = int(args.is_zip)
        srcPth = args.srcPth.strip()
        backPth = args.backPth.strip()
        is_maxsize = int(args.is_maxsize.strip())
        maxsize = int(args.maxsize.strip())
        exclude = args.exclude.strip()

        conf = dict(local_dev=local_dev,
                    is_devback=is_devback,
                    is_zip = is_zip,
                    srcPth = srcPth,
                    backPth = backPth,
                    is_maxsize = is_maxsize,
                    maxsize = maxsize,
                    exclude = exclude
                    )
        if local_dev not in self.__config['list']:
            return {'msg':'%s挂载目录不存在'%local_dev}
        else:
            self.__set_config(local_dev, {'backupconf':conf})
        R = {'msg':'备份设置保存成功',"status":1}
        if int(args.now_doing):
            if 'Windows' in inSystem:
                s = "python /www/server/panel/plugin/mfftpdev/mfftpdev.py %s"%local_dev
            else:
                s = "nohup python /www/server/panel/plugin/mfftpdev/mfftpdev.py %s>/dev/null 2>&1 &"%local_dev
                pro = self.get_fs_pro()
                if pro[0]:
                    return {'msg':"备份已保存,程序或计划正在运行，可以稍后手动", "status":0}
        
            public.ExecShell(s)
            R = {'msg':'备份设置保存成功,备份正在后台运行',"status":1}
            
        return R


    def del_dev(self, args):
        local_dev = args.local_dev.strip()
        if local_dev in self.__config['list'] and self.__config['list'][local_dev].get('serv_host') in ('0.0.0.0','0',''):
            pass
        else:
            if not local_dev or not os.path.isdir(local_dev) :
                return {"msg":"挂载路径参数错误","status":0}
            #BSD and macOS, to unmount the filesystem: umount mountpoint
            s = "fusermount -u %s"%local_dev
            public.ExecShell(s)
            
        self.__set_config('-'+local_dev)

        return {"msg":"挂载卸载成功，刷新中。。。","status":1}
    
    
        
    def index(self, args):
        return {'conf':self.__config}
        
        

    def get_search(self, args):
        folder = args.folder.strip() if "folder" in args else ""
        if not folder or folder=="/" or not os.path.isdir(folder):
            return {"error":"文件夹路径有误且不能为/"}
        utime = args.utime.strip() if "utime" in args else ""
        if utime:
            utime = time.strptime(utime, '%Y-%m-%d %H:%M:%S')
            utime = time.mktime(utime)-8*3600
        M = 1024*1024
        fsize = (int(args.fsize.strip()) or 1024)*1024
        
        data = []
        
        if 'subfold' not in  args:
            for f in os.listdir(folder):
                fpath = os.path.join(folder,f)
                if not os.path.isfile(fpath):continue
                size = os.path.getsize(fpath)
                if size<=fsize: continue
                if utime and os.path.getmtime(fpath)<=utime: continue
                if is_binary_file(fpath): continue
                fpath = fpath.replace('\\','/')
                
                try:
                    data.append([fpath.decode('GBK'), int(size/M)])
                except:
                    data.append([fpath, int(size/M)])
                
                
        else:
            for root, dirs, files in os.walk(folder, True, None, False): 
                for f in files:
                    fpath = os.path.join(root,f)
                    size = os.path.getsize(fpath)
                    if size<=fsize: continue
                    if utime and os.path.getmtime(fpath)<=utime: continue
                    if is_binary_file(fpath): continue
                    fpath = fpath.replace('\\','/')
                    try:
                        data.append([fpath.decode('GBK'), int(size/M)])
                    except:
                        data.append([fpath, int(size/M)])
        
        return {'data':data, 'total':len(data)} 

    def __get_config(self,key=None,force=False):
        if not self.__config or force:
            config_file = self.__plugin_path + '/'+ 'config.json'
            if not os.path.exists(config_file): return None
            f_body = public.ReadFile(config_file)
            if not f_body: return None
            self.__config = json.loads(f_body)
            
        if key:
            if key in self.__config: return self.__config[key]
            return None
        
        return self.__config


    def __set_config(self,key=None,value=None):
        if not self.__config: self.__config = {"list":{}} 
        d = self.__config["list"]
        if key[0]=='-':
            d.pop(key[1:],None)
        elif key in d:
            d[key].update(value)
        else:
            d[key]=value
            
        config_file = self.__plugin_path +'/'+ 'config.json'
        try:
            public.WriteFile(config_file,json.dumps(self.__config))
        except UnicodeDecodeError:
            d2 = {}
            for k in d:
                d2[k.decode('GBK')]=d[k]
            self.__config["list"] = d2
            public.WriteFile(config_file,json.dumps(self.__config))
        
        return True

    






        
        
    
    
        
    

