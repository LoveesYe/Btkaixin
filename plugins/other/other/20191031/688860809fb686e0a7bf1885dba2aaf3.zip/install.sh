#!/bin/bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH

#配置插件安装目录
install_path=/www/server/panel/plugin/mfftpdev

b="Darwin"
c="centos"
d="ubuntu"
l="Linux"



#安装
Install()
{
	
	echo '正在安装...'
	#==================================================================
	#依赖安装开始

    a=`uname  -a`
    a5=${a: 0: 5} 
    
    if [[ $a =~ $b ]];then
        echo "mac"
    elif [[ $a =~ $c ]];then
        yum -y install sshfs
        yum -y install sshpass
        yum -y install curlftpfs
        
    elif [[ $a =~ $d ]];then
        sudo apt-get -y install curlftpfs
        sudo apt-get -y install sshpass
        sudo apt-get -y install sshfs
    elif [[ $a =~ $l ]];then
        yum -y install sshfs
        yum -y install sshpass
        yum -y install curlftpfs
    else
        echo $a
    fi
	#依赖安装结束
	#==================================================================

	echo '================================================'
	echo '安装完成'
}

#卸载
Uninstall()
{
	rm -rf $install_path
}

#操作判断
if [ "${1}" == 'install' ];then
	Install
elif [ "${1}" == 'uninstall' ];then
	Uninstall
else
	echo 'Error!';
fi
