
        
        $("#ischeck").on("click",function (data) {
             var emailtext = $("#aemail").val()
            var aachecked = $("input[name='aache']").is(':checked');
            
            console.log('是否勾选：'+aachecked)
            if(aachecked){
                $('#copyemail').val(emailtext)
                
                $('#copyemailid').css({"height":"0px","overflow":"hidden"})
            }else{
                $('#copyemailid').css({"height":"auto","overflow":"visible"})
            }
        })
        
       $('form').submit(function (event) {
            let aadata =  $('form').serialize();  
            console.log('提交啦')
            console.log(aadata)
            
            console.log($('#aport').val())
            
            $(document).ready(function(){
                    parent.$.post("/plugin?action=a&s=sqlconfig&name=mysqlfind",aadata,function(res){
                        layer.msg('提交成功')
                        
                        
                        parent.$.post("/plugin?action=a&s=dblist&name=mysqlfind",{},function(result){
		                    if(result.code == 0){
		                        
		                        var ceshidata = result.data.reverse()
                                    var optionHtml = '';
                                    for(var i in ceshidata){
                                        var value1 = ceshidata[i].Db;
                                        var value2 = ceshidata[i].Db;
                                        optionHtml += "<option value='" + value1 + "'>" + value2 + "</option>";
                                    }
                                    $('#sqltext').append(optionHtml);
                                    layui.form.render('select');
		                        
		                    }else{
		                        layer.msg('输入服务器信息不正确，无法查询数据库')
		                    }
            		         
            		    })
                        
                    })
                })
            
            
           
          
            return false;
        })
        
        $('.itemsid').on('click', function(e){
            console.log('111')
            // console.log(e)
        })
        