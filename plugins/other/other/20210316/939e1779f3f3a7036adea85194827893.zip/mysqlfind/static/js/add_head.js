var stopfind = 0
var timer 
var itemstext
var num = 0;
function getObjectValues(object)
    {
        var values = [];
        for (var property in object)
        values.push(object[property]);
        return values;
    }
    function getObjectKeys(object)
  {
    var keys = [];
    for (var property in object)
      keys.push(property);
    return keys;
  }
function getCurrentDate(date){
        var y = date.getFullYear();
        var m = date.getMonth()+1;
        var d = date.getDate();
        var h = date.getHours();
        var min = date.getMinutes();
        var s = date.getSeconds();
        var str=y+'年'+(m<10?('0'+m):m)+'月'+(d<10?('0'+d):d)+'日  '+(h<10?('0'+h):h)+':'+(min<10?('0'+min):min)+':'+(s<10?('0'+s):s);
        return str;
    }
    function itemsfunc(e){
      let text = $('#resnum'+e).text()
      let data = JSON.parse(text)
    let trtext = '';
    for(var i = 0 ;i < data.length;i++){
    let tdtext = '';
    	let akey = getObjectKeys(data[i])
    	let avalue = getObjectValues(data[i])
    	for(var r = 0 ;r < akey.length;r++){
    	    if(tdtext !== ''){
    	       tdtext = tdtext +'<tr>'+
        		'<td class="tdClass">' + akey[r] + '</td>' + 
        		'<td class="tdClass">' +avalue[r] + '</td>'  +'</tr>'
    	    }else{
    	        tdtext = '<tr>'+
        		'<td class="tdClass">' + akey[r] + '</td>' + 
        		'<td class="tdClass">' +avalue[r] + '</td>' +'</tr>'
    	    }
    	}
    	if(trtext !== ''){
    	    trtext = trtext + '<tr>'+tdtext +'</tr>'+'<tr style="border:none;height:40px;">'+' ' +'</tr>'
    	}else{
    	    trtext = '<tr>'+tdtext +'</tr>'+'<tr style="border:none;height:40px;">'+' ' +'</tr>'
    	}
    }
    
     let htmltext = '<div  class="layui-form"><table class="layui-table" id = "group" style="padding-left:20px;display: flex;font-size: 3.5vw;text-align: center;border-collapse:collapse;">'+trtext+'</table></div>'
    console.log(trtext)
      
      layer.open({
        type: 1
        ,title: '详情' //不显示标题栏
        ,closeBtn: false
        ,area: ['800px', '600px']
        ,shade: 0.8
        ,id: 'LAY_layuipro' //设定一个id，防止重复弹出
        ,btn: [ '关闭']
        ,btnAlign: 'c'
        ,moveType: 1 //拖拽模式，0或者1
        ,content: htmltext
        ,success: function(layero){
          var btn = layero.find('.layui-layer-btn');
        }
      });
  }
layui.use([ 'layer', 'form', 'element' ], function() {
		var $ = layui.jquery, 
		layer = layui.layer, 
		form = layui.form, 
		element = layui.element;
		$(document).ready(function(){
		    parent.$.post("/plugin?action=a&s=dblist&name=mysqlfind",{},function(result){
		        
		         var ceshidata = result.data.reverse()
                        var optionHtml = '';
                        for(var i in ceshidata){
                            var value1 = ceshidata[i].Db;
                            var value2 = ceshidata[i].Db;
                            optionHtml += "<option value='" + value1 + "'>" + value2 + "</option>";
                        }
                        $('#sqltext').append(optionHtml);
                        layui.form.render('select');
		    })
		    
		 parent.$.post("/plugin?action=a&s=readsqlcfg&name=mysqlfind",{},function(result){
		     if(result.data == ''){
		         layer.msg('请先完整填写服务器配置并保存')
                
		     }else{
                        let adata = JSON.parse(result.data)
                        
                        $("#apassword").val(adata.password)
                       $("#aemail").val(adata.username)
                       $("#aport").val(adata.hostport)
                                
                                $(".layui-input").eq(0).text(adata.hostname);
                                $('#hostnameid').find("option[value='" + adata.hostname + "']").attr('selected','selected');
                                $(".layui-input").eq(0).val($('#hostnameid').find("option[value='" + adata.hostname + "']")[0].text);
		     }            
        })
		});
	});
    function del(id){
        // console.log('wwwwwwwwwwwwww')
    }
     $('#frm').submit(function (event) {
        event.preventDefault()
  })
    function getQueryVariable(variable)
        {
               var query = window.location.search.substring(1);
               var vars = query.split("&");
               for (var i=0;i<vars.length;i++) {
                       var pair = vars[i].split("=");
                       if(pair[0] == variable){return pair[1];}
               }
               return(false);
        }
    
    var headertext = parent.$.ajaxSettings.headers
    
    layui.use('table', function(){
      var table = layui.table;
      table.render({
        elem: '#test'
        ,width:'360'
        ,height:'600'
        ,url:'/plugin?action=a&s=dirlist&name=mysqlfind'
    ,method: 'post' //如果无需自定义HTTP类型，可不加该参数
    ,headers:{
        'x-cookie-token':headertext[Object.keys(headertext)[1]],
                'x-http-token':headertext[Object.keys(headertext)[0]]
    }
        ,cellMinWidth: 80 //全局定义常规单元格的最小宽度，layui 2.2.1 新增
        ,cols: [[
            {type:'checkbox',toolbar:'11111',style:'border-right:#000000 0px solid;'}
          ,{field:'title', width:310, title: '请选择要备份的文件夹或者文件',event:'eventee' }
        ]]
         ,page: false
         ,limit:20
          ,id: 'testReload'
      });
      
var $ = layui.$, active = {
    getCheckData: function(){ //获取选中数据
      
    }
    ,getCheckDatacopy: function(){ //获取选中数目
            
            let text =  $("select[name='sqltext']").val(); 
            let texttwo =  $("input[name='keywords']").val(); 
            if(texttwo == ''){
                layer.msg('请输入查找内容')
            }else{
            startfind=$("#find").html();
            if(($("#find").html())=='数据库全局查找'){
                stopfind = 0;
                $("#find").html('暂停查找')
                $("#listid").empty(); 
            }
            else if(($("#find").html())=='暂停查找'){
                $("#find").html('继续查找')
                stopfind = 1;
            }
            else{
                 $("#find").html('暂停查找')
                 stopfind = 0;
            }
            
            if(stopfind == 0 && startfind=='数据库全局查找'){
                 parent.$.post("/plugin?action=a&s=find&name=mysqlfind",{dbname:text,keywords:texttwo,type:$("select[name='mode']").val()},function(result){
                     let list = result.data
                     let biaoji = 0;
                     let tbnametext = '';
                     
                    if(list.length !== 0){
                        timer =  setInterval(function(){
                            num ++;
                            // console.log('剩余长度：'+list.length)
                                    if(stopfind == 0){
                                        
                                        $("#restext").html(getCurrentDate(new Date())+':正在查找'+list[0].TABLE_NAME+'表的'+list[0].COLUMN_NAME+'列');
                                        
                                        parent.$.post("/plugin?action=a&s=query&name=mysqlfind",{dbname:text,keywords:texttwo,tbname:list[0].TABLE_NAME,colname:list[0].COLUMN_NAME,type:$("select[name='mode']").val()},function(res){
                                        //   console.log(res)
                                          
                                          //数据展示
                                          if(res.data.length !== 0){
                                              
                                              if(tbnametext !== list[0].TABLE_NAME ){
                                                  let htmltitle = '<div class="" style="width:500px;text-align:center;height:40px;line-height:40px;border-bottom:1px solid #d2d2d2;background: #f5f5f5;font-weight: bold;">'+list[0].TABLE_NAME +'</div>'
                                                     $('#listid').append(htmltitle);
                                              }
                                              
                                              console.log(num)
                                              console.log(JSON.stringify(res.data))
                                              
                                              let htmltext = ' <div class="colid" style="display:flex;border-bottom:1px solid #d2d2d2;"><div style="width:100px;text-overflow:ellipsis; white-space: nowrap;text-align:center;border-right:1px solid #d2d2d2;">'+list[0].COLUMN_NAME+' </div><div class="itemsid" id="resnum'+num+'"  onClick=itemsfunc(' + num + ') style="width:400px;height:40px;overflow: hidden;text-overflow:ellipsis; white-space: nowrap;"><text  style="border-bottom:1px solid blue;width:380px;margin:0 10px;">'+JSON.stringify(res.data)+'</text></div></div>'
                                             $('#listid').append(htmltext);
                                          }
                                          
                                          
                                          list.splice(0,1);
                                          
                                          if(list.length == 1){
                                              console.log('结束循环啦~~')
                                                clearTimeout(timer)
                                                biaoji = 1;
                                                num = 0;
                                                
                                                 $("#restext").html(getCurrentDate(new Date())+':查找完成！');
                                                 
                                                stopfind = 0;
                                                $("#find").html('数据库全局查找')
                                          }else{
                                            //   console.log('还有数据噢~去掉一个 继续循环')
                                              
                                               if(res.data.length !== 0){
                                                    tbnametext = list[0].TABLE_NAME;
                                               }
                                             
                                              
                                             
                                          }
                                          
                                        })
                                  
                                    }
                        },200)
                        
                    }else{
                            layer.msg('没有数据')
                    }
                    
                     
                 })                    
                }
            
                else{
                console.log('暂停中.....')
                 }
            }       
            
    }
    ,isAll: function(){ //验证是否全选
      var checkStatus = table.checkStatus('idTest');
      layer.msg(checkStatus.isAll ? '全选': '未全选')
    }
  };
  
  
  
  $('.demoTable .layui-btn').on('click', function(){
    var type = $(this).data('type');
    active[type] ? active[type].call(this) : '';
  });
  
        $('#tofile').on('click', function(){
              console.log('sendoneclick')
             let titletexttwo = $("#blinput").val();
            console.log(titletexttwo)
            
            
            
                                table.reload('testReload', {
                                        where: {
                                            dir:titletexttwo
                                        }
                                      }, 'data');
          });
      
      table.on("checkbox(test)",function(data){
          console.log('radio')
          console.log(data)
      })
      
      
        table.on("tool(test)",function(obj){
          console.log('eeeeeeeeeee')
          console.log(obj)
          console.log(obj.event)
          if(obj.event == 'eventee'){
                                $("#blinput").val(obj.data.dirname);
                                let titletext
                                if(obj.data.title.indexOf('上级目录')>-1){
                                    titletext = obj.data.dirname
                                }else{
                                    titletext = obj.data.dirname
                                }
                                
                                if(obj.data.isfile == 0){
                                    table.reload('testReload', {
                                        where: {
                                            dir:titletext
                                        }
                                      }, 'data');
                             }
          }
      })
      
      table.on('row(test)', function (obj) {
            console.log(obj.data.title.indexOf('上级目录')>-1)
        

  });
      
      
    });
         
    
    // 搜索按钮的点击事件
    
    
     $('#tofile').on('click', function(){
            console.log('toto')
            let titletexttwo = $("#blinput").val();
            console.log(titletexttwo)
            table.reload('testReload', {
                    // page: {
                    //   curr: 1 //重新从第 1 页开始
                    // }
                    // ,
                    where: {
                        dir:titletexttwo
                    }
                  }, 'data');
            })