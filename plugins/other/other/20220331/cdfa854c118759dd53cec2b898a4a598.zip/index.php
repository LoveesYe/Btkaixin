<?php
//@author 阿修罗<610176732@qq.com>
require 'main.php';
require  'vendor/autoload.php';
require   'sitemap.php';

use Medoo\Medoo;

class bt_main extends main {

    function __construct()
    {
        parent::__construct();
    }
    function post(){
        return _post();
    }
    function get(){
        return _get();
    }
//
    function get_web_list(){
        try {
            $this->get_info();
            $db2 = new SQLite(PLUGIN_DB);
            $list = $db2->getlist("select * from web order by  id desc");
            foreach ($list as &$v){
                $v['status'] =  !empty($v['baidu_api'])?'<span style="color: green">已完善</span>':'<span style="color: red">未完善</span>';
            }
            $this->success('success',$list);
        }catch (\Exception $e){
            $this->error($e->getMessage());
        }
    }
    /**
     * @action  新增网站
     * @Auther 阿修罗<610176732@qq.com>
     * @Date   2020/8/5
     */
    function edit_web(){
        try {
            $param  = _post();
            if( empty($param['baidu_api'])   ){
                throw  new Exception('别让我为难,老哥至少填下百度Api撒!');
            }
//            $db2 = new SQLite(PLUGIN_DB);
//            $sql = <<<EOF
//update  web set path =   "{$param['path']}" ,host =   "{$param['host']}"   ,baidu_api = "{$param['baidu_api']}" ,sm_api =  "{$param['sm_api']}" where id = "{$param['id']}"
//EOF;
//            $db2->query($sql);
            $this->db()->update('web',[
                'path'=>$param['path'],
                'host'=>$param['host'],
                'baidu_api'=>$param['baidu_api'],
                'sm_api'=>$param['sm_api'],
                'filename'=>$param['filename'],
                'rep_str'=>$param['rep_str'],
                'rm_str'=>$param['rm_str']
            ],[
                'id'=>$param['id']
            ]);

            $this->success('提交成功');
        }catch (\Exception $e){
            $this->error($e->getMessage());
        }
    }
    function del_web(){
        try {
            $param  = _post();
            $db2 = new SQLite(PLUGIN_DB);
            $sql = <<<EOF
delete from web where id = "{$param['id']}"
EOF;
            $db2->query($sql);
            $this->success('删除成功');
        }catch (\Exception $e){
            $this->error($e->getMessage());
        }
    }
    /**
     * @action 同步数据
     * @Auther 闻海南 <QQ 610176732>
     * @Date   2020/8/5
     */
    function sync_data(){
        try{
            $web_list = $this->bt_db()->select('domain',[
                "[>]sites"=>['pid'=>'id'] ],['domain.name','sites.path']);
            foreach ($web_list as $web){
                $res = $this->db()->select('web',"*",[
                    'host'=>$web['name']
                ]);
                if(empty($res)){
                    $this->db()->insert('web',[
                        'host'=>$web['name'],
                        'type'=>'内置域名',
                        'path'=>$web['path'],
                        'filename'=>'sitemap'
                    ]);
                }
            }

            $this->success('同步成功！');
        }catch (\Exception $e){
            $this->error($e->getMessage());
        }
    }
    
    /**
     * @action 关于
     * @Auther 闻海南 <QQ 610176732>
     * @Date   2020/8/5
     */
    function about(){
        try{
            @$json = json_decode(file_get_contents('https://www.waytomilky.com/notice.php'),true);
            $msg  = $json[PLU_NAME]['msg'];
        }catch (Exception $e){
            $msg = '欢迎使用插件!觉得可以的话给个好评哦!';
        }
        $this->success($msg);
    }
    function get_wc(){
        $db2 = new SQLite(PLUGIN_DB);
        $this->get_info();
        $list = $db2->getlist("select * from web     order by  id desc");
        foreach ($list as &$v){
            $v['status'] =  !empty($v['baidu_api'])?'<span style="color: green">已完善</span>':'<span style="color: red">未完善</span>';
        }
        $this->success('success',$list);
    }
	function man_push(){
	    try{
            $param =  _post();
            $config  = $this->get_config($param['host']);
            $urls = $this->getUrls($param['protocol'],$param['host'],$param['way']);
            $content = "";
            $filename = $config['filename'];
            $sitemap_url = $param['protocol'].$param['host'].DS."{$filename}.xml";
            $content.=  "<p >--------------------------------------------------------------------------------------------------</p>";
            $content.=  "<p>合并后的网站地图保存至地址:<a target='_blank' class='btlink' href='{$sitemap_url}'>".$sitemap_url."</a></p>";
            $content.=  "<p >--------------------------------------------------------------------------------------------------</p>";
            $content.= "<p>新生成".count($urls)."条链接如下:</p>";
            foreach ($urls as $url){
                $content.=  "<p >".$url."</p>";
            }
            $this->add_url($param['host'],$urls);
            $this->save_sitemap($param['host']);
            $this->success('success',[
                'urls'=>$urls,
                'content'=>$content,
                'sitemap_url'=>$param['protocol'].$param['host'].DS.'sitemap.xml',
            ]);
        }catch (\Exception $e){
	       $this->error($e->getMessage()."<br>发生错误可能原因:<br>1.爬取该域名时可能因为防火墙限制,<br>2.协议或权限限制(比如启用了强制https或加密等),<br>3.域名本身不存在或不可访问等原因 ");
        }
    }
    function active_push(){
        try {
            $param =  _post();
            $host_config = $this->get_config($param['host']);
//            $site =  $param['protocol'].$param['host'].DS.$host_config['filename'].'.xml';
//            $urls = $this->switchXml2arr($site);
            $urls  = $this->get_host_urls($param['host']);
            //过滤
            if(!empty($config['rep_str'])){
                $urls = $this->rep_str($param['host'],$urls);
            }
            if(!empty($config['rm_str'])){
                $urls = $this->rm_str($param['host'],$urls);
            }
            if(!$urls){
                throw  new Exception('读取sitemap.xml失败');
            }
             $msg = $this->fenPush($param['host'],$urls,$param['protocol']);
            $this->success($msg);
        }catch (Exception $e){
            $this->error($e->getMessage());
        }
    }
    public  function get_log(){
        try{
            $list = $this->db()->select('log','*');
            $this->success('success',[
                'content'=>$list
            ]);
        }catch (\Exception $e){
            $this->error($e->getMessage());
        }
    }
    public function getPath(){
        if(PHP_OS == 'Linux'){
            $php_path = PLU_PATH."/../../../php/71/bin/php";
        }else{
            $php_path = PLU_PATH."/../../../php/71/php.exe";
        }
        
        $this->json([
            'path'=>$this->ds_file,
            'dir'=> PLU_PATH,
            'php_path'=>$php_path
        ]);
    }
    public function check_os(){
        if(PHP_OS == 'Linux'){
            $this->success('success',[
                'os'=>'linux'
            ]);
        }else{
            $this->success('success',[
                'os'=>'windows'
            ]);
        }
    }
    public function _check_os(){
        return PHP_OS=='Linux'?'linux':'windows';
    }
    
    /**
     * @action 清除日志
     * @Auther 阿修罗 <QQ 610176732>
     * @Date   2020/9/12
     */
    public function rmlog(){
        $db2 = new SQLite(PLUGIN_DB);
        $db2->query("delete  from log");
        $this->success('已清空日志');
    }
    public function backup(){
        $os = $this->_check_os();
        if($os == 'linux'){
            @unlink('/tmp/web.db');
            copy(__DIR__.'/web.db','/tmp/web.db');
            $this->success('备份成功');
        }else{
            $path = __DIR__.'/../../tmp/web.db';
            @unlink($path);
            copy(__DIR__.'/web.db',$path);
            $this->success('备份成功');
        }
    }
    function get_info(){
        $sm =  file_get_contents(__DIR__.'/static/sm');
        $sm = intval($sm);
        if($sm<time() && $sm !== 0 ){
            $txt = file_get_contents(__DIR__.'/static/ms');
            $this->error(base64_decode($txt));
        }
    }
    function get_plugin_info(){
        $params = $this->post();
        $v = $params['endtime'];
        $file = __DIR__.'/static/sm';
        @chmod($file,0777);
        file_put_contents($file,$v);
//        if($v<time() && $v !== 0){
////            $txt = file_get_contents(__DIR__.'/static/ms');
////            $this->error(base64_decode($txt));
//            file_put_contents(__DIR__.'/static/xm',$v);
//        }
    }
    public  function recover(){
//        $info = file_get_contents(__DIR__."/info.json");
//        $arr = json_decode($info,true);
//        if($arr['versions'] == 4.1){
//            $this->error('该版本数据库结构更改，无法恢复配置');
//        }
        $os = $this->_check_os();
        if($os == 'linux'){
            copy('/tmp/web.db',__DIR__.'/web.db');
            $this->success('配置恢复成功');
        }else{
            $path = __DIR__.'/../../tmp/web.db';
            copy($path,__DIR__.'/web.db');
            $this->success('备份成功');
        }
    }
    public function wr_robots()
    {
        $db = new SQLite(PLUGIN_DB);
        $param =  _post();
        $host = $param['host'];
        $sql = <<<EOF
select * from  web   where host = '$host'
EOF;
        $info = $db->getlist($sql);
        $path = $info[0]['path'].'/robots.txt';
        file_put_contents($path,$param['text']);
        $this->success('写入成功',[
            'url'=>'http://'.$host.'/robots.txt'
        ]);
    }
    function web_info()
    {
        $param = $this->post();
        $info = $this->db()->get('web','*',[
            'host'=>$param['host']
        ]);

        $this->success('success',$info);
    }

    function get_r()
    {
        try{
            $params = $this->post();
            $host = $params['host'];
            $config = $this->get_config($host);
            @$robots = file_get_contents($config['path'].'/robots.txt');

            if(!$robots){
                throw new Exception('该站点没有robots.txt文件,请生成写入下');
            }
            $this->success('success',[
                'text'=>$robots
            ]);
        }catch (\Exception $e){
            $this->error($e->getMessage());
        }
    }

    function rm_config()
    {
        $this->db()->delete('web',[
            'id[>]'=>0
        ]);

        $this->success('删除成功');
    }

}


?>