#!/usr/bin/python
# coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# editor: mufei(ypdh@qq.com tel:15712150708)
'''
牧飞 _ __ ___   ___   ___  / _| ___(_)
| '_ ` _ \ / _ \ / _ \| |_ / _ \ |
| | | | | | (_) | (_) |  _|  __/ |
|_| |_| |_|\___/ \___/|_|  \___|_|
'''
#+--------------------------------------------------------------------
#|   宝塔第三方应用开发 mfSearch
#+--------------------------------------------------------------------

__all__ = ['mfsearch_main']

import sys,os,json,time

#设置运行目录
basedir = os.path.abspath(os.path.dirname(__file__))
plugin_path = "/www/server/panel/plugin/mfsearch/"
try:
    os.chdir("/www/server/panel")
except :
    os.chdir(os.path.join(basedir, '..', '..'))
    plugin_path = basedir.rstrip('/')+'/'


import codecs
 
def is_binary_file(ff):
    TEXT_BOMS = (
        codecs.BOM_UTF16_BE,
        codecs.BOM_UTF16_LE,
        codecs.BOM_UTF32_BE,
        codecs.BOM_UTF32_LE,
        codecs.BOM_UTF8,
    )
    with open(ff, 'rb') as file:
        CHUNKSIZE = 8192
        initial_bytes = file.read(CHUNKSIZE)
        file.close()
    return not any(initial_bytes.startswith(bom) for bom in TEXT_BOMS) and b'\0' in initial_bytes

    
    
    
class Files:
    maxfilesize = 1024*1024*20
    
    @staticmethod
    def search(sTxt, sPath, callback=None, 
               is_re=0, is_word=0, is_case=0, is_deep=0,
               exts=['.xls','.csv','.txt','.log','.html','.sql'], 
               mode=0,
               utime=0, utimemode=0,
               debug=0):
        """is_re:是否正则匹配,
           sTxt: 需要匹配的文字 如:"13714261894|胡芳芳(\s|$)|4304[0-9]{2}[0-9]{10}[02468]"
           sPath: 需要搜索的路径
           callback: 回调函数
           sTxt: "姓名"只支持UTF-8格式匹配, 
        """
        if not sTxt: return
        #sTxt=sTxt.decode('utf-8').encode('GBK')
        
        import gc,os,re
        #print gc.get_threshold()
        #gc.set_threshold(700, 10, 5)
        if isinstance(exts, str):
            _exts = exts.replace('.','[.]').replace('*','.*').replace(';','|').strip('|')
            _exts = '('+_exts+')'+'$'
        is_re = is_re or mode==2 or is_word or is_case
        if is_re and is_word: 
            if sTxt[0].isalnum():  sTxt=r"\b"+sTxt
            if sTxt[-1].isalnum(): sTxt=sTxt+r"\b"
   
        rs = [] #结果
        
        if not is_deep:
            for f in os.listdir(sPath):
                cs = ''
                fpath = os.path.join(sPath,f)
                if not os.path.isfile(fpath):  continue
                if isinstance(exts, str):
                    if '*.*' not in exts:
                        if not re.match(_exts, f, flags=re.I): continue #match
                    elif is_binary_file(fpath):
                        continue
                else:
                    ext = os.path.splitext(f)[1].lower() 
                    if ext not in exts: continue

                if utimemode and utime:
                        #_utime = time.strftime('%Y-%m-%d %H:%M:%S',time.gmtime(os.path.getmtime(fpath)))
                    _utime = os.path.getmtime(fpath)
                    if   utimemode==1 and _utime>=utime:continue
                    elif utimemode==2 and _utime<=utime:continue
                
                try:
                    fp=open(fpath, 'r', encoding='UTF-8')
                except:
                    fp=open(fpath, 'r')
                    
                i = 0
                try:
                    for line in fp: #for line in fp.readlines() #加个readlines很占内存
                        i+=1
                        if is_re :
                            if is_case and not re.search(sTxt, line,flags=re.I): continue
                            elif not is_case and not re.search(sTxt, line): continue
                        else:
                            if line.find(sTxt)==-1: continue 
                        if callback: callback(line, fpath, i)
                        #rs.append([line, fpath])
                except:
                    pass
                    
                fp.close()
        else:
            for root, dirs, files in os.walk(sPath, True, None, False): #遍列目录  #第一次就遍列完目录了,如果再在下层遍列就重复了 
                #处理该文件夹下所有文件: 
                for f in files:
                    cs = ''
                    fpath = os.path.join(root,f)
                    if not os.path.isfile(fpath):  continue
                    if isinstance(exts, str):
                        if '*.*' not in exts:
                            if not re.match(_exts, f, flags=re.I): continue #match
                        elif is_binary_file(fpath):
                            continue
                    else:
                        ext = os.path.splitext(f)[1].lower() 
                        if ext not in exts: continue

                    
                    if utimemode and utime:
                        #_utime = time.strftime('%Y-%m-%d %H:%M:%S',time.gmtime(os.path.getmtime(fpath)))
                        _utime = os.path.getmtime(fpath)
                        if   utimemode==1 and _utime>=utime:continue
                        elif utimemode==2 and _utime<=utime:continue
                    
                    try:
                        fp=open(fpath, 'r', encoding='UTF-8')
                    except:
                        fp=open(fpath, 'r')
                    i = 0
                    try:
                        for line in fp: #for line in fp.readlines() #加个readlines很占内存
                            i+=1
                            if is_re :
                                if is_case and not re.search(sTxt, line,flags=re.I): continue
                                elif not is_case and not re.search(sTxt, line): continue
                            else:
                                if line.find(sTxt)==-1: continue 
                            if callback: callback(line, fpath, i)
                            #rs.append([line, fpath])
                    except: 
                        pass
                        
                    fp.close()
        
        return rs 
        
    @staticmethod
    def replace(sTxt, eTxt, sPath, callback=None, 
               is_re=0, is_word=0, is_case=0, is_deep=0,
               exts=['.xls','.csv','.txt','.log','.html','.sql'], 
               mode=0, is_backup=0,
               utime=0, utimemode=0,
               debug=0):
        
        if not sTxt: return
        
        import zipfile
        import gc,re,time
        if is_backup:
            basedir = os.path.abspath(os.path.dirname(__file__))
            backdir = os.path.join(basedir, 'backups')
            if not os.path.isdir(backdir): os.mkdir(backdir)
            t = time.strftime('%Y%m%d%H%M%S')
            fpath = os.path.join(backdir,  "%s.zip"%t)
            
            try:
                zfile = zipfile.ZipFile(fpath, "w", compression=zipfile.ZIP_DEFLATED)
            except:
                return {}
        
        #print gc.get_threshold()
        #gc.set_threshold(700, 10, 5)
        if isinstance(exts, str):
            _exts = exts.replace('.','[.]').replace('*','.*').replace(';','|').strip('|')
            _exts = '('+_exts+')'+'$'
        is_re = is_re or mode==2 or is_word or is_case
        if is_re and is_word: 
            if sTxt[0].isalnum():  sTxt=r"\b"+sTxt
            if sTxt[-1].isalnum(): sTxt=sTxt+r"\b"
   
        rs = [] #结果
        
        if not is_deep:
            for f in os.listdir(sPath):
                cs = ''
                fpath = os.path.join(sPath,f)
                if not os.path.isfile(fpath):  continue
                if isinstance(exts, str):
                    if '*.*' not in exts:
                        if not re.search(_exts, f, flags=re.I): continue #match
                    elif is_binary_file(fpath):
                        continue
                else:
                    ext = os.path.splitext(f)[1].lower() 
                    if ext not in exts: continue

                if utimemode and utime:
                        #_utime = time.strftime('%Y-%m-%d %H:%M:%S',time.gmtime(os.path.getmtime(fpath)))
                    _utime = os.path.getmtime(fpath)
                    if   utimemode==1 and _utime>=utime:continue
                    elif utimemode==2 and _utime<=utime:continue
                if os.path.getsize(fpath) > Files.maxfilesize: continue

                try:
                    fp=open(fpath, 'r', encoding='UTF-8')
                    encoding = 1
                except:
                    encoding = 0
                    fp=open(fpath, 'r')
                content = fp.read()
                fp.close()
                
                if is_re:
                    if is_case :
                        if not re.search(sTxt, content,flags=re.I): continue
                        content = re.sub(sTxt, eTxt, content, flags=re.I)
                    else:
                        if not re.search(sTxt, content): continue
                        content = re.sub(sTxt, eTxt, content)
                else:
                    if content.find(sTxt)==-1: continue 
                    content = content.replace(sTxt, eTxt)
                if is_backup:
                    bf = fpath.strip('/')
                    zfile.write(fpath, bf) 
                if encoding:
                    with open(fpath, 'w', encoding='UTF-8') as f: f.write(content) 
                else:
                    with open(fpath, 'w') as f: f.write(content)           
                    
                if callback: callback(fpath)
                        
                
        else:
            for root, dirs, files in os.walk(sPath, True, None, False): #遍列目录  #第一次就遍列完目录了,如果再在下层遍列就重复了 
                #处理该文件夹下所有文件: 
                for f in files:
                    cs = ''
                    fpath = os.path.join(root,f)
                    if not os.path.isfile(fpath):  continue
                    if isinstance(exts, str):
                        if '*.*' not in exts:
                            if not re.search(_exts, f, flags=re.I): continue #match
                        elif is_binary_file(fpath):
                            continue
                    else:
                        ext = os.path.splitext(f)[1].lower() 
                        if ext not in exts: continue

                    if utimemode and utime:
                        #_utime = time.strftime('%Y-%m-%d %H:%M:%S',time.gmtime(os.path.getmtime(fpath)))
                        _utime = os.path.getmtime(fpath)
                        if   utimemode==1 and _utime>=utime:continue
                        elif utimemode==2 and _utime<=utime:continue
                    if os.path.getsize(fpath) > Files.maxfilesize: continue
                    
                    try:
                        fp=open(fpath, 'r', encoding='UTF-8')
                        encoding = 1
                    except:
                        encoding = 0
                        fp=open(fpath, 'r')
                    try:
                        content = fp.read()
                    except UnicodeDecodeError:
                        continue
                        
                    fp.close()
                    
                    if is_re:
                        if is_case :
                            if not re.search(sTxt, content,flags=re.I): continue
                            content = re.sub(sTxt, eTxt, content, flags=re.I)
                        else:
                            if not re.search(sTxt, content): continue
                            content = re.sub(sTxt, eTxt, content)
                    else:
                        if content.find(sTxt)==-1: continue 
                        content = content.replace(sTxt, eTxt)
                    if is_backup:
                        bf = fpath.strip('/')
                        zfile.write(fpath, bf) 
                    if encoding:
                        with open(fpath, 'w', encoding='UTF-8') as f: f.write(content) 
                    else:
                        with open(fpath, 'w') as f: f.write(content)       
                        
                    if callback: callback(fpath)
                    
        if is_backup:
            zfile.close()
        return rs          



def unicode_convert(input_data):
    if isinstance(input_data, dict):
        d = {}
        for key,value in input_data.iteritems():
            d[unicode_convert(key)] = unicode_convert(value)
        return d
    elif isinstance(input_data, list):
        return [unicode_convert(element) for element in input_data]
    elif isinstance(input_data, unicode):
        return input_data.encode('utf-8')
    else:
        return input_data


class mfsearch_main:
    __plugin_path = plugin_path
    __config = None

    #构造方法
    def  __init__(self):
        pass

    #自定义访问权限检查
    #一但声明此方法，这意味着可以不登录面板的情况下，直接访问此插件，由_check方法来检测是否有访问权限
    #如果您的插件必需登录后才能访问的话，请不要声明此方法，这可能导致严重的安全漏洞
    #如果权限验证通过，请返回True,否则返回 False 或 public.returnMsg(False,'失败原因')
    #示例未登录面板的情况下访问get_logs方法： /mfsearch/get_logs.json  或 /mfsearch/get_logs.html (使用模板)
    def _check_x(self,args):
        #token = '123456'
        #limit_addr = ['192.168.1.2','192.168.1.3']
        #if args.token != token: return public.returnMsg(False,'Token验证失败!')
        #if not args.client_ip in limit_addr: return public.returnMsg(False,'IP访问受限!')
        return True
  
    def get_search(self, args):
        if 'stext' not in args or not args.stext: return {'error':'搜索信息不能为空'}
        if 'exts' not in args or not args.exts: return {'error':'后缀不能为空；所有文件请输入*.*'}
        if 'folder' not in args or not args.folder or args.folder=='/': return {'error':'目录不能为空'}
        if not os.path.isdir(args.folder): return {'error':'目录不存在'}
        mode = int(args.mode) if 'mode' in args else 0
        noword = int(args.noword) if 'noword' in args else 0
        GB18030 = int(args.GB18030) if 'GB18030' in args else 0
        is_word = int(args.isword) if 'isword' in args else 0
        is_case = int(args.iscase) if 'iscase' in args else 0
        is_deep = int(args.subfold) if 'subfold' in args else 0
        is_re = 1 if  mode==2 else 0
        #sTxt=sTxt.decode('utf-8').encode('GBK')

        utime = args.utime.strip() if "utime" in args else ""
        if utime:
            utime = time.strptime(utime, '%Y-%m-%d %H:%M:%S')
            utime = time.mktime(utime) #-8*3600
        utimemode = int(args.utimemode) if 'utimemode' in args else 0
        
        d = {}
        def callback(line, fpath, i):
            if noword:
                try:
                    if GB18030: json.dumps([fpath])
                    d.setdefault(fpath, {})
                except:
                    fpath = fpath.decode('GB18030')
                    d.setdefault(fpath, {})
                return 
                
                
            try:
                if GB18030: json.dumps([fpath])
                d.setdefault(fpath, {})[str(i)]=line
            except:
                fpath = fpath.decode('GB18030')
                d.setdefault(fpath, {})[str(i)]=line
                
        Files.search(args.stext, args.folder, callback=callback,
                     exts = args.exts,
                     is_word=is_word, is_case=is_case,mode=mode, is_deep=is_deep,
                     utime = utime, utimemode=utimemode
                    )
                            
        _args = {
            'stext':args.stext,'exts':args.exts,'folder':args.folder,'mode':args.mode,
            'isword':is_word,'iscase':is_case, #'stext':args.stext,'stext':args.stext,
            'subfold':is_deep, 'utime':utime, 'utimemode':utimemode
        }

        total = len(d)
        
        try:
            json.dumps({'data':d})
        except:
            try:
                d = json.dumps(d, ensure_ascii=False).decode('GB18030')
                json.dumps({'data':d})
            except:
                try:
                    _d = json.dumps(d, ensure_ascii=False)
                    json.dumps({'data':_d})
                    d = _d
                except:
                    return {'error':'编码返回错误，您可以选择不输出行信息或使用GB18030编码试试'}
                        
        rs = {'data':d, 
              'args':_args,
              'total':total ,
              'status':1}
               
        return rs
        
        
    def get_replace(self, args):
        if 'stext' not in args or not args.stext: return {}
        if 'exts' not in args or not args.exts: return {}
        if 'folder' not in args or not args.folder or args.folder=='/': return {}
        mode = int(args.mode) if 'mode' in args else 0
        is_word = int(args.isword) if 'isword' in args else 0
        is_case = int(args.iscase) if 'iscase' in args else 0
        is_deep = int(args.subfold) if 'subfold' in args else 0
        is_backup = int(args.isbackup) if 'isbackup' in args else 0
        
        is_re = 1 if  mode==2 else 0
        utime = args.utime.strip() if "utime" in args else ""
        if utime:
            utime = time.strptime(utime, '%Y-%m-%d %H:%M:%S')
            utime = time.mktime(utime) #-8*3600
        utimemode = int(args.utimemode) if 'utimemode' in args else 0
        
        d = []
        def callback(fpath):
            try:
                json.dumps([fpath])
                d.append(fpath)
            except:
                fpath = fpath.decode('GBK')
                d.append(fpath)
                
            
            
        Files.replace(args.stext, args.etext, args.folder, callback=callback,
                     exts = args.exts,
                     is_word=is_word, is_case=is_case,mode=mode, is_deep=is_deep,
                     is_backup=is_backup,
                     utime = utime, utimemode=utimemode 
                    )
                            
        _args = {
            'stext':args.stext,'exts':args.exts,'folder':args.folder,'mode':args.mode,
            'isword':is_word,'iscase':is_case, #'stext':args.stext,'stext':args.stext,
            'subfold':is_deep, 'utime':utime, 'utimemode':utimemode
        } 
        backupdir = os.path.join(self.__plugin_path, 'backups')

        total = len(d)
        try:
            json.dumps(d)
        except:
            try:
                d = json.dumps(d, ensure_ascii=False).decode('GBK')
            except:
                d = json.dumps(d, ensure_ascii=False)
                
        return {'data':d, 'args':_args, 'total':total, 'backupdir':backupdir,'status':1}    
        

    

