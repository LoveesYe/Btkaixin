#!/usr/bin/python
# coding: utf-8
# +-------------------------------------------------------------------
# | Tyoecho管理
# +-------------------------------------------------------------------
# | Copyright (c) 2017-2020 cxbsoft(https://blog.bsot.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: cxbsoft@bsot.cn
# +-------------------------------------------------------------------

#+--------------------------------------------------------------------
#|   Typecho管理
#+--------------------------------------------------------------------
import sys,os,json,requests,random,pymysql,re

#设置运行目录
os.chdir("/www/server/panel")

#添加包引用位置并引用公共包
sys.path.append("class/")
import public

#from common import dict_obj
#get = dict_obj();


#在非命令行模式下引用面板缓存和session对象
if __name__ != '__main__':
    from BTPanel import cache,session,redirect

    #设置缓存(超时10秒) cache.set('key',value,10)
    #获取缓存 cache.get('key')
    #删除缓存 cache.delete('key')

    #设置session:  session['key'] = value
    #获取session:  value = session['key']
    #删除session:  del(session['key'])


class typechomg_main:
    __plugin_path = "/www/server/panel/plugin/typechomg/"
    __config = None

    #构造方法
    def  __init__(self):
        pass
    def read_json(self,path):
        path = "/www/server/panel/plugin/typechomg/jsons/"+path
        f = open(path)
        json_content = json.load(f)
        return json_content
    def write_json(self,path,content):
        path = "/www/server/panel/plugin/typechomg/jsons/"+path
        f = open(path,"w")
        json.dump(content,f)
    def plugins(self,args):
        config = self.read_json("config.json")[0]
        root_typecho = config['root_typecho']
        plugin_file = root_typecho + "usr/plugins/"
        files = os.listdir(plugin_file)
        plugins = []
        for file_item in files:
            isdir = os.path.isdir(plugin_file + file_item)
            if(isdir):
                plugins.append(file_item)
        html = """
        <div class="sfm-opt">
            <button class="btn btn-default btn-sm" onclick="typechomg.new_plugin()">添加插件</button>    
        </div>
        <table class="table table-hover">
        <thead>
        <tr>
        <th style="width:165">插件名</th>
        <th style="text-align:right;">操作</th>
        </tr>
        <tbody>
        """
        for plugin_item in plugins:
            html += """
            <tr>
            <td>%s</td>
            <td style="text-align:right;"><a class="btlink" onclick="typechomg.remove_plugin('%s')">卸载</a></td>
            </tr>
            """%(plugin_item,plugin_item)
        html += """
        </tbody></table>
        """
        
        return html
    def install_plugin(self,args):
        config = self.read_json("config.json")[0]
        root_typecho = config['root_typecho']
        plugin_file = root_typecho + "usr/plugins/"
        temp_file = "/www/server/panel/plugin/typechomg/temp/"
        dirs = os.listdir(temp_file)
        for dir_item in dirs:
            dir_item = temp_file + dir_item
            
            os.system("unzip -n %s -d %s"%(dir_item,plugin_file))
            os.system("chmod -Rf 777 %s"%(plugin_file))
            os.system("rm %s"%dir_item)
        return "ok"
    def new_plugin(self,args):
        html = """
        <h2>从本地导入</h2>
        <h4 style="colour:red">注意：请手动按照插件安装格式修改插件文件夹名称</h4>
        <button class="btn btn-default btn-sm pull-left" onclick="UploadFiles('/www/server/panel/plugin/typechomg/temp/')">上传文件(zip)</button>
        <button class="btn btn-default btn-sm pull-left" onclick="Install_app()">安装</button>
        <br><br><br>
        <h2>应用商店</h2>
        <table class="table table-hover">
        <thead>
        <tr>
        <th style="width:165">插件名</th>
        <th style="text-align:right;">操作</th>
        </tr>
        <tbody>
        """
        storeurl = "http://service.bsot.cn/typechomg/store/storelist.php"
        plugin_store = public.HttpGet(storeurl,timeout=60)
        storelist = json.loads(plugin_store)
        for store in storelist:
            plugin_name = store['name']
            downloadurl = store['url']
            html += """
            <tr>
            <td>%s</td>
            <td style="text-align:right;"><a class="btlink" onclick="typechomg.install_plugin_online('%s')">安装</a></td>
            </tr>
            """%(plugin_name,downloadurl)
        html += """
        </tbody></table>
        """
        return html
    def install_plugin_online_download(self,args):
        downloadurl = args['downloadurl']
        filecontent = requests.get(downloadurl).content
        zipname = str(random.random())
        f = open("/www/server/panel/plugin/typechomg/temp/online%s.zip"%zipname,"wb")
        f.write(filecontent)
        f.close()
        return zipname
    def install_plugin_online(self,args):
        config = self.read_json("config.json")[0]
        zipname = args['zipname']
        root_typecho = config['root_typecho']
        plugin_file = root_typecho + "usr/plugins/"
        temp_file = "/www/server/panel/plugin/typechomg/temp/" + "online%s.zip"%zipname
        os.system("unzip -n %s -d %s"%(temp_file,plugin_file))
        os.system("chmod -Rf 777 %s"%(plugin_file))
        os.system("rm %s"%temp_file)
        return "ok"
    def remove_plugin(self,args):
        config = self.read_json("config.json")[0]
        root_typecho = config['root_typecho']
        plugin_file = root_typecho + "usr/plugins/"
        plugin_name = args['plugin_name']
        os.system("rm -rf %s%s"%(plugin_file,plugin_name))
        return "suc"
    def save_setting(self,args):
        root_typecho = args['root_typecho']
        sql_name = args['sql_name']
        sql_sevrer = args['sql_sevrer']
        sql_user = args['sql_user']
        sql_pass = args['sql_pass']
        dataname = args['dataname']
        config = self.read_json("config.json")
        config[0]['root_typecho'] = root_typecho
        config[0]['sql_name'] = sql_name
        config[0]['sql_user'] = sql_user
        config[0]['sql_pass'] = sql_pass
        config[0]['dataname'] = dataname
        config[0]['sql_server'] = sql_sevrer
        self.write_json("config.json",config)
        return "ok"
    def get_articles(self,args):
        config = self.read_json("config.json")[0]
        sql_name = config['sql_name']
        sql_pass = config['sql_pass']
        sql_user = config['sql_user']
        dataname = config['dataname']
        sql_server = config['sql_server']
        db = pymysql.connect(sql_server,sql_user,sql_pass,sql_name)
        cursor = db.cursor()
        command = "select * from %scontents where type='post'"%dataname
        result = cursor.execute(command)
        html = """
        
        <h2>文章管理</h2>
        <p>你目前有%s篇文章</p>
        <br>
        <table class="table table-hover">
        <thead>
        <tr>
        <th style="width:165">文章名</th>
        <th style="text-align:right;">操作</th>
        </tr>
        <tbody>
        """%result
        for article in cursor.fetchall():
            name = article[1]
            html += """
            <tr>
            <td>%s</td>
            <td style="text-align:right;"><a class="btlink" onclick="typechomg.article_manager('%s')">管理</a></td>
            </tr>
            """%(name,name)
        html += """
        </tbody></table>
        """
        return html
    def manage_article(self,args):
        name = args['name1']
        config = self.read_json("config.json")[0]
        sql_name = config['sql_name']
        sql_pass = config['sql_pass']
        sql_user = config['sql_user']
        dataname = config['dataname']
        sql_server = config['sql_server']
        db = pymysql.connect(sql_server,sql_user,sql_pass,sql_name)
        cursor = db.cursor()
        command = "select * from %scontents where title='%s'"%(dataname,name)
        cursor.execute(command)
        html = """
        
        <h2>概览</h2>
        
        """
        for article in cursor.fetchall():
            views = article[17]
            html += "<p>这篇文章一共被浏览过%s次</p>"%views
            html += """
            
            <br><br>
            <h2>评论</h2>
            <div class="sfm-opt">
                <button class="btn btn-default btn-sm" onclick="typechomg.urlsafe('%s')">评论安全检测</button>
                
            </div>
            <table class="table table-hover">
            <thead>
            <tr>
            <th style="width:165">评论者</th>
            <th>评论内容</th>

            <th style="text-align:right;">操作</th>
            </tr>
            <tbody>
            """%name
            cid = article[0]
            command = "select * from %scomments where cid='%s' and type='comment'"%(dataname,cid)
            cursor.execute(command)
            for comment in cursor.fetchall():
                commenter = comment[3]
                content = comment[10]
                coid = comment[0]
                homepage = comment[7]
                comments = article[12]
                html += """
                <tr>
                <td>%s</td>
                <td>%s</td>
                <td style="text-align:right;">
                <a class="btlink" onclick="typechomg.delete_comment('%s','%s','%s')">删除评论</a>
                <a class="btlink" target='_blank' href='%s'">进入ta的主页</a>
                </td>
                </tr>
                """%(commenter,content,coid,name,comments,homepage)
            html += """
            </tbody></table>
            """
        return html
    def urlsafe(self,args):
        title = args['title']
        config = self.read_json("config.json")[0]
        html = """

            <h2>评论安全检测</h2>
            <p>仅显示垃圾评论</p>
            <table class="table table-hover">
            <thead>
            <tr>
            <th style="width:165">评论者</th>
            <th>评论者主页URL检测</th>
            <th>评论内容检测</th>
            <th style="text-align:right;">操作</th>
            </tr>
            <tbody>

        """
        sql_name = config['sql_name']
        sql_pass = config['sql_pass']
        sql_user = config['sql_user']
        dataname = config['dataname']
        sql_server = config['sql_server']
        db = pymysql.connect(sql_server,sql_user,sql_pass,sql_name)
        cursor = db.cursor()
        command = "select * from %scontents where title='%s'"%(dataname,title)
        cursor.execute(command)

        for article in cursor.fetchall():
            cid = article[0]
            command = "select * from %scomments where cid='%s' and type='comment'"%(dataname,cid)
            cursor.execute(command)
            for comment in cursor.fetchall():
                commenter = comment[3]
                content = comment[10]
                coid = comment[0]
                homepage = comment[7]
                comments = article[12]
                if(homepage != None):
                    urlsafe_url = requests.get("http://api.bsot.cn/urlsafe/urlsafe.php?url=%s"%homepage).text
                    try:
                        urlsafe_url = json.loads(urlsafe_url)
                        urlsafe_url_result = urlsafe_url['wordtit']
                    except:
                        urlsafe_url_result = "检测异常，终止"
                else:
                    urlsafe_url_result = "安全"
                content_process = self.process_content(content)
                if(content_process == []):
                    content_url_result = "安全"
                else:
                    content_url_result = self.content_process(content_process)['wordtit']
                    
                if((urlsafe_url_result != "" and urlsafe_url_result != "安全") or (content_url_result != "" and content_url_result != "安全" )):
                    if(content_url_result == ""):
                        content_url_result = "安全"
                    if(urlsafe_url_result == ""):
                        urlsafe_url_result = "安全"
                    html += """
                    <tr>
                    <td>%s</td>
                    <td>%s</td>
                    <td>%s</td>
                    <td style="text-align:right;">
                    <a class="btlink" onclick="typechomg.delete_comment('%s','%s','%s')">删除评论</a>
                    </td>
                    </tr>
                    """%(commenter,urlsafe_url_result,content_url_result,coid,title,comments)
                else:
                    pass
                
        return html
    def process_content(self,content):
        urls = re.findall('https?://(?:[-\w.]|(?:%[\da-fA-F]{2}))+', content)
        return urls
    def content_process(self,content):
        
        for content_url in content:
            try:
                urlsafe_url_item = json.loads(requests.get("http://api.bsot.cn/urlsafe/urlsafe.php?url=%s"%content_url).text)
            except:
                urlsafe_url_item = {"wordtit" : "检测异常，终止"}
            if(urlsafe_url_item != ""):
                return urlsafe_url_item
        return "" 
    def delete_coid(self,args):
        coid = args['coid']
        name = args['name1']
        comments = int(args['comments']) -1
        config = self.read_json("config.json")[0]
        sql_name = config['sql_name']
        sql_pass = config['sql_pass']
        sql_user = config['sql_user']
        dataname = config['dataname']
        sql_server = config['sql_server']
        db = pymysql.connect(sql_server,sql_user,sql_pass,sql_name)
        cursor = db.cursor()
        command = "delete from %scomments where coid='%s'"%(dataname,coid)
        cursor.execute(command)
        
        command = "update %scontents set commentsNum='%s' where title='%s'"%(dataname,comments,name)
        cursor.execute(command)
        db.commit()
        return "ok"
    def links(self,args):
        config = self.read_json("config.json")[0]
        root_typecho = config['root_typecho']
        sql_name = config['sql_name']
        sql_user = config['sql_user']
        sql_pass = config['sql_pass']
        dataname = config['dataname']
        sql_server = config['sql_server']
        db = pymysql.connect(sql_server,sql_user,sql_pass,sql_name)
        cursor = db.cursor()
        command = "select * from %slinks"%(dataname)
        cursor.execute(command)
        html = """
        <button class="btn btn-default btn-sm pull-left" onclick="typechomg.add_link()">添加友链</button>
        <button class="btn btn-default btn-sm pull-left" onclick="typechomg.delete_useless_link()">一键删除无用链接</button>
        <table class="table table-hover">
        <thead>
        <tr>
        <th style="width:165">名称</th>
        <th>链接</th>
        <th>类别</th>
        <th>描述</th>
        <th style="text-align:right;">操作</th>
        </tr>
        <tbody>
        
        """
        for link in cursor.fetchall():
            cate = link[3]
            description = link[5]
            lid = link[0]
            if(cate == "ten"):
                cate = "全站链接（左侧）"
            elif(cate == "good"):
                cate = "推荐链接"
            elif(cate == "one"):
                cate = "内容链接"
            name = link[1]
            link_content = link[2]
            html += """
            <tr>
            <td>%s</td>
            <td>%s</td>
            <td>%s</td>
            <td>%s</td>
            <td style="text-align:right;">
            <a class="btlink" onclick="typechomg.delete_link('%s')">删除链接</a>
            </td>
            </tr>
            
            """%(name,link_content,cate,description,lid)
        html += """
        </tbody></table>
        """
        return html
    def check_useless_links(self,args):
        config = self.read_json("config.json")[0]
        root_typecho = config['root_typecho']
        sql_name = config['sql_name']
        sql_user = config['sql_user']
        sql_pass = config['sql_pass']
        dataname = config['dataname']
        sql_server = config['sql_server']
        db = pymysql.connect(sql_server,sql_user,sql_pass,sql_name)
        cursor = db.cursor()
        command = "select * from %slinks"%(dataname)
        cursor.execute(command)
        #req = urllib.request.build_opener()
        x = 0
        useless = []
        #req.addheaders = [('User-agent', 'Mozilla/49.0.2')]
        for link in cursor.fetchall():
            links = link[2]
            try:
                requests.get(links)
            except:
                useless.append(links)
                x += 1
        useless = json.dumps(useless,ensure_ascii=False, encoding='UTF-8')
        return [str(x),useless]
    def delete_useless_links(self,args):
        useless = json.loads(args['links'])
        config = self.read_json("config.json")[0]
        sql_name = config['sql_name']
        sql_pass = config['sql_pass']
        sql_user = config['sql_user']
        dataname = config['dataname']
        sql_server = config['sql_server']
        db = pymysql.connect(sql_server,sql_user,sql_pass,sql_name)
        cursor = db.cursor()
        for link in useless:
            command = "delete from %slinks where url='%s'"%(dataname,link)
            cursor.execute(command)
        db.commit()
        return "ok"
    def delete_link(self,args):
        lid = args['lid']
        config = self.read_json("config.json")[0]
        sql_name = config['sql_name']
        sql_pass = config['sql_pass']
        sql_user = config['sql_user']
        dataname = config['dataname']
        sql_server = config['sql_server']
        db = pymysql.connect(sql_server,sql_user,sql_pass,sql_name)
        cursor = db.cursor()
        command = "delete from %slinks where lid='%s'"%(dataname,lid)
        cursor.execute(command)
        db.commit()
        
#        for link in cursor.fetchall():
#
#            this_lid = (int)(link[0]) 
#            this_order = (int)(link[-1])
#            lid = this_lid -1
#            order = this_order -1
#            command = "update %slinks set lid=%s and order=%s where lid=%s"%(dataname,lid,order,this_lid)
#            cursor.execute(command)
#        db.commit()
        return "ok"
    def add_link(self,args):
        html = """
        
            友链名称:  <input class="bt-input-text mr5"  id="link_name"/><br />
            URL:      <input class="bt-input-text mr5" style:"width:400px" id="link_url" /><br />
            描述:     <input class="bt-input-text mr5" id="description" /><br />
            图标:     <input class="bt-input-text mr5" id="image_url" /><br />
         <div class="form-group" style="width:200px">
            <label for="exampleFormControlSelect1">类型</label>
            <select class="form-control" id="class_link">
                <option value="ten">全站链接</option>
                <option value="one">内容链接</option>
                <option value="good">推荐链接</option>
            </select>
        </div>
        <div class="sfm-opt">
                <button class="btn btn-default btn-sm" onclick="typechomg.link_add()">添加友链</button>
                
            </div>
        """
        return html
    def add_link_process(self,args):
        class_link = args['class_link']
        link_name = args['link_name']
        link_url = args['link_url']
        image_url = args['image_url']
        description = args['description']
        config = self.read_json("config.json")[0]
        sql_name = config['sql_name']
        sql_user = config['sql_user']
        sql_pass = config['sql_pass']
        dataname = config['dataname']
        
        sql_server = config['sql_server']
        db = pymysql.connect(sql_server,sql_user,sql_pass,sql_name)
        cursor = db.cursor()
        command = "select * from %slinks"%(dataname)
        lines = cursor.execute(command)
        lidmax = 0
        for line1 in cursor.fetchall():
            countnow = int(line1[0])
            if(countnow > lidmax):
                lidmax = countnow
            
        
        counter = lidmax + 1
        if(image_url == None):
            command = "insert into %slinks values(%s,'%s','%s','%s',NULL,'%s','bt_panel','%s')"%(dataname,counter,link_name,link_url,class_link,description,counter)
        else:
            command = "insert into %slinks values(%s,'%s','%s','%s','%s','%s','bt_panel','%s')"%(dataname,counter,link_name,link_url,class_link,image_url,description,counter)
        cursor.execute(command)
        db.commit()
        return "ok"
    def get_config(self,args):
        config = self.read_json("config.json")[0]
        root_typecho = config['root_typecho']
        sql_name = config['sql_name']
        sql_user = config['sql_user']
        sql_pass = config['sql_pass']
        dataname = config['dataname']
        sql_server = config['sql_server']
        html = """
        
            <h2>配置修改</h2>
            <br />
            <br />
            <div class="soft-man-con bt-form">
            Typecho根目录: <input class="bt-input-text mr5" style="width:500px" id="root_typecho"  value="%s" /><br />
            数据库名:      <input class="bt-input-text mr5" id="sql_name" value="%s" /><br />
            数据库服务器:  <input class="bt-input-text mr5" id="sql_server" value="%s" /><br />
            数据库用户:    <input class="bt-input-text mr5" id="sql_user" value="%s" /><br />
            数据库密码:    <input type="password" class="bt-input-text mr5" id="sql_pass" value="%s" /><br />
            数据前缀:      <input class="bt-input-text mr5" id="dataname" value="%s" /><br />
            </div>
            <div class="sfm-opt">
                <button class="btn btn-default btn-sm" onclick="typechomg.save_setting()">保存配置</button>
                
            </div>

        """%(root_typecho,sql_name,sql_server,sql_user,sql_pass,dataname)
        return html
