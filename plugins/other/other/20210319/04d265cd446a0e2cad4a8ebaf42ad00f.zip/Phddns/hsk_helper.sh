#!/bin/bash
PrintDebugLog(){
	echo "$(date '+%Y-%m-%d %H:%M:%S') $1">>/www/server/panel/plugin/Phddns/debug.log
}

PrintDebugLog "000"

if [ "$(ps -ef|grep hsk_device_refresh.sh|grep -v grep|awk '{print $2}')" == "" ]; then
	PrintDebugLog "111"
	/www/server/panel/plugin/Phddns/hsk_device_refresh.sh &
fi

PrintDebugLog "222"

exit 0
