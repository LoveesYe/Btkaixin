#!/bin/bash

PrintDebugLog(){
	echo "$(date '+%Y-%m-%d %H:%M:%S') $1">>/www/server/panel/plugin/Phddns/debug.log
}



#检查花生壳插件运行，守护重启
MakesurePddns(){
	if [[ $1 -ne 1 ]]; then
		if [ "$(pidof phddns)" == "" ]; then
			PrintDebugLog "restart phddns"
			setsid $2 -i 12707 -k 4a8995692d3c4774 -s https://hsk-embed.oray.com -l /www/server/panel/plugin/Phddns/phtunnel.log -c /www/server/panel/plugin/Phddns/phtunnel.json -p /www/server/panel/plugin/Phddns/phtunnel.pid -r &
		fi
	fi
	PrintDebugLog "MakesurePddns,$1,$(ps -ef|grep phddns|grep -v grep|awk '{print $2}')"
}
	
step=2				#业务轮询间隔，单位秒
last_result=""		#缓存上次结果
serviceport="8888"	#本地网络端口

other_phtunnel=0	#是否存在其他花生壳核心模块
if [ -n "$(pidof phtunnel)" ]; then
	other_phtunnel=1
fi

outDeviveInfo="/www/server/panel/plugin/Phddns/static/device.json"
echo "{\"success\":false,\"serviceport\":$serviceport,\"other_phtunnel\":$other_phtunnel}">$outDeviveInfo	#初始化设备配置

phtunnel_path="/www/server/panel/plugin/Phddns/ubuntu/phddns"	#phddns路径，根据平台判断
#if [ -n "(lsb_release -a|grep Ubuntu)" ]; then
#	phtunnel_path="/www/server/panel/plugin/Phddns/ubuntu/phddns"
#fi

MakesurePddns $other_phtunnel $phtunnel_path	#检查花生壳运行状态

count=0
for ((;1;)) do
	sleep $step
	
	if [ "$(ps -ef|grep BT-Panel|grep -v grep|awk '{print $2}')" == "" ]; then #判断宝塔状态
		phddnsPid=$(ps -ef|grep phddns|grep -v grep|awk '{print $2}')
		for j in ${phddnsPid}
		do
			kill -9 $j
		done
		PrintDebugLog "BT-Pannel not alive"
		continue
	fi
	
	serviceport=$(cat /www/server/panel/data/port.pl)	#读取本地默认端口
	if [ "$serviceport" == "" ]; then
		serviceport="8888"
	fi
	
	other_phtunnel=0	#是否存在其他花生壳核心模块
	if [ -n "$(pidof phtunnel)" ]; then
		other_phtunnel=1
	fi
	
	count=$[$count+1]
	if [ $count -gt 10 ]; then	#n*step执行一次检测
		count=0
		MakesurePddns $other_phtunnel $phtunnel_path
	fi
	
	result="{\"success\":true,\"getsn\":"	#刷新设备配置逻辑
	
	res_sn=$(curl 127.0.0.1:16062/ora_service/getsn 2>/dev/null)		#访问花生壳接口获取数据
	res_mgurl=$(curl 127.0.0.1:16062/ora_service/getmgrurl 2>/dev/null)	#访问花生壳接口获取数据

	result+="${res_sn}"
	result+=",\"getmgrurl\":"
	result+="${res_mgurl}"
	result+=",\"serviceport\":"	
	result+="$serviceport"
	result+=",\"other_phtunnel\":"	
	result+="$other_phtunnel"
	result+="}"
	
	#PrintDebugLog "$result"

	#写入配置文件逻辑
	if [ "$last_result" != "$result" ]; then
		last_result=$result
		if [ "${res_sn}" == "" ];then
			echo "{\"success\":false,\"serviceport\":$serviceport,\"other_phtunnel\":$other_phtunnel}">$outDeviveInfo
		else
			echo "${result}">$outDeviveInfo
		fi
	fi
done;

exit 0
