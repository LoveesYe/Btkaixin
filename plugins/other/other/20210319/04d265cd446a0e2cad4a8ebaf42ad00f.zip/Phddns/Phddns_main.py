#!/usr/bin/python
# coding: utf-8
# +-------------------------------------------------------------------
# | 花生壳PHTunnel宝塔插件Windows
# +-------------------------------------------------------------------
# | Copyright (c) 2002-2020 Oray. All Rights Reserved.
# +-------------------------------------------------------------------
# | Author: tanglei
# +-------------------------------------------------------------------

#+--------------------------------------------------------------------
#|   花生壳PHTunnel官方插件
#+--------------------------------------------------------------------
import sys,os,json,subprocess,time,platform,psutil
import _thread  
import public
import os.path
from pathlib import Path

platform_info = platform.system()

# 在非命令行模式下引用面板缓存和session对象
if __name__ != '__main__':
    from BTPanel import cache,session,redirect

# 花生壳插件名称
strPhtunnel = "Phddns.exe"
phtunnel_file=""
param=""
cur_dir=""
html_file=""

# 打印调试日志
def debug_log(strLog):
    log_file = os.getcwd()+"\\plugin\\Phddns\\debug.log"
    f = open(log_file, "a")
    f.writelines("%s> %s\n"%(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()),strLog))
    f.close()
    return;

# 判断进程是否存在，根据名称    
def process_exsit(processname):
    pl = psutil.pids()
    for pid in pl:
        if psutil.Process(pid).name() == processname:
            return 1
    else:
        return 0

# 获取设备信息SN/PWD/IP等
def getsn_info(other_phtunnel):
    #debug_log("getsn")
    if other_phtunnel==1:
        return ""
    res=""
    phinfo = subprocess.getoutput('curl http://localhost:16062/ora_service/getsn')
    findIndex = phinfo.find('{')
    if findIndex>-1:
        res = phinfo[findIndex:]
    return res
    
# 获取已登录帐号基本信息
def get_mgrurl_info():
    #debug_log("get_mgrurl_info")
    mgrUrl = subprocess.getoutput('curl http://localhost:16062/ora_service/getmgrurl')
    res=""
    findIndex = mgrUrl.find('{')
    if findIndex>-1:
        res = mgrUrl[findIndex:]
    return res
    
def update_device_json(info):
    #设备配置文件路径
    debug_log("update_device_json:%s"%info)
    device_cfg = os.getcwd()+"\\plugin\\Phddns\\static\\device.json"
    #debug_log(device_cfg)
    f = open(device_cfg, "w")
    print(info, file = f)
    f.close()
    

def makesure_phtunnel(threadName,delay):
    global cur_dir
    global phtunnel_file
    global param
    global html_file
    
    debug_log("man logic")
    
    #执行逻辑计数器
    count = 0
    #上次获取信息结果，用于防止重复io读写
    last_result=""
    #默认端口
    serviceport=8888
    
    #debug_log(cur_dir+'/data/port.pl')
    if os.path.exists(cur_dir+'/data/port.pl'):   #读取本地网络端口配置
        f = open(cur_dir+'/data/port.pl')
        if f:
            serviceport = int(f.readline())  #读取首行
        
    if serviceport<8888:
        serviceport = 8888
        
    #win平台暂时拿这个检测宝塔进程，宝塔进程不存在，退出phddns
    os.system("start "+cur_dir+"\\plugin\\Phddns\\windows\\phddns_helper.exe")
    
    #初始化更新下配置文件
    update_device_json("{\"success\":false,\"serviceport\":%d}"%(serviceport))
    
    #文件存在持续执行，因卸载插件没有收到事件，判断网页文件是否存在，来停止运行
    while os.path.exists(html_file):
        other_phtunnel=process_exsit("phtunnel.exe")  #是否存在其他花生壳核心模块
        
        if all ( [count==0,process_exsit(strPhtunnel)==0,other_phtunnel==0] ):
            debug_log("start phddns:%d"%os.system("start "+phtunnel_file+param))  #守护进程
        
        time.sleep(delay)
        
        #获取花生壳接口数据，并刷新文件
        res_sn = getsn_info(other_phtunnel)
        if res_sn=="":
            update_device_json("{\"success\":false,\"serviceport\":%d,\"other_phtunnel\":%d}"%(serviceport,other_phtunnel))
        else:
            mgrurl_info = get_mgrurl_info()
            
            #组装相关结果信息
            result=("{\"success\":true,\"getsn\":%s,\"getmgrurl\":%s,\"serviceport\":%d,\"other_phtunnel\":%d}"%(res_sn,mgrurl_info,serviceport,other_phtunnel))	#刷新设备配置逻辑
            if last_result!=result:
                last_result = result
                update_device_json(result)
        
        count = count+1
        if count>10:    #n*2秒执行进程保护检测
            count = 0

    #强退花生壳进程
    debug_log("main logic stop...")
    exit_cmd = ("taskkill /f /im \"%s\""% "phddns_helper.exe")
    os.system(exit_cmd)
    
    exit_cmd = ("taskkill /f /im \"%s\""% strPhtunnel)
    os.system(exit_cmd)
    
    #删除残留文件夹
    phddnsDir = Path(cur_dir+"\\plugin\\Phddns\\")
    if phddnsDir.is_dir():
        shutil.rmtree(phddnsDir)
   

class Phddns_main:
    __plugin_path = "/www/server/panel/plugin/Phddns/"
    __config = None
    
    #构造方法
    def  __init__(self):
        global cur_dir
        global phtunnel_file
        global param
        global html_file
        
        #当前工作目录
        cur_dir = os.getcwd()

        #花生壳路径
        phtunnel_file = cur_dir+"\\plugin\\Phddns\\windows\\"+strPhtunnel
        #网页主文件路径
        html_file = cur_dir+"\\plugin\\Phddns\\index.html"
    
        #启动参数
        param = (" -i 12707 -s https://hsk-embed.oray.com -k 4a8995692d3c4774 -l %s/phtunnel.log -c %s/phtunnel.json -p %s/phtunnel.pid -r"%
            ((cur_dir+"\\plugin\\Phddns"),(cur_dir+"\\plugin\\Phddns"),(cur_dir+"\\plugin\\Phddns")))


    #自定义访问权限检查
    #一但声明此方法，这意味着可以不登录面板的情况下，直接访问此插件，由_check方法来检测是否有访问权限
    #如果您的插件必需登录后才能访问的话，请不要声明此方法，这可能导致严重的安全漏洞
    #如果权限验证通过，请返回True,否则返回 False 或 public.returnMsg(False,'失败原因')
    #示例未登录面板的情况下访问get_logs方法： /demo/get_logs.json  或 /demo/get_logs.html (使用模板)
    #可通过args.fun获取被请求的方法名称
    #可通过args.client_ip获取客户IP
    def _check(self,args):
        return True

    #访问/demo/index.html时调用的默认方法s
    def index(self,args):
        debug_log("main platform_info:"+platform_info);
        
        is_init=0
        if platform_info=="Windows":
            is_init = process_exsit(strPhtunnel)
            debug_log("main index:%d"%is_init);
            if is_init==0:
                _thread.start_new_thread( makesure_phtunnel, ("makesure_phtunnel",2,))  # 创建工作线程
        else:
            public.ExecShell("/bin/bash /www/server/panel/plugin/Phddns/hsk_helper.sh")
        return is_init
