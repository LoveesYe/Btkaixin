#!/bin/bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH

#配置插件安装目录
install_path=/www/server/panel/plugin/Phddns

#安装
Install()
{
	echo '正在安装...'
	#==================================================================
	#依赖安装开始


	#依赖安装结束
	#==================================================================
	#echo '安装完成'
	
	rfpid=$(ps -ef|grep hsk_device_refresh.sh|grep -v grep|awk '{print $2}')
	for i in ${rfpid}
	do
		kill -9 $i
	done
	phddnsPid=$(ps -ef|grep phddns|grep -v grep|awk '{print $2}')
	for j in ${phddnsPid}
	do
		kill -9 $j
	done
	
	#cp /www/server/panel/plugin/Phddns/phddns/icon.png /www/server/panel/BTPanel/static/img/soft_ico/ico-Phddns.png
	
	chmod 777 /www/server/panel/plugin/Phddns/ubuntu/phddns
	chmod 777 /www/server/panel/plugin/Phddns/hsk_device_refresh.sh
	chmod 777 /www/server/panel/plugin/Phddns/hsk_helper.sh
	/www/server/panel/plugin/Phddns/hsk_device_refresh.sh &
	
	
	#删除可能残留文件
	rm /www/server/panel/plugin/Phddns/version.pl
	
}

#卸载
Uninstall()
{
	### kill sh
	rfpid=$(ps -ef|grep hsk_device_refresh.sh|grep -v grep|awk '{print $2}')
	for i in ${rfpid}
	do
			kill -9 $i
	done
	
	phddnsPid=$(ps -ef|grep phddns|grep -v grep|awk '{print $2}')
	for j in ${phddnsPid}
	do
		kill -9 $j
	done
	rm -rf $install_path
}

#操作判断
if [ "${1}" == 'install' ];then
	Install
elif [ "${1}" == 'uninstall' ];then
	Uninstall
else
	echo 'Error!';
fi
