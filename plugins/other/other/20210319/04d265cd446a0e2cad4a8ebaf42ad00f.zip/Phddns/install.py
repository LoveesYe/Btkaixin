import sys,os,shutil
panelPath = os.getenv('BT_PANEL')
os.chdir(panelPath);
sys.path.append("class/")
import public,json

__name = 'Phddns'
__path = panelPath + '/plugin/' + __name

def install():  
    print("install")

    os.system("taskkill /f /im \"Phddns.exe\"") #杀掉正在运行的程序，保证覆盖安装

    if not os.path.exists(__path):
        os.makedirs(__path)
    
    pl_file = __path+'/version.pl'  #删除可能的残留文件
    if os.path.exists(pl_file):
        os.remove(pl_file)


def update():
    install()

def uninstall():
    print("uninstall")
    os.system("taskkill /f /im \"phddns_helper.exe\"")
    os.system("taskkill /f /im \"Phddns.exe\"")
    shutil.rmtree(__path)

if __name__ == "__main__":
    opt = sys.argv[1]
    if opt == 'update':
        update()
    elif opt == 'uninstall':
        uninstall()
    else:
        install()
