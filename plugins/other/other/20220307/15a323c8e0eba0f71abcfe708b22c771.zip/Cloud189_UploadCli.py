# encoding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: sudem sudem.sang@atonal.tech
# +-------------------------------------------------------------------

# 使用命令行上传 文件到天翼云盘
import os, sys, json, requests

os.chdir("/www/server/panel")
sys.path.append("class/")
import public

import cloud189_tools, cloud189_main

if "__main__" == __name__:
    print("===========================")
    print("Cloud189 BTpanel Plugin")
    print("You Are Use Cli Mode")
    print("===========================")
    _mkpath = False
    _md5 = False
    LocalPath = sys.argv[1]
    CloudPath = sys.argv[2]
    FileName = sys.argv[3]
    if len(sys.argv) > 4:
        if sys.argv[4] == 1:
            _mkpath = True
        print("已启动自动递归新建路径地址功能")
    if len(sys.argv) > 5:
        if sys.argv[5] == "md5":
            _md5 = True
        print("已启动自动递归新建路径地址功能")
    cloud = cloud189_tools.cloud189_tools()

    if _md5:
        FileExt = FileName.split(".")[1]
        FileName = public.FileMd5(LocalPath) + "." + FileExt

    _upload = True
    # CloudPath 的文件Id
    CloudPathId = cloud.FindPathFileId(CloudPath)
    if not CloudPathId:
        if _mkpath == 0:
            print("上传文件失败,云端路径地址[" + CloudPath + "]不存在!")
            _upload = False
        else:
            paths = CloudPath.split('/')
            path = "/"
            fileid = "-11"
            for p in paths:
                path = path + p
                fileid = cloud.FindPathFileId(path)
                if not fileid:
                    cloud.CreateNewFolder(fileid, p)
            CloudPathId = cloud.FindPathFileId(CloudPath)
            if not CloudPathId:
                print("自动递归新建文件夹失败,请检查文件路径[" + CloudPath + "]中是否含有特殊字符")
                _upload = False

    # 开始上传文件
    if _upload:
        cloud_main = cloud189_main.cloud189_main()
        upload = public.dict_obj()
        upload.localpath = LocalPath
        upload.filename = FileName
        upload.parentId = CloudPathId
        cloud_main.UploadFile_CLI(upload)
