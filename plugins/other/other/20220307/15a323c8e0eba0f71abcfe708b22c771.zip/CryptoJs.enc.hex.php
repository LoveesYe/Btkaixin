<?php

// 用于解码天翼的上传使用的 CryptoJS 的 PHP
// 注意，即使客户服务器没有安装PHP 环境，插件会自动请求 https://tools.iw3c.com.cn/nodejs/Base64_HexParse 
// 由远端对数据进行编码

error_reporting(E_ALL ^ E_WARNING  ^ E_DEPRECATED);

function is_cli(){
    return preg_match("/cli/i", php_sapi_name()) ? true : false;
}

if(is_cli()) $text = $argv[1];
else $text = $_REQUEST["text"];
if($text=="") {
    $rdata["status"] = "error";
    $rdata["msg"] = "编码数据失败，传入的数据不能为空";
    $rdata["data"] = null;
}
else {
    $rdata["status"] = "success";
    $rdata["msg"] = "编码数据成功";
    $rdata["data"] = base64_encode(pack('H*', $text));;
}
echo json_encode($rdata);