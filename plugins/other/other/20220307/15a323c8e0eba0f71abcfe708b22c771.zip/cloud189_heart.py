# encoding: utf-8
#!/usr/bin/python
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: sudem sudem.sang@atonal.tech
# +-------------------------------------------------------------------

# 本脚本、插件部分依赖修改了来自 Aruelius 的 cloud189 项目
# Thanks https://github.com/Aruelius/cloud189
# 向协同编写 此项目的 rachpt 、 cxyzzz 、 qip 、 Morxi 表示衷心的感谢
# 本项目 在 github 开源


# 本脚本的用于 每间隔1分钟向该死的天翼网盘发送一个心跳包
# 使得天翼网盘认为你一直维持在线
import time,os,sys
import cloud189_tools,cloud189_main

#设置运行目录
os.chdir("/www/server/panel")

#添加包引用位置并引用公共包
sys.path.append("class/")
import public

if __name__ == "__main__":
    cloud = cloud189_tools.cloud189_tools()
    main  = cloud189_main.cloud189_main()
    config = main.ReadPanelConfig("")
    while True:
        cloud.SendHeartBeat()
        time.sleep(int(config["Config"]["HeartTime"]))



