# encoding: utf-8
import os,sys,platform,json,re

# 插件预初始化，解决插件在python2.7.5 环境下报错的问题
# 插件已经做 2.7.5 版本环境的兼容处理 但仍然建议用户升级到最新的python 3.x

def ReadFile(filename,mode = 'r'):
    """
    读取文件内容
    @filename 文件名
    return string(bin) 若文件不存在，则返回None
    """
    import os
    if not os.path.exists(filename): return False
    try:
        fp = open(filename, mode)
        f_body = fp.read()
        fp.close()
    except Exception as ex:
        if sys.version_info[0] != 2:
            try:
                fp = open(filename, mode,encoding="utf-8")
                f_body = fp.read()
                fp.close()
            except:
                fp = open(filename, mode,encoding="GBK")
                f_body = fp.read()
                fp.close()
        else:
            return False
    return f_body

def WriteFile(filename,s_body,mode='w+'):
    """
    写入文件内容
    @filename 文件名
    @s_body 欲写入的内容
    return bool 若文件不存在则尝试自动创建
    """
    try:
        fp = open(filename, mode)
        fp.write(s_body)
        fp.close()
        return True
    except:
        try:
            fp = open(filename, mode,encoding="utf-8")
            fp.write(s_body)
            fp.close()
            return True
        except:
            return False
# 取操作系统版本
def GetSystemVersion():
    key = 'sys_version'
    version = ReadFile('/etc/redhat-release')
    if not version:
        version = ReadFile('/etc/issue').strip().split("\n")[0].replace('\\n', '').replace('\l', '').strip()
    else:
        version = version.replace('release ', '').replace('Linux', '').replace('(Core)', '').strip()
    return version


# 取宝塔面板的版本
comm = ReadFile('/www/server/panel/class/common.py')
bt_ver = re.search("g\.version\s*=\s*'(\d+\.\d+\.\d+)'", comm).groups()[0]
# 取python 的版本
py_ver = platform.python_version()
# 取当前服务器的版本
sys_ver = GetSystemVersion()

env ={"bt":bt_ver,"python":py_ver,"os":sys_ver}
WriteFile("/www/server/panel/plugin/cloud189/static/js/env.js","var env="+json.dumps(env))
print("var env="+json.dumps(env))




