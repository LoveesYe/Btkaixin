# encoding: utf-8
# !/usr/bin/python
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: sudem sudem.sang@atonal.tech
# +-------------------------------------------------------------------

# 本脚本、插件部分依赖修改了来自 Aruelius 的 cloud189 项目
# Thanks https://github.com/Aruelius/cloud189
# 向协同编写 此项目的 rachpt 、 cxyzzz 、 qip 、 Morxi 表示衷心的感谢
# 本项目 在 github 开源

import os, requests, json, re, time, base64, hashlib, sys, time, math, hmac, rsa
from binascii import b2a_hex, a2b_hex
from urllib.parse import quote, unquote, urlencode
from bs4 import BeautifulSoup
from Crypto.Cipher import AES
from hashlib import sha1

# 设置运行目录
os.chdir("/www/server/panel")

# 添加包引用位置并引用公共包
sys.path.append("class/")
import public


class cloud189_tools:
    __session = requests.session()
    __init_login = False
    __plugin_path = "/www/server/panel/plugin/cloud189/"
    __rsa = """-----BEGIN PUBLIC KEY-----
MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDY7mpaUysvgQkbp0iIn2ezoUyh
i1zPFn0HCXloLFWT7uoNkqtrphpQ/63LEcPz1VYzmDuDIf3iGxQKzeoHTiVMSmW6
FlhDeqVOG094hFJvZeK4OzA6HVwzwnEW5vIZ7d+u61RV1bsFxmB68+8JXs3ycGcE
4anY+YzZJcyOcEGKVQIDAQAB
-----END PUBLIC KEY-----
"""

    def __init__(self):
        self.headers = {
            'Accept':'application/json;charset=UTF-8',
            'Referer': 'https://cloud.189.cn/main.action',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36'
        }
        self.__session.headers.update(self.headers)

    def encrypt(self, password):
        return base64.b64encode(
            rsa.encrypt((password).encode('utf-8'), rsa.PublicKey.load_pkcs1_openssl_pem(self.__rsa.encode()))).decode()

    def int2char(self, a):
        BI_RM = list("0123456789abcdefghijklmnopqrstuvwxyz")
        return BI_RM[a]

    def b64tohex(self, a):
        b64map = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
        d = ""
        e = 0
        for i in range(len(a)):
            if list(a)[i] != "=":
                v = b64map.index(list(a)[i])
                if 0 == e:
                    e = 1
                    d += self.int2char(v >> 2)
                    c = 3 & v
                elif 1 == e:
                    e = 2
                    d += self.int2char(c << 2 | v >> 4)
                    c = 15 & v
                elif 2 == e:
                    e = 3
                    d += self.int2char(c)
                    d += self.int2char(v >> 2)
                    c = 3 & v
                else:
                    e = 0
                    d += self.int2char(c << 2 | v >> 4)
                    d += self.int2char(15 & v)
        if e == 1:
            d += self.int2char(c << 2)
        return d

    def LoginInit(self):
        #修复登录出错的问题 
        init = self.__session.get("https://cloud.189.cn/api/portal/loginUrl.action?redirectURL=https%3A%2F%2Fcloud.189.cn%2Fweb%2Fredirect.html")
        try:
            captchaToken = re.findall(r"captchaToken' value='(.+?)'", init.text)[0]
            lt = re.findall(r'lt = "(.+?)"', init.text)[0]
            returnUrl = re.findall(r"returnUrl = '(.+?)'", init.text)[0]
            paramId = re.findall(r'paramId = "(.+?)"', init.text)[0]
            self.__session.headers.update({"lt": lt})
            return captchaToken, returnUrl, paramId
        except:
            if self.__init_login:
                return False, False, False
            else:
                self.__init_login = True
                return self.LoginInit()

    def LoginCaptcha(self, captchaToken, username):
        r = self.__session.post(
            url="https://open.e.189.cn/api/logbox/oauth2/needcaptcha.do",
            data={"accountType": "01", "userName": "{RSA}" + self.b64tohex(self.encrypt(username)), "appKey": "cloud"}
        )
        if r.text == "0":
            return ""
        else:
            r = self.__session.get(
                url="https://open.e.189.cn/api/logbox/oauth2/picCaptcha.do",
                params={"token": captchaToken}
            )
            if not os.path.exists(self.__plugin_path + "static/webcache/"):
                os.mkdir(self.__plugin_path + "static/webcache/")
            captcha = self.__plugin_path + "static/webcache/captcha_" + public.GetRandomString(16) + ".png"
            with open(captcha, "wb") as f:
                f.write(r.content)
                f.close()
            captcha = captcha.replace("/www/server/panel/plugin", "")
            return captcha

    def LoginPost(self, username, password, validateCode, captchaToken, returnUrl, paramId):
        r = self.__session.post(
            url="https://open.e.189.cn/api/logbox/oauth2/loginSubmit.do",
            data={
                "appKey": "cloud",
                "accountType": '01',
                "userName": "{RSA}" + self.b64tohex(self.encrypt(username)),
                "password": "{RSA}" + self.b64tohex(self.encrypt(password)),
                "validateCode": validateCode,
                "captchaToken": captchaToken,
                "returnUrl": returnUrl,
                "mailSuffix": "@189.cn",
                "paramId": paramId
            }
        )
        login = json.loads(r.text)
        if login["result"] == 0:
            self.__session.get(login["toUrl"])
            self.SaveUserCookies()
            self.CloseAllHeartCli()
            self.StartHeartCli()
        return login

    # 发送心跳包
    def SendHeartBeat(self):
        url = "https://cloud.189.cn/api/open/user/getUserInfoForPortal.action"
        r = requests.get(url, headers=self.headers, cookies=self.LoadUserCookies())
        if os.path.exists(self.__plugin_path + "Users/UserCache.json"):
            UserCache = json.loads(public.ReadFile(self.__plugin_path + "Users/UserCache.json"))
        else:
            UserCache = {}
        UserCache["HeartBeat"] = public.format_date()
        self.WriteLog("发送心跳请求成功!")
        public.WriteFile(self.__plugin_path + "Users/UserCache.json", json.dumps(UserCache))
        public.WriteFile(self.__plugin_path + "heart.log",r.text)
        return json.loads(r.text)

    def CloseAllHeartCli(self):
        popen = os.popen("ps -ef | grep btpython")
        tasks = popen.read()
        popen.close()
        tasks = tasks.split("\n")
        for task in tasks:
            if task != "":
                task = task.split(" ")
                task_str = []
                for t in task:
                    if t != "":
                        if len(task_str) >= 8:
                            task_str[7] = task_str[7] + " " + t
                        else:
                            task_str.append(t)
                pid = task_str[1]
                shell = task_str[7]
                if shell == "btpython /www/server/panel/plugin/cloud189/cloud189_heart.py":
                    public.ExecShell("kill -9 " + pid)

    def StartHeartCli(self):
        public.ExecShell("nohup btpython " + self.__plugin_path + "cloud189_heart.py &")

    def SaveUserCookies(self):
        if not os.path.exists(self.__plugin_path + "Users"):
            os.mkdir(self.__plugin_path + "Users")
        public.WriteFile(self.__plugin_path + "Users/CloudCache.json", json.dumps(self.__session.cookies.get_dict()))

    def LoadUserCookies(self):
        try:
            Cookies = json.loads(public.ReadFile(self.__plugin_path + "Users/CloudCache.json"))
            return Cookies
        except:
            return {}

    # 取用户的个人信息
    def ReadUserInfo(self):
        r = requests.get("https://cloud.189.cn/v2/getLoginedInfos.action?showPC=true", headers=self.headers,
                         cookies=self.LoadUserCookies())
        UserInfo = json.loads(r.text)
        try:
            return {"status": UserInfo["errorCode"], "msg": UserInfo["errorMsg"]}
        except:
            if os.path.exists(self.__plugin_path + "Users/UserCache.json"):
                UserCache = json.loads(public.ReadFile(self.__plugin_path + "Users/UserCache.json"))
            else:
                UserCache = {}
            UserCache["LoginInfo"] = UserInfo
            public.WriteFile(self.__plugin_path + "Users/UserCache.json", json.dumps(UserCache))
            UserInfo["status"] = "success"
            UserInfo["path"] = self.__plugin_path + "Users/UserCache.json"
            return UserInfo

    # 取指定目录的文件列表
    # v1.1 支持关键字搜索
    def ReadFileList(self, fileid, page=1, keyword=""):
        if keyword!="":
            return self.SearchFileList(fileid, page, keyword)
        # 修复天翼 文件列表地址修改
        url = "https://cloud.189.cn/api/open/file/listFiles.action?pageSize=50&pageNum="+ str(page) +"&mediaType=0&folderId="+ str(fileid)+"&iconOption=5&orderBy=lastOpTime&descending=true"
        r = requests.get(url, headers=self.headers, cookies=self.LoadUserCookies())
        list =  json.loads(r.text)["fileListAO"]
        for item in list["fileList"]:
            item["id"]  = str(item["id"])
        for item in list["folderList"]:
            item["id"] = str(item["id"])
        path =  self.ReadFilePathNode(fileid,[])
        list["filepath"] = path["filepath"]
        list["pathdirs"] = path["pathdirs"]
        return list

    def SearchFileList(self,fileid,page,keyword):
        # 修复天翼 文件列表地址修改
        url = "https://cloud.189.cn/api/open/file/searchFiles.action?pageSize=50&pageNum=" + str(
            page) + "&folderId=" + str(fileid) + "&iconOption=5&orderBy=lastOpTime&descending=true&filename=" + str(keyword)
        r = requests.get(url, headers=self.headers, cookies=self.LoadUserCookies())
        list = json.loads(r.text)
        for item in list["fileList"]:
            item["id"] = str(item["id"])
        for item in list["folderList"]:
            item["id"] = str(item["id"])
        path = self.ReadFilePathNode(fileid, [])
        list["filepath"] = path["filepath"]
        list["pathdirs"] = path["pathdirs"]
        return list


    def ReadFilePathNode(self,fileid,pathdirs=[]):
        file = self.ReadFileInfo(fileid)
        if fileid != "-11":
            parentId = file["parentId"]
            filepath =  file["fileName"]
            if file["isFolder"]:
                filepath = filepath + "/"
                pathdirs.insert(0,{"fileId":fileid,"fileName":file["fileName"]})
            fileNode = self.ReadFilePathNode(parentId,pathdirs)
            filepath = fileNode["filepath"] + filepath
            return {"filepath":filepath,"pathdirs":pathdirs}
        else:
            pathdirs.insert(0, {"fileId":"-11","fileName":""})
            return {"filepath":"/","pathdirs":pathdirs}


    def ReadFileListAll(self, fileid,spage=1):
        FileList = self.ReadFileList(fileid)
        FileNums = FileList["count"]
        PageNums = math.ceil(float(FileNums) / 50)
        page = 1
        fileList = []
        folderList = []
        while page <= PageNums:
            if page != 1:
                FileList = self.ReadFileList(fileid, page)
            # 天翼接口更改 先遍历所有的文件夹
            for folder in FileList["folderList"]:
                folderList.append(folder)
            # 接着遍历所有的文件
            for file in FileList["fileList"]:
                fileList.append(file)
            page = page + 1
        if spage == -1:
            return {"status": "success", "page": -1, "fileid": fileid,
                    "data": {"fileList": fileList, "folderList": folderList}}
        else:
            folderPage = math.ceil(len(folderList) / 50)
            if spage <= folderPage:
                if (spage * 50) > len(folderList):
                    smax = len(folderList)
                    fs = (spage-1) * 50
                    fe = smax -1
                    folder = folderList[fs:fe]
                    fs = 0
                    fe = (spage * 50) - smax
                    if fe > len(fileList):
                        fe = len(fileList)
                    file = fileList[fs:fe-1]
                else:
                    file = []
                    folder = folderList[:(spage-1)*50,:spage*50-1]
                return {"status": "success", "page": spage, "fileid": fileid,
                        "data": {"fileList": file, "folderList": folder}}
            else:
                sp = folderPage * 50 - len(folderList)
                tpage = (spage - folderPage)
                file = fileList[sp + (tpage-1) * 50 : tpage * 50-1]
                return {"status": "success", "page": spage, "fileid": fileid,
                        "data": {"fileList": file, "folderList": []}}

    # 递归遍历取天翼云下面所有的文件
    def ReadPanAllFile(self, fileId="-11", path=""):
        PanFile = []
        print("请求目录[" + path + "](" + fileId + ")下面的所有文件")
        Files = self.ReadFileListAll(fileId, -1)["data"]
        for file in Files["folderList"]:
            file["filePath"] = path + "/" + file["name"]
            dirFile = self.ReadPanAllFile(file["id"], file["filePath"])
            for dfile  in dirFile:
                PanFile.append(dfile)
        for file in Files["fileList"]:
            file["filePath"] = path + "/" + file["name"]
            PanFile.append(file)
        return PanFile

    # 取指定文件的详细信息
    def ReadFileInfo(self, fileid):
        Config = json.loads(public.ReadFile(self.__plugin_path + "Users/PanelConfig.json"))
        try:
            FileInfo_Ver = Config["Link_FileInfo_Ver"]
        except:
            FileInfo_Ver = "V1"
        if FileInfo_Ver == "V1":
            try:
                url = "https://cloud.189.cn/api/portal/getFileInfo.action?fileId=" + fileid
                r = requests.get(url, headers=self.headers, cookies=self.LoadUserCookies())
                file = json.loads(r.text)
                file["FileInfo_Ver"] = "V1"
                file["url"] = url
                return file
            except:
                files = self.ReadFileList(fileid)
                lkey = len(files["path"]) - 2
                ppath = files["path"][lkey]
                file = self.ReadFileListAll(ppath["fileId"], -1, "", fileid)
                if file["status"] == "success":
                    file["file"]["FileInfo_Ver"] = "V2"
                    return file["file"]
                else:
                    return {"status": "error", "msg": "读取文件信息失败"}
        else:
            try:
                files = self.ReadFileList(fileid)
                lkey = len(files["path"]) - 2
                ppath = files["path"][lkey]
                file = self.ReadFileListAll(ppath["fileId"], -1, "", fileid)
                if file["status"] == "success":
                    file["file"]["FileInfo_Ver"] = "V2"
                    return file["file"]
                else:
                    return {"status": "error", "msg": "读取文件信息失败"}
            except:
                url = "https://cloud.189.cn/api/portal/getFileInfo.action?fileId=" + fileid
                r = requests.get(url, headers=self.headers, cookies=self.LoadUserCookies())
                file= json.loads(r.text)
                file["FileInfo_Ver"] = "V1"
                return  file




    # 取指定文件的下载地址信息
    def ReadFileDownLoadLink(self, fileid):
        if int(fileid) < 0:
            self.WriteLog("获取fid:" + fileid + "的文件的下载地址失败,不允许取fileid <0 的文件")
            return {"status": "error", "msg": "获取文件下载地址失败,不允许取fileid <0 的文件"}
        url = "https://cloud.189.cn/api/portal/getFileInfo.action?fileId=" + fileid
        r = requests.get(url, headers=self.headers, cookies=self.LoadUserCookies())
        file = json.loads(r.text)
        downloadUrl = "https:" + file["downloadUrl"]
        try:
            ra = requests.get(downloadUrl, headers=self.headers, cookies=self.LoadUserCookies(),
                              allow_redirects=False)
            download189 = ra.headers["Location"]
            rq = requests.get(download189, headers=self.headers, cookies=self.LoadUserCookies(),
                              allow_redirects=False)
            redirecturl = rq.headers["Location"]
            try:
                Expires = redirecturl.split("Expires=")[1].split("&")[0]
            except:
                Expires = ""
            self.WriteLog("解析指定的文件:" + fileid + "的地址成功，oSs下载地址:" + redirecturl)
            return {"status": "success", "downloadurl": downloadUrl, "redirecturl": redirecturl,
                    "Expire": Expires, "donwload_189": download189,"info":file}
        except:
            self.WriteLog("解析指定的文件:" + fileid + "的地址失败，未知错误")
            return {"status": "error", "msg": "获取文件下载地址失败,未知错误", "downloadUrl": downloadUrl}

    # 解析天翼分享的文件的外链 版本2
    def ReadFileShareLinkV2(self, link, password=False):
        # 从连接中提取 code
        code = re.findall(r"code=[A-Za-z0-9]*", link)
        if len(code) != 1:
            code = re.findall(r"^[A-Za-z0-9].*$", link)
            if len(code) == 1:
                code = code[0]
            else:
                return {"status": "error",
                        "msg": "分享连接格式有误,目前仅支持 https://cloud.189.cn/web/share?code=xxxxxxxx 和 https://cloud.189.cn/t/xxxxxx 格式的链接 ",
                        "len": len(code)}
        else:
            code = code[0].replace("code=", "")
        # 取分享的文件 / 文件夹名称信息
        rheader = self.headers
        rheader["accept"] = "application/json;charset=UTF-8"
        share = json.loads(
            requests.get("https://cloud.189.cn/api/open/share/getShareInfoByCode.action?shareCode=" + code,
                         headers=rheader, cookies=self.LoadUserCookies()).text)
        if share["isFolder"]:
            share["isFolder"] = "true"
        else:
            share["isFolder"] = "false"
        # 取分享的文件的内容数据信息
        url = "https://cloud.189.cn/api/open/share/listShareDir.action?pageNum=1&pageSize=60" \
              + "&fileId=" + share["fileId"] + "&shareDirFileId=" + share["fileId"] + "&isFolder=" \
              + share["isFolder"] + "&shareId=" + str(share["shareId"]) + "&shareMode=" + str(share["shareMode"]) + \
              "&iconOption=5&orderBy=lastOpTime&descending=true"
        if password:
            url = url + "&accessCode=" + password
        files = json.loads(requests.get(url, headers=rheader, cookies=self.LoadUserCookies()).text)
        if "response" in files: files = files["response"]
        if str(files["res_code"]) != "0":
            return {"status": "error", "cloud_msg": files["res_message"], "msg": "解析分享谅解地址出错,请检查地址、分享密码是否有效"}
        else:
            fileList = []
            expire = False
            for file in files["fileListAO"]["fileList"]:
                url = "https://cloud.189.cn/api/open/file/getFileDownloadUrl.action?fileId=" + str(
                    file["id"]) + "&dt=1&shareId=" + str(share["shareId"])
                download = json.loads(requests.get(url, headers=self.headers, cookies=self.LoadUserCookies()).text)
                if(str(download["res_code"])!='0'):
                    file["res_code"] = str(download["res_code"])
                    file["downloadUrl"]  = ''
                    fileList.append(file)
                else:
                    downloadUrl = download["fileDownloadUrl"]
                    resp = requests.get(downloadUrl, allow_redirects=False)
                    file["downloadUrl"] = resp.headers["Location"]
                    rp = self.UrlParse(file["downloadUrl"])
                    expire = rp["args"]["Expires"]
                    file["res_code"] = '0'
                    fileList.append(file)
            return {"status": "success", "count": len(fileList), "files": fileList,"expires": expire}


    # 解析天翼分享的文件的外链
    def ReadFileShareLink(self, link, password=False):
        slink = link
        link = "https://cloud.189.cn/t/" + link
        shareHtml = requests.get(link, headers=self.headers, cookies=self.LoadUserCookies()).text
        public.WriteFile(self.__plugin_path + "static/debug.html", shareHtml)
        file_request = {}
        shareid = ""
        verifyCode = ""
        downloadurl = ""
        try:
            _shareId = re.search("var _shareId = '\d+';", shareHtml).group()
            _verifyCode = re.search("var _verifyCode = '\d+';", shareHtml).group()
            shareid = _shareId.split("'")[1]
            verifyCode = _verifyCode.split("'")[1]
        except:
            soup = BeautifulSoup(shareHtml, "html.parser")
            inputs = soup.find_all("input")
            for input in inputs:
                try:
                    if input["class"][0] == "shareId":
                        shareid = input["value"]
                    if input["class"][0] == "downloadUrl":
                        downloadurl = "https:" + input["value"]
                except:
                    pass
        if shareid == "":
            self.WriteLog("解析分享的链接地址:" + slink + "失败,指定的外链格式错误或者已经被删除")
            return {"status": "unfind", "msg": "指定的外链地址格式错误或分享的文件已经被删除", "link": link}
        else:
            # 多文件请求
            if verifyCode != "":
                url = "https://cloud.189.cn/v2/listShareDirByShareIdAndFileId.action?shortCode=" + slink + "&accessCode=" + \
                      password + "&verifyCode=" + verifyCode + "&orderBy=1&order=ASC&pageNum=1&pageSize=60"
                r = requests.get(url, headers=self.headers, cookies=self.LoadUserCookies())
                file_request = json.loads(r.text)
                fileids = ""
                redirecturl = []
                downloadurl = []
                Expires = []
                try:
                    for file in file_request["data"]:
                        url = "https://cloud.189.cn/v2/getFileDownloadUrl.action?shortCode=" + slink + "&fileId=" + \
                              file["fileId"]
                        url = requests.get(url, headers=self.headers, cookies=self.LoadUserCookies()).text
                        url = url.replace("\/", "/")
                        url = url.replace("\"", "")
                        downloadurl.append(url)
                        redirecturl.append(self.ReadRedirectUrl("https:" + url))
                        result = self.UrlParse(redirecturl)
                        Expires = append(result["args"]["Expires"])

                except:
                    self.WriteLog("解析分享的链接地址:" + slink + "失败,指定的外链格式或密码错误，或者已经被删除")
                    return {"status": "error", "shareid": shareid, "cloud": file_request, "verifyCode": verifyCode,
                            "link": link}
            else:
                if downloadurl != "https:":
                    redirecturl = self.ReadRedirectUrl(downloadurl)
                else:
                    if not password:
                        return {"status": "pass_error", "fileVO": shareid}
                    url = "https://cloud.189.cn/shareFileVerifyPass.action?fileVO.id=" + shareid + "&accessCode=" + password
                    Verify = requests.get(url, headers=self.headers, cookies=self.LoadUserCookies()).text

                    if Verify == "":
                        self.WriteLog("解析分享的链接地址:" + link + "失败,用户输入的密码不正确!")
                        return {"status": "pass_error", "fileVO": shareid, "msg": "解析地址失败，用户输入的密码不正确"}
                    else:
                        try:
                            downloadurl = json.loads(Verify)["longDownloadUrl"]
                            redirecturl = self.ReadRedirectUrl(downloadurl, True)
                            self.WriteLog("解析分享的链接地址:" + link + "成功，oos下载地址:" + redirecturl)
                        except:
                            # 使用 大文件解析API
                            url = "https://cloud.189.cn/shareFileByVerifyCode.action?accessCode=" + password + "&shortCode=" + slink
                            info = requests.get(url, headers=self.headers, cookies=self.LoadUserCookies()).text
                            fileId = json.loads(info)["fileId"]
                            # 请求文件下载地址
                            url = "https://cloud.189.cn/v2/getFileDownloadUrl.action?shortCode=" + slink + "&fileId=" + fileId
                            url = requests.get(url, headers=self.headers, cookies=self.LoadUserCookies()).text
                            url = url.replace("\/", "/")
                            downloadurl = url.replace("\"", "")
                            redirecturl = self.ReadRedirectUrl("https:" + downloadurl)
                        result = self.UrlParse(redirecturl)
                        Expires = result["args"]["Expires"]
            return {"status": "success", "msg": "获取链接解析地址成功", "args": result["args"], "host": result["host"],
                    "OssFilePath": result["path"], "shareid": shareid, "cloud": file_request, "verifyCode": verifyCode,
                    "downloadurl": "https:" + downloadurl, "redirecturl": redirecturl, "expires": Expires}

    def ReadRedirectUrl(self, url, Verify=False):
        ra = requests.get(url, headers=self.headers, cookies=self.LoadUserCookies(), allow_redirects=False)
        redirect = ra.headers["Location"]
        if Verify:
            return redirect.replace("http://", "https://")
        r = requests.get(redirect, headers=self.headers, cookies=self.LoadUserCookies(), allow_redirects=False)
        return r.headers["Location"]

    def CreateNewFolder(self, parentId, filename):
        url = "https://cloud.189.cn/api/open/file/createFolder.action"
        content = {'parentFolderId':parentId,"folderName":filename}
        r = requests.post(url,data=content, headers=self.headers, cookies=self.LoadUserCookies())
        return json.loads(r.text)

    def TaskFileFloder(self, type, taskInfos, targetFolderId=False):
        post = {}
        post["type"] = type
        post["taskInfos"] = json.dumps(taskInfos)
        if targetFolderId:
            post["targetFolderId"] = targetFolderId
        url = "https://cloud.189.cn/createBatchTask.action"
        r = requests.post(url, data=post, headers=self.headers, cookies=self.LoadUserCookies())
        taskid = r.text.strip('"').strip('\'')
        return {"status": "success", "taskid": taskid, "type": type,"url":url,"data":post       }

    def TaskStatusRead(self, taskid, type):
        post = {}
        post["type"] = type
        post["taskId"] = taskid
        url = "https://cloud.189.cn/checkBatchTask.action"
        r = requests.post(url, data=post, headers=self.headers, cookies=self.LoadUserCookies())
        return json.loads(r.text)

    def ReadUserRecycle(self, pageid, pagesize):
        pageid = str(pageid)
        pagesize = str(pagesize)
        url = "https://cloud.189.cn/v2/listRecycleBin.action?pageNum=" + pageid + "&pageSize=" + pagesize
        r = requests.get(url, headers=self.headers, cookies=self.LoadUserCookies())
        recycle = json.loads(r.text)
        return recycle

    # 此方法弃用
    def DeleteFileFormRecycle(self, fileid, familyId):
        url = "https://cloud.189.cn/v2/deleteFile.action?familyId=" + familyId + "&fileIdList=" + fileid
        r = requests.get(url, headers=self.headers, cookies=self.LoadUserCookies())
        return json.loads(r.text)

    # 此方法弃用
    def EmptyRecycle(self, familyId):
        url = "https://cloud.189.cn/v2/emptyRecycleBin.action?familyId=" + familyId
        r = requests.get(url, headers=self.headers, cookies=self.LoadUserCookies())
        return json.loads(r.text)

    def ShareFilePublic(self, fileid, time):
        url = "https://cloud.189.cn/v2/createOutLinkShare.action?fileId=" + str(fileid) + "&expireTime=" + str(time)
        r = requests.get(url, headers=self.headers, cookies=self.LoadUserCookies())
        OutLink = json.loads(r.text)
        url = "https://cloud.189.cn/v2/setOpenShare.action?shareVO.shareId=" + str(OutLink["shareId"])
        r = requests.get(url, headers=self.headers, cookies=self.LoadUserCookies())
        ShareId = json.loads(r.text)
        if int(ShareId["shareId"]) == int(OutLink["shareId"]):
            return {"status": "success", "shortShareUrl": OutLink["shortShareUrl"], "accesssCode": False}
        else:
            return {"status": "error", "OutLink": OutLink}

    def ShareFilePrivate(self, fileid, time):
        url = "https://cloud.189.cn/v2/privateLinkShare.action?fileId=" + str(fileid) + "&expireTime=" + str(
            time) + "&withAccessCode=1"
        r = requests.get(url, headers=self.headers, cookies=self.LoadUserCookies())
        return json.loads(r.text)

    def ListUserShare(self, pageid, pagenum):
        pageid = str(pageid)
        pagenum = str(pagenum)
        url = "https://cloud.189.cn/v2/listShares.action?shareType=1&pageNum=" + pageid + "&pageSize=" + pagenum
        r = requests.get(url, headers=self.headers, cookies=self.LoadUserCookies())
        return json.loads(r.text)

    def CancelUserShare(self, shareId):
        shareId = str(shareId)
        url = "https://cloud.189.cn/v2/cancelShare.action?shareIdList=" + shareId + "&cancelType=1"
        r = requests.get(url, headers=self.headers, cookies=self.LoadUserCookies())
        return json.loads(r.text)

    def FindPathfileName(self, FileId, fileName):
        Paths = self.ReadFileList(FileId)
        for item in Paths["data"]:
            if item["fileName"] == fileName:
                return item["fileId"]
        return False

    # 解析网盘文件的地址
    def FindPathFileId(self, CloudPath):
        if CloudPath == "/":
            return "-11"
        else:
            fileid = "-11"
            Paths = CloudPath.split("/")
            for p in Paths:
                if p != "":
                    fileid = self.FindPathfileName(fileid, p)
                if not fileid:
                    break
            return fileid

    # 预上传文件
    def UploadFile_Init(self, filename, localpath, parentId):
        print("预上传文件切片中...")
        silpts = self.FileSlipt(localpath)
        fid = silpts["fid"]
        cut = 0
        print("预上传文件切片结束，切片id[" + fid + "]")
        filesize = os.path.getsize(localpath)
        # userflow = self.GetUserFlowToday()
        # if filesize >= userflow:
        #     self.WriteLog("上传文件(" + localpath + ")失败,用户今日可用上传流量不足,需要(" + filesize + "),用户剩余(" + (userflow - 1) + ")")
        #     return {"status": "flow",
        #             "msg": "上传文件(" + localpath + ")失败,用户今日可用上传流量不足,需要(" + filesize + "),用户剩余(" + (userflow - 1) + ")"}
        chunksMd5Hex = []
        chunksMd5Base = []
        chunksMd5Str = ""
        print("计算文件分片信息中...")
        while cut < silpts["bags"]:
            cut_filename = "/PythonFileSplit/" + fid + "/" + fid + "_" + str(cut + 1) + ".cut"
            cut_md5 = public.FileMd5(cut_filename).upper()
            print("第[" + str(cut + 1) + "/" + str(silpts["bags"]) + "]个文件分片的MD5:" + cut_md5)
            chunksMd5Hex.append(cut_md5)
            chunksMd5Str = chunksMd5Str + chunksMd5Hex[cut]
            if cut + 1 < silpts["bags"]:
                chunksMd5Str = chunksMd5Str + "\n"
            chunksMd5Base.append(self.Parse_CryptoJS_enc_hex(chunksMd5Hex[cut]))
            cut = cut + 1
        print("计算文件md5中...")
        md5 = public.FileMd5(localpath)
        print("文件的MD5:" + md5)
        if silpts["bags"] > 1:
            sliceMd5 = public.md5(chunksMd5Str)
        else:
            sliceMd5 = md5
        data = {"fileName": quote(filename, 'utf-8'), "parentFolderId": parentId, "fileMd5": md5,
                "fileSize": filesize, "sliceMd5": sliceMd5, "sliceSize": 10 * 1024 * 1024}
        Init = {}
        Init["status"] = "success"
        Init["cloud"] = self.Cloud189_UploadXhr("/person/initMultiUpload", data)
        Init["chunksMd5Base"] = chunksMd5Base
        Init["silpts"] = silpts
        return Init

    # 获取当前需要上传的文件的分片信息
    def UploadFile_GetPartsInfo(self, uploadid):
        data = {"uploadFileId": uploadid}
        return self.Cloud189_UploadXhr("/person/getUploadedPartsInfo", data)

    # 获取每个分片在上传时的上传参数
    def UploadFile_GetMultUploads(self, uploadid, chunksMd5Base):
        id = 1
        partInfo = ""
        for chunk in chunksMd5Base:
            if id != 1:
                partInfo = partInfo + ","
            partInfo = partInfo + str(id) + "-" + chunk
            id = id + 1
        data = {"uploadFileId": uploadid, "partInfo": partInfo}
        return self.Cloud189_UploadXhr("/person/getMultiUploadUrls", data)

    # 开始执行分片上传
    def UploadFile_SendMultAll(self, Urls, silpts, filepath, fileid):
        id = 1
        upload = {}
        while id <= silpts["bags"]:
            log = "开始上传文件（" + filepath + ") 第 （" + str(id) + "/" + str(silpts["bags"]) + "个文件分片)"
            self.WriteLog(log)
            _header = Urls["partNumber_" + str(id)]["requestHeader"]
            headers = _header.split("&")
            header = {}
            for h in headers:
                pos = h.find("=")
                key = h[0:pos]
                value = h[pos + 1:]
                header[key] = value
            url = Urls["partNumber_" + str(id)]["requestURL"]
            file = "/PythonFileSplit/" + silpts["fid"] + "/" + silpts["fid"] + "_" + str(id) + ".cut"
            uploadtry = 0
            while uploadtry < 3:
                upload["res_" + str(id)] = self.UploadFile_SendMult(url, header, file)
                if upload["res_" + str(id)]["text"] != "":
                    upload["res_" + str(id)]["status"] = "error"
                    log = "在第" + (uploadtry + 1) + "尝试(最多3次)"
                    log = log + "\n上传文件（" + filepath + ") 第 （" + str(id) + "/" + str(
                        silpts["bags"]) + "个文件分片时发生错误，云端fileid:" + fileid
                    log = log + "\n云端响应信息如下:" + upload["res_" + str(id)]["text"]
                    self.WriteLog(log)
                    if uploadtry == 2:
                        return {"status": "failed", "upload": upload, "filepath": filepath, "localfid": silpts["fid"],
                                "errorid": id}
                else:
                    upload["res_" + str(id)]["status"] = "success"
                    log = "上传文件（" + filepath + ") 第 （" + str(id) + "/" + str(
                        silpts["bags"]) + "个文件分片成功，云端fileid:" + fileid + " 云端ETAG:" + \
                          upload["res_" + str(id)]["header"]["ETag"]
                    self.WriteLog(log)
                    break
            id = id + 1
        return {"status": "success", "upload": upload, "filepath": filepath, "localfid": silpts["fid"]}

    # 上传文件分片
    def UploadFile_SendMult(self, url, header, file):
        header["User-Agent"] = self.headers["User-Agent"]
        header["Referer"] = "https://cloud.189.cn/main.action"
        header["Origin"] = "https://cloud.189.cn"
        r = requests.put(url, data=open(file, "rb"), headers=header)
        res = {}
        res["header"] = r.headers
        res["text"] = r.text
        return res

    # 完成文件上传
    def UploadFile_Commit(self, uploadid):
        data = {"uploadFileId": uploadid}
        return self.Cloud189_UploadXhr("/person/commitMultiUploadFile", data)

    # 取用户今日剩余流量
    def GetUserFlowToday(self):
        url = "https://cloud.189.cn/vip/todayFlowRemain.action"
        r = requests.get(url, headers=self.headers, cookies=self.LoadUserCookies())
        size = r.text
        if size == self.ReadUserSessionKey():
            size = 99999999999999
        return json.loads(size)

    # 获取天翼上传使用的 rsa 的密钥
    def GetCloudRsaKey(self):
        url = "https://cloud.189.cn/security/generateRsaKey.action?keyLength=1024"
        r = requests.get(url, headers=self.headers, cookies=self.LoadUserCookies())
        return json.loads(r.text)

    # 天翼坑爹的上传请求加密 (核心)
    def Cloud189_UploadXhr(self, url, data):
        uuid = self.Cloud189_RandStr('xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx')
        sessionSecret = self.Cloud189_RandStr('xxxxxxxxxxxx4xxxyxxxxxxxxxxxxxxx')[0:24]
        date = round(time.time() * 1000)
        xhrMethod = "GET"
        paramData = self.ParseDistUrl(data)
        key = sessionSecret[0:16]
        params = self.AES_Encrypt(key, paramData)
        headerData = {"SessionKey": self.ReadUserSessionKey(), "Operate": xhrMethod, "RequestURI": url, "Date": date,
                      "params": params}
        signData = self.ParseDistUrl(headerData)
        Signature = hmac.new(sessionSecret.encode(), signData.encode(), sha1).hexdigest()
        RsaKey = self.GetCloudRsaKey()
        EncryptionText = self.Cloud189_RSA(sessionSecret, RsaKey["pubKey"])
        headers = self.headers
        headers["SessionKey"] = self.ReadUserSessionKey()
        headers["Signature"] = Signature
        headers["X-Request-Date"] = str(date)
        headers["X-Request-ID"] = uuid
        headers["EncryptionText"] = EncryptionText
        headers["PkId"] = RsaKey["pkId"]
        headers["Referer"] = "https://cloud.189.cn/main.action"
        r = requests.get("https://upload.cloud.189.cn" + url + "?params=" + params, headers=headers)
        return json.loads(r.text)

    # 读取用户的FamilyId
    def ReadRecycleFamilyId(self):
        try:
            UserCache = json.loads(public.ReadFile(self.__plugin_path + "Users/UserCache.Json"))
            familyId = str(UserCache["Recycle"]["familyId"])
        except:
            Cloud = self.ReadUserRecycle(1, 50)
            familyId = str(Cloud["familyId"])
        return familyId

    # 读取用户的 SesssionKey
    def ReadUserSessionKey(self):
        try:
            UserCache = json.loads(public.ReadFile(self.__plugin_path + "Users/UserCache.json"))
            sessionKey = str(UserCache["LoginInfo"]["sessionKey"])
        except:
            Cloud = self.ReadUserInfo()
            sessionKey = str(Cloud["sessionKey"])
        return sessionKey

    # 取指定目录下的所有文件的总大小信息
    def ReadFileDirAllSize(self, fileid):
        fileCount = 0
        dirCount = 0
        fileSize = 0
        FileInfo = self.ReadFileInfo(fileid)
        if not FileInfo["isFolder"] :
            return {"status": "success", "fileid": fileid, "filesize": FileInfo["fileSize"], "type": "file"}
        else:
            FileList = self.ReadFileList(fileid)
            FileNums = FileList["count"]
            PageNums = math.ceil(float(FileNums) / 50)
            page = 1
            while page <= PageNums:
                if page != 1:
                    FileList = self.ReadFileList(fileid, page)
                # 天翼接口更改 先遍历所有的文件夹
                for folder in FileList["folderList"]:
                    fileSize = fileSize + self.ReadFileDirAllSize(folder["id"])["fileSize"]
                    dirCount = dirCount + 1
                # 接着遍历所有的文件
                for file in FileList["fileList"]:
                    fileSize = fileSize + file["size"]
                    fileCount = fileCount + 1
                page = page + 1
            return {"status": "success", "fileid": fileid, "fileSize": fileSize, "type": "dir",'fileCount':fileCount,'dirCount':dirCount}

    # 写插件日志
    def WriteLog(self, log):
        LogName = self.__plugin_path + "Users/PluginLog_" + public.format_date("%Y%m%d") + ".log"
        if os.path.exists(LogName):
            LogData = public.ReadFile(LogName)
        else:
            LogData = ""
        newlog = "[" + public.format_date() + "]" + log
        if LogData == "":
            LogData = newlog
        else:
            LogData = LogData + "\n" + newlog
        print(newlog)
        public.WriteFile(LogName, LogData)

    # 获取文件打包下载的地址
    # 注意这个接口已经废弃
    def GetFileGroupLink(self, fileids):
        url = "https://cloud.189.cn/downloadMultiFiles.action?sessionKey" + self.ReadUserSessionKey() + "&fileIdS=" + fileids + "&downloadType=1&recursive=1"
        r = requests.get(url, headers=self.headers, cookies=self.LoadUserCookies(), allow_redirects=False)
        vdownload = r.headers["Location"]
        self.WriteLog("获取文件打包下载地址成功，fileids:" + fileids + "，下载地址：" + vdownload)
        return vdownload

    # =============================================================
    #
    #    下方为 插件运行时用的一些自己定义的 工具函数
    #
    # =============================================================

    # 天翼坑逼的随机函数
    def Cloud189_RandStr(self, text):
        nums = len(text)
        i = 0
        newtext = ""
        while i < nums:
            if text[i] == "x" or text[i] == "y":
                newtext = newtext + public.GetRandomString(1).lower()
            else:
                newtext = newtext + text[i]
            i = i + 1
        return newtext

    # 调用远端接口进行 RSA 加密
    def Cloud189_RSA(self, text, pubKey, NodeJs=False):
        # 使用远端 NodeJS API 接口加密 （历史原因,不推荐）
        if NodeJs:
            data = {"text": text, "pubKey": pubKey}
            r = requests.post("https://tools.iw3c.com.cn/nodejs/rsa_encrypt", data=data)
            encrypt = json.loads(r.text)["result"]
            return encrypt
        else:
            rsa_pubKey = "-----BEGIN PUBLIC KEY-----\n" + pubKey + "\n-----END PUBLIC KEY-----\n"
            PublicKey = rsa.PublicKey.load_pkcs1_openssl_pem(rsa_pubKey.encode())
            password = text.encode("utf-8")
            encrypt = rsa.encrypt(password, PublicKey)
            enText = base64.b64encode(encrypt).decode()
            return enText

    # AES 加密
    def AES_Encrypt(self, key, data):
        pad = lambda s: s + (16 - len(s) % 16) * chr(16 - len(s) % 16)
        data = pad(data)
        cipher = AES.new(key.encode('utf8'), AES.MODE_ECB)
        encryptedbytes = cipher.encrypt(data.encode('utf8'))
        encodestrs = b2a_hex(encryptedbytes)
        return encodestrs.decode("utf-8")

    # 对指定的文件进行切片处理
    def FileSlipt(self, lpath, csize=1024 * 10):
        csize = csize * 1024
        f = open(lpath, "rb")
        # 生成文件识别编码
        fid = public.GetRandomString(16)
        # 统计需要切片数量
        bags = int(math.ceil(float(os.path.getsize(lpath)) / float(csize)))
        cut = 1
        if not os.path.exists("/PythonFileSplit"):
            os.mkdir("/PythonFileSplit")
        os.mkdir("/PythonFileSplit/" + fid)
        while cut != bags + 1:
            c = open("/PythonFileSplit/" + fid + "/" + fid + "_" + str(cut) + ".cut", "wb")
            fdata = f.read(csize)
            c.write(fdata)
            c.close()
            cut = cut + 1
        return {"fid": fid, "bags": bags}

    # 删除指定的文件切片
    def RemoveFileSlipt(self, fid):
        public.ExecShell("rm -rf /PythonFileSplit/" + fid)

    # 对指定的字符串进行CryptoJS.enc.hex.编码
    def Parse_CryptoJS_enc_hex(self, text):
        # public.WriteFile(self.__plugin_path+"CryptoJS_HEX.tmp",text)
        EnvirPHP = self.GetPanelPhpEnvir()
        if not EnvirPHP:
            data = {"text": text}
            r = requests.post("https://tools.iw3c.com.cn/nodejs/Base64_HexParse", data=data)
            Parse = json.loads(r.text)["result"]
        else:
            popen = os.popen("php " + self.__plugin_path + "CryptoJs.enc.hex.php " + text)
            Parse = json.loads(popen.read())["data"]
            popen.close()
        return Parse

    # 判断客户机器是否存在PHP 环境
    def GetPanelPhpEnvir(self):
        popen = os.popen("php -v")
        shell = popen.read()
        popen.close()
        # 客户机器上不存在 PHP 环境 需要使用远端API 进行 部分操作
        if shell.find("-bash: php:") != -1:
            return False
        else:
            return True

    def ParseDistUrl(self, dist):
        url = ""
        fdist = True
        for key, value in dist.items():
            if not fdist:
                url = url + "&"
            url = url + str(key) + "=" + str(value)
            fdist = False
        return url

    def UrlParse(self, url):
        data = {}
        try:
            import urlparse
            result = urlparse.urlparse(url)
            args = urlparse.parse_qs(result.query)
            data["path"] = result.path
        except:
            from urllib import parse
            result = parse.urlparse(url)
            args = parse.parse_qs(result.query)
            data["path"] = result.path
        data["args"] = json.loads(json.dumps(args))
        data["host"] = result.scheme + "://" + result.netloc
        for k in data["args"]:
            data["args"][k] = data["args"][k][0]
        return data









































