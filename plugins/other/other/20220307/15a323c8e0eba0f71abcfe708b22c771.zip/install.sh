#!/bin/bash
PATH=/www/server/panel/pyenv/bin:/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH

#配置插件安装目录
install_path=/www/server/panel/plugin/cloud189

#安装
Install()
{
	
	echo '正在安装...'
	#==================================================================
	#依赖安装开始
	# v1.0a 修复一处错误 无需安装 pycrypto
  btpip install bs4 pycryptodome
  mkdir ${install_path}/download

  # 删除python的编译缓存目录
  rm -rf ${install_path}__pycache__
  btpython ${install_path}/cloud189_install.py data

  # 输出当前服务器的环境变量
  btpython ${install_path}/cloud189_env.py
  
  # 安装图标
  rm -rf /www/server/panel/BTPanel/static/img/soft_ico/ico-cloud189.png
  cp ${install_path}/icon.png /www/server/panel/BTPanel/static/img/soft_ico/ico-cloud189.png

	#依赖安装结束
	#==================================================================

	echo '================================================'
	echo '安装完成'
}

#卸载
Uninstall()
{
	rm -rf $install_path
}

#操作判断
if [ "${1}" == 'install' ];then
	Install
elif [ "${1}" == 'uninstall' ];then
	Uninstall
else
	echo 'Error!';
fi
