# encoding: utf-8
#!/usr/bin/python
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: sudem sudem.sang@atonal.tech
# +-------------------------------------------------------------------

# 本脚本、插件部分依赖修改了来自 Aruelius 的 cloud189 项目
# Thanks https://github.com/Aruelius/cloud189
# 向协同编写 此项目的 rachpt 、 cxyzzz 、 qip 、 Morxi 表示衷心的感谢
# 本项目 在 github 开源

# 插件安装脚本
import os,sys,requests,json

#设置运行目录
os.chdir("/www/server/panel")

#添加包引用位置并引用公共包
sys.path.append("class/")
import public


class cloud189_install:

    # 安装插件数据库对象
    def install_pluginDatabase(self):
        sql = """CREATE TABLE cloud189_task (
    Id         INTEGER PRIMARY KEY AUTOINCREMENT,
	taskid     TEXT,
    taskname   TEXT,
    taskaction TEXT,
    taskstatus INT,
    taskparam  TEXT,
    starttime  INTEGER,
    endtime    INTEGER,
    inittime   INTEGER
);"""
        public.M(None).execute(sql, ())
        print ("插件数据库安装成功!")

    # 取aria2c 的版本
    # v1.0  从main.py 复制到 install.py
    # v1.0a 修复读取Aria2的版本信息是出错的问题
    def GetVersionAria2(self):
        popen = os.popen("aria2c -v")
        shell = popen.read()
        popen.close()
        if shell == "":
            return False
        else:
            shell = shell.split("\n")
            shell = shell[0].split(" ")
            if shell[0] == "-bash:":
                return False
            else:
                return shell[2]                 


    # 安装aria2c 下载工具
    def install_Aria2c(self):
        print ("尝试使用 YUM/APT 源快速安装")
        os.system("yum install aria2 -y")
        os.system("apt-get install aria2 -y")
        if not self.GetVersionAria2():
            print("快速安装失败，尝试使用编译安装")
            r = requests.get("https://btplugin.iw3c.com.cn/aria2/1.35.0/install_aria2c.sh")
            public.WriteFile("/www/server/panel/plugin/cloud189/install_aria2c.sh", r.text)
            os.system("cd /www/server/panel/plugin/cloud189/ && bash install_aria2c.sh")
            os.system("rm -rf /www/server/panel/plugin/cloud189/install_aria2c.sh")

        print("Aria2c 下载器安装成功!")



    # 安装链接解析器
    def install_linkparsetools(self,TaskInfo):
        import panelSite, panelApi, database
        param = json.loads(TaskInfo["taskparam"])
        # 检查是否开启面板的API 访问功能
        try:
            data = json.loads(public.ReadFile("/www/server/panel/config/api.json"))
            btApi = panelApi.panelApi()
        except:
            return {"status":"error","msg":"当前用户没有启用面板的API接口"}
            
        if not data["open"]:
            return {"status":"error","msg":"当前用户没有启用面板的API接口"}
            #api = public.dict_obj()
            #api.t_type = "2"
            #btApi.set_token(api)

        # 添加127.0.0.1 的访问许可
        localhost = False
        limit_addr = data["limit_addr"]
        for addr in limit_addr:
            if addr == "127.0.0.1":
                localhost = True
                break
        if not localhost:
            limit_addr.append("127.0.0.1")
            data = json.loads(public.ReadFile("/www/server/panel/config/api.json"))
            data["limit_addr"] = limit_addr
            public.WriteFile("/www/server/panel/config/api.json",json.dumps(data))


        BtSite = panelSite.panelSite()
        PhpVersion = BtSite.GetPHPVersion("")
        max = "00"
        for ver in PhpVersion:
            if int(ver["version"]) >= int(max):
                max = ver["version"]

        if int(max)<71:
            return {"status":"error","msg":"链接解析器需要最低PHP7.1版本支持"}

        # 检查当前是否已经存在名为 cloud189_link 的数据库
        cloud_database = public.M("databases").where("name=?", ("cloud189_link",)).select()
        if len(cloud_database) == 1:
            database_password = cloud_database[0]["password"]
        else:
            database_password = public.GetRandomString(16)

        # 添加站点
        site = public.dict_obj()
        site.webname  = json.dumps({"domain":param["host"],"domainlist":[],"count":0})
        site.ps = "天翼网盘助手链接解析器"
        site.path = "/www/wwwroot/cloud189_linkparsetools"
        site.ftp = "false"
        site.sql = "MySQL"
        site.codeing = "utf8"
        site.datauser = "cloud189_link"
        site.datapassword = database_password
        site.type = "PHP"
        site.port = "80"
        site.version = max
        site.type_id = "0"
        NewSite = BtSite.AddSite(site)

        # 判断站点是否已经新增成功
        try:
            NewSiteId = NewSite["siteId"]
        except:
            return {"status":"error","msg":"添加站点[" + param["host"] + "]失败，指定的域名已经存在"}

        # 设置伪静态
        rewrite = public.ReadFile("/www/server/panel/rewrite/nginx/thinkphp.conf")
        public.WriteFile("/www/server/panel/vhost/rewrite/"+param["host"]+".conf",rewrite)


        # 请求版本数据
        link = json.loads(requests.get("https://btplugin.iw3c.com.cn/cloud189/linktools/version.json").text)
        # 下载源代码
        os.system("cd /www/wwwroot/cloud189_linkparsetools && wget "+link["download"])
        # 解压源代码
        os.system("cd /www/wwwroot/cloud189_linkparsetools && unzip "+link["filename"]+" && rm -rf "+link["filename"])
        # 修改主配置文件
        config ={}
        config["db_host"] = "127.0.0.1"
        # v1.0.c 修复在部署解析器代码时的数据库参数错误的问题
        config["db_name"] = config["db_user"] = "cloud189_link"
        config["db_pass"] = site.datapassword
        config["bt_api"]  = data["token_crypt"]
        # v1.0.c 修复在部署解析器代码时的端口号后面有换行符的问题
        config["bt_port"] = public.ReadFile("/www/server/panel/data/port.pl").replace("\n","")
        public.WriteFile("/www/wwwroot/cloud189_linkparsetools/cloud189.config",json.dumps(config))
        # v1.0.c 修复在部署解析器代码时权限不足的问题
        os.system("chmod -R 777 /www/wwwroot/cloud189_linkparsetools/")

        # 设置网站的运行目录
        siteconfig = public.dict_obj()
        siteconfig.id = NewSiteId
        siteconfig.runPath = "/public"
        BtSite.SetSiteRunPath(siteconfig)

        # 从sql 导入数据库
        BtDb = database.database()
        sitedb = public.dict_obj()
        sitedb.name = "cloud189_link"
        sitedb.file = "/www/wwwroot/cloud189_linkparsetools/cloud189_plugin.sql"
        BtDb.InputSql(sitedb)
        # v1.1 删除无用的SQL
        os.system("rm -rf "+sitedb.file)
        # V1.1.b 修复返回状态码错误的问题
        return {"status":"success","msg":"安装链接解析器成功","ver":link["version"],"host":param["host"],"db_pass":config["db_pass"],"bt_api":config["bt_api"]}



if "__main__" == __name__:
    cloud = cloud189_install()
    action = sys.argv[1]
    if action == "data":
        cloud.install_pluginDatabase()


