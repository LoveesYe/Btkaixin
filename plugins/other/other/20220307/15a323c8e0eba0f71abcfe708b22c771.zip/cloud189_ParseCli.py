# encoding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: sudem sudem.sang@atonal.tech
# +-------------------------------------------------------------------

# 使用命令行解析天翼云链接
import os, sys, json, requests,time
os.chdir("/www/server/panel")
sys.path.append("class/")
import public

import cloud189_tools, cloud189_main

if "__main__" == __name__:

    print("===========================")
    print("Cloud189 BTpanel Plugin")
    print("Cli FileInfo ParseTools")
    print("===========================")

    start_t = time.time()

    inputConfig  = sys.argv[1]
    outputResult = sys.argv[2]



    if not os.path.exists(inputConfig):
        print ("Error,Config File Not Exists!")
    if not os.path.exists(outputResult):
        print ("Error,Result File Not Exists!")
    cloud = cloud189_tools.cloud189_tools()
    Config = json.loads(public.readFile(inputConfig))
    if Config["parseType"] == "file":
        fileInfo = cloud.ReadFileInfo(Config["fileId"])
    if Config["parseType"] == "path":
        fileId = cloud.FindPathFileId(Config["filePath"])
        fileInfo = cloud.ReadFileInfo(fileId)
    end_t  = time.time()
    speedTime = round((end_t-start_t)*1000,3)
    result = {"fileInfo":fileInfo,"speedTime":speedTime,"parseTime":public.format_date()}

    print("parseTime:" + public.format_date() + ",speedTime:" + str(speedTime) + "ms")
    public.writeFile(outputResult,json.dumps(fileInfo))





