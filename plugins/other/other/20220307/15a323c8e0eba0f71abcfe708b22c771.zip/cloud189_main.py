# encoding: utf-8
#!/usr/bin/python
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: sudem sudem.sang@atonal.tech
# +-------------------------------------------------------------------

# 本脚本、插件部分依赖修改了来自 Aruelius 的 cloud189 项目
# Thanks https://github.com/Aruelius/cloud189
# 向协同编写 此项目的 rachpt 、 cxyzzz 、 qip 、 Morxi 表示衷心的感谢
# 本项目 在 github 开源

import os,requests,json,sys,time,math,platform,re

#设置运行目录
os.chdir("/www/server/panel")

#添加包引用位置并引用公共包
sys.path.append("class/")
import public

import cloud189_tools,cloud189_install


class cloud189_main:

    __plugin_path = "/www/server/panel/plugin/cloud189/"

    def __init__(self):
        self.CloudTools = cloud189_tools.cloud189_tools()



    def CloudLogin(self,args):
        captchaToken, returnUrl, paramId = self.CloudTools.LoginInit()
        if not captchaToken:
            return {"status":"error","msg":"SESSION 异常！通常这是由于短期内连续登录导致，请尝试重启宝塔面板。"}
        validateCode = self.CloudTools.LoginCaptcha(captchaToken,args.username)
        if validateCode != "":
            return {"status":"captcha","captchaToken":captchaToken,"returnUrl":returnUrl,"paramId":paramId,"validateCode":validateCode}
        else:
            Cloud =  self.CloudTools.LoginPost(args.username,args.password,validateCode, captchaToken, returnUrl, paramId )
            return  {"status":"success","cloud":Cloud}

    def CloudLogin_ReCaptcha(self,args):
        validateCode = self.CloudTools.LoginCaptcha(args.captchaToken, args.username)
        return {"status":"success","validateCode":validateCode}


    def CloudReLogin(self,args):
        Cloud = self.CloudTools.LoginPost(args.username, args.password, args.validateCode, args.captchaToken, args.returnUrl, args.paramId)
        return {"status": "success", "cloud": Cloud}


    def CloudUserInfo(self,args):
        try:
            Cloud =  self.CloudTools.ReadUserInfo()
            return {"status": "success", "msg": "获取用户账户信息成功", "cloud": Cloud}
        except:
            # 删除用户登录的缓存文件
            os.remove(self.__plugin_path + "Users/CloudCache.json")
            return {"status": "error", "msg": "获取用户账户信息失败"}

    def hasitem(self, obj, attr, val):
        if obj.__getitem__(attr) != None:
            return obj.__getitem__(attr)
        else:
            return val

    def CloudListFileInfo(self, args):
        keyword = self.hasitem(args, 'keyword', "")
        page = int(self.hasitem(args, 'page', 1))
        fileid = self.hasitem(args, 'fileid', "-11")
        allList = self.hasitem(args, 'allList', False)

        if allList:
            try:
              Cloud = self.CloudTools.ReadFileListAll(fileid, page, "")
              return {"status": "success", "msg": "获取用户文件列表成功", "cloud": Cloud, "fileid": fileid}
            except:
                return {"status": "error", "msg": "列出指定文件夹下一级目录内的文件失败,请检查fileid", "page": page, "fileid": fileid}
        else:
            try:
                Cloud = self.CloudTools.ReadFileList(fileid, page, keyword)
                # 修复缺少 pageNum 参数导致的可能的报错
                Cloud["pageNum"] = page
                if Cloud["count"] == 0:
                    Cloud["pageCount"] = 0
                else:
                    # 修复总页数计算出错的bug
                    Cloud["pageCount"] = math.ceil(int(Cloud["count"]) / 50)
                return {"status": "success", "msg": "获取用户文件列表成功", "cloud": Cloud, "fileid": fileid}
            except:
                return {"status": "error", "msg": "列出指定目录下的文件失败,请检查fileid", "page": page, "fileid": fileid}





    def CloudPathFileId(self,args):
        FileId = self.CloudTools.FindPathFileId(args.path)
        if FileId:
            return {"status":"success","msg":"查询指定文件路径的FileId成功!","path":args.path,"FileId":FileId}
        else:
            return {"status": "success", "msg": "查询指定文件路径的FileId失败!请检查路径地址是否有误", "path": args.path}



    def CloudPathFindById(self,args):
        path = self.CloudTools.ReadFilePathNode(args.fileid)
        if path:
            return {"status": "success", "msg": "查询指定文件FileId路径地址成功!", "path": path, "fileid": args.fileid}
        else:
            return {"status": "success", "msg": "查询指定文件FileId路径地址失败!请检查请检查fileid", "fileid": args.fileid}

    # 读取用户分享的链接信息
    # 输入参数:  password string 加密分享的密码（可选）
    #          link      string 分享的地址

    def CloudReadShare(self, args):
        try:
            password = args.password
        except:
            password = False
        cloud = self.CloudTools.ReadFileShareLink(args.link.strip(), password)
        return cloud

    # 读取用户分享的链接信息
    # 输入参数:  password string 加密分享的密码（可选）
    #          link      string 分享的地址
    def CloudReadShareV2(self, args):
        try:
            password = args.password
        except:
            password = False
        cloud = self.CloudTools.ReadFileShareLinkV2(args.link.strip(), password)
        return cloud


    # 取指定的文件的详细信息
    def CloudReadFileInfo(self,args):
        Cloud = self.CloudTools.ReadFileInfo(args.fileid)
        try:
            fileid = Cloud["fileId"]
            if str(fileid) == str(args.fileid):
                return {"status": "success", "msg": "获取文件详细信息成功", "cloud": Cloud}
            else:
                return {"status": "error", "msg": "获取文件详细信息失败", "cloud": Cloud}
        except:
            return {"status": "error", "msg": "获取文件详细信息失败", "cloud": Cloud}



    # 取指定文件的下载信息（不返回超时等信息）
    def CloudReadFileIdUrl(self, args):
        Cloud = self.CloudTools.ReadFileDownLoadLink(args.fileid)
        return Cloud

    # 取指定的文件的下载地址信息
    def CloudReadFileDownload(self,args):
        Cloud = self.CloudTools.ReadFileDownLoadLink(args.fileid)
        if Cloud["status"] !="success":
            return {"status": "error", "msg": "获取文件真实下载地址失败","cloud":Cloud}
        result = self.CloudTools.UrlParse(Cloud["redirecturl"])
        return {"status": "success", "msg": "获取文件真实下载地址信息成功","Expire":result["args"]["Expires"],
                "redirecturl": Cloud["redirecturl"], "args":result["args"],"host":result["host"], "OssFilePath":result["path"]}

    # 取网盘指定地址的文件的现在地址信息
    def CloudReadPathDownload(self,args):
        FileId = self.CloudTools.FindPathFileId(args.path)
        if FileId:
            Cloud = self.CloudTools.ReadFileDownLoadLink(FileId)
            if Cloud["status"] != "success":
                return {"status": "error", "msg": "获取文件真实下载地址失败", "cloud": Cloud,"path": args.path}
            result = self.CloudTools.UrlParse(Cloud["redirecturl"])
            return {"status": "success", "msg": "获取文件真实下载地址信息成功","redirecturl": Cloud["redirecturl"],
                    "args": result["args"], "host": result["host"],"OssFilePath": result["path"],"Expire":result["args"]["Expires"]}
        else:
            return {"status": "error", "msg": "获取文件真实下载地址失败,路径地址不存在", "path": args.path}


    # 在指定的位置新建一个文件夹
    def CreateNewFolder(self,args):
        Cloud  = self.CloudTools.CreateNewFolder(args.parentId,args.filename)
        return {"status":"success","msg":"新建文件夹成功","cloud":Cloud}

    # 删除指定的文件或者文件夹
    def DeleteFileobj(self,args):
        TaskInfos = []
        for file in json.loads(args.files):
            fileInfo = self.ReadFileTaskInfo(file)
            if fileInfo["isFolder"]:  fileInfo["isFolder"] = 1
            else: fileInfo["isFolder"] = 0
            task = {"fileId":fileInfo["fileId"],"fileName":fileInfo["fileName"],"isFolder":fileInfo["isFolder"]}
            TaskInfos.append(task)
        Cloud = self.CloudTools.TaskFileFloder("DELETE",TaskInfos)
        Cloud = self.CloudTools.TaskStatusRead(Cloud["taskid"],Cloud["type"])
        return {"status": "success", "msg": "执行删除文件\文佳夹的任务队列成功", "cloud": Cloud}

    # 复制指定文件或者文件夹到指定目录
    def CopyFileobj(self,args):
        TaskInfos = []
        for file in json.loads(args.files):
            fileInfo = self.ReadFileTaskInfo(file)
            if fileInfo["isFolder"]:
                fileInfo["isFolder"] = 1
            else:
                fileInfo["isFolder"] = 0
            task = {"fileId": fileInfo["fileId"], "fileName": fileInfo["fileName"], "isFolder": fileInfo["isFolder"]}
            TaskInfos.append(task)
        Cloud = self.CloudTools.TaskFileFloder("COPY", TaskInfos,args.targetid)
        Cloud = self.CloudTools.TaskStatusRead(Cloud["taskid"], Cloud["type"])
        return {"status": "success", "msg": "执行复制文件\文件夹的任务队列成功", "cloud": Cloud}

    # 移动指定文件或者文件夹到指定的目录
    def MoveFileobj(self, args):
        TaskInfos = []
        for file in json.loads(args.files):
            fileInfo = self.ReadFileTaskInfo(file)
            if fileInfo["isFolder"]:
                fileInfo["isFolder"] = 1
            else:
                fileInfo["isFolder"] = 0
            task = {"fileId": fileInfo["fileId"], "fileName": fileInfo["fileName"], "isFolder": fileInfo["isFolder"]}
            TaskInfos.append(task)
        Cloud = self.CloudTools.TaskFileFloder("MOVE", TaskInfos, args.targetid)
        Cloud = self.CloudTools.TaskStatusRead(Cloud["taskid"], Cloud["type"])
        return {"status": "success", "msg": "执行移动文件\文件夹的任务队列成功", "cloud": Cloud}



    # 取指定类型的文件成为任务队列的元素
    def ReadFileTaskInfo(self,args):
        try:
            fileid = args.fileid
        except:
            fileid = args
        f = public.dict_obj()
        f.fileid = fileid
        FileInfo = self.CloudReadFileInfo(f)["cloud"]
        if FileInfo["isFolder"]:
            FileInfo["isFolder"] = 1
        else:
            FileInfo["isFolder"] = 0
        TaskList = ["fileId","fileName","isFolder","srcParentId"]
        TaskInfo = {}
        for List in TaskList:
            if List == "srcParentId":
                TaskInfo[List] = FileInfo["parentId"]
            else:
                TaskInfo[List] = FileInfo[List]
        return TaskInfo

    # 取指定的任务队列执行情况
    def ReadTaskIdInfo(self,args):
        Cloud = self.CloudTools.TaskStatusRead(args.taskid,args.type)
        return {"status": "success", "msg": "取任务队列信息成功", "cloud": Cloud}


    # 列出用户分享的文件列表
    def ListUserShares(self,args):
        try:
            pageid = pagesize = False
            pageid = args.pageid
            pagesize = args.pagesize
        except:
            if not pageid:
                pageid = 1
            if not pagesize:
                pagesize = 50
        Cloud = self.CloudTools.ListUserShare(pageid,pagesize)
        Cloud["pageCount"] = math.ceil(Cloud["recordCount"] / Cloud["pageSize"])
        return {"status": "success", "msg": "列出文件分享信息成功", "cloud": Cloud}

    # 取消文件分享
    def CancelUserShares(self,args):
        Cloud = self.CloudTools.CancelUserShare(args.shareid)
        return {"status": "success", "msg": "取消分享文件成功", "cloud": Cloud}


    # 列出回收站里的所有的文件
    def ListRecyleFiles(self,args):
        try:
            pageid = pagesize = False
            pageid = args.pageid
            pagesize = args.pagesize
        except:
            if not pageid:
                pageid = 1
            if not pagesize:
                pagesize = 50
        Cloud = self.CloudTools.ReadUserRecycle(pageid,pagesize)
        for file in Cloud["fileList"]:
            file["id"] = str(file["id"])
        Cloud["pageCount"] = math.ceil(Cloud["count"]/pagesize)
        return {"status": "success", "msg": "取回收站文件信息成功", "cloud": Cloud}


    # 从回收站恢复文件
    def RestoreFileFromRecycle(self,args):
        TaskInfos = []
        for file in json.loads(args.files):
            fileInfo = self.ReadFileTaskInfo(file)
            if fileInfo["isFolder"]:  fileInfo["isFolder"] = 1
            else: fileInfo["isFolder"] = 0
            task = {"fileId":fileInfo["fileId"],"fileName":fileInfo["fileName"],"isFolder":fileInfo["isFolder"]}
            TaskInfos.append(task)
        Cloud = self.CloudTools.TaskFileFloder("RESTORE", TaskInfos)
        Cloud = self.CloudTools.TaskStatusRead(Cloud["taskid"], Cloud["type"])
        return {"status": "success", "msg": "执行从回收站恢复文件的任务队列成功", "cloud": Cloud}


    # 从回收站里面删除一个文件
    def DeleteFileFromRecycle(self,args):
        TaskInfos = []
        fileInfo = self.ReadFileTaskInfo(args.files)
        if fileInfo["isFolder"]:
            fileInfo["isFolder"] = 1
        else:
            fileInfo["isFolder"] = 0
        task = {"fileId": fileInfo["fileId"], "fileName": fileInfo["fileName"], "isFolder": fileInfo["isFolder"]}
        TaskInfos.append(task)
        Cloud = self.CloudTools.TaskFileFloder("CLEAR_RECYCLE", TaskInfos)
        Cloud = self.CloudTools.TaskStatusRead(Cloud["taskid"], Cloud["type"])
        return {"status": "success", "msg": "从回收站删除文件成功", "cloud": Cloud}

    # 清空回收站里的文件
    def RemoveFiles(self,args):
        TaskInfos = []
        Cloud = self.CloudTools.TaskFileFloder("EMPTY_RECYCLE", TaskInfos)
        Cloud = self.CloudTools.TaskStatusRead(Cloud["taskid"], Cloud["type"])
        return {"status": "success", "msg": "清空回收站数据成功", "cloud": Cloud}


    # 上传某个文件(请在CLI 异步线程队列中使用)
    def UploadFile_CLI(self,args):
        print ("准备上传本地文件：" + args.localpath)
        Init =  self.CloudTools.UploadFile_Init(args.filename,args.localpath,args.parentId)
        print ("预上传文件响应:" + json.dumps(Init))
        if Init["status"] == "success":
            chunksMd5Base = Init["chunksMd5Base"]
            silpts = Init["silpts"]
            Init = Init["cloud"]
            # 文件不存在 获取需要上传的分片的信息
            if Init["data"]["fileDataExists"] == 0:
                print("文件秒传失败,开始自动分片上传")
                Parts = self.CloudTools.UploadFile_GetPartsInfo(Init["data"]["uploadFileId"])
                print("获取云端文件分片信息成功：" + json.dumps(Parts))
                Uploads = self.CloudTools.UploadFile_GetMultUploads(Parts["data"]["uploadFileId"], chunksMd5Base)
                print("获取需要上传的文件分片信息成功：" + json.dumps(Parts))
                Process = self.CloudTools.UploadFile_SendMultAll(Uploads["uploadUrls"], silpts,args.localpath,Parts["data"]["uploadFileId"])
                if Process["status"] != "success":
                    self.CloudTools.WriteLog("上传文件" + args.localpath + "失败,无法上传第" + Process["id"] + "个分片的数据")
                else:
                    commit = self.CloudTools.UploadFile_Commit(Parts["data"]["uploadFileId"])
            # 文件已经存在 开始进行秒传
            else:
                commit = self.CloudTools.UploadFile_Commit(Init["data"]["uploadFileId"])
            if commit["code"]!="SUCCESS":
                self.CloudTools.WriteLog("上传文件" + args.localpath + "失败,在提交文件时云端返回了错误响应：\n" + json.dumps(commit))
            else:
                self.CloudTools.WriteLog("上传文件成功，云端文件Id:" + commit["file"]["userFileId"] + ",云端文件名:" +commit["file"]["fileName"]  + ",文件MD5：" + commit["file"]["fileMd5"])
                self.CloudTools.WriteLog("!!!!!===============================!!!!!\n" + json.dumps(commit))
        else:
            self.CloudTools.WriteLog("上传文件失败，您今日剩余可用的上传流量不足")
        print("删除本地切片缓存")
        self.CloudTools.RemoveFileSlipt(silpts["fid"])

    # 取指定文件夹下的所有文件的大小信息
    def GetUserDirSize(self,args):
        cloud = self.CloudTools.ReadFileDirAllSize(args.fileid)
        return {"status": "success", "msg": "取文件夹大小信息成功", "cloud": cloud}

   # 取用户剩余的流量信息
    def GetUserTodayFlow(self,args):
        size = self.CloudTools.GetUserFlowToday()
        if size == "UserDayFlowOverLimited":
            size = 0
        return {"status": "success", "msg": "获取今日可用流量成功", "size": size}

    # 取插件的描述信息
    def GetPluginVersion(self,args):
        plugininfo = json.loads(public.ReadFile(self.__plugin_path+"info.json"))
        return {"status":"success","plugin":plugininfo}

    # 取插件的运行日志信息
    def GetPluginLogs(self,args):
        logfile = self.__plugin_path + "Users/PluginLog_" + public.format_date("%Y%m%d") + ".log"
        if not os.path.exists(logfile):
            return {"status":"success","logs":""}
        else:
            LogData = public.ReadFile(logfile)
            return {"status":"success","logs":LogData}

    # 分享指定的文件
    def ShareUserFile(self,args):
        # 私密分享某个文件
        if args.type == "private":
            cloud = self.CloudTools.ShareFilePrivate(args.fileid,args.time)
        else:
            cloud = self.CloudTools.ShareFilePublic(args.fileid,args.time)
        return {"status": "success", "msg": "分享指定的文件成功", "cloud": cloud}

    # 取wget的版本
    def GetVersionWget(self,args):
        popen = os.popen("wget -V")
        shell = popen.read()
        popen.close()
        shell = shell.split("\n")
        return shell[0].split(" ")[2]

    # 取aria2c 的版本
    # v1.0a 修复读取Aria2的版本信息是出错的问题
    def GetVersionAria2(self,args):
        popen = os.popen("aria2c -v")
        shell = popen.read()
        popen.close()
        if shell == "":
            return False
        else:
            shell = shell.split("\n")
            shell = shell[0].split(" ")
            if shell[0] == "-bash:":
                return False
            else:
                return shell[2]

    # 取宝塔面板api 的密钥信息
    def ReadBtApiToken(self,args):
        try:
            Api  = json.loads(public.ReadFile("/www/server/panel/config/api.json"))
            Token = Api["token_crypt"]
            limitAddr = Api["limit_addr"]
            return {"status":"success","Token":Token,"limit_addr":limitAddr}
        except:
            return False

    # 读取插件的配置信息
    def ReadPanelConfig(self,args):
        if os.path.exists(self.__plugin_path + "Users/PanelConfig.json"):
            Config = json.loads(public.ReadFile(self.__plugin_path + "Users/PanelConfig.json"))
        else:
            Config = {}
            Config["Link_Parse"] = False
            Config["Download_Tools"] = "Wget"
            Config["HeartTime"] = "120"
            public.WriteFile(self.__plugin_path + "Users/PanelConfig.json",json.dumps(Config))
        Config["Wget_Version"] = self.GetVersionWget("")
        Config["Aria2_Version"] = self.GetVersionAria2("")
        try:
            Config["BtApi"] = self.ReadBtApiToken("")
            # 传给前端的API TOKEN 加密处理中间16位
            Config["BtApi"]["Token"] =Config["BtApi"]["Token"][0:8] +"********" +"********"  + Config["BtApi"]["Token"][24:32]
        except:
            pass
        try:
            FileInfo_Ver = Config["Link_FileInfo_Ver"]
        except:
            FileInfo_Ver = "V1"
        Config["Link_FileInfo_Ver"] = FileInfo_Ver
        if os.path.exists(self.__plugin_path + "Users/UserCache.json"):
            Config["HeartBeat"] = json.loads(public.ReadFile(self.__plugin_path + "Users/UserCache.json"))["HeartBeat"]
        else:
            Config["HeartBeat"] = ""
        return {"status":"success","Config":Config}

    # 读取插件任务队列
    def ReadPluginTaskLine(self,args):
        try:
            page = int(args.page)
            num = int(args.num)
            spage = str((page-1)*num)
        except:
            page = 1
            num = 15
            spage = "0"
        TaskLine = public.M("cloud189_task").order("id desc").limit(spage+ "," + str(num)).select()
        Pagesize = math.ceil(public.M("cloud189_task").count() / num)
        return {"status":"success","page":page,"num":num,"Tasks":TaskLine,"count":len(TaskLine),"pageSize":Pagesize}

    # 添加指定的任务队列
    def AddPluginTaskLine(self,args):
        # taskstatus -1 初始化定义任务队列
        #            0  开始执行任务队列
        #            1  执行任务队列结束
        taskid = public.GetRandomString(16)
        public.M("cloud189_task").add("taskid,taskname,taskaction,taskparam,inittime,taskstatus",(taskid,args.taskname,args.taskaction,args.taskparam,int(time.time()),-1))
        import panelTask
        t = panelTask.bt_task()
        t.create_task(args.bt_taskname,0,args.taskshell+taskid,taskid)
        result = public.M("task_list").where("other=?",(taskid)).select()
        return {"status":"success","taskid":taskid,"result":result}

    # 读取指定的计划任务的信息
    def ReadPlguinTaskInfo(self,taskid):
        info = public.M("cloud189_task").where("taskid=?",(taskid,)).select()
        return info

    # 重启心跳计时器
    def SaveReloadHeart(self,args):
        Config = json.loads(public.ReadFile(self.__plugin_path + "Users/PanelConfig.json"))
        Config["HeartTime"] = args.HeartTime
        public.WriteFile(self.__plugin_path + "Users/PanelConfig.json", json.dumps(Config))
        self.CloudTools.CloseAllHeartCli()
        self.CloudTools.StartHeartCli()
        return {"status": "success", "msg": "重启心跳计时器成功！"}

    # 保存下载器的配置信息
    def SaveDownloadTools(self,args):
        if args.tools=="idown":
            return {"status": "error", "msg": "抱歉暂不支持使用Aria2c 插件下载"}
        if args.tools == "Aria2c":
            Aria2c = self.GetVersionAria2("")
            if not Aria2c:
                return {"status": "error", "msg": "当前系统尚未安装aria2c 下载工具"}
        Config = json.loads(public.ReadFile(self.__plugin_path + "Users/PanelConfig.json"))
        Config["Download_Tools"] = args.tools
        public.WriteFile(self.__plugin_path + "Users/PanelConfig.json", json.dumps(Config))
        return {"status": "success", "msg": "保存下载器选择成功"}

    # 保存文件详情读取方式的接口
    def SaveFileInfoConfig(self,args):
        Config = json.loads(public.ReadFile(self.__plugin_path + "Users/PanelConfig.json"))
        Config["Link_FileInfo_Ver"] = args.ver
        public.WriteFile(self.__plugin_path + "Users/PanelConfig.json", json.dumps(Config))
        return {"status": "success", "msg": "设置文件详情读取方式成功"}


    # 添加计划任务安装aria2c
    def AddTaskInstall_Aria2c(self,args):
        task = public.dict_obj()
        task.taskname = "安装Aria2c下载工具"
        task.taskaction = "aria2c"
        task.taskparam = ""
        task.bt_taskname = "天翼网盘助手-安装Aria2c下载工具"
        task.taskshell = "cd " + self.__plugin_path + " && btpython -u  cloud189_main.py "
        bttask = self.AddPluginTaskLine(task)
        return {"status":"success","msg":"添加计划任务安装aria2c成功","task":bttask}

    # 添加计划任务安装链接解析器
    def Install_LinkTools(self,args):
        taskInfo = {}
        taskInfo["taskparam"] = json.dumps({"host":args.host})
        cloud_install = cloud189_install.cloud189_install()
        install = cloud_install.install_linkparsetools(taskInfo)

        if install["status"] == "success":
            Config = json.loads(public.ReadFile(self.__plugin_path + "Users/PanelConfig.json"))
            Config["Link_Parse"] = True
            if install["ver"]!="1.1.beta":
                Config["Link_Parse_Static"] = True
            else:
                Config["Link_Parse_Static"] = False
            Config["Link_Parse_Ver"] = "天翼网盘链接解析器--V" + install["ver"]
            Config["Link_Parse_Host"] = args.host
            Config["Link_Parse_SSl"] = args.ssl
            public.WriteFile(self.__plugin_path + "Users/PanelConfig.json", json.dumps(Config))
            return {"status": "success", "msg": "安装链接解析器成功"}
        else:
            return {"status": "error", "msg": "安装链接解析器失败","install":install}


    # 异步执行任务队列
    def RunTaskOnCli(self,taskInfo):
        taskid = taskInfo["taskid"]
        #开始执行 任务队列
        public.M("cloud189_task").where("taskid=?",(taskid,)).setField("taskstatus",0)
        public.M("cloud189_task").where("taskid=?", (taskid,)).setField("starttime", int(time.time()))

        taskaction = taskInfo["taskaction"]
        cloud_install = cloud189_install.cloud189_install()
        if taskaction == "aria2c":
            cloud_install.install_Aria2c()
        if taskaction == "download":
            param = json.loads(taskInfo["taskparam"])
            Config = json.loads(public.ReadFile(self.__plugin_path + "Users/PanelConfig.json"))
            if Config["Download_Tools"] == "Wget":
                shell = "cd "+param["localpath"]+"  && wget \"" + param["fileurl"] + "\" -O \"" + param["localname"] + "\""
            if Config["Download_Tools"] == "Aria2c":
                shell = "aria2c -x 16 -d \"" + param["localpath"] + "\" -o \"" + param["localname"] + "\" \"" + param["fileurl"] + "\""
            print ("执行SHELL：" + shell)
            os.system(shell)
        if taskaction == "upload":
            param = json.loads(taskInfo["taskparam"])
            upload = public.dict_obj()
            upload.filename = param["filename"]
            upload.localpath = param["localpath"]
            upload.parentId = param["parentid"]
            self.UploadFile_CLI(upload)
        if taskaction == "alllist":
            print ("开始遍历网盘中的所有文件")
            files = self.ListPanAllFile(taskid)
            print ("网盘文件已经遍历完毕,用时:" + files["UseTime"] + ",列出文件共" + str(files["FileNums"]) + "个")
        # 结束执行 任务队列
        public.M("cloud189_task").where("taskid=?", (taskid,)).setField("taskstatus", 1)
        public.M("cloud189_task").where("taskid=?", (taskid,)).setField("endtime", int(time.time()))
        print ("任务已经执行结束")


    # 取指定任务的执行日志
    def GetRunTaskLog(self,args):
        taskid = args.taskid
        bttask = public.M("task_list").where("other=?", (taskid)).select()
        try:
            log_file = "/www/server/panel/tmp/" + str(bttask[0]["id"]) + ".log"
            if not os.path.exists(log_file):
                return {"status":"success","logfile":log_file,"logtime":public.format_date(),"taskid":taskid,"msg":"日志文件不存在","content":"日志文件不存在,可能任务尚未执行或者任务执行结束日志已经被清除"}
        except:
            return {"status": "success", "logtime": public.format_date(), "taskid": taskid, "msg": "日志文件不存在",
                    "content": "日志文件不存在,可能任务尚未执行或者任务执行结束日志已经被清除"}
        return {"status": "success","logfile":log_file,"logtime":public.format_date(),"taskid": taskid, "msg": "读取日志[" + log_file + "]成功","content": public.ReadFile(log_file)}

    # 修改链接解析器的SSL 设置
    def SetParseSSLTools(self,args):
        Config = json.loads(public.ReadFile(self.__plugin_path + "Users/PanelConfig.json"))
        if Config["Link_Parse_SSl"] == "off":
            Config["Link_Parse_SSl"] = "on"
        else:
            Config["Link_Parse_SSl"] = "off"
        public.WriteFile(self.__plugin_path + "Users/PanelConfig.json", json.dumps(Config))
        return {"status": "success", "msg": "修改解析器SSL配置成功"}

    # 获取文件的下载地址信息
    def GetFileDownloadLink(self,args,data=False):
        down = self.CloudReadFileIdUrl(args)
        info = down["info"]
        Config = json.loads(public.ReadFile(self.__plugin_path + "Users/PanelConfig.json"))
        # 是否需要伪静态转发
        # 兼容旧版本伪静态配置字段为空的问题
        try:
            if Config["Link_Parse_Static"]:
                parse = "File/" + args.fileid + "." + info["fileType"]
            else:
                parse = "index.php/fileid/" + args.fileid + "/" + public.md5(info["fileIdDigest"]) + "." + \
                        info["cloud"]["fileType"]
        except:
            parse = "index.php/fileid/" + args.fileid + "/" + public.md5(info["fileIdDigest"]) + "." + \
                    info["fileType"]
        try:
            if Config["Link_Parse_SSl"] == "on":
                parse = "https://" + Config["Link_Parse_Host"] + "/" + parse
            else:
                parse = "http://" + Config["Link_Parse_Host"] + "/" + parse
        except:
            parse = False
        del down['info']
        return {"download": down, "fileinfo": {"cloud":info}, "parse": parse}



    # 取文件夹下面的所有文件的下载地址信息
    def GetFileDownloadLink_Dir(self,args):
        Files = self.CloudTools.ReadFileListAll(args.fileid,-1)
        return Files
        Links = []
        for item in Files["data"]:
            if not item["isFolder"]:
                file_args = public.dict_obj()
                file_args.fileid = item["fileId"]
                file = self.GetFileDownloadLink(file_args,item)
                file["fileid"] = item["fileId"]
                Links.append(file)
        return Links


    # 添加任务队列，下载指定的文件
    def AddTaskDownload_FileInfo(self,args):
        if not self.TestFileNameFormat(args.localname)["fileFormat"]:
            return {"status": "error", "msg": "本地文件名称非法","filename":args.localname}
        else:
            task = public.dict_obj()
            task.taskname = "下载网盘文件[" + args.filename + "]"
            task.taskaction = "download"
            task.taskparam = json.dumps({"localname":args.localname,"localpath":args.localpath,"fileurl":args.fileurl})
            task.bt_taskname = "天翼网盘助手-下载网盘文件"
            task.taskshell = "cd " + self.__plugin_path + " && btpython -u cloud189_main.py "
            bttask = self.AddPluginTaskLine(task)
            return {"status": "success", "msg": "添加计划任务下载网盘文件成功", "task": bttask}


    # 检查指定文件名是否正确
    def TestFileNameFormat(self,filename):
        fileFormat = False
        try:
            if not os.path.exists("/tmp/testfilename/"):
                os.mkdir("/tmp/testfilename")
            public.WriteFile("/tmp/testfilename/" + filename,"This is A Test File For FileName Test")
            if os.path.exists("/tmp/testfilename/" + filename):
                fileFormat = True
            os.remove("/tmp/testfilename/" + filename)
        except:
            pass
        return {"filename":filename,"fileFormat":fileFormat}

    # 取消删除指定的计划任务
    def DeleteTaskId(self,args):
        taskid = args.taskid
        cloud189 = False
        try:
            cloud189 = public.M("cloud189_task").where("taskid=?", (taskid)).delete()
            bttask = public.M("task_list").where("other=?", (taskid)).select()
            id = bttask[0]["id"]
            import panelTask
            task = public.dict_obj()
            task.id = id
            t = panelTask.bt_task()
            t.remove_task(task)
            return {"status": "success", "taskid": taskid, "msg": "已经删除指定的任务"}
        except:
            if cloud189:
                return {"status": "success", "taskid": taskid, "msg": "已经删除指定的任务"}
            else:
                return {"status": "error", "taskid": taskid, "msg": "删除指定的任务失败，指定的任务不存在"}

    # 文件打包下载
    # 本接口废弃
    def DownloadFileGroup(self,args):
        GroupUrl =  self.CloudTools.GetFileGroupLink(args.fileids)
        return GroupUrl
        Config = json.loads(public.ReadFile(self.__plugin_path + "Users/PanelConfig.json"))
        if args.dtype == "link":
            try:
                if Config["Link_Parse_Static"]:
                    parse = "Files/" + self.StrShortCrypto(args.fileids) + ".zip"
                else:
                    parse = "index.php/group/" + args.fileids + "/" + public.md5(args.fileids) + ".zip"
            except:
                  parse = "index.php/group/" + args.fileids + "/" + public.md5(args.fileids) + ".zip"
          
            if Config["Link_Parse_SSl"] == "on":
                parse = "https://" + Config["Link_Parse_Host"] + "/" + parse
            else:
                parse = "http://" + Config["Link_Parse_Host"] + "/" + parse
            result = self.CloudTools.UrlParse(GroupUrl)
            return {"status": "success", "msg": "获取文件真实下载地址信息成功", "redirecturl": GroupUrl,"ParseUrl":parse,"Expire":result["args"]["Expires"],
                    "args": result["args"], "host": result["host"], "OssFilePath": result["path"],"FileId":public.md5(args.fileids)}
        if args.dtype == "download":
            if not self.TestFileNameFormat(args.localname)["fileFormat"]:
                return {"status": "error", "msg": "本地文件名称非法", "filename": args.localname}
            else:
                task = public.dict_obj()
                task.taskname = "打包下载网盘文件"
                task.taskaction = "download"
                task.taskparam = json.dumps(
                    {"localname": "[打包下载]天翼云盘-" + public.GetRandomString(8) + ".zip", "localpath": args.localpath, "fileurl": GroupUrl})
                task.bt_taskname = "天翼网盘助手-打包下载网盘文件"
                task.taskshell = "cd " + self.__plugin_path + " && btpython -u cloud189_main.py "
                bttask = self.AddPluginTaskLine(task)
                return {"status": "success", "msg": "添加任务打包下载网盘文件成功", "task": bttask}

    # 添加任务队列，上传指定的文件
    def AddTaskUpload_FileInfo(self, args):
        # 检查指定文件路径是否存在
        if not os.path.exists(args.localpath):
            return {"status":"error","msg":"指定的文件不存在请检查您的文件","localpath":args.localpath}
        else:
            task = public.dict_obj()
            task.taskname = "上传网盘文件[" + args.filename + "]"
            task.taskaction = "upload"
            task.taskparam = json.dumps(
                {"parentid": args.parentid, "localpath": args.localpath,"filename":args.filename})
            task.bt_taskname = "天翼网盘助手-上传网盘文件"
            task.taskshell = "cd " + self.__plugin_path + " && btpython -u cloud189_main.py "
            bttask = self.AddPluginTaskLine(task)
            return {"status": "success", "msg": "添加任务上传网盘文件成功", "task": bttask}

    # 取操作系统版本
    def GetSystemVersion(self,args):
        key = 'sys_version'
        version = public.ReadFile('/etc/redhat-release')
        if not version:
            version = public.ReadFile('/etc/issue').strip().split("\n")[0].replace('\\n', '').replace('\l', '').strip()
        else:
            version = version.replace('release ', '').replace('Linux', '').replace('(Core)', '').strip()
        return version


    # 获取当前插件运行环境
    def PluginEnv(self,args):
        # 取宝塔面板的版本
        comm = public.ReadFile('/www/server/panel/class/common.py')
        bt_ver = re.search("g\.version\s*=\s*'(\d+\.\d+\.\d+)'", comm).groups()[0]
        # 取python 的版本
        py_ver = platform.python_version()
        # 取当前服务器的版本
        sys_ver = self.GetSystemVersion("")

        env = {"bt": bt_ver, "python": py_ver, "os": sys_ver,"msg":public.format_date()}
        public.WriteFile("/www/server/panel/plugin/cloud189/static/js/env.js", "var env=" + json.dumps(env))
        return {"status":"success","msg":"获取当前系统的环境变量成功","env":env}


    # 通过IW3C 插件SMTP 邮件发送通道发送邮件
    def SendSmtpMail(self,args):
        import iw3c_auth
        iw3c = iw3c_auth.iw3c_auth()
        receive = []
        receive.append(args.receive)
        try:
            response = iw3c.SendMail_IW3C(receive,args.title,args.content)
            return {"status":"success","msg":"使用IW3C邮件通道发送邮件成功","response":response}
        except:
            return {"status":"error","msg":"使用IW3C邮件通道发送邮件失败","param":args}
    
    # 对需要压缩的的字符串请求远端接口进行压缩
    def StrShortCrypto(self,Str):
        pdata = {"text":Str}
        r  = requests.post("https://api.iw3c.com.cn/api/Strcrypto/Set/",data=pdata);
        return json.loads(r.text)["Data"]["data"]["md5"]

    # 列出系统中所有的文件
    def ListPanAllFile(self,Id):
        import time
        start_time = int(time.time())
        List = self.CloudTools.ReadPanAllFile()
        UseTime = int(time.time()) - start_time
        UserInfo = self.CloudUserInfo(public.dict_obj())
        Files = {"FileNums":len(List),"CacheTime":public.format_date(),"UseTime":str(UseTime) + "s",
                 "UserAccount":UserInfo["cloud"]["userAccount"],"UserId":UserInfo["cloud"]["userId"],
                 "DataName":self.__plugin_path + "Users/PanAllFiles/"+Id+".json","List":List}
        if not os.path.exists(self.__plugin_path + "Users/PanAllFiles/"):
            os.mkdir(self.__plugin_path + "Users/PanAllFiles/")
        public.WriteFile(self.__plugin_path + "Users/PanAllFiles/"+Id+".json",json.dumps(Files))
        return Files

    # 添加任务队列，列出系统中所有的文件
    def AddTask_ListAllFile(self, args):
        task = public.dict_obj()
        task.taskname = "列出网盘中的所有文件"
        task.taskaction = "alllist"
        task.taskparam = json.dumps({})
        task.bt_taskname = "天翼网盘助手-列出网盘中的所有文件"
        task.taskshell = "cd " + self.__plugin_path + " && btpython -u cloud189_main.py "
        bttask = self.AddPluginTaskLine(task)
        return {"status": "success", "msg": "添加计划任务列出网盘中的所有文件成功", "task": bttask}

    # 设置debug模式
    def CheckDebugStatus(self, get):
        debug_path = 'data/debug.pl'
        status = "on"
        if not os.path.exists(debug_path):
            status = "off"
            t_str = '开启'
            public.writeFile(debug_path, 'True')
            public.WriteLog('面板配置', '%s开发者模式(debug)[天翼网盘插件(Version<2.0)]' % t_str)
            public.restart_panel()
        return {"status": "success", "msg": "开发者模式检查成功", "debug_status": status}


if "__main__" == __name__:
    print ("===========================")
    print ("Cloud189 BTpanel Plugin")
    print ("You Are Use Cli Mode")
    print ("===========================")
    cloud = cloud189_main()
    TaskInfo = False
    TaskId = False
    try:
        TaskId = sys.argv[1]
        TaskInfo = cloud.ReadPlguinTaskInfo(TaskId)[0]
        print("TaskId:" + TaskId)
        print("TaskInfo" + json.dumps(TaskInfo))
    except:
        if not TaskId:
            print ("Cannot Find TaskId")
        else:
            print ("Something Bad Happend")
    if TaskInfo:
        cloud.RunTaskOnCli(TaskInfo)









































