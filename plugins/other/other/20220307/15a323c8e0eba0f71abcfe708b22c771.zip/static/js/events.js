Cloud189.LoadStaticPage(false);

$('p[name="bt-cloud-menu"]').on("click",function(){
    Cloud189.LoadStaticPage($(this));
})

function OnFilePageLoad(){
    $("#setAllBox").on("click",function () {
        if ($(this).prop("checked")) $('input[name="setBox"]').prop("checked",true);
        else $('input[name="setBox"]').prop("checked",false);
         LoadCheckBoxCheck();
    });

    // 当单选框被点击选中的时候
    $('input[name="setBox"]').on("click",function(){
        LoadCheckBoxCheck();
    })


    // 当点击了某个项目的时候
    $('span[name="list-files"]').on("click",function () {
       filetype = $(this).attr("filetype");
       fileid   = $(this).attr("fileid");
       // 如果点击的是文件夹的处理逻辑
       if(filetype=="dir"){
           // 清空当前搜索框中的内容
            $("#file_search").val("");
            LoadCheckBoxCheck();
            Cloud189.LoadFileList(fileid);
       }
    })


    // 点击删除链接的事件
    $('a[name="Link_Delete"]').on("click",function(){
        var fileid = $(this).attr("fileid");
        var filelist = []; filelist.push(fileid);
       Cloud189.DeleteFile(filelist);
    })

    // 点击下载按钮的事件
    $('a[name="Link_Donwload"]').on("click",function(){
        var fileid = $(this).attr("fileid");
        layer_download =  layer.open({
            type: 2,
            title: '下载文件',
            shadeClose: true,
            shade: 0.8,
            area: ['600px', '25%'],
            content: '/cloud189/static/viewer/layer/download.html?fileid=' + fileid
         });
    });

    // 点击分享按钮的事件
    $('a[name="Link_Share"]').on("click",function () {
        var fileid = $(this).attr("fileid");
        layer.open({
            type: 2,
            title: '分享文件',
            shadeClose: true,
            shade: 0.8,
            area: ['800px', '40%'],
            content: '/cloud189/static/viewer/layer/share.html?fileid=' + fileid
        });

    })

    // 点击复制按钮的事件
    $('a[name="Link_Copy"]').on("click",function () {
        InsertIntoFileIdLists($(this).attr("fileid"));
        FileIdAction = "copy";
        layer.msg("已复制文件，请前往文件夹粘贴",{icon:1});
        LoadCheckBoxCheck();
    })


     // 点击剪切按钮的事件
    $('a[name="Link_Move"]').on("click",function () {
        InsertIntoFileIdLists($(this).attr("fileid"));
        FileIdAction = "move";
         layer.msg("已剪切文件，请前往文件夹粘贴",{icon:1});
         LoadCheckBoxCheck();
    })

    if($("#setAllBox").prop("checked")){
        $("#setAllBox").click();
    }
}

function OnConfigLoad() {
    $("#OnInstallAria2").on("click",function(){
           Cloud189.InstallAria2c();
    })

     $("#PluginSSLStatus").on("click",function(){
           Cloud189.SetPluginConfigSSl();
    })

    $("#OnInstallLinkTools").on("click",function(){
        layer.open({
            type: 2,
            title: '安装链接解析器',
            shadeClose: true,
            shade: 0.8,
            area: ['800px', '60%'],
            content: '/cloud189/static/viewer/layer/linktools.html'
        });
    })
}

function LoadCheckBoxCheck(){
    if(!FileIdAction) FileIdLists = false;
     $('button[name="OnFileSelect"]').css("display","none");
     $("#OnPasteFile").css("display","none");
     // 刷新单选框页面的信息
    $('input[name="setBox"]').each(function () {
        if($(this).prop("checked")) InsertIntoFileIdLists($(this).attr("fileid"));
    });
    // 列表中存在文件 显示 删除,复制,移动按钮
    if (FileIdLists)  $('button[name="OnFileSelect"]').css("display","block");
    // 显示粘贴按钮
    if (FileIdAction) $("#OnPasteFile").css("display","block");

}

// 向文件列表队列里添加元素
function InsertIntoFileIdLists(fileid) {
    if(!FileIdLists) { FileIdLists = []; FileIdLists.push(fileid);}
    else{
         len = FileIdLists.length;
         IsExists = false;
         for(var i=0;i<len;i++){
             if (FileIdLists[i] == fileid){
                 IsExists  =true;
                 break;
             }
         }
         if(!IsExists) FileIdLists.push(fileid);
    }
}

function LoadDownloadPage(filedownload=false) {
    layer.close(parent.layer_download);
    if(filedownload){
           file_download = filedownload;
            parent.layer_download=layer.open({
            type: 2,
            title: '下载文件',
            shadeClose: true,
            shade: 0.8,
            area: ['800px', '40%'],
            content: '/cloud189/static/viewer/layer/download_task.html'
     });
    }

}

function LoadShowLogs(){


      $('a[name="ShowTaskLines"]').on("click",function(){
        var taskid = $(this).attr("taskid");
            layer.open({
            type: 2,
            title: '任务队列',
            shadeClose: true,
            shade: 0.8,
            area: ['800px', '900px'],
            content: '/cloud189/static/viewer/layer/logs.html?taskid='+taskid
         });
      });

      // 点击停止当前任务的事件
      $('a[name="StopTaskLines"]').on("click",function(){
            var taskid = $(this).attr("taskid");
            Cloud189.StopTaskLines(taskid);
      })
}

function LoadRecyclePage(){
    // 删除指定的文件
    $('a[name="Link_Delete"]').on("click",function(){
        Cloud189.DeleteRecycleFile($(this).attr("fileid"));
    });

     $('a[name="Link_Restore"]').on("click",function(){
        Cloud189.RestoreRecycleFile($(this).attr("fileid"));
    });
}


