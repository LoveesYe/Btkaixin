
if(bt.get_cookie("Cloud189_DirParentId")!="" && typeof(bt.get_cookie("Cloud189_DirParentId"))!="undefined" )
    var DirParentId = bt.get_cookie("Cloud189_DirParentId");
else  DirParentId = "-11";

if(bt.get_cookie("Cloud189_DirNowFileId")!="" &&  typeof(bt.get_cookie("Cloud189_DirNowFileId"))!="undefined")
    var DirNowFileId = bt.get_cookie("Cloud189_DirNowFileId");
else  DirNowFileId = "-11";

PluginConsole("插件环境变量："+JSON.stringify(env),"success");
var _pyver= env.python.split(".")
var pyver = _pyver[0]*100 + _pyver[1]*10 + _pyver[2]*1
if(pyver<300 && !env.msg) layer.msg("当前插件正在Python(" + env.python + ")运行,您需要将面板Python 环境升级到（python3.x）,您可参阅插件首页的使用说明");


// 复制 移动 拷贝 时的文件的列表数组
var FileIdLists = false;
var FileIdAction = false;
var layer_download  = false;
var file_download = false;

// 当前页面的所有文件数据列表
var FileList = false;

load_reflush = false;

// 当前用户的登录状态
var LocalUser=false;


