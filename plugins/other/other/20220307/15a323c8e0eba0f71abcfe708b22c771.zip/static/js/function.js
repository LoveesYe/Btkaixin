
function GetTimeNowStr(){
   var timestamp = Date.parse(new Date());
   return timestamp;
}

 function in_list(list,value)
 {
        var len = list.length;
        for(var p=0;p<len;p++) if(value == list[p]) return true;
        return false;

 }

 function randomString(len) {
　　      len = len || 32;
          var chars = 'ABCDEFGHIJKMLNOPQRSTUVWXYZabcdefghijkmlnopqrstuvwxyz0123456789'
　　      var maxPos = chars.length;
　　      var pwd = '';for (i = 0; i < len; i++) pwd +=chars.charAt(Math.floor(Math.random() * maxPos));
　　      return pwd;

}

function byteConvert(bytes){
   if (isNaN(bytes)) {
        return '';
    }
    var symbols = ['bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    var exp = Math.floor(Math.log(bytes)/Math.log(2));
    if (exp < 1) {
        exp = 0;
    }
    var i = Math.floor(exp / 10);
    bytes = bytes / Math.pow(2, 10 * i);

    if (bytes.toString().length > bytes.toFixed(2).toString().length) {
        bytes = bytes.toFixed(2);
    }
    return bytes + ' ' + symbols[i];
}

function GetExtName(fileName) {
    var extArr = fileName.split(".");
    var exts = ['folder', 'folder-unempty', 'sql', 'c', 'cpp', 'cs', 'flv', 'css', 'js', 'htm', 'html', 'java', 'log', 'mht', 'php', 'url', 'xml', 'ai', 'bmp', 'cdr', 'gif', 'ico', 'jpeg', 'jpg', 'JPG', 'png', 'psd', 'webp', 'ape', 'avi', 'flv', 'mkv', 'mov', 'mp3', 'mp4', 'mpeg', 'mpg', 'rm', 'rmvb', 'swf', 'wav', 'webm', 'wma', 'wmv', 'rtf', 'docx', 'fdf', 'potm', 'pptx', 'txt', 'xlsb', 'xlsx', '7z', 'cab', 'iso', 'bz2', 'rar', 'zip', 'gz', 'bt', 'file', 'apk', 'bookfolder', 'folder', 'folder-empty', 'folder-unempty', 'fromchromefolder', 'documentfolder', 'fromphonefolder', 'mix', 'musicfolder', 'picturefolder', 'videofolder', 'sefolder', 'access', 'mdb', 'accdb', 'sql', 'c', 'cpp', 'cs', 'js', 'fla', 'flv', 'htm', 'html', 'java', 'log', 'mht', 'php', 'url', 'xml', 'ai', 'bmp', 'cdr', 'gif', 'ico', 'jpeg', 'jpg', 'JPG', 'png', 'psd', 'webp', 'ape', 'avi', 'flv', 'mkv', 'mov', 'mp3', 'mp4', 'mpeg', 'mpg', 'rm', 'rmvb', 'swf', 'wav', 'webm', 'wma', 'wmv', 'doc', 'docm', 'dotx', 'dotm', 'dot', 'rtf', 'docx', 'pdf', 'fdf', 'ppt', 'pptm', 'pot', 'potm', 'pptx', 'txt', 'xls', 'csv', 'xlsm', 'xlsb', 'xlsx', '7z', 'gz', 'cab', 'iso', 'rar', 'zip', 'bt', 'file', 'apk', 'css'];
    var extLastName = extArr[extArr.length - 1].toLowerCase();
    for (var i = 0; i < exts.length; i++) {
        if (exts[i] == extLastName) {
            return exts[i];
        }
    }
    return 'file';
}

function getQueryVariable(variable)
{
       var query = window.location.search.substring(1);
       var vars = query.split("&");
       for (var i=0;i<vars.length;i++) {
               var pair = vars[i].split("=");
               if(pair[0] == variable){return pair[1];}
       }
       return(false);
}


 function getLocalTime(a) {
    a = a.toString();
	if(a.length > 10) {
		a = a.substring(0, 10)
	}
	return new Date(parseInt(a) * 1000).format("yyyy-MM-dd hh:mm:ss")
}

function CopyStrToClipBoard(str,msg)
{
    var clipboard = new ClipboardJS('#btn_copy_text');

     clipboard.on('success', function(e) {
         e.clearSelection();
         layer.msg(msg,{icon:1,time:1800});
     });
     clipboard.on('error', function(e) {
         window.prompt("您的浏览器不支持自动复制到剪切板...",e.text);
         e.clearSelection();
     });

     $("#btn_copy_text").attr('data-clipboard-text',str);
     $("#btn_copy_text").click();
}

function PluginConsole(msg,type="default")
{
    var style = "";
    switch (type){
        case "error":   style = "color:red" ; break;
        case "success": style = "color:green"; break;
        case "warning": style = "color:orange"; break;
        default: style = ""; break;
    }
    console.log("%c"+getLocalTime(GetTimeNowStr())+":%c[天翼网盘助手(Cloud189)]:"+msg,"color:blue",style);
}
