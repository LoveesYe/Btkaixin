   //定义窗口尺寸
    $('.layui-layer-page').css({ 'width': '1400px' });

    //左测菜单切换效果
    $(".bt-w-menu p").click(function () {
        $(this).addClass('bgw').siblings().removeClass('bgw')
    });

    // 定义请求到后端的地址
    var plugin_url = "/cloud189/";

