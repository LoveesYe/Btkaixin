var Cloud189 = {
    LoadStaticPage:function (that) {
        if(load_reflush) { clearInterval(load_reflush); load_reflush = false;}

        if(that) pageid = $(that).attr("pageid");
        else pageid = "myaccount";

        $.ajax({
            url: plugin_url + "static/viewer/" + pageid  +".html?t="+ GetTimeNowStr(),
            type:"GET",
            success:function (html) {
                $(".plugin_body").html(html);
            },
            error:function () {
                html = "<html><head><title>404 Not Found</title></head><body><center><h1>404 Not Found</h1></center><hr><center>天翼网盘助手</center></body></html><!-- a padding to disable MSIE and Chrome friendly error page --><!-- a padding to disable MSIE and Chrome friendly error page -->\n" +
                    "<!-- a padding to disable MSIE and Chrome friendly error page --><!-- a padding to disable MSIE and Chrome friendly error page --><!-- a padding to disable MSIE and Chrome friendly error page --><!-- a padding to disable MSIE and Chrome friendly error page -->"
                $(".plugin_body").html(html);
            }
        })
    },

    LoadPanelEnv:function (){
          $.ajax({
              url: plugin_url + "PluginEnv.json?t=" + GetTimeNowStr(),
              type: "POST",
              data: env,
              dataType: "JSON",
              success: function (rdata) {
                  env = rdata["env"]
              },
              error: function () {
                 PluginConsole("获取面板插件环境变量出错","warning");
              }
          });


    },

    // 取当前已经登录的用户的账户信息
    LoadUserInfo:function(){
        layer.load(2);
        $.ajax({
            url:plugin_url + "CloudUserInfo.json?t="+GetTimeNowStr(),
            type:"POST",
            data:{},
            dataType:"JSON",
            success:function (rdata) {
                 layer.closeAll("loading");
                if(rdata["cloud"]["status"]=="success"){
                     LocalUser = rdata["cloud"];
                     var relogin = "&nbsp;<a href='/cloud189/static/viewer/login.html' class='btlink' target='_blank'>切换账号</a>";
                     $("#Cloud-UserAccount").html(rdata["cloud"]["userAccount"] + relogin);
                     $("#Cloud-UserId").html(rdata["cloud"]["userId"]);
                     $("#Cloud-UserSession").html(rdata["cloud"]["sessionKey"]);
                     $("#Cloud-UserEncrypt").html(rdata["cloud"]["encryptAccount"]);
                     $("#Cloud-UserVip").html(Cloud189.LoadCloudUserVipName(rdata["cloud"]["superVip"]));
                     $("#Cloud-UserQuota").html(byteConvert(rdata["cloud"]["quota"]));
                     var allDonwload =  "&nbsp;&nbsp;&nbsp;<a class='btlink' href='javascript:;' id='AllDonwload'>列出网盘所有文件</a>"
                     $("#Cloud-UserUsed").html("天翼云盘:"+ byteConvert(rdata["cloud"]["usedSize"]) + "/189邮箱:" + byteConvert(rdata["cloud"]["used189Size"]) + "&nbsp;&nbsp;总量：" + byteConvert(rdata["cloud"]["used189Size"]+rdata["cloud"]["usedSize"]) + allDonwload);

                     $("#AllDonwload").on("click",function (){
                         layer.confirm('本功能将消耗服务器大量性能,仅为天翼账户状态异常时使用，请勿重复操作!', { btn:['确定','取消'],"title":"警告!"}, function () {Cloud189.AddAllFileDownload()}, function (){});
                     })
                }
                else if(rdata["cloud"]["status"]=="InvalidSessionKey")
                {
                    var relogin = "&nbsp;<a href='/cloud189/static/viewer/login.html' class='btlink' target='_blank'>点击登录</a>";
                      $("#Cloud-UserAccount").html("<span style='color: red'>尚未登录</span>" + relogin);
                }
            }
        })
    },

    AddAllFileDownload(){
        layer.load(2);
        $.ajax({
            url:plugin_url + "AddTask_ListAllFile.json?t=" + GetTimeNowStr(),
            type:"POST",
            data:"",
            dataType:"JSON",
            success:function(rdata){
                layer.closeAll("loading");
                layer.msg("系统将在稍候异步列出云盘中的所有文件...请勿重复操作",{icon:1});
            }
        })
    },
    LoadCloudUserVipName:function (vip) {
        switch (vip) {
            case 0:   return "<span style='color: gray'>普通会员</span>";
            case 100: return "<span style='color: #f39c12'>黄金会员</span>";
            case 200: return "<span style='color: purple'>铂晶会员</span>";
        }
    },

    LoadCloudUserTodayFlow:function () {
        // 判断当前的用户是否已经登录
             layer.load(2);
             $.ajax({
            url:plugin_url + "GetUserTodayFlow.json?t="+GetTimeNowStr(),
            type:"POST",
            data:{},
            dataType:"JSON",
            success:function (rdata) {
                 layer.closeAll("loading");
                 if(rdata["size"]==99999999999999) $("#Cloud-UserTodayFlow").html("无限流量");
                $("#Cloud-UserTodayFlow").html(byteConvert(rdata["size"]))
            }});

    },

    LoadPluginInfo:function(){
        $.ajax({
            url:plugin_url + "GetPluginVersion.json?t="+GetTimeNowStr(),
            type:"POST",
            data:{},
            dataType:"JSON",
            success:function(rdata){
                $("#plugin_name").html(rdata["plugin"]["title"]);
                $("#plugin_version").html(rdata["plugin"]["versions"]);
                $("#plugin_btlink").html(rdata["plugin"]["plugin_bt"]);
                $("#plugin_btlink").attr("href",rdata["plugin"]["plugin_bt"]);
                $("#plugin_iw3c").html(rdata["plugin"]["plugin_iw3c"]);
                $("#plugin_iw3c").attr("href",rdata["plugin"]["plugin_iw3c"]);
            }
        })
    },

    LoadPluginLogs:function(){
        $.ajax({
            url:plugin_url + "GetPluginLogs.json?t=" +GetTimeNowStr(),
            type:"POST",
            data:{},
            dataType:"JSON",
            success:function (rdata) {
                $("#plugin_logs").html(rdata["logs"]);
            }
        })
    },

    LoadFileList:function (fileid="-11") {
        if(!LocalUser){
            layer.msg("请先登录天翼网盘!",{icon:5});
            PluginConsole("获取文件列表失败，用户没有登录。Fileid:"+ fileid,"warning");
        }
        else{
             layer.load(2);
             if(DirNowFileId!=fileid) PageLocalNum = 1;
             PluginConsole("列出文件目录,fileid:"+fileid+",page:"+PageLocalNum+",keyword:"+$("#file_search").val(),"success");
             FileList = false;
          $.ajax({
            url:plugin_url + "CloudListFileInfo.json?t=" + GetTimeNowStr(),
            type:"POST",
            data:{"fileid":fileid,"page":PageLocalNum,"keyword":$("#file_search").val()},
              dataType:"JSON",
            success:function (rdata) {
                console.log(rdata);
                layer.closeAll("loading");
                if(rdata["status"]!="success")
                {
                    PluginConsole("获取文件列表失败，文件夹不存在，FileId"+ fileid,"warning");
                    layer.msg("请求的文件路径不存在!FileId"+fileid,{icon:5,time:1500});
                    bt.set_cookie("Cloud189_DirNowFileId","-11");
                    $("#file_search").val("");
                    if(fileid!="-11") Cloud189.LoadFileList("-11");
                }
                else{
                     var path = rdata["cloud"]["filepath"];
                     var pathdirs =rdata["cloud"]["pathdirs"];
                     var pathlens = pathdirs.length;
                     console.log(pathdirs);
                     for(i=0;i<pathlens;i++){
                      if(i==(pathlens-2)) { DirParentId = pathdirs[i]["fileId"]; bt.set_cookie("Cloud189_DirParentId",DirParentId); }
                      if(i==(pathlens-1)) { DirNowFileId = pathdirs[i]["fileId"];bt.set_cookie("Cloud189_DirNowFileId",DirNowFileId);}
                    }

                $("#PathPlaceBtn").html("&nbsp;&nbsp;"+path);
                $("#DirInfo").html("当前页 " +(rdata["cloud"]["folderList"].length + rdata["cloud"]["fileList"].length )+ " 条/总 " + rdata["cloud"]["count"] +"条数据")
                Body = "";
                FileList = rdata["cloud"]["folderList"];
                FileList.forEach((item,key)=>{
                    FileList[key]["isFolder"] = true;
                })
                rdata["cloud"]["fileList"].forEach((item,key)=>{
                    item["isFolder"] = false;
                    FileList.push(item);
                })
                for(i=0;i<FileList.length;i++)
                {
                    var file = FileList[i];
                    if(file["isFolder"]) { filetype = "dir";
                                fileico="ico-folder";
                                filesize = "<a fileid='"+file["id"]+"' class='btlink' href='javascript:;' onclick='Cloud189.LoadFileDirSize(this)'>点击计算</a>" ;
                    }
                    else {
                            filetype = file["fileType"];
                            fileico = "ico-"+GetExtName(file["name"]);
                            filesize = byteConvert(file["size"]);
                      }

                    var control =  "<a href='javascript:;' name='Link_Copy' class='btlink' fileid='"+file["id"]+"'>复制</a>&nbsp;"+
                        "<a href='javascript:;' name='Link_Move' class='btlink' fileid='"+file["id"]+"'>剪切</a>&nbsp;";
                    if(!file["isFolder"])
                        var control = control + "<a href='javascript:;' name='Link_Share' class='btlink' fileid='"+file["id"]+"'>分享</a>&nbsp;"+
                            "<a href='javascript:;' name='Link_Donwload' class='btlink' fileid='"+file["id"]+"'>下载</a>&nbsp;"
                    var control  = control + "<a href='javascript:;'name='Link_Delete' class='btlink' fileid='"+file["id"]+"'>删除</a>";

                    Body += "<tr class='folderBoxTr'  fileid='" + file["id"] +"'  filetype='"+ filetype +"'>\
                            <td><input type='checkbox' name='setBox' fileid='"+ file["id"] + "'></td>\
                            <td class='column-name'><span name='list-files' class='cursor' style=' width: 95%; text-overflow: clip; white-space: nowrap;' filetype='"+filetype+"' fileid='"+file["id"]+"' ><span class='ico "+fileico+"'></span><a class='text' title='FileId:" + file["id"]  + "'>" + file["name"] + "</a></span></td>\
                            <td>"+filesize + "</td>\
                            <td>" + file["lastOpTime"] + "</td>\
                            <td align='right'>" + control +"<td></tr>";
                }
                $("#files_body").html(Body);
                 PageLocalNum = rdata["cloud"]["pageNum"];
                 PageCount  = rdata["cloud"]["pageCount"];
                 $("#LocalPageNum").html(rdata["cloud"]["pageNum"]);
                  OnFilePageLoad();
                }
                // 拼接当前文件夹所在的路径

            },
            error:function (err){
                console.log(err);
                PluginConsole("获取文件列表失败，Fileid:"+ fileid,"error");
                layer.closeAll("loading");
                layer.msg("获取文件列表失败!",{icon:5});
            }
        })
        }

    },

    LoadFileDirSize:function(dom){
         if(!LocalUser)  PluginConsole("读取文件夹容量大小失败，用户没有登录","error");
        else {
             var fileid = $(dom).attr("fileid");
             layer.load(2);
             $.ajax({
                 url: plugin_url + "GetUserDirSize.json?t=" + GetTimeNowStr(),
                 type: "POST",
                 data: {"fileid": fileid},
                 dataType: "JSON",
                 success: function (rdata) {
                     layer.closeAll("loading");
                     $(dom).html(byteConvert(rdata["cloud"]["fileSize"]));
                 },
                 error:function (){
                      PluginConsole("读取文件夹容量大小失败，Fileid:"+ fileid,"error");
                     layer.closeAll("loading");
                 }
             })
         }
    },

    DeleteFile:function(files){
        if(!LocalUser)  PluginConsole("删除文件失败，用户没有登录","warning");
        else {
              layer.load(2);
            $.ajax({
            url:plugin_url + "DeleteFileobj.json?t=" + GetTimeNowStr(),
            type:"POST",
            data:{"files":JSON.stringify(files)},
            dataType:"JSON",
            success:function (rdata) {
                layer.closeAll("loading");
                var icon = (rdata["cloud"]["res_code"] == 0) ? 1 : 5;
                layer.msg("删除文件" +rdata["cloud"]["res_message"] + "!",{icon:1,time:1800});
                Cloud189.LoadFileList(DirNowFileId);
            },
             error:function (){
                     PluginConsole("删除文件失败，Files:"+ JSON.stringify(files),"error");
                     layer.closeAll("loading");
                 }
        })
           }

    },

    CopyFile:function(files){
         if(!LocalUser)  PluginConsole("复制文件失败，用户没有登录","warning");
        else {
             layer.load(2);
      $.ajax({
          url: plugin_url + "CopyFileobj.json?t=" + GetTimeNowStr(),
          type:"POST",
          data:{"files":JSON.stringify(files),"targetid":DirNowFileId},
          dataType:"JSON",
          success:function (rdata) {
                layer.closeAll("loading");
                var icon = (rdata["cloud"]["res_code"] == 0) ? 1 : 5;
                layer.msg("复制文件" +rdata["cloud"]["res_message"] + "!",{icon:1,time:1800});
                Cloud189.LoadFileList(DirNowFileId);
          },
           error:function (){
                      PluginConsole("复制文件失败，Files:"+ JSON.stringify(files),"error");
                     layer.closeAll("loading");
                 }
      })
         }

    },

    MoveFile:function(files){
        if(!LocalUser)  PluginConsole("移动文件失败，用户没有登录","warning");
        else {
               layer.load(2);
               $.ajax({
                   url: plugin_url + "MoveFileobj.json?t=" + GetTimeNowStr(),
                   type: "POST",
                   data: {"files": JSON.stringify(files), "targetid": DirNowFileId},
                   dataType: "JSON",
                   success: function (rdata) {
                       layer.closeAll("loading");
                       // layer.msg("成功移动" + rdata["cloud"]["successedCount"] + "个，失败" + rdata["cloud"]["failedCount"] + "个（共" + rdata["cloud"]["subTaskCount"] + "个）", {
                       //     icon: 1,
                       //     time: 1800
                       // });
                       var icon = (rdata["cloud"]["res_code"] == 0) ? 1 : 5;
                       layer.msg("移动文件" +rdata["cloud"]["res_message"] + "!",{icon:1,time:1800});
                       Cloud189.LoadFileList(DirNowFileId);
                   },
                    error:function (){
                       PluginConsole("移动文件失败，Files:"+ JSON.stringify(files),"error");
                       layer.closeAll("loading");
                 }
               })
           };
    },


    LoadPanelConfig:function(){
        layer.load(2);
        $.ajax({
              url:plugin_url + "ReadPanelConfig.json?t=" + GetTimeNowStr(),
            type:"POST",
            data:"",
            dataType:"JSON",
            success:function (rdata) {
                  layer.closeAll("loading");
                  rdata = rdata["Config"];

                  if(rdata["BtApi"]) $("#Plugin_BtApi").html(rdata["BtApi"]["Token"])
                  if(rdata["HeartBeat"]!="") $("#Plugin_HeartTime").html(rdata["HeartBeat"]);
                  else $("#Plugin_HeartTime").html("<a class='btlink' href='/cloud189/static/viewer/login.html'>未登录，请先登录</a>");
                  $("#Plugin_Wget").html(rdata["Wget_Version"]);
                  $("#Plugin_HeartReflush").val(rdata["HeartTime"]);
                  if(rdata["Aria2_Version"]=="") $("#Plugin_Aria2c").html("<a href=\"javascript:;\" class=\"btlink pull-right\" style=\"display: inline\" id=\"OnInstallAria2\">安装Aria2c</a>");
                  else $("#Plugin_Aria2c").html(rdata["Aria2_Version"]);
                  if(!rdata["Link_Parse"]) $("#Plugin_LinkTool").html("<a href=\"javascript:;\" class=\"btlink pull-right\" style=\"display: inline\" id=\"OnInstallLinkTools\">安装解析器</a>")
                  else{
                      $("#Plugin_LinkTool").html(rdata["Link_Parse_Ver"] + "<a href=\"javascript:;\" class=\"btlink pull-right\" style=\"display: inline\" id=\"OnInstallLinkTools\">安装解析器</a>");
                      $("#Plugin_LinkHost").html(rdata["Link_Parse_Host"]);
                      if (rdata["Link_Parse_SSl"] == "on") $("#Plugin_LinkHttps").html("<span style='color:green'>已开启</span><a href='javascript:;' id='PluginSSLStatus' class='btlink pull-right'>点击关闭</a>");
                      else   $("#Plugin_LinkHttps").html("<span style='color:red'>已关闭</span><a href='javascript:;' id='PluginSSLStatus' class='btlink pull-right'>点击开启</a>");
                  }
                  $("#Plugin_Download").val(rdata["Download_Tools"]);
                  $("#Plugin_FileInfo").val(rdata["Link_FileInfo_Ver"]);
                  OnConfigLoad();
            },
            error:function (){
                  PluginConsole("加载插件配置文件信息失败","error");
                  layer.closeAll("loading");
              }
        })
    },

    ParseShareLink:function (link,password) {
        layer.load(2);
        $.ajax({
            url:plugin_url + "CloudReadShareV2.json?t=" + GetTimeNowStr(),
            type:"POST",
            data:{"link":link,"password":password},
            dataType:"JSON",
            success:function(rdata){
                layer.closeAll("loading");
                if(rdata["status"]=="success"){
                    layer.msg("解析文件分享结果成功",{icon:1,time:1800});
                    var result = "";
                    if(rdata["expires"]){
                         var expires = getLocalTime(rdata["expires"]);
                          $("#cloud_linkexpires").html(expires);
                    }

                    rdata["files"].forEach( (file,key)=>{
                        if(key<10){
                            result += "<tr><td>" + (key+1) + "</td><td>" + file.name + "</td><td>" + byteConvert(file.size) + "</td><td>" ;
                            if(file["res_code"] == "0")
                            result += "<a  class='btlink' purl='"+file.downloadUrl+"' onclick='copyParseLink(this)' href='javascript:;'>下载</a>"   + "</td></tr>"
                            else{
                                result += "<span style='color: red'>文件过大,解析失败" + "</span></td></tr>";
                            }
                        }
                    })
                    $("#cloud_linkresult").html(result);

                }
                else{
                    layer.msg(rdata["msg"],{icon:5,time:1800});
                }
            },
            error:function (){
                  PluginConsole("请求分享链接解析失败","error");
                  layer.closeAll("loading");
              }
        })
    },

    SaveAndReloadHeart:function (HeartTime) {
        layer.load(2);
        $.ajax({
            url:plugin_url + "SaveReloadHeart.json?t=" + GetTimeNowStr(),
            type:"POST",
            data:{"HeartTime":HeartTime},
            dataType:"JSON",
            success:function(rdata){
                layer.closeAll("loading");
                layer.msg(rdata["msg"],{icon:1,time:1800});
                Cloud189.LoadPanelConfig();
            },
            error:function (){
                  PluginConsole("保存并重启心跳计时器失败","error");
                  layer.closeAll("loading");
              }
        })
    },

    InstallAria2c:function(){
        layer.load(2);
        $.ajax({
            url:plugin_url + "AddTaskInstall_Aria2c.json?t=" + GetTimeNowStr(),
            type:"POST",
            data:"",
            dataType:"JSON",
            success:function(rdata){
                layer.closeAll("loading");
                layer.msg("Aria2c 下载器已经添加到任务队列，插件将为你在后台安装...请勿重复操作",{icon:1});
            }
        })
    },

    SetPluginConfigSSl:function () {
        layer.load(2);
        $.ajax({
            url: plugin_url + "SetParseSSLTools.json?t=" + GetTimeNowStr(),
            data: "",
            dataType: "JSON",
            type: "POST",
            success: function (rdata) {
                 layer.closeAll("loading");
                 layer.msg(rdata["msg"],{icon:1});
                 Cloud189.LoadPanelConfig();
            }
        })
    },

    LoadTaskLines:function () {
        if(ReflushStatus) layer.load(2);
        $.ajax({
            url :plugin_url + "ReadPluginTaskLine.json?t=" + GetTimeNowStr(),
            data:{"page":PageLocalNum,"num":15},
            type:"POST",
            dataType:"JSON",
            success:function(rdata){
                if(ReflushStatus)layer.closeAll("loading");
                var count = rdata["count"];
                var Body = "";
                for(var i=0;i<count;i++){
                    var control = "";
                    if(rdata["Tasks"][i]["taskstatus"]==-1) var status = "<span style='color: orange'>准备执行</span>";
                    else if(rdata["Tasks"][i]["taskstatus"] == 0)  status = "<span style='color: green'>正在执行</span>";
                    else  status = "<span style='color: gray'>执行结束</span>";
                    if(rdata["Tasks"][i]["taskstatus"]!=1)  control = control + "<a href='javascript:;' taskid='"+rdata["Tasks"][i]["taskid"]+"' class='btlink' name='StopTaskLines'>取消任务</a>";
                    control = control +  "&nbsp;<a href='javascript:;' taskid='"+rdata["Tasks"][i]["taskid"]+"' class='btlink' name='ShowTaskLines'>任务日志</a>";
                   Body =  Body + "<tr><td>" + (i+1) + "</td><td>"  + rdata["Tasks"][i]["taskname"] + "</td><td>" + status + "</td><td>" + getLocalTime(rdata["Tasks"][i]["inittime"])
                    + "</td><td>" + control +"</td></tr>";
                }
                $("#taskline_body").html(Body);
                PageCount = rdata["pageSize"]
                PageLocalNum = rdata["page"]
                LoadShowLogs();
                ReflushStatus = false;
            }
        });
    },

    SetDownloadTools:function(tools){
        layer.load(2);
        $.ajax({
            url :plugin_url + "SaveDownloadTools.json?t=" + GetTimeNowStr(),
            data:{"tools":tools},
            type:"POST",
            dataType:"JSON",
            success:function(rdata){
                layer.closeAll("loading");
                if(rdata["status"]!="success"){
                    layer.msg(rdata["msg"],{icon:5});
                }
                else{
                     layer.msg(rdata["msg"],{icon:1});
                     Cloud189.LoadPanelConfig();
                }
            },
            error:function (){
                  PluginConsole("设置下载工具失败","error");
                  layer.closeAll("loading");
              }
        })
    },


    SetFileInfoRead:function(ver){
        layer.load(2);
        $.ajax({
            url :plugin_url + "SaveFileInfoConfig.json?t=" + GetTimeNowStr(),
            data:{"ver":ver},
            type:"POST",
            dataType:"JSON",
            success:function(rdata){
                layer.closeAll("loading");
                if(rdata["status"]!="success"){
                    layer.msg(rdata["msg"],{icon:5});
                }
                else{
                     layer.msg(rdata["msg"],{icon:1});
                     Cloud189.LoadPanelConfig();
                }
            },
            error:function (){
                  PluginConsole("设置文件详情读取方式","error");
                  layer.closeAll("loading");
              }
        })
    },

    StopTaskLines:function (taskid) {
        $.ajax({
            url :plugin_url + "DeleteTaskId.json?t=" + GetTimeNowStr(),
            data:{"taskid":taskid},
            type:"POST",
            dataType:"JSON",
            success:function(rdata){
                layer.closeAll("loading");
                if(rdata["status"]!="success"){
                    layer.msg(rdata["msg"],{icon:5});
                }
                else{
                     layer.msg(rdata["msg"],{icon:1});
                     Cloud189.LoadTaskLines();
                }
            },
            error:function (){
                  PluginConsole("终止/暂停插件的任务队列失败，TaskId:"+taskid,"error");
                  layer.closeAll("loading");
              }
        })
    },

    DirFileRecycle:function (pages=1) {
        if(!LocalUser)  {
            PluginConsole("列出用户回收站文件失败，用户没有登录","warning");
            layer.msg("请先登录天翼网盘!",{icon:5});
        }
        else{
        layer.load(2);
        $.ajax({
             url :plugin_url + "ListRecyleFiles.json?t=" + GetTimeNowStr(),
            data:{"pageid":pages},
            type:"POST",
            dataType:"JSON",
            success:function(rdata){
                layer.closeAll("loading");
                Body = "";
                for(i=0;i<rdata["cloud"]["fileList"].length;i++)
                {
                     var file = rdata["cloud"]["fileList"][i];
                     filetype = file["fileType"];
                     fileico = "ico-"+GetExtName(file["name"]);
                     filesize = byteConvert(file["size"]);


                      var control  ="<a href='javascript:;'name='Link_Restore' class='btlink' fileid='"+file["id"]+"'>恢复</a>" +
                        "&nbsp;&nbsp;<a href='javascript:;'name='Link_Delete' class='btlink' fileid='"+file["id"]+"'>删除</a>";

                    Body += "<tr class='folderBoxTr'  fileid='" + file["fileId"] +"'  filetype='"+ filetype +"'>\
                            <td class='column-name'><span name='list-files' class='cursor' style=' width: 95%; text-overflow: clip; white-space: nowrap;' filetype='"+filetype+"' fileid='"+file["id"]+"' ><span class='ico "+fileico+"'></span><a class='text' title='FileId:" + file["id"]  + "'>" + file["name"] + "</a></span></td>\
                            <td>"+filesize + "</td>\
                            <td>" + file["lastOpTime"] + "</td>\
                            <td align='right'>" + control +"<td></tr>";
                }

                $("#files_body").html(Body);

                PageLocalNum = pages;
                PageCount  = rdata["cloud"]["pageCount"];
                $("#LocalPageNum").html(PageLocalNum);
                LoadRecyclePage();

            },
             error:function (){
                  PluginConsole("列出回收站中的文件失败，PageId"+pageid,"error");
                  layer.closeAll("loading");
              }
        })
        }

    },

    // 从回收站删除文件
    DeleteRecycleFile:function (fileid) {
         layer.load(2);
        $.ajax({
            // 1.0.a 修复从回收站删除文件失败的BUG
            url: plugin_url + "DeleteFileFromRecycle.json?t=" + GetTimeNowStr(),
           data: {"fileid": fileid},
            type: "POST",
            dataType: "JSON",
            success: function (rdata) {
                layer.closeAll("loading");
                layer.msg("删除文件成功",{icon:1});
                Cloud189.DirFileRecycle(PageLocalNum);
            }
        });
    },

    // 从回收站恢复文件
    RestoreRecycleFile:function (fileid) {
         layer.load(2);
         files = [];
         files.push(fileid);
        $.ajax({
            url: plugin_url + "RestoreFileFromRecycle.json?t=" + GetTimeNowStr(),
            data: {"files": JSON.stringify(files)},
            type: "POST",
            dataType: "JSON",
            success: function (rdata) {
                layer.closeAll("loading");
                layer.msg("恢复文件成功",{icon:1});
                Cloud189.DirFileRecycle(PageLocalNum);
            }
        });
    },

    // 从回收站清空文件
    ClearRecycleFile:function () {
         $.ajax({
            url: plugin_url + "RemoveFiles.json?t=" + GetTimeNowStr(),
            data: "",
            type: "POST",
            dataType: "JSON",
            success: function (rdata) {
                layer.closeAll("loading");
                layer.msg("清空回收站成功",{icon:1});
                Cloud189.DirFileRecycle();
            }
        });
    },

    // 解析文件夹下面的所有文件
    ParseDirAllFiles:function (FileId)
    {
          $.ajax({
            url: plugin_url + "GetFileDownloadLink_Dir.json?t=" + GetTimeNowStr(),
            data: {"fileid":FileId},
            type: "POST",
            dataType: "JSON",
            success: function (rdata) {
                layer.closeAll("loading");
                var pasteText = "";
                rdata.forEach((item,key)=>{
                    pasteText =  pasteText + item["parse"] + "\n";
                });
                CopyStrToClipBoard(pasteText,"解析当前文件夹下所有文件成功");
            }
        });
    },

    // 从当前页面的数据数组里面取指定FileId 的数据
    ReadFileDataFromFileList:function (FileId)
    {
       // console.log(FileList);
        for(var i=0;i<FileList.length;i++)
        {
            if(FileList[i].fileId == FileId) return FileList[i];
        }

      return null
    },

    // 检查当前是否开启开发者模式
    CheckDebugStatus:function ()
    {
        $.ajax({
            url: plugin_url + "CheckDebugStatus.json?t=" + GetTimeNowStr(),
            data: "",
            type: "POST",
            dataType: "JSON",
            success: function (rdata) {
                console.log(rdata);
            }
        });
    },

    CreateDir:function(fileid,dirname,callback)
    {
        if(!LocalUser)  PluginConsole("新建文件失败，用户没有登录","error");
        else {
             $.ajax({
                 url: plugin_url + "CreateNewFolder.json?t=" + GetTimeNowStr(),
                 data: {"parentId":fileid,"filename":dirname},
                 type: "POST",
                 dataType: "JSON",
                 success: function (rdata) {
                     layer.closeAll("loading"); layer.msg("新建文件夹成功!",{icon:1}); callback();
                 },
                 error:function (e){
                     PluginConsole("新建文件夹失败，parentId:"+ fileid + ",filename:" + dirname,"error");
                     layer.closeAll("loading");
                 }
             });
         }
    },


}

// 刷新插件的环境变量
Cloud189.LoadPanelEnv();