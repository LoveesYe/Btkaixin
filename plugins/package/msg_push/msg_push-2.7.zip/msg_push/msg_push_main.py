#coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: 邹浩文 <627622230@qq.com>
# +-------------------------------------------------------------------

#+--------------------------------------------------------------------
#|   宝塔消息推送
#+--------------------------------------------------------------------
import sys
sys.path.append('/www/server/panel/class')
import json, os, time, public, re, requests, psutil, threading, datetime, base64

os.chdir("/www/server/panel")
import send_mail

class msg_push_main:
    # 用户列表
    def __init__(self):
        self.__confPath = 'plugin/msg_push/config.json'
        self.__mail_list = 'plugin/msg_push/mail_list.json'
        self.__first_check = 'plugin/msg_push/firstcheck.json'
        self.__mail_config = '/www/server/panel/data/stmp_mail.json'
        self.__mail_list_data = '/www/server/panel/data/mail_list.json'
        self.__dingding_config = '/www/server/panel/data/dingding.json'
        self.setpath="/www/server/panel"
        self.disk_error_code = 0
        self.cpu_error_code = 0
        self.net_error_code = 0
        self.mem_error_code = 0
        self.url_error_code = 0
        self.site_error_code = 0
        self.mysql_error_code = 0
        self.service_error_code = 0
        self.site_dict = {}
        self.url_dict ={}
        self.r_list = []
        self.t_list = []
        self.r_tmp_list = []
        self.t_tmp_list = []
        self.process_cpu = {}
        self.process_mem = {}
        self.cpunum = 1
        self.hour = 0
        self.ed = {}
        self.total_path = "/www/server/total/total"
        self.pyv = self._check_pyv()[0]
        self.pip = self._check_pyv()[1]
        self.mail = send_mail.send_mail()
        self.access_defs = ['checkM']

    def _check_pyv(self):
        if os.path.exists('/www/server/panel/pyenv'):
            pyv = '/www/server/panel/pyenv/bin/python'
            pip = '/www/server/panel/pyenv/bin/pip'
        else:
            pyv = '/usr/bin/python'
            pip = '/usr/bin/pip'
        return [pyv,pip]

    # 启动监控服务
    def StartServer(self, get):
        if self.check_monitor():
            a = self.CheckServer(get)
            if a["status"] == True:
                return public.returnMsg(True, '服务已经在运行了无需再启动')
            os.system("nohup %s %s/plugin/msg_push/msg_push &" % (self.pyv,self.setpath))
            a = self.CheckServer(get)
            if a["status"] == True:
                os.system("/usr/bin/echo '1' > %s/plugin/msg_push/open.txt" % self.setpath)
                return public.returnMsg(True, '服务启动成功')
            else:
                return public.returnMsg(False, '服务启动失败')
        else:
            return public.returnMsg(False, '请先打开 面板监控<br>开启方法: 菜单-->监控-->开启监控</br>')

    def StopServer(self, get):
        a = self.CheckServer(get)
        if a["status"] != True:
            return public.returnMsg(True, '服务没有启动')
        else:
            a = public.ExecShell("ps aux|grep msg_push|grep -v 'grep'|awk 'NR==1 {print $2}'")[0].strip("\n")
            os.system("kill -9 %s" % a)
            os.system("/usr/bin/echo '0' > %s/plugin/msg_push/open.txt" % self.setpath)
            return public.returnMsg(True, '服务停止成功')

    def CheckServer(self, get):
        a = public.ExecShell("ps aux|grep 'msg_push'|grep -v 'grep'|wc -l")[0].strip()
        if a == "0":
            return public.returnMsg(False, '服务未启动')
        else:
            return public.returnMsg(True, '服务已启动')
    # 新建消息推送
    def create_msg_even(self,get):

        if self.__check_msg_even(get.push_name):
            return public.returnMsg(False, '指定消息推送已存在')
        if not self.check_monitor():
            return public.returnMsg(False, '请先开启面板监控')
        if get.check_type != "report":
            if int(get.push_time) < 10:
                return public.returnMsg(False, '邮件发送间隔时间不能小于10分钟')
        getdata = get.__dict__
        data = {}
        for k in getdata.keys():
            if k == "args" or k == "data" or k == "s" or k == "action" or k == "name":
                continue
            if "value" in k:
                try:
                    n = int(getdata[k])
                    if n > 100 or n <= 0:
                        return public.returnMsg(False, '阈值不能小于等于0或大于100')
                except:
                    return public.returnMsg(False, '请输入整数')
            if "time" in k:
                try:

                    n = int(getdata[k])
                    if n <= 0:
                        return public.returnMsg(False, '不能输入负数或0')
                except:
                    return public.returnMsg(False, '请输入整数')
            if k=="mysql":
                if getdata[k] == "1":
                    if not os.path.exists("/www/server/panel/plugin/masterslave"):
                        return public.returnMsg(False, '没有安装【Mysql主从】插件，无法启用监控')
            if k=="report":
                if not os.path.exists("/www/server/panel/plugin/total"):
                    return public.returnMsg(False, '没有安装【网站监控报表】插件插件，无法启用报表发送')
            data[k] = getdata[k]
        if "url_list" in data.keys():
            site = {
                'url_list':data["url_list"],
                'key':data["key"],
                'site_name':data["site_name"],
                'adv':data["adv"]
            }
            data.pop("url_list")
            data.pop("key")
            data.pop("adv")
            data.pop("site_name")
            data["site"] = site
        conf_data = self.__read_config(self.__confPath)
        conf_data.append(data)
        self.__write_config(self.__confPath, conf_data)
        public.WriteLog('消息推送', ' 添加监控[' + data["push_name"] + ']')
        return public.returnMsg(True, '添加成功')

    # 检查事件是否存在
    def __check_msg_even(self,push_name):
        conf_data = self.__read_config(self.__confPath)
        for i in conf_data:
            if i["push_name"] == push_name:
                return i

    # 获取事件列表
    def get_msgpush_list(self, get):
        conf = self.__read_config(self.__confPath)
        for i in conf:
            if "push_time" in i.keys():
                i["push_time"] = "10"
            try:
                if i["site"]:
                    i["url_list"] = i["site"]["url_list"]
                    i["key"] = i["site"]["key"]
                    i["adv"] = i["site"]["adv"]
                    i["site_name"] = i["site"]["site_name"]
                    i.pop("site")
            except:
                pass
        return conf



    # 修改事件监控阈值
    def modify_msgpush(self,get):
        data = self.get_msgpush_list(get)
        push_name = get.push_name
        get_data = get.__dict__
        keys = {"push_type":"推送类型",
                "cpu_alarm_value":"CPU阈值",
                "cpu_check_time":"CPU检查周期",
                "mem_alarm_value":"内存阈值",
                "mem_check_time":"内存检查周期",
                "net_alarm_value":"带宽预警阈值",
                "net_check_time":"带宽监测时间",
                "net_bandwidth":"最大带宽",
                "site_check_url":"检查URL",
                "site_check_word":"检查关键字",
                "disk_alarm_value":"监控磁盘阈值",
                "url_list":"监控域名",
                "adv":"精确站点监控",
                "key":"监控站点关键字",
                "site_name":"监控站点",
                "push_time":"推送间隔时间",
                "report":"报表发送时间",
                "report_type":"报表类型",
                "netcard":"网卡",
                "open":"检测开关"}
        alter_options = ""
        try:
            push_time = get.push_time
        except:
            get.push_time = 10
        if int(get.push_time) < 10:
            return public.returnMsg(False, '邮件发送间隔时间不能小于10分钟')
        for i in data:
            if push_name == i["push_name"]:
                if not "push_time" in i.keys():
                    i["push_time"] = "10"
                for k in keys.keys():
                    try:
                        if get_data[k]:
                            if "value" in k:
                                try:
                                    a = int(get_data[k])
                                    if a <= 0 or a > 100:
                                        return public.returnMsg(False, '阈值不能小于等于0或大于100')
                                except:
                                    return public.returnMsg(False, '请输入整数')
                            if "time" in k:
                                try:
                                    a = int(get_data[k])
                                    if a <= 0:
                                        return public.returnMsg(False, '不能输入负数或0')
                                except:
                                    return public.returnMsg(False, '请输入整数')
                            if str(i[k]) != get_data[k]:
                                ldata = ""
                                udata = ""
                                if "value" in k:
                                    ldata += i[k] + "%"
                                    udata += get_data[k] + "%"
                                elif "time" in k:
                                    ldata += i[k] + "分钟"
                                    udata += get_data[k] + "分钟"
                                elif "open" in k or "adv" in k:
                                    if get_data[k] == "1":
                                        udata += "开启"
                                        ldata += "关闭"
                                    else:
                                        udata += "关闭"
                                        ldata += "开启"
                                elif "bandwidth" in k:
                                    udata += get_data[k] + "Mbps"
                                    ldata += i[k] + "Mbps"
                                elif "url" in k:
                                    udata += get_data[k]
                                    ldata += i[k]
                                else:
                                    udata += get_data[k]
                                    ldata += i[k]
                                alter_options += '推送名称 "%s" 的%s "%s" 修改为 "%s"' % (push_name, keys[k], ldata, udata)
                                i[k] = get_data[k]
                    except:
                        pass
                if alter_options:
                    public.WriteLog('消息推送', ' 修改配置[' + alter_options + ']')
        for i in data:
            try:
                if i["url_list"]:
                    site = {
                        "url_list":i["url_list"],
                        "key":i["key"],
                        "adv":i["adv"],
                        "site_name":i["site_name"]
                    }
                    i.pop("url_list")
                    i.pop("key")
                    i.pop("adv")
                    i.pop("site_name")
                    i["site"] = site
            except:
                pass

        self.__write_config(self.__confPath, data)
        return public.returnMsg(True, '修改成功')

    #删除推送事件
    def remove_msgpush(self,get):
        data = self.__read_config(self.__confPath)
        push_name = get.push_name
        for i in range(len(data)):
            if data[i]["push_name"] == push_name:
                del data[i]
                self.__write_config(self.__confPath, data)
                public.WriteLog('消息推送', ' 删除配置[' + push_name + ']')
                return public.returnMsg(True, '删除成功')
    # 第一次打开提醒设置邮件
    def CheckMailFirst(self, get):
        if not public.readFile(self.__first_check):
            public.writeFile(self.__first_check,"1")
        a = public.readFile(self.__first_check)
        e = self.get_email_list(get)["emails"]
        if a == "1" and not e:
            b = a + "1"
            public.writeFile(self.__first_check,b)
            return a
        else:
            return 0

    # 获取邮箱列表
    def get_email_list(self, get):
        emails = public.readFile(self.__mail_list)
        if not emails:
            public.writeFile(self.__mail_list, '[]')
            emails = []
        else:
            emails = json.loads(emails)
        return {'emails':emails}

    # 添加邮箱地址
    def add_email(self, get):
        emails = self.get_email_list(get)['emails']
        if len(emails) > 2: return public.returnMsg(False, '最多添加3个收件地址!')
        if get.email in emails: return public.returnMsg(False, '指定收件地址已存在!')
        # rep = "^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$"
        rep = "\w[-\w.+]*@([A-Za-z0-9][-A-Za-z0-9]+\.)+[A-Za-z]{2,14}"
        if not re.search(rep,get.email):
            return public.returnMsg(False, '请输入正确的邮箱格式')
        emails.append(get.email)
        public.WriteLog('消息推送', '添加收件地址[' + get.email + ']')
        self.__write_config(self.__mail_list,emails)
        return public.returnMsg(True, '添加成功')

    # 删除邮箱地址
    def remove_email(self, get):
        emails = self.get_email_list(get)['emails']
        emails.remove(get.email)
        public.WriteLog('消息推送', '删除收件地址[' + get.email + ']')
        self.__write_config(self.__mail_list,emails)
        return public.returnMsg(True, '删除成功')


    # 读配置
    def __read_config(self, path):
        if not os.path.exists(path) or not public.readFile(path):
                public.writeFile(path, '[]')
        upBody = public.readFile(path)
        return json.loads(upBody)

    # 写配置
    def __write_config(self ,path, data):
        return public.writeFile(path, json.dumps(data))

    # 外部读配置
    def read_config(self):
        return self.__read_config(self.__confPath)
    # 监控CPUIO
    def GetCpuIo(self,starttime):
        # 取指定时间段的CpuIo
        data = public.M('cpuio').dbfile('system').where("addtime>=? AND addtime<=?",(starttime, time.time())).field('id,pro,mem').order('id asc').select()
        return data

    # 检测硬盘使用
    def Check_hd_use(self):
            cmd_get_hd_use = '/bin/df'
            try:
                fp = os.popen(cmd_get_hd_use)
            except:
                ErrorInfo = r'get_hd_use_error'
                return ErrorInfo
            re_obj = re.compile(r'^/dev/.+\s+(?P<used>\d+)%\s+(?P<mount>.+)')
            hd_use = {}
            for line in fp:
                match = re_obj.search(line)
                if match:
                    hd_use[match.groupdict()['mount']] = match.groupdict()['used']
            fp.close()
            return hd_use
    # 返回{'/www/wwwroot/www_youbadbad_cn/files': '6', '/boot': '14', '/': '61'}

    def CheckInodeUse(self):
        cmd_get_hd_use = '/bin/df -i'
        try:
            fp = os.popen(cmd_get_hd_use)
        except:
            ErrorInfo = r'get_hd_use_error'
            return ErrorInfo
        re_obj = re.compile(r'^/dev/.+\s+(?P<used>\d+)%\s+(?P<mount>.+)')
        hd_use = {}
        for line in fp:
            match = re_obj.search(line)
            if match:
                hd_use[match.groupdict()['mount']] = match.groupdict()['used']
        fp.close()
        return hd_use

    # 检测网络用量
    def GetNetWorkIo(self, starttime):
        #取指定时间段的网络Io
        data =  public.M('network').dbfile('system').where("addtime>=? AND addtime<=?",(starttime,time.time())).field('id,up,down').order('id asc').select()
        return data
    # 发送邮件
    def __send_mail(self, url, data):
        return public.httpPost(url, data)

    # 检查站点健康
    def check_site_health(self,i):
        site_check_word = i["site_check_word"]
        site_check_url = i["site_check_url"]
        try:
            site_data = requests.get(site_check_url,timeout=5)
            site_data.encoding = 'utf-8'
            self.url_dict[site_check_url] = site_check_word in site_data.text
        except:
            self.url_dict[site_check_url] = False

    def get_local_site_list(self,get=None):
        site = {}
        site_list = public.M("sites").field("id,name").select()
        for i in site_list:
            domain_list = public.M("domain").where("pid=?", (i["id"],)).field("name").select()
            l = []
            for domain in domain_list:
                l.append(domain["name"])
            site[i["name"]] = l
        return site

    def check_local_site_health(self,url):
        url = "http://"+url
        try:
            a = requests.get(url, timeout=5)
            self.site_dict[url] = a.status_code
        except:
            self.site_dict[url] = "timeout"

    def ThreadingCheck(self,i):
        site_list = i["site"]
        if site_list["adv"] == "1":
            i["site_check_word"] = site_list["key"]
            u = site_list["url_list"]
            i["site_check_url"] = u
            t = threading.Thread(target=self.check_site_health, args=(i,))
            t.start()
        else:
            u = site_list["url_list"]
            t = threading.Thread(target=self.check_local_site_health, args=(u,))
            t.start()

    # 检查监控是否开启
    def check_monitor(self):
        monitor_file = 'data/control.conf'
        if os.path.exists(monitor_file):
            return True

    # URL回调
    def callback_url(self):
        # 构造post请求
        pass
    # 获取日志
    def get_logs(self, get):
        import page
        page = page.Page()
        count = public.M('logs').where('type=?', (u'消息推送',)).count()
        limit = 12
        info = {}
        info['count'] = count
        info['row'] = limit
        info['p'] = 1
        if hasattr(get, 'p'):
            info['p'] = int(get['p'])
        info['uri'] = get
        info['return_js'] = ''
        if hasattr(get, 'tojs'):
            info['return_js'] = get.tojs
        data = {}

        # 获取分页数据
        data['page'] = page.GetPage(info, '1,2,3,4,5,8')
        data['data'] = public.M('logs').where('type=?', (u'消息推送',)).order('id desc').limit(
            str(page.SHIFT) + ',' + str(page.ROW)).field('log,addtime').select()
        return data

    def CheckPort(self,ip,port):
        import socket
        sk = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sk.settimeout(5)
        try:
            sk.connect((ip, int(port)))
            return True
        except:
            return False

    def GetNetCard(self,get):
        import psutil
        a = psutil.net_io_counters(pernic=True)
        l = []
        for i in a.keys():
            if i != "lo":
                l.append(i)
        return l

    # def GetProcessCpuPercent(self,i):
    #     try:
    #         pp = psutil.Process(i)
    #         if pp.name() not in self.process_cpu.keys():
    #             self.process_cpu[pp.name()] = float(pp.cpu_percent(interval=0.1))
    #             return
    #         self.process_cpu[pp.name()]+=float(pp.cpu_percent(interval=0.1))
    #     except:
    #         pass
    # # 取占用最大cpu的进程
    # def ThreadingGetProcessCpuPercent(self):
    #     self.process_cpu = {}
    #     for i in psutil.pids():
    #         time.sleep(0.2)
    #         threading.Thread(target=self.GetProcessCpuPercent,args=(i,)).start()
    #     time.sleep(3)
    #     maxk = max(self.process_cpu,key=self.process_cpu.get)
    #     if maxk == "gunicorn":
    #         del(self.process_cpu[maxk])
    #     maxk = max(self.process_cpu, key=self.process_cpu.get)
    #     return [maxk,self.process_cpu[maxk]]
    def get_max_cpu_program(self):
        result = public.ExecShell("ps -aux | sort -k3nr | head -1")
        cpu_percend = result[0].split()[2]
        try:
            program_name = result[0].split(':')[2][3:-1]
        except:
            program_name = result[0].split(':')[1][3:-1]
        print([program_name,cpu_percend])
        return [program_name,cpu_percend]

    # 取占用内存最高的进程
    def GetProcessMemPercent(self,i):
        try:
            pp = psutil.Process(i)
            if pp.name() not in self.process_mem.keys():
                self.process_mem[pp.name()] = float(pp.memory_info().rss / 1024 / 1024)
                return
            self.process_mem[pp.name()]+=float(pp.memory_info().rss / 1024 / 1024)
        except:
            pass

    def ThreadingGetProcessMemPercent(self):
        self.process_mem = {}
        for i in psutil.pids():
            time.sleep(0.2)
            threading.Thread(target=self.GetProcessMemPercent,args=(i,)).start()
        time.sleep(3)
        maxk = max(self.process_mem,key=self.process_mem.get)
        if maxk == "gunicorn":
            del(self.process_mem[maxk])
        maxk = max(self.process_mem, key=self.process_mem.get)
        return [maxk,self.process_mem[maxk]]

    def __get_file_json(self,filename,defaultv = {}):
        try:
            if not os.path.exists(filename): return defaultv;
            return json.loads(public.readFile(filename))
        except:
            os.remove(filename)
            return defaultv
    # 获取站点名称
    def GetNameOfSites(self):
        sites = []
        getsites = public.M('sites').field('name').select()
        for s in getsites:
            sites.append(s["name"])
        return sites

    def GetLogs(self,data,sites_data,get_type):
        # data 日志文件内容
        # sites_data 预设的dict
        # get_type 获取类型，时日月报表
        if get_type == "network":
            for n in data:
                sites_data[get_type] += data[n]
        else:
            for time in data:
                for c in data[time]:
                    if c not in sites_data[get_type]:
                        sites_data[get_type][c] = 0
                    sites_data[get_type][c] += int(data[time][c])
    def GetTime(self,time):
        year = datetime.datetime.now().year
        month = datetime.datetime.now().month
        hour = datetime.datetime.now().hour
        day = datetime.datetime.now().day
        lastHour = hour - 1
        yesterday = day - 1
        lastMonth = month - 1
        times = {"year": year, "month": month, "day": day, "hour": hour,"lastHour":lastHour,"yesterday":yesterday,"lastMonth":lastMonth}
        for i in times:
            if times[i] < 10:
                times[i] = "0"+str(times[i])
            else:
                times[i] = str(times[i])
        return times[time]

    # 获取监控报表
    def GetSiteReport(self,siteName,gettime):
        if gettime == "daily":
            date = datetime.datetime.now()+datetime.timedelta(days=-1)
            date = date.strftime("%Y-%m-%d")
        else:
            date = datetime.datetime.now().strftime("%Y-%m-%d")
        sites_data = {"client":{},"network":0,"request":{},"spider":{}}
        get_types = ["client","network","request","spider"]
        logpath = self.total_path+"/"+siteName
        if os.path.exists(logpath):
            for get_type in get_types:
                if gettime == "month":
                    logfiles = os.listdir(logpath+"/"+get_type)
                    if "total.json" in logfiles:
                        logfiles.remove("total.json")
                    for f in logfiles:
                        if str(self.GetTime("year"))+"-"+str(self.GetTime("lastMonth")) in f:
                            lg = "%s/%s/%s" % (logpath, get_type, f)
                            data = self.__get_file_json(lg)
                            self.GetLogs(data,sites_data,get_type)
                    continue
                lg = "%s/%s/%s.json" % (logpath,get_type,date)
                data = self.__get_file_json(lg)
                if gettime == "daily":
                    self.GetLogs(data,sites_data,get_type)
                else:
                    for time in data:
                        if time == gettime:
                            sites_data[get_type] = data[time]
        else:
            pass
        return sites_data

    def GetAllSiteReport(self,i,email_data,warningUrl):
        report_type = i["report_type"]
        report = i["report"]
        push_type = i["push_type"]
        rep_ip = "^(25[0-5]|2[0-4]\d|[0-1]?\d?\d)(\.(25[0-5]|2[0-4]\d|[0-1]?\d?\d)){3}$"
        localip = self.GetLocalIp()
        if not re.search(rep_ip,str(localip)):
            localip = "获取失败"
        serverip = "\nServer IP: 【 %s 】 " % localip
        sites = self.GetNameOfSites()
        hourList = self.GetTimeStamp()
        sites_data = {}
        r_file = "%s/plugin/msg_push/rsc.txt" % self.setpath
        rsc = public.readFile(r_file)
        if not rsc:
            rsc = {"day":"","month":""}
            public.writeFile(r_file,json.dumps(rsc))
        else:
            rsc = json.loads(rsc)
        #将前端传入的时间小于10的加前面加0
        list = []
        if "," in report:
            report = report.split(",")
            for x in report:
                if int(i) < 10:
                    x = "0"+str(x)
                list.append(str(x))
            report = list
        else:
            try:
                if int(report) < 10:
                    report = "0"+str(report)
            except:
                pass
        now = time.time()
        for x in sites:
            if report_type == "hour":
                sites_data[x] = self.GetSiteReport(x, self.GetTime("lastHour"))
            else:
                sites_data[x] = self.GetSiteReport(x, report_type)
        if report_type == "hour":
            for h in hourList:
                if h < now < h + 20000:
                    if self.hour == 0:
                        email_data["title"] = "监控报表时报表"
                        email_data["body"] = serverip+self.FormatHtml(sites_data,push_type)
                        even = ""
                        print('调用发送邮件')
                        if self.__SendMail(email_data,even,warningUrl,push_type):
                            self.hour += 1
                            break
                else:
                    if  h + 300 < now < h + 500:
                        self.hour = 0
        elif report_type == "daily":
            if report == self.GetTime("hour"):
                if not rsc["day"]:
                    yesterday = "%s-%s-%s" % (self.GetTime("year"),self.GetTime("month"),self.GetTime("yesterday"))
                    email_data["title"] = "监控报表日报表 %s" % yesterday
                    email_data["body"] = serverip+self.FormatHtml(sites_data,push_type)
                    even = ""
                    if self.__SendMail(email_data,even,warningUrl,push_type):
                        rsc["day"] = "1"
                        public.writeFile(r_file, json.dumps(rsc))
                    # print("监控报表日报表"+str(email_data))
            else:
                if rsc["day"]:
                    rsc["day"] = ""
                    public.writeFile(r_file, json.dumps(rsc))
        else:
            if report[0] == self.GetTime("day") and self.GetTime("hour") == report[1]:
                if not rsc["month"]:
                    lastMonth =  "%s-%s" % (self.GetTime("year"),self.GetTime("lastMonth"))
                    email_data["title"] = "报表监控月报表 %s" % lastMonth
                    email_data["body"] = serverip+self.FormatHtml(sites_data,push_type)
                    even = ""
                    public.writeFile("/tmp/month.html",str(email_data["body"]))
                    # print("监控报表月报表" + str(email_data))
                    if self.__SendMail(email_data,even,warningUrl,push_type):
                        rsc["month"] = "1"
                        public.writeFile(r_file, json.dumps(rsc))
            else:
                if rsc["month"]:
                    rsc["month"] = ""
                    public.writeFile(r_file, json.dumps(rsc))


    def FormatHtml(self,sites_data,ding=None):
        try:
            from prettytable import PrettyTable as pt
        except:
            public.ExecShell('{} install prettytable'.format(self.pip))
            from prettytable import PrettyTable as pt
        # today = datetime.datetime.now().strftime("%Y-%m-%d")
        title = ["站点名", "PV", "UV", "IP", "200", "404", "500", "502", "503", "流量", "请求数", "蜘蛛"]
        table = pt(title)
        try:
            ding_data = []
            for sd in sites_data:
                data = []
                data.append(sd)
                status = ["pv","uv","ip","200","404","500","502","503"]
                for s in status:
                    if s in sites_data[sd]["request"].keys():
                        data.append(sites_data[sd]["request"][s])
                    else:
                        data.append(0)
                data.append(sites_data[sd]["network"])
                rql = ["GET","PUT","POST","DELETE"]
                rq_times = 0
                for r in rql:
                    if r in sites_data[sd]["request"].keys():
                        rq_times += int(sites_data[sd]["request"][r])
                data.append(rq_times)
                spiders = 0
                for s in sites_data[sd]["spider"]:
                    spiders += int(sites_data[sd]["spider"][s])
                data.append(spiders)
                ding_data.append(data)
                table.add_row(data)
        except Exception as e:
            print(e)
        if ding == 'dingding':
            string = "\n"
            title = [x for x in title if x not in ["200", "404", "500", "503", "流量", "蜘蛛"]]
            string += "\t".join(title) + "\n"
            index = [4,5,6,8,9,11]
            for i in ding_data:
                i = [str(i[n]) for n in range(len(i)) if n not in index]
                string += "\t".join(i) + "\n"
            return string
        table.reversesort = True
        text = table.get_html_string(format=True)
        html = '<html>\n<head>\n<meta charset="utf-8">\n%s\n</head>\n</html>' % text
        html = html.replace("cols","all")
        return html


    # 获取24小时时间戳
    def GetTimeStamp(self):
        tsl = []
        for i in range(24):
            d = datetime.datetime.now().strftime("%Y-%m-%d") + " %2d:00:00" % i
            timelist = time.strptime(d, "%Y-%m-%d %H:%M:%S")
            tsl.append(int(time.mktime(timelist)))
        return tsl
    # 判断监控报表是否安装
    def CheckTotal(self,get):
        path = "/www/server/panel/plugin/total/total_main.py"
        if not os.path.exists(path):
            return public.returnMsg(False, '请先安装监控报表')
        else:
            return public.returnMsg(True, '已经安装监控报表')

    # 发送邮件
    def __SendMail(self,email_data,even,warningUrl,push_type):
        """
        发送消息通知
        @filename 文件名
        @s_body 欲写入的内容
        return bool 若文件不存在则尝试自动创建
        """
        serverip = "\nServer IP: 【 %s 】 " % self.GetLocalIp()
        if "title" not in email_data.keys() or "body" not in email_data.keys():
            email_data["body"] = serverip + even
        msg_channel = self.get_channel_settings()
        if push_type == 'msg_mail' and msg_channel['msg_mail']['msg_mail'] and msg_channel['msg_mail']['info']['status']:
            print('获取邮件列表 {}'.format(self.get_msg_maillist()))
            for i in self.get_msg_maillist():
                send_result = self.user_stmp_mail_send(i,email_data['title'],email_data['body'])
                if not send_result['status']:
                    res = send_result
                else:
                    res = '1'
        elif push_type == 'dingding' and msg_channel['dingding']['dingding'] and msg_channel['dingding']['info']['status']:
            content = email_data['body']
            send_result= self.user_dingding_send(content)
            if not send_result['status']:
                res = send_result
            else:
                res = '1'
        else:
            try:
                email_data = base64.b64encode(json.dumps(email_data))
            except:
                email_data = base64.b64encode(json.dumps(email_data).encode()).decode()
            data = {"access_key": self.GetAccessKey(), "data": email_data,
                    "token": self.SetToken(email_data)}
            res = self.__send_mail(warningUrl, data)
        if res == "1":
            if even:
                public.WriteLog('消息推送', "告警邮件发送成功")
            else:
                public.WriteLog('消息推送', "报表发送成功")
            time.sleep(60)
            return True
        else:
            time.sleep(60)
            public.WriteLog('消息推送', "邮件发送失败 %s" % res)

    def GetLocalIp(self):
        # 取本地外网IP
        try:
            filename = '/www/server/panel/data/iplist.txt'
            ipaddress = public.readFile(filename).strip()
            if not ipaddress:
                import urllib2
                url = 'http://pv.sohu.com/cityjson?ie=utf-8'
                opener = urllib2.urlopen(url)
                m_str = opener.read()
                ipaddress = re.search('\d+.\d+.\d+.\d+', m_str).group(0)
                public.WriteFile(filename, ipaddress)
            c_ip = public.check_ip(ipaddress)
            if not c_ip:
                a, e = public.ExecShell("curl ifconfig.me")
                return a
            return ipaddress
        except:
            # return public.get_error_info()
            try:
                url = public.GetConfigValue('home') + '/Api/getIpAddress';
                return public.HttpGet(url)
            except:
                return public.GetHost()

    # 循环监控代码
    def CheckCPU(self,cache,i,email_data,warningUrl):
        # 检查cpu负载
        try:
            starttime = time.time() - int(i["cpu_check_time"]) * 60
            cpu_data = self.GetCpuIo(starttime)
            cpusum = 0
            for cpuio in cpu_data:
                cpusum += int(cpuio["pro"])
            cpu_avg = cpusum / len(cpu_data)
            push_type = i["push_type"]

            if int(i["cpu_alarm_value"]) <= cpu_avg:
                evenmd5 = "cpumsg" + public.Md5(str(cpu_avg))
                now = time.time()
                t = now - float(cache["cpumsg"][1])
                push_time = int(i["push_time"])*60
                if cache["cpumsg"][0] != evenmd5 and t >= push_time:
                    # mxp = self.ThreadingGetProcessCpuPercent()
                    mxp = self.get_max_cpu_program()
                    cache["cpumsg"][1] = now
                    cache["cpumsg"][0] = evenmd5
                    even = "CPU已经使用[  %.2f%s  ]超过设定阈值，其中【%s】进程占用cpu最高，占用率为 %.2f%s" % (cpu_avg, "%", mxp[0],float(mxp[1])/int(self.cpunum),"%")
                    public.WriteLog('消息推送', even)
                    # 判断告警方式发送消息
                    email_data["title"] = "CPU监控异常"
                    self.__SendMail(email_data,even,warningUrl,push_type)
                    self.cpu_error_code += 1

            else:
                if self.cpu_error_code != 0:
                    self.cpu_error_code = 0
                    public.WriteLog('消息推送', str(cache["cpumsg"]))
                    cache["cpumsg"][0] = ""
                    even = "cpu 告警状态已经恢复正常"
                    email_data["title"] = "cpu 告警状态已经恢复正常"
                    public.WriteLog('消息推送', even)
                    self.__SendMail(email_data,even,warningUrl,push_type)
                    # if self.__send_mail(warningUrl, email_data) == "1":
                    #     public.WriteLog('消息推送', "cpu 恢复邮件发送成功")
        except:
            public.WriteLog("消息推送","".format(public.get_error_info()))

    def CheckDisk(self,cache,i,email_data,warningUrl):
        hd_data = self.Check_hd_use()
        inode_data = self.CheckInodeUse()
        for keys in hd_data:
            use = int(hd_data[keys])
            inode_use = int(inode_data[keys])
            c_use = int(i["disk_alarm_value"])
            push_type = i["push_type"]
            if use >= c_use or inode_use >= c_use:
                evenmd5 = "diskmsg" + public.Md5(str(use))
                now = time.time()
                t = now - float(cache["diskmsg"][1])
                push_time = int(i["push_time"]) * 60
                if cache["diskmsg"][0] != evenmd5 and t >= push_time:
                    disk_data = '  %s  目录已经使用 %s%s 空间，inode 已经使用 %s%s' % (keys, use, "%",inode_use,"%")
                    cache["diskmsg"][0] = evenmd5
                    cache["diskmsg"][1] = now
                    even = "磁盘已经使用[  %s  ]超过设定阈值" % disk_data
                    public.WriteLog('消息推送', even)
                    email_data["title"] = "磁盘监控异常"
                    self.__SendMail(email_data, even, warningUrl,push_type)
                    self.disk_error_code += 1
                    self.ed[keys] = self.disk_error_code
                    # 判断告警方式发送消息
            else:
                try:
                    if self.ed[keys] != 0:
                        self.ed[keys] = 0
                        cache["diskmsg"][0] = ""
                        even = "磁盘告警状态已经恢复正常"
                        email_data["title"] = "磁盘告警状态已经恢复正常"
                        self.__SendMail(email_data, even, warningUrl,push_type)
                        public.WriteLog('消息推送', even)
                except:
                    self.ed[keys] = 0

    def CheckNet(self, cache, i, email_data, warningUrl):
        import psutil
        ct = int(i["net_check_time"])
        nb = int(i["net_bandwidth"])
        nv = int(i["net_alarm_value"])
        push_time = int(i["push_time"])
        cache_t = float(cache["netmsg"][1])
        if "netcard" not in i.keys():
            i["netcard"] = "lo"
        net_tmp = psutil.net_io_counters(pernic=True)

        r_tmp = net_tmp[i["netcard"]].bytes_recv
        t_tmp = net_tmp[i["netcard"]].bytes_sent
        push_type = i["push_type"]
        if len(self.r_tmp_list) < 2:
            self.r_tmp_list.append(r_tmp)
        else:
            self.r_tmp_list.pop(0)
            self.r_tmp_list.append(r_tmp)
        if len(self.t_tmp_list) < 2:
            self.t_tmp_list.append(t_tmp)
        else:
            self.t_tmp_list.pop(0)
            self.t_tmp_list.append(t_tmp)

        r = int(self.r_tmp_list[-1]) - int(self.r_tmp_list[-2])
        t = int(self.t_tmp_list[-1]) - int(self.t_tmp_list[-2])
        if len(self.r_list) > ct:
            self.r_list.pop(0)
        if len(self.t_list) > ct:
            self.t_list.pop(0)
        self.r_list.append(r)
        self.t_list.append(t)
        rsum = 0
        tsum = 0

        for i in self.r_list:
            rsum += i
        for i in self.t_list:
            tsum += i
        rsum = rsum/1024/ct
        tsum = tsum/1024/ct
        net_bandwidth = nb*1024*nv/ 100
        if rsum >= net_bandwidth and tsum >= net_bandwidth:
            d = "上行带宽 %.2fKB 下行带宽 %.2fKB" % (tsum, rsum)
            even = "带宽已经使用[ %s ]超过设定阈值" % d
            evenmd5 = "netmsg" + public.Md5(even)
            now = time.time()
            t = now - cache_t
            push_time = push_time*60
            if cache["netmsg"][0] != evenmd5 and t >=push_time:
                cache["netmsg"][0] = evenmd5
                cache["netmsg"][1] = now
                public.WriteLog('消息推送', even)
                email_data["title"] = "带宽监控异常"
                self.__SendMail(email_data, even, warningUrl,push_type)
                self.net_error_code += 1
        else:
            if self.net_error_code != 0:
                self.net_error_code = 0
                cache["netmsg"][0] = ""
                even = "带宽告警状态已经恢复正常"
                email_data["title"] = "带宽告警状态已经恢复正常"
                self.__SendMail(email_data, even, warningUrl,push_type)
                public.WriteLog('消息推送', "带宽告警状态已经恢复正常")

    def CheckMem(self,cache,i,email_data,warningUrl):
        starttime = time.time() - int(i["mem_check_time"]) * 60
        mem_data = self.GetCpuIo(starttime)
        memsum = 0
        for mem in mem_data:
            memsum += int(mem["mem"])
        mem_avg = memsum / len(mem_data)
        push_type = i["push_type"]
        if int(i["mem_alarm_value"]) <= mem_avg:
            evenmd5 = "memmsg" + public.Md5(str(mem_avg))
            now = time.time()
            t = now - float(cache["memmsg"][1])
            push_time = int(i["push_time"]) * 60
            if cache["memmsg"][0] != evenmd5 and t >= push_time:
                mxp = self.ThreadingGetProcessMemPercent()
                even = "内存已经使用[  %d%s  ]超过设定阈值，其中【%s】进程占用内存最高，占用率为 %sMB" % (mem_avg, "%", mxp[0],mxp[1])
                cache["memmsg"][0] = evenmd5
                cache["memmsg"][1] = now
                public.WriteLog('消息推送', even)
                email_data["title"] = "内存监控异常"
                self.__SendMail(email_data, even, warningUrl,push_type)
                self.mem_error_code += 1
                # 判断告警方式发送消息
        else:
            if self.mem_error_code != 0:
                self.mem_error_code = 0
                cache["memmsg"][0] = ""
                even = "内存告警状态已经恢复正常"
                email_data["title"] = "内存告警状态已经恢复正常"
                self.__SendMail(email_data, even, warningUrl,push_type)
                public.WriteLog('消息推送', even)

    def CheckUrl(self,cache,i,email_data,warningUrl):
        site_url = i["site_check_url"]
        self.check_site_health(i)
        push_type = i["push_type"]
        for u in self.url_dict:
            if not self.url_dict[u]:
                even = "URL [  %s  ] 监控到访问异常" % site_url
                evenmd5 = "sitemsg" + public.Md5(even)
                now = time.time()
                t = now - float(cache["sitemsg"][1])
                push_time = int(i["push_time"]) * 60
                if cache["sitemsg"][0] != evenmd5 and t >= push_time:
                    cache["sitemsg"][0] = evenmd5
                    cache["sitemsg"][1] = now
                    public.WriteLog('消息推送', even)
                    email_data["title"] = "URL监控异常"
                    self.__SendMail(email_data, even, warningUrl,push_type)
                    self.url_error_code += 1
            else:
                if self.url_error_code != 0:
                    self.url_error_code = 0
                    cache["sitemsg"][0] = ""
                    even = "URL告警状态已经恢复正常 [ %s ]" % site_url
                    email_data["title"] = even
                    public.WriteLog('消息推送', even)
                    self.__SendMail(email_data, even, warningUrl,push_type)

    def CheckLocalSite(self,cache,i,email_data,warningUrl):
        self.ThreadingCheck(i)
        l = []
        l.append(i["site"]["url_list"])
        push_type = i["push_type"]
        if i["site"]["adv"] == "1":
            while len(self.url_dict) !=len(l):
                time.sleep(0.5)
        else:
            while len(self.site_dict) != len(l):
                time.sleep(0.5)

        if self.site_dict:
            a = self.site_dict
        else:
            a = self.url_dict
        for s in a.keys():
            if a[s] != 200 or not a[s]:
                even = "站点 [  %s  ] 监控到访问异常" % s
                evenmd5 = "localsitemsg" + public.Md5(even)
                now = time.time()
                t = now - float(cache["memmsg"][1])
                push_time = int(i["push_time"]) * 60
                if cache["localsitemsg"][0] != evenmd5 and t >= push_time:
                    cache["localsitemsg"][0] = evenmd5
                    cache["localsitemsg"][1] = now
                    public.WriteLog('消息推送', even)
                    email_data["title"] = even
                    self.__SendMail(email_data, even, warningUrl,push_type)
                    self.site_error_code += 1
            else:
                if self.site_error_code != 0:
                    self.site_error_code = 0
                    cache["localsitemsg"][0] = ""
                    even = "站点告警状态已经恢复正常 [ %s ]" % s
                    email_data["title"] = even
                    public.WriteLog('消息推送', even)
                    self.__SendMail(email_data, even, warningUrl,push_type)

    def CheckMysql(self,cache,email_data,warningUrl,i):
        import panelMysql as pm
        f = "%s/plugin/masterslave/data.json" % self.setpath
        conf = public.readFile(f)
        push_type = i["push_type"]
        if not conf:
            if self.mysql_error_code < 1:
                self.mysql_error_code += 1
                public.WriteLog('消息推送', "主从没有配置")
        conf = json.loads(conf)
        try:
            now = time.time()
            t = now - float(cache["memmsg"][1])
            push_time = int(i["push_time"]) * 60
            if "master_ip" in conf.keys():
                slavestatus = pm.panelMysql().query("show slave status")[0]
                Slave_IO_Running = slavestatus[10]
                Slave_SQL_Running = slavestatus[11]
                if Slave_IO_Running != "Yes" or Slave_SQL_Running != "Yes":
                    even = "mysql主从异常"
                    evenmd5 = "mysqlmsg" + public.Md5(even)
                    if cache["mysqlmsg"][0] != evenmd5 and t >= push_time:
                        cache["mysqlmsg"][0] = evenmd5
                        cache["mysqlmsg"][1] = now
                        email_data["title"] = "Mysql主从异常"
                        self.__SendMail(email_data, even, warningUrl,push_type)
                        self.mysql_error_code += 1
                        public.WriteLog('消息推送', "Mysql主从异常")
                else:
                    if self.mysql_error_code != 0:
                        self.mysql_error_code = 0
                        cache["mysqlmsg"][0] = ""
                        even = "Mysql主从异常恢复"
                        email_data["title"] = "Mysql主从异常恢复"
                        public.WriteLog('消息推送', even)
                        self.__SendMail(email_data, even, warningUrl,push_type)
            else:
                for n in range(len(conf["slave_ip"])):
                    slaveip = conf["slave_ip"][n]
                    slaveport = conf["slave_port"][n]
                    if not self.CheckPort(slaveip, slaveport):
                        even = '无法访问从服务器<br>请确认安全组是否已经放行<br>：{}:{}'.format(slaveip,slaveport)
                        evenmd5 = "mysqlmsg" + public.Md5(even)
                        if cache["mysqlmsg"][0] != evenmd5 and t >= push_time:
                            cache["mysqlmsg"][0] = evenmd5
                            cache["mysqlmsg"][1] = now
                            self.mysql_error_code += 1
                            public.WriteLog('消息推送', even)
                            email_data["title"] = "Mysql主从异常"
                            self.__SendMail(email_data, even, warningUrl,push_type)
                            return
                    slavestatus = public.ExecShell(
                        "mysql -h%s -P%s --connect_timeout=3 -u%s -p%s -e 'show slave status\G'" % (
                            slaveip, slaveport, "user" + conf["slave_user"],
                            "pass" + conf["slave_pass"]))[0]
                    Slave_IO_Running = "Slave_IO_Running:\s+(\w+)"
                    Slave_SQL_Running = "Slave_SQL_Running:\s+(\w+)"
                    Slave_IO_Running = re.search(Slave_IO_Running, slavestatus).group(1)
                    Slave_SQL_Running = re.search(Slave_SQL_Running, slavestatus).group(1)
                    if Slave_IO_Running != "Yes" or Slave_SQL_Running != "Yes":
                        even = "mysql主从异常"
                        evenmd5 = "mysqlmsg" + public.Md5(even)
                        if cache["mysqlmsg"][0] != evenmd5 and t >= push_time:
                            cache["mysqlmsg"][0] = evenmd5
                            cache["mysqlmsg"][1] = now
                            email_data["title"] = "Mysql主从异常"
                            self.__SendMail(email_data, even, warningUrl,push_type)
                        public.WriteLog('消息推送', "Mysql主从异常！！")
                    else:
                        if self.mysql_error_code != 0:
                            self.mysql_error_code = 0
                            cache["mysqlmsg"][0] = ""
                            even = "Mysql主从异常恢复"
                            public.WriteLog('消息推送', even)
                            email_data["title"] = "Mysql主从异常恢复"
                            self.__SendMail(email_data, even, warningUrl,push_type)
        except:
            public.WriteLog('消息推送', "error: " + public.get_error_info())

    def _get_check_time(self,i):
        try:
            if int(i['report']) < 10:
                i['report'] = "0" + str(i['report'])
        except:
            i['report'] = "09"
        if not self.GetTime("hour") == i['report']:
            return True

    def check_ssl_expired(self,cache,i,email_data,warningUrl):
        if self._get_check_time(i):
            cache['sslmsg'][1] = 1
            return '还没到检查时间'
        if cache['sslmsg'][1] == 1 or cache['sslmsg'][1]=='':
            sites = self.GetNameOfSites()
            push_type = i["push_type"]
            import data
            d = data.data()
            even = '<br>'
            for sitename in sites:
                ssl_info = d.get_site_ssl_info(sitename)
                if str(ssl_info) == '-1':
                    continue
                if not int(ssl_info['endtime']) <= int(i['ssl_check_time']):
                    continue
                tmp = "监控到网站 [ {} ] 的SSL就要过期了，过期时间是：{}天后".format(sitename,int(ssl_info['endtime']))
                public.WriteLog('消息推送', tmp)
                even += tmp+'<br>'
            if even == '<br>':
                return '没有检查到即将过期的证书'

            email_data["title"] = "监控到有网站SSL即将到期！"

            self.__SendMail(email_data, even, warningUrl, push_type)
            cache['sslmsg'][1] = 0

    def _check_service_status(self,service_run_path):
        res = public.ExecShell('ps aux|grep {}|grep -v grep'.format(service_run_path))
        if res[0]:
            return True

    def service_process(self,cache,i,email_data,warningUrl):
        service_list = {"redis":{"s":"redis","p":"/www/server/redis/src/redis-server"},
                        "mysql":{"s":"mysqld","p":"/www/server/mysql/bin/mysqld"},
                        "ftp":{"s":"pure-ftpd","p":"pure-ftpd"},
                        "php52":{"s":"php-fpm-52","p":"/www/server/php/52/"},
                        "php53":{"s":"php-fpm-53","p":"/www/server/php/53/"},
                        "php54":{"s":"php-fpm-54","p":"/www/server/php/54/"},
                        "php55":{"s":"php-fpm-55","p":"/www/server/php/55/"},
                        "php56":{"s":"php-fpm-56","p":"/www/server/php/56/"},
                        "php70":{"s":"php-fpm-70","p":"/www/server/php/70/"},
                        "php71":{"s":"php-fpm-71","p":"/www/server/php/71/"},
                        "php72":{"s":"php-fpm-72","p":"/www/server/php/72/"},
                        "php73":{"s":"php-fpm-73","p":"/www/server/php/73/"},
                        "php74":{"s":"php-fpm-74","p":"/www/server/php/74/"},
                        "php80":{"s":"php-fpm-80","p":"/www/server/php/80/"},
                        "nginx":{"s":"nginx","p":"/www/server/nginx/sbin/nginx"},
                        "apache":{"s":"httpd","p":"/www/server/apache/bin/httpd"},
                        "docker":{"s":"docker","p":"/usr/bin/dockerd"}
                        }
        if i['service'] not in service_list:
            return "无服务还未适配"
        push_type = i["push_type"]
        service_run_path = service_list[i['service']]['p']
        service_status = self._check_service_status(service_run_path)
        service = service_list[i['service']]['s']
        if not service_status:
            now = time.time()
            t = now - float(cache["service_msg"][1])
            push_time = int(i["push_time"]) * 60
            if t >= push_time:
                # service_data = '系统检测到服务【%s】已经停止！'.format(i['service'])
                even = '系统检测到服务【%s】已经停止！'.format(i['service'])
                if i['action'] == 'restart':
                    public.ExecShell('systemctl restart {}'.format(service))
                    time.sleep(3)
                    if self._check_service_status(service_run_path):
                        even += "\n服务已经重新启动！"
                    else:
                        even += "\n服务已经重新启动失败！"
                cache["service_msg"][1] = now
                public.WriteLog('消息推送', even)
                email_data["title"] = "{} 监控异常".format(service)
                self.__SendMail(email_data, even, warningUrl,push_type)
                self.service_error_code += 1
                self.ed[service] = self.service_error_code
                # 判断告警方式发送消息
        else:
            try:
                if self.ed[service] != 0:
                    self.ed[service] = 0
                    cache["service_msg"][0] = ""
                    even = "{} 告警状态已经恢复正常".format(service)
                    email_data["title"] = "{} 告警状态已经恢复正常".format(service)
                    self.__SendMail(email_data, even, warningUrl,push_type)
                    public.WriteLog('消息推送', even)
            except:
                self.ed[service] = 0

    def SetToken(self,email_data):
        ufile = "/www/server/panel/data/userInfo.json"
        uconf = public.readFile(ufile)
        if uconf:
            uconf = json.loads(uconf)
            sk = uconf["secret_key"]
        else:
            return False
        token = public.Md5(sk+email_data)
        return token
    def GetAccessKey(self):
        ufile = "/www/server/panel/data/userInfo.json"
        uconf = public.readFile(ufile)
        if uconf:
            uconf = json.loads(uconf)
            ak = uconf["access_key"]
        else:
            return False
        return ak

    def get_channel_settings(self,get=None):
        qq_mail_info = json.loads(public.ReadFile(self.__mail_config))
        if len(qq_mail_info) == 0:
            user_mail = False
        else:
            user_mail = True
        dingding_info = json.loads(public.ReadFile(self.__dingding_config))
        if len(dingding_info) == 0:
            dingding = False
        else:
            dingding = True
        ret = {}
        ret['msg_mail'] = {"msg_mail": user_mail, "mail_list": self.__mail_list,"info":self.get_user_mail()}
        ret['dingding'] = {"dingding": dingding,"info":self.get_dingding()}
        return ret

    # 查看钉钉
    def get_dingding(self):
        qq_mail_info = json.loads(public.ReadFile(self.__dingding_config))
        if len(qq_mail_info) == 0:
            return public.returnMsg(False, '无信息')
        return public.returnMsg(True, qq_mail_info)

    # 查看自定义邮箱配置
    def get_user_mail(self):
        qq_mail_info = json.loads(public.ReadFile(self.__mail_config))
        if len(qq_mail_info) == 0:
            return public.returnMsg(False, '无信息')
        if not 'port' in qq_mail_info:qq_mail_info['port']=465
        return public.returnMsg(True, qq_mail_info)

    # 使用钉钉发送消息
    def user_dingding_send(self, content):
        qq_mail_info = json.loads(public.ReadFile(self.__dingding_config))
        if len(qq_mail_info) == 0:
            return public.returnMsg(False, '未找到您配置的钉钉的配置信息,请在设置中添加')
        # if not (hasattr(get, 'content')): return public.returnMsg(False, '请输入你需要发送的数据')
        if self.mail.dingding_send(content):
            return public.returnMsg(True, '发送成功')
        else:
            return public.returnMsg(False, '发送失败')

    # 用户自定义邮件发送
    def user_stmp_mail_send(self, email,title,body):
        # if not (hasattr(get, 'email')): return public.returnMsg(False, '请填写邮件地址')
        emailformat = re.compile(r'[a-zA-Z0-9.-_+%]+@[a-zA-Z0-9]+\.[a-zA-Z0-9]+')
        if not emailformat.search(email): return public.returnMsg(False, '请输入正确的邮箱')
        # 测试发送邮件
        email_list = self.get_msg_maillist()
        if not email.strip() in email_list: return public.returnMsg(True, '邮箱不存在,请添加到邮箱列表中')
        # 先判断是否存在stmp信息
        qq_mail_info = json.loads(public.ReadFile(self.__mail_config))
        if len(qq_mail_info) == 0:
            return public.returnMsg(False, '未找到STMP的信息,请在设置中重新添加自定义邮件STMP信息')
        if self.mail.qq_smtp_send(email, title, body):
            # 发送成功
            return public.returnMsg(True, '发送成功')
        else:
            return public.returnMsg(False, '发送失败')

    def get_msg_maillist(self):
        mail_data = []
        try:
            if not os.path.exists(self.__mail_list_data):
                ret = []
                public.writeFile(self.__mail_list_data, json.dumps(ret))
            else:
                try:
                    mail_data = json.loads(public.ReadFile(self.__mail_list_data))
                except:
                    ret = []
                    public.writeFile(self.__mail_list_data, json.dumps(ret))
            return mail_data
        except:return mail_data

    # def set_send_method(self,get):
    #     public.writeFile('plugin/msg_push/send_method',get.send_method)

    # 检查开始
    def checkM(self):
        if self.check_monitor():
            cache = {"cpumsg":["",0],"diskmsg":["",0],"netmsg":["",0],"memmsg":["",0],"sitemsg":["",0],"mysqlmsg":["",0],
                     "localsitemsg":["",0],"sslmsg":["",""],"service_msg":["",0]}
            warningUrl = "http://www.bt.cn/api/index/send_mail_msg"
            while True:
                mail_list = self.get_email_list(None)["emails"]
                mail_list = ",".join(mail_list)
                email_data = {"email": mail_list}
                conf_data = self.__read_config(self.__confPath)
                self.cpunum = psutil.cpu_count()
                for i in conf_data:
                    if int(i["open"]) == 1:
                        try:
                            if "push_time" not in i.keys():
                                i["push_time"] = "10"
                            if "cpu_alarm_value" in i.keys() and i["cpu_alarm_value"] != "":
                                self.CheckCPU(cache,i,email_data,warningUrl)
                            # 检查磁盘空间
                            if "disk_alarm_value" in i.keys() and i["disk_alarm_value"] != "":
                                self.CheckDisk(cache,i,email_data,warningUrl)
                            # 检测带宽
                            if "net_alarm_value" in i.keys() and i["net_alarm_value"] != "":
                                self.CheckNet(cache,i,email_data,warningUrl)
                            # 检测内存
                            if "mem_alarm_value" in i.keys() and i["mem_alarm_value"] != "":
                                self.CheckMem(cache,i,email_data,warningUrl)
                            # 检测URL健康
                            if "site_check_url" in i.keys() and i["site_check_url"]:
                                self.url_dict = {}
                                self.CheckUrl(cache,i,email_data,warningUrl)
                            # 检测站点
                            if "site" in i.keys() and i["site"]["url_list"]:
                                self.site_dict = {}
                                self.CheckLocalSite(cache, i, email_data, warningUrl)
                            # 检查mysql主从健康
                            if "mysql" in i.keys() and i["mysql"] != "":
                                self.CheckMysql(cache,email_data,warningUrl,i)
                            # 小时报表发送
                            if "report_type" in i.keys() and i['check_type'] == 'report':
                                self.GetAllSiteReport(i,email_data,warningUrl)
                            # 检查ssl过期
                            if "report_type" in i.keys() and i['check_type'] == 'check_ssl_expired':
                                self.check_ssl_expired(cache,i,email_data,warningUrl)
                            if "service" in i.keys() and i["service"] != "":
                                self.service_process(cache,i,email_data,warningUrl)
                        except Exception as e:
                            print(public.get_error_info())
                time.sleep(60)
        else:
            return public.returnMsg(False, '请先打开 面板监控，开启方法菜单-->监控-->开启监控')


if __name__ == '__main__':
    msg_push = msg_push_main()
    msg_push.checkM()
