return {
    ["settings"] = {
        ["open"] = true,
        ["ip_for"] = {
            [1] = "x-forwarded-for",
            [2] = "x-real-ip"
        },
        ["cache"] = {
            ["type"] = "simple",
            ["size"] = "64",
            ["host"] = "",
            ["port"] = "",
            ["username"] = "",
            ["password"] = ""
        }
    },
    ["sites"] = {
        
    }
}