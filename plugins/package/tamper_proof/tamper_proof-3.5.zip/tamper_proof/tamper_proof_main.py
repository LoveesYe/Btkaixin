#coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: hwliang <hwliang@bt.cn>
# +-------------------------------------------------------------------
#+--------------------------------------------------------------------
#|   宝塔防篡改程序
#+--------------------------------------------------------------------
import os,sys,public,json,time

class tamper_proof_main:
    __plugin_path = '/www/server/panel/plugin/tamper_proof'
    __sites = None
    __session_name = 'tamper_proof' + time.strftime('%Y-%m-%d')



    # 取当前可用PHP版本
    def GetPHPVersion(self):
        phpVersions = public.get_php_versions()
        httpdVersion = ""
        data = []
        for val in phpVersions:
            tmp = {}
            checkPath = '/www/server/php/' + val + '/bin/php'
            if val in ['00', 'other']: checkPath = '/etc/init.d/bt'
            if httpdVersion == '2.2': checkPath =  '/www/server/php/' + val + '/libphp5.so'
            if os.path.exists(checkPath):
                tmp['version'] = val
                tmp['name'] = 'PHP-' + val
                if val == '00':
                    continue

                if val == 'other':
                    continue
                data.append(tmp)
        if len(data)>=0:
            return data[0]
        return False

    def sim_test(self,get):
        '''
        @name 模拟测试是否成功
        @author 梁凯强<2022-1-11>
        @param path 目录
        @return int
        '''
        path=get.path.strip()
        if not os.path.exists(path):return public.returnMsg(False,"此目录不存在")
        #判断是否安装php
        php_version =self.GetPHPVersion()
        if not php_version:return public.returnMsg(False,"未安装PHP测试失败")
        php_path='/www/server/php/' + php_version['version'] + '/bin/php'
        php_name= path+"/"+str(int(time.time()))+".php"
        if os.path.exists(php_name):
            public.ExecShell("rm -rf %s"%php_name)
        ###写入


        cmdString=php_path+" -r \"file_put_contents('{}','{}');\"".format(php_name,php_name)
        public.ExecShell(cmdString,user='www')
        time.sleep(0.5)
        if os.path.exists(php_name):
            if os.path.exists(php_name):
                public.ExecShell("rm -rf %s" % php_name)
            return public.returnMsg(False,"拦截失败,可能未开启防篡改")
        return public.returnMsg(True, "拦截成功")



    def get_speed(self,get):
        speed_file = self.__plugin_path + '/speed.pl'
        log_file = self.__plugin_path + '/service.log'
        result = {'speed':'','log':'','status':True,'msg':'获取成功'}
        if os.path.exists(speed_file):
            result['speed'] = public.readFile(speed_file)
        if os.path.exists(log_file):
            result['log'] = public.GetNumLines(log_file,11)
        return result

    def get_run_logs(self,get):
        log_file = self.__plugin_path + '/service.log'
        return public.returnMsg(True,public.GetNumLines(log_file,200))
    
    def get_index(self,get):
        ret=self.get_tamper_proof()
        if ret==0:
            return  False
        self.sync_sites(get)
        day = None
        if hasattr(get,'day'): day = get.day
        data = {}
        data['open'] = self.get_service_status(None)
        data['sites'] = self.get_sites(None)
        data['total'] = self.get_total()
        for i in range(len(data['sites'])):
            data['sites'][i]['total'] = self.get_total(data['sites'][i]['siteName'],day)
        return data

    def get_sites(self,get = None):
        if self.__sites: return self.__sites
        siteconf = self.__plugin_path + '/sites.json'
        d = public.readFile(siteconf)
        if not os.path.exists(siteconf) or not d:
            public.writeFile(siteconf,"[]")
        data = json.loads(public.readFile(siteconf))

        # 处理多余字段开始 >>>>>>>>>>
        is_write = False
        rm_keys = ['lock','bak_open']
        for i in data:
            i_keys = i.keys()
            if not 'open' in i_keys: i['open'] = False
            for o in rm_keys:
                if o in i_keys:
                    if i[o]: i['open'] = True
                    i.pop(o)
                    is_write = True
        if is_write: public.writeFile(siteconf,json.dumps(data))
        # 处理多余字段结束 <<<<<<<<<<<<<
        
        self.__sites = data
        return data

    def get_site_find(self,get):
        return self.__get_find(get.siteName)

    def __get_find(self,siteName):
        data = self.get_sites(None)
        for siteInfo in data:
            if siteName == siteInfo['siteName']: return siteInfo
        return None

    def save_site_config(self,siteInfo):
        data = self.get_sites(None)
        for i in range(len(data)):
            if data[i]['siteName'] != siteInfo['siteName']: continue
            data[i] = siteInfo
            break
        self.write_sites(data)

    def write_sites(self,data):
        public.writeFile(self.__plugin_path + '/sites.json',json.dumps(data))
        public.ExecShell('/etc/init.d/bt_tamper_proof reload')

    def service_admin(self,get):
        m_logs = {'start':'启动','stop':'停止','restart':'重启'}
        public.ExecShell('/etc/init.d/bt_tamper_proof %s' % get.serviceStatus)
        self.write_log('%s防篡改服务' % m_logs[get.serviceStatus])
        return public.returnMsg(True,u'操作成功!')

    def get_service_status(self,get):
        result = public.ExecShell("/etc/init.d/bt_tamper_proof status|grep already")
        return (len(result[0]) > 3)

    def set_site_status(self,get):
        siteInfo = self.get_site_find(get)
        if not siteInfo: return public.returnMsg(False,u'指定站点不存在!')
        try:
            siteInfo['open'] =  not siteInfo['open']
        except:
            siteInfo['open'] = not siteInfo['open']
        # if siteInfo['open']:
        #     if not self.check_site_type(siteInfo): return public.returnMsg(False,u'不支持指定项目!')
        self.save_site_config(siteInfo)
        m_logs = {True:'开启',False:'关闭'}
        self.write_log('%s站点[%s]防篡改保护' % (m_logs[siteInfo['open']],siteInfo['siteName']))
        return public.returnMsg(True,u'设置成功!')


    def set_site_status_all(self,get):
        '''
            @name 批量设置网站状态
            @author hwliang<2021-05-13>
            @param get<dict_obj{
                siteNames: JSON<网站名称> JSON列表字符串, 例：["bt.cn","abc.cn"]
                siteState: int<防篡改状态> 0.关闭 1.开启
            }>
            @return dict
        '''
        sites = self.get_sites(None)
        siteState = True if get.siteState == '1' else False
        siteNames = json.loads(get.siteNames)
        m_logs = {True:'开启',False:'关闭'}
        for i in range(len(sites)):
            if sites[i]['siteName'] in siteNames: 
                sites[i]['open'] =  siteState
                self.write_log('%s站点[%s]防篡改保护' % (m_logs[siteState],sites[i]['siteName']))
        self.write_sites(sites)
        return public.returnMsg(True,'批量设置成功')



    def CheckSyssafe(self):
        if os.path.exists("/www/server/panel/plugin/syssafe"):
            confile = "/www/server/panel/plugin/syssafe/config.json"
            conf = json.loads(public.readFile(confile))
            if "xargs" not in conf["process"]["process_white"]:
                return False
            return True
        else:
            return True


    def check_site_type(self,siteInfo):
        n = 0
        if os.path.exists(siteInfo['path'] + '/addons'): n += 1
        if os.path.exists(siteInfo['path'] + '/attachment'): n += 1
        if os.path.exists(siteInfo['path'] + '/data'): n += 1
        if os.path.exists(siteInfo['path'] + '/payment'): n += 1
        if n > 3: return False
        return True


    def site_reload(self,siteInfo):
        public.ExecShell("{} {} {}".format(public.get_python_bin(),self.__plugin_path + '/tamper_proof_service.py unlock',siteInfo['path']))
        tip_file = self.__plugin_path + '/tips/' + siteInfo['siteName'] + '.pl'
        if os.path.exists(tip_file): os.remove(tip_file)

    def add_excloud(self,get):
        siteInfo = self.get_site_find(get)
        if not siteInfo: return public.returnMsg(False,u'指定站点不存在!')
        get.excludePath = get.excludePath.strip()
        if not get.excludePath: return public.returnMsg(False,'排除内容不能为空')

        for excludePath in get.excludePath.split('\n'):
            if not excludePath: continue
            if excludePath.find('/') != -1:
                if not os.path.exists(excludePath): continue
            excludePath = excludePath.lower()
            if excludePath[-1] == '/': excludePath = get.excludePath[:-1]
            if excludePath in siteInfo['excludePath']: continue
            siteInfo['excludePath'].insert(0,excludePath)
            self.write_log('站点[%s]添加排除目录名[%s]到排除列表' % (siteInfo['siteName'],excludePath))

        self.site_reload(siteInfo)
        self.save_site_config(siteInfo)
        return public.returnMsg(True,u'添加成功!')

    def remove_excloud(self,get):
        siteInfo = self.get_site_find(get)
        get.excludePath = get.excludePath.strip()
        if not get.excludePath: return public.returnMsg(False,'排除文件或目录不能为空')
        if not siteInfo: return public.returnMsg(False,u'指定站点不存在!')
        for excludePath in get.excludePath.split(','):
            if not excludePath: continue
            if not excludePath in siteInfo['excludePath']: continue
            siteInfo['excludePath'].remove(excludePath)
            self.write_log('站点[%s]从排除列表中删除目录名[%s]' % (siteInfo['siteName'],excludePath))
        self.site_reload(siteInfo)
        self.save_site_config(siteInfo)
        return public.returnMsg(True,u'删除成功!')

    def add_protect_ext(self,get):
        # if get.protectExt.find('.') != -1: return public.returnMsg(False,u'扩展名称不能包含[.]')
        siteInfo = self.get_site_find(get)
        if not siteInfo: return public.returnMsg(False,u'指定站点不存在!')
        get.protectExt = get.protectExt.strip().lower()
        for protectExt in get.protectExt.split("\n"):
            if protectExt[0] == '/':
                if os.path.isdir(protectExt): continue
            if protectExt in siteInfo['protectExt']: continue
            siteInfo['protectExt'].insert(0,protectExt)
            self.write_log('站点[%s]添加文件类型或文件名[.%s]到受保护列表' % (siteInfo['siteName'],protectExt))
        self.site_reload(siteInfo)
        self.save_site_config(siteInfo)
        return public.returnMsg(True,u'添加成功!')

    def remove_protect_ext(self,get):
        siteInfo = self.get_site_find(get)
        if not siteInfo: return public.returnMsg(False,u'指定站点不存在!')
        get.protectExt = get.protectExt.strip()
        if not get.protectExt: return public.returnMsg(False,'被删除的保护列表不能为空')
        for protectExt in get.protectExt.split(','):
            if not protectExt in siteInfo['protectExt']: continue
            siteInfo['protectExt'].remove(protectExt)
            self.write_log('站点[%s]从受保护列表中删除[.%s]' % (siteInfo['siteName'],protectExt))
        self.site_reload(siteInfo)
        self.save_site_config(siteInfo)
        return public.returnMsg(True,u'删除成功!')

    def sync_sites(self,get):
        data = self.get_sites(None)
        sites = public.M('sites').field('name,path').select()
        config = json.loads(public.readFile(self.__plugin_path + '/config.json'))
        names = []
        n = 0
        for siteTmp in sites:
            names.append(siteTmp['name'])
            siteInfo = self.__get_find(siteTmp['name'])
            if siteInfo:
                if siteInfo['path'] != siteTmp['path']:
                    siteInfo['path'] = siteTmp['path']
                    self.save_site_config(siteInfo)
                    data = self.get_sites()
                    
                continue
            siteInfo = {}
            siteInfo['siteName'] = siteTmp['name']
            siteInfo['path'] = siteTmp['path']
            siteInfo['open'] = False
            siteInfo['excludePath'] = config['excludePath']
            siteInfo['protectExt'] = config['protectExt']
            data.append(siteInfo)
            n +=1

        newData = []
        for siteInfoTmp in data:
            if siteInfoTmp['siteName'] in names:
                newData.append(siteInfoTmp)
            else:
                public.ExecShell("rm -rf " + self.__plugin_path + '/sites/' + siteInfoTmp['siteName'])
                n+=1
        if n > 0: self.write_sites(newData)
        self.__sites = None

    def get_total(self,siteName = None,day=None):
        defaultTotal = {"total":0,"delete":0,"create":0,"modify":0,"move":0}
        if siteName:
            total = {}
            total['site'] = public.readFile(self.__plugin_path + '/sites/'+siteName+'/bt_tamper_proof_total/total.json')
            if total['site']: 
                total['site'] = json.loads(total['site'])
            else:
                total['site'] = defaultTotal
            if not day: day = time.strftime("%Y-%m-%d",time.localtime())
            total['day'] = public.readFile(self.__plugin_path + '/sites/'+siteName + '/bt_tamper_proof_total/' + day + '/total.json')
            if total['day']: 
                total['day'] = json.loads(total['day'])
            else:
                total['day'] = defaultTotal
        else:
            filename = self.__plugin_path + '/sites/total.json'
            if os.path.exists(filename):
                total = json.loads(public.readFile(filename))
            else:
                total = defaultTotal
        return total

    def get_days(self,path):
        days = []
        if not os.path.exists(path): os.makedirs(path)
        for dirname in os.listdir(path):
            if dirname == '..' or dirname == '.' or dirname == 'total.json': continue
            if not os.path.isdir(path + '/' + dirname): continue
            days.append(dirname)
        days = sorted(days,reverse=True)
        return days

    #取文件指定尾行数
    def GetNumLines(self,path,num,p=1):
        pyVersion = sys.version_info[0]
        try:
            import cgi
            if not os.path.exists(path): return ""
            start_line = (p - 1) * num
            count = start_line + num
            fp = open(path,'rb')
            buf = ""
            fp.seek(-1, 2)
            if fp.read(1) == "\n": fp.seek(-1, 2)
            data = []
            b = True
            n = 0
            for i in range(count):
                while True:
                    newline_pos = str.rfind(str(buf), "\n")
                    pos = fp.tell()
                    if newline_pos != -1:
                        if n >= start_line:
                            line = buf[newline_pos + 1:]
                            try:
                                data.append(json.loads(cgi.escape(line)))
                            except: pass
                        buf = buf[:newline_pos]
                        n += 1
                        break
                    else:
                        if pos == 0:
                            b = False
                            break
                        to_read = min(4096, pos)
                        fp.seek(-to_read, 1)
                        t_buf = fp.read(to_read)
                        if pyVersion == 3:
                            if type(t_buf) == bytes: t_buf = t_buf.decode('utf-8')
                        buf = t_buf + buf
                        fp.seek(-to_read, 1)
                        if pos - to_read == 0:
                            buf = "\n" + buf
                if not b: break
            fp.close()
        except: return []
        if len(data) >= 2000:
            arr = []
            for d in data:
                arr.insert(0,json.dumps(d))
            public.writeFile(path,"\n".join(arr))
        return data

    def get_safe_logs(self,get):
        data = {}
        path = self.__plugin_path + '/sites/'+get.siteName + '/bt_tamper_proof_total'
        data['days'] = self.get_days(path)
        if not data['days']:
            data['logs'] = []
        else:
            if not 'p' in get: get.p = 1
            day =  data['days'][0]
            if hasattr(get,'day'): day = get.day
            data['get_day'] = day
            data['logs'] = self.GetNumLines(path + '/' + day + '/logs.json',2000,int(get.p))
        return data

    def ClearDayLog(self,get):
        data = {}
        path = self.__plugin_path + '/sites/' + get.siteName + '/bt_tamper_proof_total'
        data['days'] = self.get_days(path)
        if get.day in data['days']:
            logpath = path+"/"+get.day+"/logs.json"
            if os.path.exists(logpath):
                public.ExecShell("echo ''> %s" % logpath)
                public.WriteLog('防篡改程序', logpath+" 防篡改日志清理成功")
                return public.returnMsg(True, u'清理成功!')
            else:
                return public.returnMsg(False, u'没有该日志文件!')


    def get_logs(self,get):
        import page
        page = page.Page()
        count = public.M('logs').where('type=?',(u'防篡改程序',)).count()
        limit = 12
        info = {}
        info['count'] = count
        info['row']   = limit
        info['p'] = 1
        if hasattr(get,'p'):
            info['p']    = int(get['p'])
        info['uri']      = {}
        info['return_js'] = ''
        if hasattr(get,'tojs'):
            info['return_js']   = get.tojs
        data = {}
        data['page'] = page.GetPage(info,'1,2,3,4,5')
        data['data'] = public.M('logs').where('type=?',(u'防篡改程序',)).order('id desc').limit(str(page.SHIFT)+','+str(page.ROW)).field('log,addtime').select()
        return data

    def write_log(self,log):
        public.WriteLog('防篡改程序',log)


    def get_tamper_proof(self):
        from BTPanel import session, cache
        import panelAuth
        if self.__session_name in session: return session[self.__session_name]
        cloudUrl = public.GetConfigValue('home')+'/api/panel/get_soft_list'
        pdata = panelAuth.panelAuth().create_serverid(None)
        ret = public.httpPost(cloudUrl, pdata)
        if not ret:
            if not self.__session_name in session: session[self.__session_name] = 1
            return 1
        try:
            ret = json.loads(ret)
            for i in ret["list"]:
                if i['name'] == 'tamper_proof':
                    if i['endtime'] >= 0:
                        if not self.__session_name in session: session[self.__session_name] = 2
                        return 2
            if not self.__session_name in session: session[self.__session_name] = 0
            return 0
        except:
            if not self.__session_name in session: session[self.__session_name] = 1
            return 1
        # stop config

    def stop(self):
        public.ExecShell('/etc/init.d/bt_tamper_proof stop')
        try:
            version = public.version()
            rcnlist = public.httpGet(public.GetConfigValue('home')+'/api/panel/notpro?version=%s' % version)
        except:
            pass
        return True
