# coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: hwliang<hwliang@bt.cn>
# +-------------------------------------------------------------------

# +--------------------------------------------------------------------
# |   宝塔事件型防篡改
# +--------------------------------------------------------------------
import sys
sys.path.insert(0,'/www/server/panel/class')
import os, pyinotify, public, json, shutil, time


class MyEventHandler(pyinotify.ProcessEvent):
    _PLUGIN_PATH = "/www/server/panel/plugin/tamper_proof"
    __CONFIG = '/config.json'
    _SITES = '/sites.json'
    _SITES_DATA = None
    __CONFIG_DATA = None
    _DONE_FILE = None
    bakcupChirdPath = []

    def rmdir(self,filename):
        try:
            shutil.rmtree(filename)
        except: pass

    def process_IN_CREATE(self, event):
        siteInfo = self.get_SITE_CONFIG(event.pathname)
        if not self.check_FILE(event, siteInfo, True): return False
        self._DONE_FILE = event.pathname
        if event.dir:
            if os.path.exists(event.pathname): self.rmdir(event.pathname)
        else:
            if os.path.exists(event.pathname): 
                try:
                    os.remove(event.pathname)
                    self.write_LOG('create', siteInfo['siteName'], event.pathname)
                except:pass
        

    def process_IN_MOVED_TO(self, event):
        # 检查是否受保护
        siteInfo = self.get_SITE_CONFIG(event.pathname)
        if not self.check_FILE(event, siteInfo): return False

        if not getattr(event,'src_pathname',None): 
            if os.path.isdir(event.pathname):
                self.rmdir(event.pathname)
            else:
                os.remove(event.pathname)
            self.write_LOG('move', siteInfo['siteName'], '未知 -> ' + event.pathname)
            return True
        
        # 是否为标记文件
        if event.src_pathname == self._DONE_FILE: return False 

        if not os.path.exists(event.src_pathname):
            # 标记
            self._DONE_FILE = event.pathname
            # 还原
            os.renames(event.pathname,event.src_pathname)

        # 记录日志
        self.write_LOG('move', siteInfo['siteName'], event.src_pathname + ' -> ' + event.pathname)

    def check_FILE(self, event, siteInfo, create=False):
        if not siteInfo: return False
        if self.exclude_PATH(event.pathname): 
            return False
        if event.dir and create: return True
        if not event.dir:
            if not self.protect_EXT(event.pathname): 
                return False
        return True

    def protect_EXT(self, pathname):
        if pathname.find('.') == -1: return False
        extName = pathname.split('.')[-1].lower()
        siteData = self.get_SITE_CONFIG(pathname)
        if siteData:
            if extName in siteData['protectExt']:
                return True
        return False

    def exclude_PATH(self, pathname):
        if pathname.find('/') == -1: return False
        siteData = self.get_SITE_CONFIG(pathname)
        return self.exclude_PATH_OF_SITE(pathname,siteData['excludePath'])


    def exclude_PATH_OF_SITE(self, pathname,excludePath):
        pathname = pathname.lower()
        dirNames = pathname.split('/')
        if excludePath:
            if pathname in excludePath:
                return True
            if pathname + '/' in excludePath:
                return True
            for ePath in excludePath:
                if ePath in dirNames: return True
                if pathname.find(ePath) == 0: return True
        return False

    def get_SITE_CONFIG(self, pathname):
        if not self._SITES_DATA: self._SITES_DATA = json.loads(public.readFile(self._PLUGIN_PATH + self._SITES))
        for site in self._SITES_DATA:
            length = len(site['path'])
            if len(pathname) < length: continue
            if site['path'] != pathname[:length]: continue
            return site
        return None

    def get_CONFIG(self):
        if self.__CONFIG_DATA: return self.__CONFIG_DATA
        self.__CONFIG_DATA = json.loads(public.readFile(self._PLUGIN_PATH + self.__CONFIG))


    def list_DIR(self, path, siteInfo):  # path 站点路径
        if not os.path.exists(path): return
        lock_files = []
        lock_dirs = []
        explode_a = ['log','logs','cache','templates','template','upload','img','image','images','public','static','js','css','tmp','temp','update','data']
        for name in os.listdir(path):
            try:
                filename = "{}/{}".format(path,name).replace('//','/')
                lower_name = name.lower()
                lower_filename = filename.lower()
                if os.path.isdir(filename): # 是否为目录
                    if lower_name in siteInfo['excludePath']: continue # 是否为排除的文件名
                    if not self.exclude_PATH_OF_SITE(filename,siteInfo['excludePath']): # 是否为排除目录
                        # if not lower_name in explode_a: # 是否为固定不锁定目录
                        #     lock_dirs.append('"' + name + '"')
                        self.list_DIR(filename, siteInfo)
                    continue

                if not lower_name in siteInfo['protectExt'] and not lower_filename in siteInfo['protectExt']: # 是否为受保护的文件名或文件全路径
                    if not self.get_EXT_NAME(lower_name) in siteInfo['protectExt']: continue # 是否为受保护文件类型
                
                if lower_filename in siteInfo['excludePath']: continue # 是否为排除文件
                if lower_name in siteInfo['excludePath']: continue # 是否为排除的文件名
                lock_files.append('"'+name+'"')
            except:
                print(public.get_error_info())
        if lock_files:
            os.system("cd {} && chattr +i {} > /dev/null &".format(path,' '.join(lock_files)))
        # if lock_dirs:
        #     os.system("cd {} && chattr +a {}".format(path,' '.join(lock_dirs)))

    def get_EXT_NAME(self, fileName):
        return fileName.split('.')[-1]

    def write_LOG(self, eventType, siteName, pathname):
        dateDay = time.strftime("%Y-%m-%d", time.localtime())
        logPath = self._PLUGIN_PATH + '/sites/' + siteName + '/bt_tamper_proof_total/' + dateDay
        if not os.path.exists(logPath): os.makedirs(logPath)
        logFile = os.path.join(logPath, 'logs.json')
        logVar = [int(time.time()), eventType, pathname]
        fp = open(logFile, 'a+')
        fp.write(json.dumps(logVar) + "\n")
        fp.close()
        logFiles = [
            logPath + '/total.json',
            self._PLUGIN_PATH + '/sites/' + siteName + '/bt_tamper_proof_total/total.json',
            self._PLUGIN_PATH + '/sites/total.json'
        ]

        for totalLogFile in logFiles:
            if not os.path.exists(totalLogFile):
                totalData = {"total": 0, "delete": 0, "create": 0, "modify": 0, "move": 0}
            else:
                dataTmp = public.readFile(totalLogFile)
                if dataTmp:
                    totalData = json.loads(dataTmp)
                else:
                    totalData = {"total": 0, "delete": 0, "create": 0, "modify": 0, "move": 0}

            totalData['total'] += 1
            totalData[eventType] += 1
            public.writeFile(totalLogFile, json.dumps(totalData))

    # 设置.user.ini
    def set_user_ini(self,path,up = 0):
        os.chdir(path)
        useriniPath = path + '/.user.ini'
        if os.path.exists(useriniPath):
            os.system('chattr +i ' + useriniPath)
        for p1 in os.listdir(path):
            try:
                npath = path + '/' + p1
                if not os.path.isdir(npath): continue
                useriniPath = npath + '/.user.ini'
                if os.path.exists(useriniPath): 
                    os.system('chattr +i ' + useriniPath)
                if up < 3: self.set_user_ini(npath, up + 1)
            except: continue
        return True

    def unlock(self,path):
        os.system('chattr -R -i {} &> /dev/null'.format(path))
        os.system('chattr -R -a {} &> /dev/null'.format(path))
        self.set_user_ini(path)
        

    def close(self,reload = False):
        # 解除锁定
        sites = self.get_sites()
        print("")
        print("="*60)
        print("【{}】正在关闭防篡改，请稍候...".format(public.format_date()))
        print("-"*60)
        for siteInfo in sites:
            tip = self._PLUGIN_PATH + '/tips/' + siteInfo['siteName'] + '.pl'
            if not siteInfo['open'] and not os.path.exists(tip): continue
            if reload and siteInfo['open']: continue
            if sys.version_info[0] == 2:
                print("【{}】|-解锁网站[{}]".format(public.format_date(),siteInfo['siteName'])),
            else:
                os.system("echo -e '【{}】|-解锁网站[{}]\c'".format(public.format_date(),siteInfo['siteName']))
                #print("【{}】|-解锁网站[{}]".format(public.format_date(),siteInfo['siteName']),end=" ")
            self.unlock(siteInfo['path'])
            if os.path.exists(tip): os.remove(tip)
            print("\t=> 完成")
        print("-"*60)
        print('|-防篡改已关闭')
        print("="*60)
        #print(">>>>>>>>>>BT-END<<<<<<<<<<")


    # 获取网站配置列表
    def get_sites(self):
        siteconf = self._PLUGIN_PATH + '/sites.json'
        d = public.readFile(siteconf)
        if not os.path.exists(siteconf) or not d:
            public.writeFile(siteconf,"[]")
        data = json.loads(public.readFile(siteconf))

        # 处理多余字段开始 >>>>>>>>>>
        is_write = False
        rm_keys = ['lock','bak_open']
        for i in data:
            i_keys = i.keys()
            if not 'open' in i_keys: i['open'] = False
            for o in rm_keys:
                if o in i_keys:
                    if i[o]: i['open'] = True
                    i.pop(o)
                    is_write = True
        if is_write: public.writeFile(siteconf,json.dumps(data))
        # 处理多余字段结束 <<<<<<<<<<<<<
        return data

    def __enter__(self):
        self.close()

    def __exit__(self,a,b,c):
        self.close()


def run():
    # 初始化inotify对像
    event = MyEventHandler()
    watchManager = pyinotify.WatchManager()
    starttime = time.time()
    mode = pyinotify.IN_CREATE | pyinotify.IN_MOVED_TO

    # 处理网站属性
    sites = event.get_sites()
    print("="*60)
    print("【{}】正在启动防篡改，请稍候...".format(public.format_date()))
    print("-"*60)
    tip_path = event._PLUGIN_PATH + '/tips/'
    if not os.path.exists(tip_path): os.makedirs(tip_path)
    speed_file = event._PLUGIN_PATH + '/speed.pl'
    for siteInfo in sites:
        tip = tip_path + siteInfo['siteName'] + '.pl'
        if not siteInfo['open']: continue
        if sys.version_info[0] == 2:
            print("【{}】|-网站[{}]".format(public.format_date(),siteInfo['siteName'])),
        else:
            os.system("echo -e '【{}】|-网站[{}]\c'".format(public.format_date(),siteInfo['siteName']))
            # print("【{}】|-网站[{}]".format(public.format_date(),siteInfo['siteName']),end=" ")
        public.writeFile(speed_file,"正在处理网站[{}]，请稍候...".format(siteInfo['siteName']))
        if not os.path.exists(tip):
            event.list_DIR(siteInfo['path'], siteInfo)
        try:
            watchManager.add_watch(siteInfo['path'], mode, auto_add=True, rec=True)
        except:
            print(public.get_error_info())
        
        public.writeFile(tip,'1')
        print("\t\t=> 完成")

    #启动服务
    endtime = round(time.time() - starttime,2)
    public.WriteLog(u'防篡改程序', u"网站防篡改服务已成功启动,耗时[%s]秒" % endtime)
    notifier = pyinotify.Notifier(watchManager, event)
    print("-"*60)
    print('|-防篡改服务已启动')
    print("="*60)
    end_tips = ">>>>>>>>>>BT-END<<<<<<<<<<"
    print(end_tips)
    public.writeFile(speed_file,end_tips)
    notifier.loop()
    



if __name__ == '__main__':
    if len(sys.argv) > 1:
        if 'stop' in sys.argv:
            event = MyEventHandler()
            event.close()
        elif 'start' in sys.argv:
            run()
        elif 'unlock' in sys.argv:
            event = MyEventHandler()
            event.unlock(sys.argv[2])
        elif 'reload' in sys.argv:
            event = MyEventHandler()
            event.close(True)
        else:
            print('args error')

    else:
        run()