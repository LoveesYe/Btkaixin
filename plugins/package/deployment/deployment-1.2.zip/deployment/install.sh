#!/bin/bash
PATH=/www/server/panel/pyenv/bin:/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH
install_tmp='/tmp/bt_install.pl'
public_file=/www/server/panel/install/public.sh

Install_deployment()
{
	mkdir -p /www/server/panel/plugin/deployment
	mkdir -p /www/server/panel/plugin/deployment/package
	echo '正在安装脚本文件...' > $install_tmp
	echo '安装完成' > $install_tmp
}

Uninstall_deployment()
{
	rm -rf /www/server/panel/plugin/deployment
}


action=$1
if [ "${1}" == 'install' ];then
	Install_deployment
else
	Uninstall_deployment
fi
