--[[
#-------------------------------------------------------------------
# 宝塔Linux面板
#-------------------------------------------------------------------
# Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
#-------------------------------------------------------------------
# Author: 梁凯强 <1249648969@qq.com>
#-------------------------------------------------------------------

#----------------------
# WAF防火墙 for nginx  body 过滤
#----------------------
]]--
local cpath = "/www/server/btwaf/"
local json = require "cjson"
local headers = ngx.header
local ngx_match = ngx.re.find
local uri = ngx.unescape_uri(ngx.var.uri)
error_rule = nil
function read_file(name)
    fbody = read_file_body(jpath .. name .. '.json')
    if fbody == nil then
        return {}
    end
    return json.decode(fbody)
end


function read_file_body(filename)
   fp = io.open(filename,'r')
   if fp == nil then
        return nil
    end
   fbody = fp:read("*a")
    fp:close()
    if fbody == '' then
        return nil
    end
   return fbody
end

function write_file(filename,body)
   fp = io.open(filename,'w')
   if fp == nil then
        return nil
    end
   fp:write(body)
   fp:flush()
   fp:close()
   return true
end

local config = json.decode(read_file_body(cpath .. 'config.json'))
local site_config = json.decode(read_file_body(cpath .. 'site.json'))

function get_server_name()
   local c_name = ngx.var.server_name
   local my_name = ngx.shared.btwaf:get(c_name)
   if my_name then return my_name end
   local tmp = read_file_body(cpath .. '/domains.json')
   if not tmp then return c_name end
   local domains = json.decode(tmp)
   for _,v in ipairs(domains)
   do
      for _,d_name in ipairs(v['domains'])
      do
         if c_name == d_name then
            ngx.shared.btwaf:set(c_name,v['name'],3600)
            return v['name']
         end
      end
   end
   return c_name
end


function arrlen(arr)
   if not arr then return 0 end
   count = 0
   for _,v in ipairs(arr)
   do
      count = count + 1
   end
   return count
end



function get_body_character_string()
   local char_string=config['body_character_string']
   if not char_string then return false end
   if arrlen(char_string) ==0 then return false end
   if arrlen(char_string) >=1 then return char_string end
   -- body
end



function get_site_character_string(site_config)
   if not site_config then return false end
   local char_string=site_config['body_character_string']
   if not char_string then return false end
   if arrlen(char_string) ==0 then return false end
   if arrlen(char_string) >=1 then return char_string end
   -- body
end


function return_message(status,msg)
   ngx.header.content_type = "application/json;"
   ngx.status = status
   ngx.log(ngx.ERR, "error: ", json.encode(msg))
end


function cc_increase_static()
  local keys = {"pdf","zip","rar","gz"}
  for _,k in ipairs(keys)
  do
    local aa="/?.*\\."..k.."$"
    if ngx_match(uri,aa,"isjo") then
      return true
    end
  end
  return false
end

function check_type()
  if headers["Content-Type"] == nil then return false end
  if string.find(headers["Content-Type"], "text/html") ~= nil or  string.find(headers["Content-Type"], "application/json") ~= nil then
    return true
  end
  return false
end
-- function check_type()
--   if string.find(headers["Content-Type"], "text/html") ~= nil then
--     return true
--   end
--   return false
-- end




function body_btwaf()
   if not check_type() then return false end 
   if cc_increase_static() then return false end
   server_name = string.gsub(get_server_name(),'_','.')
   if not config['open'] or not is_site_config('open') then return false end
   local chunk, eof = ngx.arg[1], ngx.arg[2]
   local buffered = ngx.ctx.buffered
   if not buffered then
        buffered = {}  -- XXX we can use table.new here 
        ngx.ctx.buffered = buffered
   end
   if chunk ~= "" then
       buffered[#buffered + 1] = chunk
       ngx.arg[1] = nil
   end
  if eof then
      local whole = table.concat(buffered)
      ngx.ctx.buffered = nil
           -- 全局匹配模式
      local get_body=get_body_character_string()
      if get_body then
          for __,v in pairs(get_body)
          do 
              for k2,v2 in pairs(v)
                  do
                      if type(k2)=='string' then
                              whole,c1 = string.gsub(whole,k2,v2)
                              if c1 > 0 then ngx.header.content_length = nil end
                      end
                 end
           end
      end
      -- -- 网站单独匹配模式
      if site_config then 
        local site_body=get_site_character_string(site_config[server_name])
        if site_body then
            for __,v in pairs(site_body)
            do 
                   for k2,v2 in pairs(v)
                    do
                        if type(k2)=='string' then
                            ngx.header.content_length = nil
                            whole,c2 = string.gsub(whole,k2,v2)
                            if c2 > 0 then ngx.header.content_length = nil end
                        end
                    end
            end
        end
    end
      ngx.arg[1] = whole
  end

end

body_btwaf()