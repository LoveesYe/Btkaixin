// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.11/esri/copyright.txt for details.
//>>built
define({zoom:"\u7f29\u653e\u81f3",next:"\u4e0b\u4e00\u4e2a\u8981\u7d20",previous:"\u4e0a\u4e00\u4e2a\u8981\u7d20",dock:"\u505c\u9760",undock:"\u672a\u505c\u9760",pageText:"{index}/{total}",selectedFeature:"\u6240\u9009\u8981\u7d20",selectedFeatures:"{total} \u6761\u7ed3\u679c",tooManyFields:"\u6b64\u56fe\u5c42\u7684\u5b57\u6bb5\u8fc7\u591a\uff0c\u67d0\u4e9b\u5b57\u6bb5\u5c06\u4e0d\u4f1a\u663e\u793a\u3002"});