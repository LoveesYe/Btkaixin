#coding: utf-8
#-------------------------------------------------------------------
# 宝塔Linux面板
#-------------------------------------------------------------------
# Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
#-------------------------------------------------------------------
# Author: hwliang<hwl@bt.cn>
#-------------------------------------------------------------------

import sys #line:10
import time #line:11
import os #line:12
import struct #line:13
os .chdir ('/www/server/panel')#line:15
if 'class/'in sys .path :sys .path .insert (0 ,"class/")#line:16
import copy #line:17
try :#line:18
    import pcap #line:19
except ImportError :#line:20
    if os .path .exists ('/usr/bin/apt'):#line:21
        os .system ("apt install libpcap-dev")#line:22
    elif os .path .exists ('/usr/bin/dnf'):#line:23
        os .system ("dnf install libpcap-devel")#line:24
    elif os .path .exists ('/usr/bin/yum'):#line:25
        os .system ("yum install libpcap-devel")#line:26
    os .system ("btpip install pypcap")#line:27
    try :#line:28
        import pcap #line:29
    except ImportError :#line:30
        print ("pypcap module install failed.")#line:31
        sys .exit ()#line:32
class process_network_total :#line:35
    __O0000000000O0O0OO ='logs/process_network_total.pid'#line:36
    __OOO00OOOOO0OO00O0 ={}#line:37
    __O0O0OOOO00O0OO000 ={}#line:38
    __O000O00O00O0O0000 ={}#line:39
    __OO0OO000O00OO0OO0 =0 #line:40
    __OOOO0O000O000O0O0 =0 #line:41
    __OO00OO00O0O0OO00O =0 #line:42
    def start (OO0OO0O0O000O00OO ,timeout =0 ):#line:45
        ""#line:51
        O0OOO00OOOO00O0OO =time .time ()#line:52
        OO0OO0O0O000O00OO .__OO00OO00O0O0OO00O =timeout +O0OOO00OOOO00O0OO #line:53
        OO0OO0O0O000O00OO .__OO0OO000O00OO0OO0 =O0OOO00OOOO00O0OO #line:54
        try :#line:55
            O0OO0OO000O0O00OO =pcap .pcap ()#line:56
            O0OO0OO000O0O00OO .setfilter ('tcp')#line:57
            for O0OO00OOOOOOO00OO ,O00OOO0OOO00000OO in O0OO0OO000O0O00OO :#line:58
                OO0OO0O0O000O00OO .handle_packet (O00OOO0OOO00000OO )#line:59
                if timeout >0 :#line:61
                    if O0OO00OOOOOOO00OO >OO0OO0O0O000O00OO .__OO00OO00O0O0OO00O :#line:62
                        OO0OO0O0O000O00OO .rm_pid_file ()#line:63
                        break #line:64
        except :#line:65
            OO0OO0O0O000O00OO .rm_pid_file ()#line:66
    def handle_packet (OO0O0OOO000O0O00O ,O00O0OO000O0O0OO0 ):#line:68
        ""#line:74
        OO0000OOO0000O0O0 =O00O0OO000O0O0OO0 [14 :34 ]#line:76
        OOO000000000O00OO =OO0000OOO0000O0O0 [12 :16 ]#line:78
        O0OOO0O000OOO000O =OO0000OOO0000O0O0 [16 :20 ]#line:79
        O0000000000O0O0O0 =O00O0OO000O0O0OO0 [34 :36 ]#line:81
        OO00OOO0O0OO000OO =O00O0OO000O0O0OO0 [36 :38 ]#line:82
        OO0OO0O00O000O0O0 =OOO000000000O00OO +b':'+O0000000000O0O0O0 #line:84
        O0OO0O0OO00000O0O =O0OOO0O000OOO000O +b':'+OO00OOO0O0OO000OO #line:85
        O0000OOOOO00O0OO0 =len (O00O0OO000O0O0OO0 )#line:87
        OO0O0OOO000O0O00O .total_net_process (O0OO0O0OO00000O0O ,OO0OO0O00O000O0O0 ,O0000OOOOO00O0OO0 )#line:89
    def total_net_process (O000OOOOOO00O0000 ,O0OOOOO000OO00O0O ,O0O0OOOOOOOOO0OO0 ,OO0OO0O0OOOOOOO00 ):#line:91
        ""#line:99
        O000OOOOOO00O0000 .get_tcp_stat ()#line:100
        OO0O00OO00O0OO00O =None #line:101
        O0O00OOO00O000OO0 =time .time ()#line:102
        if O0OOOOO000OO00O0O in O000OOOOOO00O0000 .__O0O0OOOO00O0OO000 :#line:103
            OO0OO0OO0O0OO0O00 =O000OOOOOO00O0000 .__O0O0OOOO00O0OO000 [O0OOOOO000OO00O0O ]#line:104
            OO0O00OO00O0OO00O ='down'#line:105
        elif O0O0OOOOOOOOO0OO0 in O000OOOOOO00O0000 .__O0O0OOOO00O0OO000 :#line:106
            OO0OO0OO0O0OO0O00 =O000OOOOOO00O0000 .__O0O0OOOO00O0OO000 [O0O0OOOOOOOOO0OO0 ]#line:107
            OO0O00OO00O0OO00O ='up'#line:108
        else :#line:109
            if O0O00OOO00O000OO0 -O000OOOOOO00O0000 .__OO0OO000O00OO0OO0 >3 :#line:110
                O000OOOOOO00O0000 .__OO0OO000O00OO0OO0 =O0O00OOO00O000OO0 #line:111
                O000OOOOOO00O0000 .get_tcp_stat (True )#line:112
                if O0OOOOO000OO00O0O in O000OOOOOO00O0000 .__O0O0OOOO00O0OO000 :#line:113
                    OO0OO0OO0O0OO0O00 =O000OOOOOO00O0000 .__O0O0OOOO00O0OO000 [O0OOOOO000OO00O0O ]#line:114
                    OO0O00OO00O0OO00O ='down'#line:115
                elif O0O0OOOOOOOOO0OO0 in O000OOOOOO00O0000 .__O0O0OOOO00O0OO000 :#line:116
                    OO0OO0OO0O0OO0O00 =O000OOOOOO00O0000 .__O0O0OOOO00O0OO000 [O0O0OOOOOOOOO0OO0 ]#line:117
                    OO0O00OO00O0OO00O ='up'#line:118
        if not OO0O00OO00O0OO00O :return False #line:120
        if not OO0OO0OO0O0OO0O00 :return False #line:121
        if not OO0OO0OO0O0OO0O00 in O000OOOOOO00O0000 .__O000O00O00O0O0000 :#line:122
            O000OOOOOO00O0000 .__O000O00O00O0O0000 [OO0OO0OO0O0OO0O00 ]={}#line:123
            O000OOOOOO00O0000 .__O000O00O00O0O0000 [OO0OO0OO0O0OO0O00 ]['down']=0 #line:124
            O000OOOOOO00O0000 .__O000O00O00O0O0000 [OO0OO0OO0O0OO0O00 ]['up']=0 #line:125
            O000OOOOOO00O0000 .__O000O00O00O0O0000 [OO0OO0OO0O0OO0O00 ]['up_package']=0 #line:126
            O000OOOOOO00O0000 .__O000O00O00O0O0000 [OO0OO0OO0O0OO0O00 ]['down_package']=0 #line:127
        O000OOOOOO00O0000 .__O000O00O00O0O0000 [OO0OO0OO0O0OO0O00 ][OO0O00OO00O0OO00O ]+=OO0OO0O0OOOOOOO00 #line:129
        O000OOOOOO00O0000 .__O000O00O00O0O0000 [OO0OO0OO0O0OO0O00 ][OO0O00OO00O0OO00O +'_package']+=1 #line:130
        if O0O00OOO00O000OO0 -O000OOOOOO00O0000 .__OOOO0O000O000O0O0 >1 :#line:133
            O000OOOOOO00O0000 .__OOOO0O000O000O0O0 =O0O00OOO00O000OO0 #line:134
            O000OOOOOO00O0000 .write_net_process ()#line:135
    def write_net_process (O0O0OOO00O00O00O0 ):#line:137
        ""#line:142
        OOOOOOOO0OO00OOOO ='/dev/shm/bt_net_process'#line:143
        O0O0O0OO0O0OO0OO0 =copy .deepcopy (O0O0OOO00O00O00O0 .__O000O00O00O0O0000 )#line:144
        OOOO0OOOO0OOOOOOO =[]#line:145
        for OOOO0OO0OOO0O0OOO in O0O0O0OO0O0OO0OO0 .keys ():#line:146
            OOOO0OOOO0OOOOOOO .append (str (OOOO0OO0OOO0O0OOO )+" "+str (O0O0O0OO0O0OO0OO0 [OOOO0OO0OOO0O0OOO ]['down'])+" "+str (O0O0O0OO0O0OO0OO0 [OOOO0OO0OOO0O0OOO ]['up'])+" "+str (O0O0O0OO0O0OO0OO0 [OOOO0OO0OOO0O0OOO ]['down_package'])+" "+str (O0O0O0OO0O0OO0OO0 [OOOO0OO0OOO0O0OOO ]['up_package']))#line:147
        OOOOOO0OOOO0OO000 =open (OOOOOOOO0OO00OOOO ,'w+',encoding ='utf-8')#line:149
        OOOOOO0OOOO0OO000 .write ('\n'.join (OOOO0OOOO0OOOOOOO ))#line:150
        OOOOOO0OOOO0OO000 .close ()#line:151
    def hex_to_ip (OOOO00O0OO0OOO000 ,OO0000OOOOOO00O00 ):#line:153
        ""#line:159
        OO0000OOOOOO00O00 ,O0O0O0OO0OOOOO00O =OO0000OOOOOO00O00 .split (':')#line:160
        OOOO0OO0O00O000OO ='.'.join ([str (int (OO0000OOOOOO00O00 [OOO00O0OOO0OO000O :OOO00O0OOO0OO000O +2 ],16 ))for OOO00O0OOO0OO000O in range (0 ,len (OO0000OOOOOO00O00 ),2 )][::-1 ])#line:161
        OO000OO00OO0000O0 =int (O0O0O0OO0OOOOO00O ,16 )#line:162
        return OOOO0OO0O00O000OO ,OO000OO00OO0000O0 #line:163
    def get_tcp_stat (O0OO0O00OOO00O00O ,force =False ):#line:165
        ""#line:171
        if not force and O0OO0O00OOO00O00O .__O0O0OOOO00O0OO000 :return O0OO0O00OOO00O00O .__O0O0OOOO00O0OO000 #line:172
        O0OO0O00OOO00O00O .__O0O0OOOO00O0OO000 ={}#line:173
        O0O00O00O0O0OOO0O ='/proc/net/tcp'#line:174
        O0O0O00O0O0OO0O00 =open (O0O00O00O0O0OOO0O ,'rb')#line:175
        O0O0O0O0000OOO00O =O0O0O00O0O0OO0O00 .read ().decode ('utf-8').split ('\n')#line:176
        O0O0O00O0O0OO0O00 .close ()#line:177
        O0O0O0O0000OOO00O =O0O0O0O0000OOO00O [1 :]#line:178
        if force :O0OO0O00OOO00O00O .get_process_inodes (force )#line:179
        for O00O0O0OO0O000O0O in O0O0O0O0000OOO00O :#line:180
            O0OO0O000000O00O0 =O00O0O0OO0O000O0O .split ()#line:181
            if len (O0OO0O000000O00O0 )<10 :continue #line:182
            OOOOOO00000O000OO =O0OO0O000000O00O0 [9 ]#line:183
            if OOOOOO00000O000OO =='0':continue #line:184
            O0O0O0O0000O0OOOO ,O00000O0OOOOO0000 =O0OO0O00OOO00O00O .hex_to_ip (O0OO0O000000O00O0 [1 ])#line:185
            if O0O0O0O0000O0OOOO =='127.0.0.1':continue #line:186
            O0O0OOO00OOOOO0OO ,O00OO00000OO00O0O =O0OO0O00OOO00O00O .hex_to_ip (O0OO0O000000O00O0 [2 ])#line:187
            if O0O0O0O0000O0OOOO ==O0O0OOO00OOOOO0OO :continue #line:188
            if O0O0OOO00OOOOO0OO =='0.0.0.0':continue #line:189
            O00OO0O000000000O =O0OO0O00OOO00O00O .inode_to_pid (OOOOOO00000O000OO ,force )#line:191
            if not O00OO0O000000000O :continue #line:192
            OO0000OO0OO0000O0 =O0OO0O00OOO00O00O .get_ip_pack (O0O0O0O0000O0OOOO )+b':'+O0OO0O00OOO00O00O .get_port_pack (O00000O0OOOOO0000 )#line:194
            O0OO0O00OOO00O00O .__O0O0OOOO00O0OO000 [OO0000OO0OO0000O0 ]=O00OO0O000000000O #line:195
        return O0OO0O00OOO00O00O .__O0O0OOOO00O0OO000 #line:196
    def get_port_pack (OOO00OO0O0O0OO0O0 ,OO00O00OOOOOO000O ):#line:199
        ""#line:205
        return struct .pack ('H',int (OO00O00OOOOOO000O ))[::-1 ]#line:206
    def get_ip_pack (O00O0000O00OO0OO0 ,OOOOO00O0O0OO0000 ):#line:208
        ""#line:214
        O0O00O0O0000O0O0O =OOOOO00O0O0OO0000 .split ('.')#line:215
        OO0O00OOOOO00O0OO =b''#line:216
        for OOOO00O0O00OOOOO0 in O0O00O0O0000O0O0O :#line:217
            OO0O00OOOOO00O0OO +=struct .pack ('B',int (OOOO00O0O00OOOOO0 ))#line:218
        return OO0O00OOOOO00O0OO #line:219
    def inode_to_pid (O0OOOOOOO0000O0OO ,O0OO0OOO00OO0OOO0 ,force =False ):#line:221
        ""#line:228
        OO00OO0OOOOOOOOO0 =O0OOOOOOO0000O0OO .get_process_inodes ()#line:229
        if O0OO0OOO00OO0OOO0 in OO00OO0OOOOOOOOO0 :#line:230
            return OO00OO0OOOOOOOOO0 [O0OO0OOO00OO0OOO0 ]#line:231
        return None #line:232
    def get_process_inodes (O0OO000000OOOOO00 ,force =False ):#line:234
        ""#line:240
        if not force and O0OO000000OOOOO00 .__OOO00OOOOO0OO00O0 :return O0OO000000OOOOO00 .__OOO00OOOOO0OO00O0 #line:241
        OOO0O0O00O000OOO0 ='/proc'#line:242
        O0OO0O0OOO0O00OO0 ={}#line:243
        for O00O0O000O000O0O0 in os .listdir (OOO0O0O00O000OOO0 ):#line:244
            try :#line:245
                if not O00O0O000O000O0O0 .isdigit ():continue #line:246
                OO00O00O00OO0000O =OOO0O0O00O000OOO0 +'/'+O00O0O000O000O0O0 +'/fd'#line:247
                for O0O00O0O0O00O0OOO in os .listdir (OO00O00O00OO0000O ):#line:248
                    try :#line:249
                        O0O0O0OOOOO0OO0OO =OO00O00O00OO0000O +'/'+O0O00O0O0O00O0OOO #line:250
                        O00O0OO0000OOOO0O =os .readlink (O0O0O0OOOOO0OO0OO )#line:251
                        if O00O0OO0000OOOO0O .startswith ('socket:['):#line:252
                            OO000OOOOOO000OOO =O00O0OO0000OOOO0O [8 :-1 ]#line:253
                            O0OO0O0OOO0O00OO0 [OO000OOOOOO000OOO ]=O00O0O000O000O0O0 #line:254
                    except :#line:255
                        continue #line:256
            except :#line:257
                continue #line:258
        O0OO000000OOOOO00 .__OOO00OOOOO0OO00O0 =O0OO0O0OOO0O00OO0 #line:259
        return O0OO0O0OOO0O00OO0 #line:260
    def get_process_name (OOOO00OO000O00O00 ,O0000O00OO0000OOO ):#line:262
        ""#line:268
        OO000O0O000O000OO ='/proc/'+O0000O00OO0000OOO +'/comm'#line:269
        if not os .path .exists (OO000O0O000O000OO ):return ''#line:270
        OO0OOOO0O000O00O0 =open (OO000O0O000O000OO ,'rb')#line:271
        O0O00OOO0OO0O0O00 =OO0OOOO0O000O00O0 .read ().decode ('utf-8').strip ()#line:272
        OO0OOOO0O000O00O0 .close ()#line:273
        return O0O00OOO0OO0O0O00 #line:274
    def write_pid (OOOO00OOOO00O0O0O ):#line:277
        ""#line:282
        O0000OO0OO0OO0OO0 =os .getpid ()#line:283
        O0O00000OO0OOOOOO =open (OOOO00OOOO00O0O0O .__O0000000000O0O0OO ,'w')#line:284
        O0O00000OO0OOOOOO .write (str (O0000OO0OO0OO0OO0 ))#line:285
        O0O00000OO0OOOOOO .close ()#line:286
    def rm_pid_file (O00O0O000OOO00OOO ):#line:288
        ""#line:293
        if os .path .exists (O00O0O000OOO00OOO .__O0000000000O0O0OO ):#line:294
            os .remove (O00O0O000OOO00OOO .__O0000000000O0O0OO )#line:295
if __name__ =='__main__':#line:297
    if len (sys .argv )>1 :#line:298
        timeout =int (sys .argv [-1 ])#line:299
    else :#line:300
        timeout =0 #line:301
    p =process_network_total ()#line:302
    p .write_pid ()#line:303
    p .start (timeout )