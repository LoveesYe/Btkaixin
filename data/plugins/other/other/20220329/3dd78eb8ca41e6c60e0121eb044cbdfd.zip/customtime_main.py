#!/usr/bin/python3
# coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: xxx <xxxx@qq.com>
# +-------------------------------------------------------------------

# +--------------------------------------------------------------------
# |   宝塔第三方应用开发DEMO
# +--------------------------------------------------------------------
import public
import sys
import os
import json
import time
import io
from datetime import datetime

if sys.version[0:1] == '2':
    import ConfigParser

    # 解决ConfigParser小写问题
    class real_conf(ConfigParser.ConfigParser):
        def __init__(self, defaults=None):
            ConfigParser.ConfigParser.__init__(self, defaults=None)

        def optionxform(self, optionstr):
            return optionstr

if sys.version[0:1] == '3':
    import configparser
    # 解决ConfigParser小写问题

    class real_conf(configparser.ConfigParser):
        def __init__(self, defaults=None):
            configparser.ConfigParser.__init__(self, defaults=None)

        def optionxform(self, optionstr):
            return optionstr
# 设置运行目录
os.chdir("/www/server/panel")

# 添加包引用位置并引用公共包
sys.path.append("class/")

# from common import dict_obj
# get = dict_obj();


# 在非命令行模式下引用面板缓存和session对象
if __name__ != '__main__':
    from BTPanel import cache, session, redirect

    # 设置缓存(超时10秒) cache.set('key',value,10)
    # 获取缓存 cache.get('key')
    # 删除缓存 cache.delete('key')

    # 设置session:  session['key'] = value
    # 获取session:  value = session['key']
    # 删除session:  del(session['key'])


class customtime_main:
    __exe_name = "customtime"
    __plugin_path = "/www/server/panel/plugin/customtime/"
    __config = __plugin_path+"custom/conf/app.ini"
    __config_tmp = __plugin_path+"custom/conf/app_tmp.ini"
    __run_log = __plugin_path+"log/customtime_service.log"
    __service_path = "/etc/init.d/"
    setupPath = "/www/server"
    # 构造方法

    def __init__(self):
        pass

    # 自定义访问权限检查
    # 一但声明此方法，这意味着可以不登录面板的情况下，直接访问此插件，由_check方法来检测是否有访问权限
    # 如果您的插件必需登录后才能访问的话，请不要声明此方法，这可能导致严重的安全漏洞
    # 如果权限验证通过，请返回True,否则返回 False 或 public.returnMsg(False,'失败原因')
    # 示例未登录面板的情况下访问get_logs方法： /demo/get_logs.json  或 /demo/get_logs.html (使用模板)
    # 可通过args.fun获取被请求的方法名称
    # 可通过args.client_ip获取客户IP
    # def _check(self,args):
        # token = '123456'
        # limit_addr = ['192.168.1.2','192.168.1.3']
        # if args.token != token: return public.returnMsg(False,'Token验证失败!')
        # if not args.client_ip in limit_addr: return public.returnMsg(False,'IP访问受限!')
        # return redirect('/login')
        # return True

    # 取当前可用PHP版本
    def GetPHPVersion(self, get):
        phpVersions = ('52', '53', '54', '55',
                       '56', '70', '71', '72', '73', '74')
        httpdVersion = ""
        filename = self.setupPath+'/apache/version.pl'
        if os.path.exists(filename):
            httpdVersion = public.readFile(filename).strip()

        if httpdVersion == '2.2':
            phpVersions = ('52', '53', '54')
        if httpdVersion == '2.4':
            phpVersions = ('53', '54', '55', '56',
                           '70', '71', '72', '73', '74')
        if os.path.exists('/www/server/nginx/sbin/nginx'):
            cfile = '/www/server/nginx/conf/enable-php-00.conf'
            if not os.path.exists(cfile):
                public.writeFile(cfile, '')

        data = []
        for val in phpVersions:
            tmp = {}
            checkPath = self.setupPath+'/php/'+val+'/bin/php'

            if httpdVersion == '2.2':
                checkPath = self.setupPath+'/php/'+val+'/libphp5.so'
            if os.path.exists(checkPath):
                tmp['version'] = val
                tmp['name'] = ''+val

                # 获取当前版本设置时间 如果没有则传当前时间
                tmp['start_date'] = time.strftime(
                    "%Y-%m-%d %H:%M:%S", time.localtime())
                # 获取当前版本运行状态
                conf_data = {}
                try:
                    f = open("%sconf.json" % (self.__plugin_path), 'r')
                    f.close()
                except IOError:
                    f = open("%sconf.json" % (self.__plugin_path), 'w')
                size = os.path.getsize("%sconf.json" % (self.__plugin_path))
                if size != 0:
                    with io.open("%sconf.json" % (self.__plugin_path), 'r', encoding="utf-8") as f:
                        conf_data = json.load(f)

                if val in conf_data and conf_data[val]['status'] == 'start':
                    tmp['status'] = conf_data[val]['status']
                    tmp['start_date'] = conf_data[val]['set_date']
                    tmp['start_realdate'] = conf_data[val]['set_realdate']
                else:
                    tmp['status'] = 'stop'

                # tmp['status'] = public.ExecShell(self.__plugin_path+"btcustomtime %s %s " % ('get_status', val))
                data.append(tmp)

        return data

    # 获取服务状态
    def get_status(self, args):
        PHPVersion_res = []
        PHPVersion = self.GetPHPVersion(self)
        for index in range(len(PHPVersion)):
            # 判断fpm是否运行中

            php_status = public.ExecShell("ps -ef | grep php-fpm-%s | awk '{print 1}'" % (
                PHPVersion[index]['version']))[0][0:1]
            if php_status == '1':
                if PHPVersion[index]['status'] == 'start':
                    PHPVersion[index]['time'] = self.GetPHPTime(
                        self, PHPVersion[index]['version'])
                    # 现在真实时间-设置时真时间=现在虚拟时间-设置时虚拟时间
                    # now_realdate- set_realdate
                    now_realdate = datetime.now()
                    set_realdate = datetime.strptime(
                        PHPVersion[index]['start_realdate'], "%Y-%m-%d %H:%M:%S")

                    # now_date- set_date
                    now_date = datetime.strptime(
                        PHPVersion[index]['time'], "%Y-%m-%d %H:%M:%S")
                    set_date = datetime.strptime(
                        PHPVersion[index]['start_date'], "%Y-%m-%d %H:%M:%S")
                    # 两个时间差，并以秒显示出来
                    real_durn = (now_realdate-set_realdate).seconds
                    fictitious_durn = (now_date-set_date).seconds
                    # 如果真实时间和虚拟时间差大于1分支则判定为服务未启动
                    time_diff = abs(real_durn-fictitious_durn)
                    if time_diff < 60:
                        PHPVersion[index]['status'] = 'start'
                    else:
                        PHPVersion[index]['status'] = 'stop'
                else:
                    PHPVersion[index]['status'] = 'stop'

            PHPVersion[index]['php_status'] = php_status
            PHPVersion_res.append(PHPVersion[index])
        # 查询对应版本的服务文件是否存在

        # PHPVersion_res = public.ExecShell("ps -ef | grep php-fpm-%s | awk '{print 1}'" % (
        #     '72'))[0][0:1]
        return {'PHPVersion': PHPVersion_res}

    def GetPHPTime(self, args, version):
        p_file = '/dev/shm/phptime_'+version+'.php'
        public.writeFile(p_file, '<?php echo date("Y-m-d H:i:s"); ?>')
        phpinfo = public.request_php(
            version, '/phptime_'+version+'.php', p_file, '')
        if os.path.exists(p_file):
            os.remove(p_file)
        return phpinfo.decode()
    # 设置服务状态(启动 停止 重启 重载) [目前用不到用了官方的方法]

    def set_status(self, args):

        php_v = {}
        if not 'status' in args:
            args.status = 'start'
        if not 'check_version' in args:
            args.check_version = 0
        if not 'set_date' in args:
            args.set_date = 0
        # return {'status': args.set_date}
        
        args.status = str(args.status)
        args.check_version = str(args.check_version)
        args.set_date = str(args.set_date)
        args.set_realdate = time.strftime(
            "%Y-%m-%d %H:%M:%S", time.localtime())

        php_v['status'] = args.status
        php_v['set_date'] = args.set_date
        php_v['set_realdate'] = args.set_realdate
        # return {'status': args.set_date}

        size = os.path.getsize("%sconf.json" % (self.__plugin_path))
        if size != 0:
            # if sys.version[0:1] == '2':
                # 写入状态文件
            with io.open("%sconf.json" % (self.__plugin_path), 'r', encoding="utf-8") as f:
                data = json.load(f)
            # if sys.version[0:1] == '3':
            #     with open("%sconf.json" %
            #                 (self.__plugin_path), 'w+',  encoding="utf-8") as f:
            #         data = json.load(f)
                
                # # 设置以utf-8解码模式读取文件，encoding参数必须设置，否则默认以gbk模式读取文件，当文件中包含中文时，会报错
                # f = io.open("%sconf.json" %
                #             (self.__plugin_path), 'w+', encoding='utf-8')
                # return {'status': f}
                # data = json.load(f)
        else:
            data = {}

        data[args.check_version] = php_v

        json_str = json.dumps(data)
        with open("%sconf.json" % (self.__plugin_path), 'w') as json_file:
            json_file.write(json_str)
        
        # return {'status': args.status,'aa':self.__plugin_path+"btcustomtime %s %s %s " % (args.status, args.check_version, args.set_date)}
        run_status=args.status
        args.status = public.ExecShell(
            self.__plugin_path+"btcustomtime %s %s %s " % (args.status, args.check_version, args.set_date))

        return {'status': args.status,'aa':self.__plugin_path+"btcustomtime %s %s %s " % (run_status, args.check_version, args.set_date)}

    def get_sysset(self, args):
        # 生成配置文件副本(正本python2无法操作 很无赖)
        public.ExecShell(self.__plugin_path+"operation.sh cache ")
        # 不同版本引用不同类库处理
        config = real_conf()

        # config.readfp(open(self.__config))

        # 读ini文件
        # conf.read(self.__config, encoding="utf-8")  # python3

        config.read(self.__config_tmp)  # python2
        sysset = {}
        # 获取所有的section
        sections = config.sections()
        for sec in sections:
            item_s = {}
            items = config.items(sec)
            for inx, item in enumerate(items):
                item_s.update({item[0]: item[1]})
            sysset.update({sec: item_s})

        # a = config.get("server","LANDING_PAGE")

        return {'sysset': sysset}
    # 保存设置

    def save_sysset(self, args):
        if not 'callback' in args:
            args.callback = ''
        if not 'sysset' in args:
            args.sysset = {}
        public.ExecShell(self.__plugin_path+"operation.sh cache ")
        sysset = json.loads(args.sysset)
        # 不同版本引用不同类库处理
        config = real_conf()
        config.read(self.__config_tmp)  # python2
        # sysset={}
        # 获取所有的section
        test_output = {}
        # 没有section的
        for sec in sysset:

            if not config.has_section(sec):
                config.add_section(sec)
                pass
            test_output[sec] = {}
            for opt in sysset[sec]:
                test_output[sec][opt.upper()] = str(sysset[sec][opt])
                config.set(sec, opt.upper(), sysset[sec][opt])
                # if not config.has_option(sec,opt.upper()):
                # wconfig.set(sec, opt.upper(), sysset[sec][opt])

        config.write(open(self.__config_tmp, "w"))
        # 从缓存副本覆盖正本
        public.ExecShell(self.__plugin_path+"operation.sh reduction ")

        return public.returnMsg(True, test_output)
    # 清理运行日志

    def clear_runlog(self, args):
        public.ExecShell('cat /dev/null > %s' % self.__run_log)
        return public.returnMsg(True, '清理成功')
    # 获取面板日志列表
    # 传统方式访问get_logs方法：/plugin?action=a&name=demo&s=get_logs
    # 使用动态路由模板输出： /demo/get_logs.html
    # 使用动态路由输出JSON： /demo/get_logs.json

    def get_logs(self, args):
        filename = self.__run_log
        if os.path.isfile(filename):
            # 宝塔封装的 public.ReadFile 不适合读取大文件
            success, failed = public.ExecShell('tail -n 1000 %s' % filename)
            if success.strip() != '':
                return public.returnMsg(True, success.strip())
            return public.returnMsg(True, '暂无运行日志')

    # 读取配置项(插件自身的配置文件)
    # @param key 取指定配置项，若不传则取所有配置[可选]
    # @param force 强制从文件重新读取配置项[可选]
    def __get_config(self, key=None, force=False):
        # 判断是否从文件读取配置
        if not self.__config or force:
            config_file = self.__plugin_path + 'config.json'
            if not os.path.exists(config_file):
                return None
            f_body = public.ReadFile(config_file)
            if not f_body:
                return None
            self.__config = json.loads(f_body)

        # 取指定配置项
        if key:
            if key in self.__config:
                return self.__config[key]
            return None
        return self.__config

    # 设置配置项(插件自身的配置文件)
    # @param key 要被修改或添加的配置项[可选]
    # @param value 配置值[可选]
    def __set_config(self, key=None, value=None):
        # 是否需要初始化配置项
        if not self.__config:
            self.__config = {}

        # 是否需要设置配置值
        if key:
            self.__config[key] = value

        # 写入到配置文件
        config_file = self.__plugin_path + 'config.json'
        public.WriteFile(config_file, json.dumps(self.__config))
        return True
