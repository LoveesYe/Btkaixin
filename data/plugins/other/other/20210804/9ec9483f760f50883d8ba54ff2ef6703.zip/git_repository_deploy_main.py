#!/usr/bin/python
# coding: utf-8

# +--------------------------------------------------------------------
# |   Git远程仓库部署工具
# +-------------------------------------------------------------------
# |   Author: 技术雨 <forxiaoyu@qq.com>
# +--------------------------------------------------------------------

import sys,os,json,string
if sys.version_info[0] == 2:
    reload(sys)
    sys.setdefaultencoding('utf-8')
elif sys.version_info[0] == 3:
    from importlib import reload
    reload(sys)

#设置运行目录
plugin_path = os.path.dirname(os.path.abspath(__file__))
panel_path = os.path.dirname(os.path.dirname(plugin_path))
os.chdir(panel_path)

#添加包引用位置并引用公共包
sys.path.append("class/")
import public,db,time

#在非命令行模式下引用面板缓存和session对象
if __name__ != '__main__':
    from BTPanel import cache,session,redirect

class git_repository_deploy_main:
    __plugin_path = "%s/" % (plugin_path)
    __config = None
    __db_path = "%s/data/git_repository_deploy.db" % (panel_path)
    __deploy_shell_path = "/www/server/git_repository_deploy"
    __web_hooks_shell_path = "%s/web_hooks.py" % (plugin_path)
    __service_shell_path = "/lib/systemd/system/git_repository_deploy.service"

    #构造方法
    def  __init__(self):
        self.__init_config()
        # 修正服务脚本目录
        if not os.path.exists("/lib/systemd/system/"):
            self.__service_shell_path = "/usr"+self.__service_shell_path

    # 初始化配置
    def __init_config(self):
        if self.__config: return
        self.__config = self.__get_config(None,True)

        if not os.path.exists(self.__db_path) or os.path.getsize(self.__db_path) == 0:
            # 初始化数据库
            import db
            sql = db.Sql().dbfile('git_repository_deploy')
            result = sql.fofile(self.__plugin_path+'default.sql')

        if not os.path.exists(self.__deploy_shell_path):
            os.makedirs(self.__deploy_shell_path)

    # 获取数据库对象
    def __table(self,table):
        import db
        return db.Sql().dbfile('git_repository_deploy').table(table)

    # 获取首页
    def get_index(self,args):
        if not 'p' in args: args.p = 1
        if not 'rows' in args: args.rows = 10
        if not 'title' in args: args.title = ''
        args.p = int(args.p)
        args.rows = int(args.rows)
        args.title = public.checkInput(args.title)

        #取网站数量
        count = self.__table('project')
        if args.title != '':
            count = count.where('title like ?','%'+args.title+'%')
        count = count.count()

        #取分页数据
        page_data = public.get_page(count,p=args.p,rows=args.rows,callback='git_repository_deploy.get_index',result='1,2,3,4,5,8')
        #通过 page_data['shift'],page_data['ros']获取数据列表
        site_list = self.__table('project').order('id desc')
        if args.title != '':
            site_list = site_list.where('title like ?','%'+args.title+'%')
        site_list = site_list.limit(page_data['shift']+','+page_data['row']).field('id,title,info,repository,branch,project_path,deploy_shell,webhooks_password,add_time,update_time').select()

        if isinstance(site_list,str):
            return {'code':0,'msg':'系统错误'}

        web_hooks_base_url = 'http://%s:%s/' % (public.GetLocalIp(),self.__get_config('web_hooks_port'))

        #构造返回字典
        data = {'data':site_list,'page':page_data['page'],'title':args.title,'web_hooks_base_url':web_hooks_base_url}
        return {
            "code":1,
            "msg":"操作成功",
            "total":count,
            "data":data
        }

    # 添加项目
    def add_project(self,args):
        if not 'title' in args: args.title = ''
        if not 'info' in args: args.info = ''
        if not 'repository' in args: args.repository = ''
        if not 'branch' in args: args.branch = ''
        if not 'project_path' in args: args.project_path = ''
        if not 'deploy_shell' in args: args.deploy_shell = ''
        if not 'webhooks_password' in args: args.webhooks_password = ''
        args.info = args.info.replace('\r','')
        args.deploy_shell = args.deploy_shell.replace('\r','')

        if not all([args.title,args.repository,args.branch,args.project_path,args.webhooks_password]):
            return {'code':0,'msg':'参数错误'}

        # projectData = self.__table('project').where('title=?',(args.title,)).find()
        # if projectData:
        #     return {'code':0,'msg':'已存在同名项目'}

        now_time = int(time.time())
        data = {
            'title' : args.title,
            'info' : args.info,
            'repository' : args.repository,
            'branch' : args.branch,
            'project_path' : args.project_path,
            'deploy_shell' : args.deploy_shell,
            'webhooks_password' : args.webhooks_password,
            'add_time' : now_time,
            'update_time' : now_time
        }

        result = self.__table('project').insert(data)
        if isinstance(result,int):
            # 写入项目配置文件
            data['id'] = result
            project_config_file = "%s/%s.conf" % (self.__deploy_shell_path,result)
            public.WriteFile(project_config_file,json.dumps(data),mode='w+')

            # 初始化项目
            public.ExecShell('rm -rf %s/.git' % (data['project_path']))
            deploy_init_shell_file = "%s/%s_init.sh" % (self.__deploy_shell_path,result)
            www_home = public.ExecShell("cat /etc/passwd | grep ^www: | awk -F : '{print $6}'")
            if www_home[1] == '':
                www_home = www_home[0].replace('\n','')
            else:
                return {'code':0,'msg':'操作失败：%s' % (www_home[1])}
            deploy_init_shell_default = '''#!/bin/bash
project_path='%s'
repository='%s'
branch='%s'
domain='%s'
www_home='%s'
export HOME=\$www_home
cd \$project_path
if [ -f \$www_home/.ssh/known_hosts ] && [ \`grep -c \$domain \$www_home/.ssh/known_hosts\` -ne '0' ];then
    git clone --no-checkout \$repository .deploy_tmp_path
else
    /usr/bin/expect <<-EOF
set timeout 30
spawn git clone --no-checkout \$repository .deploy_tmp_path
expect \\"*(yes/no*\\" {
    send \\"yes\\n\\"
}
expect eof
EOF
fi
rm -rf .git
/bin/mv -f .deploy_tmp_path/.git .
rm -rf .deploy_tmp_path
git reset --hard origin/\$branch
chown -Rf www:www \$project_path
''' % (data['project_path'],data['repository'],data['branch'],data['repository'].split(":", 1)[0][4:],www_home)
            shellResult = public.ExecShell('echo "%s" > %s && chmod 777 %s && chown www:www %s' % (deploy_init_shell_default,deploy_init_shell_file,deploy_init_shell_file,deploy_init_shell_file))
            # if shellResult[1] != '':
            #     return {'code':0,'msg':shellResult[1]}
            # 初始化仓库
            # status = public.ExecShell('sudo -u www /bin/bash %s' % (deploy_init_shell_file))
            # if status[1] != '':
            #     return {'code':0,'msg':"操作失败：%s" % (status[1])}

            www_home = public.ExecShell("cat /etc/passwd | grep ^www: | awk -F : '{print $6}'")
            if www_home[1] == '':
                www_home = www_home[0].replace('\n','')
            else:
                return {'code':0,'msg':'操作失败：%s' % (www_home[1])}

            # 生成部署脚本
            deploy_shell = data['deploy_shell']
            deploy_shell_file = "%s/%s.sh" % (self.__deploy_shell_path,result)
            deploy_shell_default = '''#!/bin/bash
GitRepository='%s'
DeployPath='%s'
GitBranch='%s'
www_home='%s'
export HOME=\$www_home
export LANG='zh_CN.UTF-8'
cd \$DeployPath
git config pull.rebase false
git reset --hard origin/\$GitBranch
git pull
git checkout -f \$GitBranch
#chown -R www:www \$DeployPath
%s
        ''' % (data['repository'],data['project_path'],data['branch'],www_home,data['deploy_shell'].replace('$','\$'))

            public.ExecShell('echo "%s" > %s && chmod 777 %s && chown www:www %s' % (deploy_shell_default,deploy_shell_file,deploy_shell_file,deploy_shell_file))

            public.ExecShell('chown -R www:www %s && chmod -R 777 %s' % (self.__deploy_shell_path,self.__deploy_shell_path))

            taskName = '代码初始化' + '-' + data['title']
            if self.__getTaskStatus(taskName) != 1:
                return {'code':0,'msg':'仓库代码初始化任务已在队列中'}
            cmd = "sudo -u www /bin/bash %s" % deploy_init_shell_file
            public.M('tasks').add('id, name, type, status, addtime, execstr', (None, '执行[' + taskName + ']', 'execshell', '0', time.strftime('%Y-%m-%d %H:%M:%S'), cmd))
            cache.delete('install_task')
            public.writeFile('/tmp/panelTask.pl', 'True')
            return {'code':1,'msg':'已将代码初始化任务添加到队列'}

            # return {'code':1,'msg':'操作成功','data':{'id':result}}
        else:
            return {'code':0,'msg':'操作失败'}

    # 编辑项目
    def edit_project(self,args):
        if not 'id' in args: args.id = 0
        if not 'title' in args: args.title = ''
        if not 'info' in args: args.info = ''
        if not 'repository' in args: args.repository = ''
        if not 'branch' in args: args.branch = ''
        if not 'project_path' in args: args.project_path = ''
        if not 'deploy_shell' in args: args.deploy_shell = ''
        if not 'webhooks_password' in args: args.webhooks_password = ''
        args.id = int(args.id)
        args.info = args.info.replace('\r','')
        args.deploy_shell = args.deploy_shell.replace('\r','')

        if not all([args.title,args.repository,args.branch,args.project_path,args.webhooks_password]):
            return {'code':0,'msg':'参数错误'}

        projectData = self.__table('project').where('id=?',(args.id,)).find()
        if not projectData:
            return {'code':0,'msg':'项目不存在'}

        # if args.title != projectData['title']:
        #     newProjectData = self.__table('project').where('title=?',(args.title,)).find()
        #     if newProjectData:
        #         return {'code':0,'msg':'已存在同名项目'}

        now_time = int(time.time())
        data = {
            'title' : args.title,
            'info' : args.info,
            'repository' : args.repository,
            'branch' : args.branch,
            'project_path' : args.project_path,
            'deploy_shell' : args.deploy_shell,
            'webhooks_password' : args.webhooks_password,
            'update_time' : now_time
        }

        result = self.__table('project').where('id = ?',(args.id,)).update(data)
        if result:

            # 写入项目配置文件
            data['id'] = projectData['id']
            project_config_file = "%s/%s.conf" % (self.__deploy_shell_path,projectData['id'])
            public.WriteFile(project_config_file,json.dumps(data),mode='w+')

            # 如果部署目录有变更则删除原部署目录的.git文件夹
            if data['project_path'] != projectData['project_path']:
                public.ExecShell('rm -rf %s/.git' % (projectData['project_path']))

            # 初始化项目
            if not os.path.exists(data['project_path']+'/.git') or data['project_path'] != projectData['project_path'] or data['repository'] != projectData['repository'] or data['branch'] != projectData['branch']:
                public.ExecShell('rm -rf %s/.git' % (data['project_path']))
                deploy_init_shell_file = "%s/%s_init.sh" % (self.__deploy_shell_path,projectData['id'])
                www_home = public.ExecShell("cat /etc/passwd | grep ^www: | awk -F : '{print $6}'")
                if www_home[1] == '':
                    www_home = www_home[0].replace('\n','')
                else:
                    return {'code':0,'msg':'操作失败：%s' % (www_home[1])}
                deploy_init_shell_default = '''#!/bin/bash
project_path='%s'
repository='%s'
branch='%s'
domain='%s'
www_home='%s'
export HOME=\$www_home
cd \$project_path
if [ -f \$www_home/.ssh/known_hosts ] && [ \`grep -c \$domain \$www_home/.ssh/known_hosts\` -ne '0' ];then
    git clone --no-checkout \$repository .deploy_tmp_path
else
    /usr/bin/expect <<-EOF
set timeout 30
spawn git clone --no-checkout \$repository .deploy_tmp_path
expect \\"*(yes/no*\\" {
    send \\"yes\\n\\"
}
expect eof
EOF
fi
rm -rf .git
/bin/mv -f .deploy_tmp_path/.git .
rm -rf .deploy_tmp_path
git reset --hard origin/\$branch
chown -Rf www:www \$project_path
''' % (data['project_path'],data['repository'],data['branch'],data['repository'].split(":", 1)[0][4:],www_home)
                shellResult = public.ExecShell('echo "%s" > %s && chmod 777 %s && chown www:www %s' % (deploy_init_shell_default,deploy_init_shell_file,deploy_init_shell_file,deploy_init_shell_file))
                # if shellResult[1] != '':
                #     return {'code':0,'msg':shellResult[1]}
                # 初始化仓库
                # status = public.ExecShell('sudo -u www /bin/bash %s' % (deploy_init_shell_file))
                # if status[1] != '':
                #     return {'code':0,'msg':"操作失败：%s" % (status[1])}
            else:
                deploy_init_shell_file = ''

            www_home = public.ExecShell("cat /etc/passwd | grep ^www: | awk -F : '{print $6}'")
            if www_home[1] == '':
                www_home = www_home[0].replace('\n','')
            else:
                return {'code':0,'msg':'操作失败：%s' % (www_home[1])}

            # 生成部署脚本
            deploy_shell = data['deploy_shell']
            deploy_shell_file = "%s/%s.sh" % (self.__deploy_shell_path,projectData['id'])
            deploy_shell_default = '''#!/bin/bash
GitRepository='%s'
DeployPath='%s'
GitBranch='%s'
www_home='%s'
export HOME=\$www_home
export LANG='zh_CN.UTF-8'
cd \$DeployPath
git config pull.rebase false
git reset --hard origin/\$GitBranch
git pull
git checkout -f \$GitBranch
#chown -R www:www \$DeployPath
%s
        ''' % (data['repository'],data['project_path'],data['branch'],www_home,data['deploy_shell'].replace('$','\$'))

            public.ExecShell('echo "%s" > %s && chmod 777 %s && chown www:www %s' % (deploy_shell_default,deploy_shell_file,deploy_shell_file,deploy_shell_file))

            public.ExecShell('chown -R www:www %s && chmod -R 777 %s' % (self.__deploy_shell_path,self.__deploy_shell_path))

            if deploy_init_shell_file != '':
                taskName = '代码初始化' + '-' + data['title']
                if self.__getTaskStatus(taskName) != 1:
                    return {'code':0,'msg':'仓库代码初始化任务已在队列中'}
                cmd = "sudo -u www /bin/bash %s" % deploy_init_shell_file
                public.M('tasks').add('id, name, type, status, addtime, execstr', (None, '执行[' + taskName + ']', 'execshell', '0', time.strftime('%Y-%m-%d %H:%M:%S'), cmd))
                cache.delete('install_task')
                public.writeFile('/tmp/panelTask.pl', 'True')
                return {'code':1,'msg':'已将代码初始化任务添加到队列'}
            else:
                return {'code':1,'msg':'操作成功','data':{'id':projectData['id']}}
        else:
            return {'code':0,'msg':'操作失败'}

    # 删除项目
    def del_project(self,args):
        if not 'id' in args: args.id = 0
        args.id = int(args.id)

        if args.id == 0:
            return {'code':0,'msg':'参数错误'}

        projectData = self.__table('project').where('id = ?',(args.id,)).find()

        result = self.__table('project').delete(args.id)
        if result:

            # 删除项目配置文件
            project_config_file = "%s/%s.conf" % (self.__deploy_shell_path,projectData['id'])
            if os.path.exists(project_config_file):
                public.ExecShell('rm -rf %s' % (project_config_file))

            # 删除git目录
            if os.path.exists(projectData['project_path']+'/.git'):
                public.ExecShell('rm -rf %s' % (projectData['project_path']+'/.git'))

            # 删除初始化脚本
            deploy_init_shell_file = "%s/%s_init.sh" % (self.__deploy_shell_path,projectData['id'])
            if os.path.exists(deploy_init_shell_file):
                public.ExecShell('rm -rf %s' % (deploy_init_shell_file))

            # 删除部署脚本
            deploy_shell_file = "%s/%s.sh" % (self.__deploy_shell_path,projectData['id'])
            if os.path.exists(deploy_shell_file):
                public.ExecShell('rm -rf %s' % (deploy_shell_file))
            
            return {'code':1,'msg':'操作成功'}
        else:
            return {'code':0,'msg':'操作失败'}

    # 拉取代码
    def pull_code(self,args):
        if not 'id' in args: args.id = 0
        args.id = int(args.id)

        if args.id == 0:
            return {'code':0,'msg':'参数错误'}

        projectData = self.__table('project').where('id = ?',(args.id,)).find()

        deploy_shell_file = "%s/%s.sh" % (self.__deploy_shell_path,projectData['id'])
        if not os.path.exists(deploy_shell_file):
            return {'code':0,'msg':'部署失败'}
        os.system('chmod +x %s' % deploy_shell_file)

        # 执行代码拉取
        # os.system("sudo -u www /bin/bash %s" % deploy_shell_file)

        taskName = '代码拉取' + '-' + projectData['title']
        if self.__getTaskStatus(taskName) != 1:
            return {'code':0,'msg':'仓库代码拉取任务已在队列中'}
        cmd = "sudo -u www /bin/bash %s" % deploy_shell_file
        public.M('tasks').add('id, name, type, status, addtime, execstr', (None, '执行[' + taskName + ']', 'execshell', '0', time.strftime('%Y-%m-%d %H:%M:%S'), cmd))
        cache.delete('install_task')
        public.writeFile('/tmp/panelTask.pl', 'True')
        return {'code':1,'msg':'已将代码拉取任务添加到队列'}

    # 重新初始化仓库
    def re_init(self,args):
        if not 'id' in args: args.id = 0
        args.id = int(args.id)

        if args.id == 0:
            return {'code':0,'msg':'参数错误'}

        projectData = self.__table('project').where('id = ?',(args.id,)).find()

        deploy_init_shell_default = "%s/%s_init.sh" % (self.__deploy_shell_path,projectData['id'])
        if not os.path.exists(deploy_init_shell_default):
            return {'code':0,'msg':'初始化脚本不存在'}
        os.system('chmod +x %s' % deploy_init_shell_default)

        # 执行初始化脚本
        # os.system("sudo -u www /bin/bash %s" % deploy_init_shell_default)
        
        taskName = '代码初始化' + '-' + projectData['title']
        if self.__getTaskStatus(taskName) != 1:
            return {'code':0,'msg':'仓库代码初始化任务已在队列中'}
        cmd = "sudo -u www /bin/bash %s" % deploy_init_shell_default
        public.M('tasks').add('id, name, type, status, addtime, execstr', (None, '执行[' + taskName + ']', 'execshell', '0', time.strftime('%Y-%m-%d %H:%M:%S'), cmd))
        cache.delete('install_task')
        public.writeFile('/tmp/panelTask.pl', 'True')
        return {'code':1,'msg':'已将代码初始化任务添加到队列'}

        # import panelTask
        # t = panelTask.bt_task()
        # result = t.create_task('初始化仓库[' + taskName + '-' + projectData['title'] + ']', 0,cmd)
        # if result :
        #     return {'code':1,'msg':'已将初始化任务添加到队列'}
        # else:
        #     return {'code':0,'msg':'初始化任务添加到队列失败'}

    # 获取任务状态
    def __getTaskStatus(self, taskName):
        result = public.M('tasks').where("status!=?", ('1',)).field('status,name').select()
        status = 1
        for task in result:
            name = public.getStrBetween('[', ']', task['name'])
            if not name:continue
            if name == taskName:
                status = int(task['status'])
        return status

    # 高级设置
    def get_system(self,args):

        web_hooks_service_status = public.ExecShell("systemctl status git_repository_deploy|grep 'Active:'")
        if web_hooks_service_status[1] == '' and 'running' in web_hooks_service_status[0]:
            web_hooks_status = 1
        else:
            web_hooks_status = 0

        www_home = public.ExecShell("cat /etc/passwd | grep ^www: | awk -F : '{print $6}'")
        if www_home[1] == '':
            www_home = www_home[0].replace('\n','')
        else:
            return {'code':0,'msg':'操作失败：%s' % (www_home[1])}

        if os.path.exists("%s/.ssh/id_rsa" % (www_home)) and os.path.exists("%s/.ssh/id_rsa.pub" % (www_home)):
            ssh_key_status = 1
        else:
            ssh_key_status = 0

        return {
            "code":1,
            "msg":"操作成功",
            "data":{
                "web_hooks_status":web_hooks_status,
                "web_hooks_port":self.__get_config('web_hooks_port'),
                "ssh_key_status":ssh_key_status,
            }
        }

    # 高级设置操作
    def get_system_act(self,args):
        if not 'web_hooks_port' in args : args.web_hooks_port = 10800
        args.web_hooks_port = int(args.web_hooks_port)

        if args.web_hooks_port != 0 and int(self.__get_config('web_hooks_port')) != args.web_hooks_port:
            self.__set_config('web_hooks_port',args.web_hooks_port)

            # 启动防火墙
            import firewalls
            firewallObject = firewalls.firewalls()
            from public import dict_obj
            get = dict_obj()
            get.port = str(self.__get_config('web_hooks_port'))
            get.ps = 'Git远程仓库部署工具端口'
            firewallObject.AddAcceptPort(get)

            public.ExecShell('systemctl stop git_repository_deploy')

            if os.path.exists("/usr/local/bin/gunicorn"):
                gunicorn_path = "/usr/local/bin/gunicorn"
            else:
                gunicorn_path = "/usr/bin/gunicorn"
            service_shell='''
[Unit]
Description=git repository deploy daemon
After=syslog.target network.target

[Service]
Restart=always
RestartSec=5
StartLimitInterval=240
StartLimitBurst=40
PrivateTmp=true
WorkingDirectory=%s
ExecStart=%s --preload -w 2 -g www -u www -w 2 -b 0.0.0.0:%s web_hooks:app

[Install]
WantedBy=multi-user.target
''' % (self.__plugin_path,gunicorn_path,self.__get_config('web_hooks_port'))
            public.ExecShell('echo "%s" > %s' % (service_shell,self.__service_shell_path))
            public.ExecShell('systemctl daemon-reload')
            public.ExecShell('systemctl restart git_repository_deploy')
            public.ExecShell('systemctl enable git_repository_deploy')

        return {
            "code":1,
            "msg":"操作成功",
        }

    # 设置服务状态
    def get_service_act(self,args):
        if not 'status' in args : args.status = 1
        args.status = int(args.status)

        if args.status == 1:
            # 启动服务
            serviceInfo = public.ExecShell('systemctl start git_repository_deploy')
        elif args.status == 2:
            # 重启服务
            serviceInfo = public.ExecShell('systemctl restart git_repository_deploy')
        elif args.status == 3:
            # 关闭服务
            serviceInfo = public.ExecShell('systemctl stop git_repository_deploy')
        else:
            # 启动服务
            serviceInfo = public.ExecShell('systemctl start git_repository_deploy')


        if serviceInfo[1] == '':
            return {
                "code":1,
                "msg":"操作成功",
            }
        else:
            return {
                "code":0,
                "msg":"操作失败",
            }

    # 设置公钥
    def get_ssh_key_act(self,args):
        if not 'status' in args : args.status = 1
        args.status = int(args.status)

        returnMsg = {
            "code":0,
            "msg":"操作失败",
            "data":{}
        }

        www_home = public.ExecShell("cat /etc/passwd | grep ^www: | awk -F : '{print $6}'")
        if www_home[1] == '':
            www_home = www_home[0].replace('\n','')
        else:
            returnMsg["msg"] = '操作失败：%s' % (www_home[1])
            return returnMsg

        if args.status == 1:
            # 查看公钥
            if os.path.exists("%s/.ssh/id_rsa.pub" % (www_home)):
                sshInfo = public.ExecShell("cat %s/.ssh/id_rsa.pub" % (www_home))
                if sshInfo[1] == '':
                    returnMsg = {
                        "code":1,
                        "msg":"操作成功",
                        "data":{
                            "pub":sshInfo[0]
                        }
                    }
            else:
                returnMsg["msg"] = "公钥不存在"
        elif args.status == 2:
            # 查看私钥
            if os.path.exists("%s/.ssh/id_rsa" % (www_home)):
                sshInfo = public.ExecShell("cat %s/.ssh/id_rsa" % (www_home))
                if sshInfo[1] == '':
                    returnMsg = {
                        "code":1,
                        "msg":"操作成功",
                        "data":{
                            "pri":sshInfo[0]
                        }
                    }
            else:
                returnMsg["msg"] = "私钥不存在"
        elif args.status == 3:
            # 清楚旧公钥
            public.ExecShell("rm -rf %s/.ssh/id_rsa" % (www_home))
            public.ExecShell("rm -rf %s/.ssh/id_rsa.pub" % (www_home))

            # 生成ssh公私钥
            status = public.ExecShell("sudo -u www ssh-keygen -t rsa -f %s/.ssh/id_rsa -N ''" % (www_home))
            if status[1] != '':
                returnMsg["msg"] = "操作失败：%s" % (status[1])
                return returnMsg
            public.ExecShell("chown -R www:www %s/.ssh" % (www_home))

            returnMsg["code"] = 1
            returnMsg["msg"] = "操作成功"
        elif args.status == 4:
            # 删除ssh公私钥
            if os.path.exists("%s/.ssh/id_rsa" % (www_home)) or os.path.exists("%s/.ssh/id_rsa.pub" % (www_home)):
                public.ExecShell("rm -rf %s/.ssh/id_rsa" % (www_home))
                public.ExecShell("rm -rf %s/.ssh/id_rsa.pub" % (www_home))
            returnMsg["code"] = 1
            returnMsg["msg"] = "操作成功"
        else:
            # 查看公钥
            if os.path.exists("%s/.ssh/id_rsa.pub" % (www_home)):
                sshInfo = public.ExecShell("cat %s/.ssh/id_rsa.pub" % (www_home))
                if sshInfo[1] == '':
                    returnMsg = {
                        "code":1,
                        "msg":"操作成功",
                        "data":{
                            "pub":sshInfo[0]
                        }
                    }
            else:
                returnMsg["msg"] = "公钥不存在"

        return returnMsg

    # 修复插件
    def get_fix(self,args):
        public.ExecShell('pip install flask')
        public.ExecShell("pip install 'gunicorn<20.0.0'")
        public.ExecShell('pip install pyOpenSSL -I')
        self.install()
        return {"code":1,"msg":"修复完成"}

    # 获取服务器信息
    def __get_serverid(self):
        import panelAuth
        auth = panelAuth.panelAuth()
        return auth.create_serverid({})

    # 获取插件购买状态
    def __get_payinfo(self):
        import panelPlugin
        plugin = panelPlugin.panelPlugin()
        state = plugin.getEndDate('git_repository_deploy')
        if state in ['未开通','待支付','已到期']:
            return False
        else:
            return True

    #读取配置项(插件自身的配置文件)
    #@param key 取指定配置项，若不传则取所有配置[可选]
    #@param force 强制从文件重新读取配置项[可选]
    def __get_config(self,key=None,force=False):
        #判断是否从文件读取配置
        if not self.__config or force:
            config_file = self.__plugin_path + 'config.json'
            if not os.path.exists(config_file):
                default = {
                    "web_hooks_port":10800,
                }
                public.writeFile(config_file,json.dumps(default))
            if not os.path.exists(config_file): return None
            f_body = public.ReadFile(config_file)
            if not f_body: return None
            self.__config = json.loads(f_body)

        #取指定配置项
        if key:
            if key in self.__config: return self.__config[key]
            return None
        return self.__config

    #设置配置项(插件自身的配置文件)
    #@param key 要被修改或添加的配置项[可选]
    #@param value 配置值[可选]
    def __set_config(self,key=None,value=None):
        #是否需要初始化配置项
        if not self.__config: self.__config = {}

        #是否需要设置配置值
        if key:
            self.__config[key] = value

        #写入到配置文件
        config_file = self.__plugin_path + 'config.json'
        public.WriteFile(config_file,json.dumps(self.__config))
        return True

    # 获取平台版本
    def __get_platform(self):
        os_type_text = ''
        aptInstalled = public.ExecShell('command -v apt')
        if aptInstalled[0] != '':
            os_type_text = 'Ubuntu'

        yumInstalled = public.ExecShell('command -v yum')
        if yumInstalled[0] != '':
            os_type_text = 'CentOS'

        return os_type_text

    # 【命令行】 - 插件安装
    def install(self):
        import sys
        if sys.version_info[0] == 3 and sys.version_info[1] >= 5:
            public.ExecShell('pip install distro')

        shellInstalled = public.ExecShell('command -v git')
        if shellInstalled[0] == '':
            print('未检测到Git，开始安装Git...')
            platform = self.__get_platform()
            if platform == 'CentOS':
                public.ExecShell('yum install git -y')
            elif platform == 'Ubuntu':
                public.ExecShell('apt install git -y')
            print('Git安装完成')

        expectInstalled = public.ExecShell('command -v expect')
        if expectInstalled[0] == '':
            print('未检测到expect，开始安装expect...')
            platform = self.__get_platform()
            if platform == 'CentOS':
                public.ExecShell('yum install expect -y')
            elif platform == 'Ubuntu':
                public.ExecShell('apt install expect -y')
            print('expect安装完成')

        if not os.path.exists(self.__db_path) or os.path.getsize(self.__db_path) == 0:
            # 初始化数据库
            import db
            sql = db.Sql().dbfile('git_repository_deploy')
            # print(sql)
            result = sql.fofile(self.__plugin_path+'default.sql')
            print(result)

        # 开启无tty执行sudo权限
        public.ExecShell("sed -i 's/^Defaults    requiretty/#Defaults    requiretty/g' /etc/sudoers")

        # 修正git命令
        if not os.path.exists('/usr/bin/git'):
            if os.path.exists('/usr/local/git/bin/git'):
                public.ExecShell("ln -s /usr/local/git/bin/git /usr/bin/git")

        # 生成ssh公私钥
        www_home = public.ExecShell("cat /etc/passwd | grep ^www: | awk -F : '{print $6}'")
        if www_home[1] == '':
            www_home = www_home[0].replace('\n','')
            # 初始化用户目录
            if not os.path.exists(www_home):
                os.makedirs(www_home)
                public.ExecShell("chown -R www:www %s" % (www_home))

            if not os.path.exists("%s/.ssh/id_rsa" % (www_home)) or not os.path.exists("%s/.ssh/id_rsa.pub" % (www_home)):
                # 清楚旧公钥
                public.ExecShell("rm -rf %s/.ssh/id_rsa" % (www_home))
                public.ExecShell("rm -rf %s/.ssh/id_rsa.pub" % (www_home))
                public.ExecShell("sudo -u www ssh-keygen -t rsa -f %s/.ssh/id_rsa -N ''" % (www_home))
            public.ExecShell("chown -R www:www %s/.ssh" % (www_home))

        if os.path.exists("/usr/local/bin/gunicorn"):
            gunicorn_path = "/usr/local/bin/gunicorn"
        elif os.path.exists("/www/server/panel/pyenv/bin/gunicorn"):
            gunicorn_path = "/www/server/panel/pyenv/bin/gunicorn"
        else:
            gunicorn_path = "/usr/bin/gunicorn"
        # 生成服务
        service_shell='''
[Unit]
Description=git repository deploy daemon
After=syslog.target network.target

[Service]
Restart=always
RestartSec=5
StartLimitInterval=240
StartLimitBurst=40
PrivateTmp=true
WorkingDirectory=%s
ExecStart=%s --preload -w 2 -g www -u www -w 2 -b 0.0.0.0:%s web_hooks:app

[Install]
WantedBy=multi-user.target
''' % (self.__plugin_path,gunicorn_path,self.__get_config('web_hooks_port'))
        public.ExecShell('echo "%s" > %s' % (service_shell,self.__service_shell_path))
        public.ExecShell('systemctl daemon-reload')
        public.ExecShell('systemctl restart git_repository_deploy')
        public.ExecShell('systemctl enable git_repository_deploy')

        # 启动防火墙
        import firewalls
        firewallObject = firewalls.firewalls()
        from public import dict_obj
        get = dict_obj()
        get.port = str(self.__get_config('web_hooks_port'))
        get.ps = 'Git远程仓库部署工具端口'
        firewallObject.AddAcceptPort(get)

    # 【命令行】 - 插件卸载
    def uninstall(self):
        # 删除.git文件夹
        site_lists = self.__table('project').field('id,title,info,repository,branch,project_path,deploy_shell,webhooks_password,add_time,update_time').select()
        for site_list in site_lists:
            if os.path.exists("%s/.git" % (site_list['project_path'])):
                public.ExecShell('rm -rf %s/.git' % (site_list['project_path']))

        # 删除数据库文件 
        if os.path.exists(self.__db_path):
            os.remove(self.__db_path)

        # 删除部署脚本
        if os.path.exists(self.__deploy_shell_path):
            public.ExecShell('rm -rf %s' % (self.__deploy_shell_path))

        # 删除服务
        public.ExecShell('systemctl stop git_repository_deploy')
        public.ExecShell('systemctl disable git_repository_deploy')
        public.ExecShell('rm -rf %s' % (self.__service_shell_path))
        public.ExecShell('systemctl daemon-reload')

#在命令行模式下执行
if __name__ == "__main__":

    g = git_repository_deploy_main()
    type = sys.argv[1]

    if type == 'install':
        g.install()
        exit()
    elif type == 'uninstall':
        g.uninstall()
        exit()
