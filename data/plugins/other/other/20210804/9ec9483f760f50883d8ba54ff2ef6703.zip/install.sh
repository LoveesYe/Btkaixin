#!/bin/bash
PATH=/www/server/panel/pyenv/bin:/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH

#配置插件安装目录
install_path=/www/server/panel/plugin/git_repository_deploy

#安装
Install()
{
    
    echo '正在安装...'
    #==================================================================
    #依赖安装开始
    pip install flask
    pip install 'gunicorn<20.0.0'

	pip install cryptography==3.2
    pip install pyOpenSSL

    python ${install_path}'/git_repository_deploy_main.py' install

    #依赖安装结束
    #==================================================================

    echo '================================================'
    echo '安装完成'
}

#卸载
Uninstall()
{
    python ${install_path}'/git_repository_deploy_main.py' uninstall
    rm -rf $install_path
}

#操作判断
if [ "${1}" == 'install' ];then
    Install
elif [ "${1}" == 'uninstall' ];then
    Uninstall
else
    echo 'Error!';
fi
