#!/usr/bin/python
# coding: utf-8
import sys
from WebHooks import app

if __name__ == '__main__':
    port = 10800
    if len(sys.argv) > 1 and int(sys.argv[1]) > 0:
        port = int(sys.argv[1]);
    app.run(host='0.0.0.0',port=port,threaded=True)