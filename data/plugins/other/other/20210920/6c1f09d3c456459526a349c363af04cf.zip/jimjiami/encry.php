<?php
$dir = __DIR__.'/backup';
$nowtime = date('YmdHi');
$longopt = array(
    'files:',
    'key:'
);
$param = getopt('', $longopt);
$files = explode("|",$param['files']);
if (!extension_loaded('bolt')) {
    print_r('fail');
}
$src      = 'src/noti';
$php_blot_key = $param['key'];
$excludes = array('vendor');
$result = [];
$dir_path = "{$dir}/{$nowtime}";

$count = 0;
foreach($files as $k=>$filePath){
    $key = md5($filePath);
    $result[$key] = $filePath;
    $dist_file = "{$dir_path}/{$key}.php";
    $contents = file_get_contents( $filePath );
    if(strpos($contents,'bolt_decrypt')!=false){
        continue;
    }
    if(!file_exists($dir_path)){
        mkdir($dir_path);
    }    
    copy($filePath,$dist_file);
    $prepend = "<?php
    bolt_decrypt( __FILE__ , '$php_blot_key'); return 0;
    ##!!!##";
    $re = '/\<\?php/m';
    preg_match($re, $contents, $matches ); 
    if(!empty($matches[0]) ){
        $contents = preg_replace( $re, '', $contents );
        ##!!!##';
    }
    /*$cipher   = bolt_encrypt( "?> ".$contents, $php_blot_key );*/
    $cipher   = bolt_encrypt( $contents, $php_blot_key );
    //$newFile  = str_replace('ttt', 'eee', $filePath );
    $fp = fopen( $filePath, 'w');
    fwrite($fp, $prepend.$cipher);
    $count++;
    fclose($fp);
    unset( $cipher );
    unset( $contents );    
}
if($count>0){
    file_put_contents("{$dir_path}/{$nowtime}.log",json_encode($result));
}

echo "ok";