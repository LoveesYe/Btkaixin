#!/usr/bin/python
# coding: utf-8
# +-------------------------------------------------------------------
# | 
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: 老俊 <469834662@qq.com>
# +-------------------------------------------------------------------

# +--------------------------------------------------------------------
# |   php文件加密
# +--------------------------------------------------------------------
import public
import sys
import os
import json
import time
import shutil

# 设置运行目录
os.chdir("/www/server/panel")

# 添加包引用位置并引用公共包
sys.path.append("class/")

#from common import dict_obj
#get = dict_obj();


# 在非命令行模式下引用面板缓存和session对象
if __name__ != '__main__':
    from BTPanel import cache, session, redirect

    # 设置缓存(超时10秒) cache.set('key',value,10)
    # 获取缓存 cache.get('key')
    # 删除缓存 cache.delete('key')

    #设置session:  session['key'] = value
    #获取session:  value = session['key']
    # 删除session:  del(session['key'])
class jimjiami_main:
    __plugin_path = "/www/server/panel/plugin/jimjiami/"
    __config = None

    # 构造方法
    def __init__(self):
        pass

    # 自定义访问权限检查
    # 一但声明此方法，这意味着可以不登录面板的情况下，直接访问此插件，由_check方法来检测是否有访问权限
    # 如果您的插件必需登录后才能访问的话，请不要声明此方法，这可能导致严重的安全漏洞
    # 如果权限验证通过，请返回True,否则返回 False 或 public.returnMsg(False,'失败原因')
    # 示例未登录面板的情况下访问get_logs方法： /demo/get_logs.json  或 /demo/get_logs.html (使用模板)
    # 可通过args.fun获取被请求的方法名称
    # 可通过args.client_ip获取客户IP
    # def _check(self, args):
    #     #token = '123456'
    #     #limit_addr = ['192.168.1.2','192.168.1.3']
    #     # if args.token != token: return public.returnMsg(False,'Token验证失败!')
    #     # if not args.client_ip in limit_addr: return public.returnMsg(False,'IP访问受限!')
    #     # return redirect('/login')
    #     return True

    # 访问/demo/index.html时调用的默认方法，需要在templates中有index.html，否则无法正确响应模板
    def index(self, args):
        return self.get_logs(args)
        
    def sites(self, args):
        data = public.M('sites').field('id,name,edate,path,status').order('id desc').select()
        service_id = "35140057a2a45adba50046f8ed8b66a9"
        url = "http://saas.laojunsay.com/btservice/api/isAuth"
        ip = public.GetLocalIp()
        p_data = {'service_id':service_id,'ip':ip}
        authInfo = public.HttpPost(url,p_data,timeout=60)
        auth = json.loads(authInfo)
        #args['version'] = '72'
        #result = self.insertso(args)
        return {'data': data,'auth':auth}

    def insertso(self,args):
        version = args['version']
        ini_path = str(args['ini_path'])
        #web服务器类型
        server_type = public.GetWebServer()
        #服务器类型
        uname = args['os']
        core_path = 'core/linux64/php'+version+'/bolt.so'
        if uname.lower().find('linux')==-1:
            core_path = 'core/win64/ts-php'+version+'/bolt.dll'
        full_path = self.__plugin_path+core_path
        ini_str = 'extension='+full_path
        ini_file = open(ini_path,'r')
        had_config = False
        for line in ini_file.readlines():
            if line.find(ini_str)>-1:
                had_config = True
                break
        ini_file.close()
        if had_config == False:
            with open(ini_path,'a') as wfile:
                wfile.write(ini_str+'\n')
            wfile.close()
        mac_address = public.get_mac_address()
        public.phpReload(version)
        #files = args['files']
        #files = ['/www/server/panel/plugin/jimjiami/ttt.php','/www/server/panel/plugin/jimjiami/ttt2.php']
        #result = self.jiami(version,files)
        thedir = '/Users/mac/plugin/jimjiami/'
        result = self.get_dir_path(thedir)
        return {'data':version,'server_type':server_type,'os':uname,'path':core_path,'full_path':full_path,'is_had':had_config,'ini_path':ini_path,'ini_str':ini_str,'mac_addr':mac_address,'encry_result':result}

    def dirtree(self,args):
        thedir = args['path']+'/'
        rootdir = {'text':'根目录','path':thedir}
        result = self.get_dir_path(thedir)
        rootdir['nodes'] = result
        return {'data':[rootdir]}     
    def encrypting(self,args):
        #return {'data':args}
        siteid = args['siteid']
        key = args['key']
        files = json.loads(args['data'])
        version = args['version']
        ini_path = args['php_ini']
        uname = args['os']
        server_type = public.GetWebServer()
        core_path = 'core/linux64/php'+version+'/jimjiami.so'
        if uname.lower().find('linux')==-1:
            core_path = 'core/win64/ts-php'+version+'/jimjiami.dll'
        full_path = self.__plugin_path+core_path
        ini_str = 'extension='+full_path
        ini_file = open(ini_path,'r')
        had_config = False
        for line in ini_file.readlines():
            if line.find(ini_str)>-1:
                had_config = True
                break
        ini_file.close()
        if had_config == False:
            with open(ini_path,'a') as wfile:
                wfile.write(ini_str+'\n')
            wfile.close()
        #public.phpReload(version)
        
        dist_files = []
        for dis_file in files:
            dist_files.append(dis_file['path'])
        result = self.jiami(version,key,dist_files,siteid)
        return {'data':result}

    def jiami(self,version,key,files,siteid):
        mulu = public.getDate(format='%Y%m%d%H%M')
        backup_dir = self.__plugin_path+"backup/"
        service_id = "35140057a2a45adba50046f8ed8b66a9"
        url = "http://saas.laojunsay.com/btservice/api/jiamiFile"
        ip = public.GetLocalIp()
        result = {}
        fdir = backup_dir+mulu
        if not os.path.exists(fdir):
            os.mkdir(fdir)
        for f in files:
            fpath = f
            fkey = public.md5(fpath)
            #old_source = public.ReadFile(fpath,mode='r')
            #dist_file = "{0}{1}/{2}.php".format(backup_dir,mulu,fkey);
            #saved = public.WriteFile(dist_file,old_source,mode='w+')
            encoder = public.ExecShell("curl -H 'Content-Type:multipart/form-data' -F 'service_id={0}' -F 'mulu={1}' -F 'fpath={2}' -F 'ip={3}' -F 'version={4}' -F 'key={5}' -F 'file=@{6}' {7}".format(service_id,mulu,fpath,ip,version,key,fpath,url))
            new_code = encoder[0]
            public.WriteFile(fpath,new_code,mode='w+')
            result[fkey] = fpath
        logFile = "{0}{1}/{2}.log".format(backup_dir,mulu,mulu)
        saved = public.WriteFile(logFile,json.dumps(result),mode='w+')
        return {'msg':"ok"}
        
        
    def confusionAll(self,args):
        siteid = args['siteid']
        key = args['key']
        files = json.loads(args['data'])
        mulu = public.getDate(format='%Y%m%d%H%M')
        backup_dir = self.__plugin_path+"backup/"
        service_id = "35140057a2a45adba50046f8ed8b66a9"
        url = "http://saas.laojunsay.com/btservice/api/encryFile"
        result = {}
        fdir = backup_dir+mulu
        ip = public.GetLocalIp()
        if not os.path.exists(fdir):
            os.mkdir(fdir)
        for f in files:
            fpath = f['path']
            fkey = public.md5(fpath)
            #old_source = public.ReadFile(fpath,mode='r')
            #dist_file = "{0}{1}/{2}.php".format(backup_dir,mulu,fkey);
            #saved = public.WriteFile(dist_file,old_source,mode='w+')
            encoder = public.ExecShell("curl -H 'Content-Type:multipart/form-data' -F 'service_id={0}' -F 'mulu={1}' -F 'fpath={2}' -F 'ip={3}' -F 'file=@{4}' {5}".format(service_id,mulu,fpath,ip,fpath,url))
            new_code = encoder[0]
            public.WriteFile(fpath,new_code,mode='w+')
            result[fkey] = fpath
        logFile = "{0}{1}/{2}.log".format(backup_dir,mulu,mulu)
        saved = public.WriteFile(logFile,json.dumps(result),mode='w+')
        return {'msg':"ok"}

    def dirfiles(self,args):
        path = args['path']
        files = os.listdir(path)
        lists = []
        for f in files:
            file_path = os.path.join(path,f)
            if (f.endswith('.php') and os.path.isfile(file_path)):
                onef = {'name':f,'path':file_path,'selected':False}
                lists.append(onef)
        return {'data':lists}

    def get_files(self,dir):
        lists = []
        for fpath,dirs,files in os.walk(dir,True):
            for f in files:
                if fpath.find('vendor')>-1:
                    continue
                if fpath.find('runtime')>-1:
                    continue
                if fpath.find('.idea')>-1:
                    continue
                if fpath.find('.git')>-1:
                    continue                
                if fpath.lower().find('thinkphp')>-1:
                    continue                                
                if f.endswith('.php'):
                    path = os.path.join(fpath,f)
                    lists.append(path)
        return lists
    def get_dir_path(self,root_path):
        files = os.listdir(root_path)
        dir_list = []
        for dir_file in files:
            dir_file_path = os.path.join(root_path,dir_file)
            if os.path.isdir(dir_file_path):
                if dir_file.find('vendor')>-1:
                    continue
                if dir_file.find('runtime')>-1:
                    continue
                if dir_file.find('.idea')>-1:
                    continue
                if dir_file.find('.git')>-1:
                    continue                
                if dir_file.lower().find('thinkphp')>-1:
                    continue                 
                adir = {'text':dir_file,'path':dir_file_path}
                adir['nodes'] = self.get_dir_path(dir_file_path)
                #adir['children'] = self.get_dir_path(dir_file_path,dir_list)
                if len(adir['nodes'])==0:
                    del adir['nodes']
                dir_list.append(adir)
        return dir_list
    def get_history(self,args):
        backup_dir = self.__plugin_path+"backup/"
        files = os.listdir(backup_dir)
        if not files:
            return
        files = sorted(files,key=lambda x: os.path.getmtime(os.path.join(backup_dir, x)),reverse=True)
        if not 'p' in args:
            args.p = 1
        if not 'rows' in args:
            args.rows = 12
        if not 'callback' in args:
            args.callback = 'get_history'
        args.p = int(args.p)
        args.rows = int(args.rows)

        # 取日志总行数
        count = len(files)
        start = (args.p-1)*args.rows
        end = start+args.rows
        fList = files[start:end]
        page_data = public.get_page(count, args.p, args.rows, args.callback)
        file_list = []
        for row in fList:
            tt = os.path.getmtime(os.path.join(backup_dir, row))
            timeArray = time.localtime(tt)
            thetime = time.strftime("%Y-%m-%d %H:%M:%S",timeArray) 
            file_list.append({'name':row,'time':thetime})
        return {'data': file_list, 'page': page_data['page']}
        
    def hello(self,args):
        return {'why':'why'}
        
    def setPassword(self,args):
        password = args.password
        service_id = "35140057a2a45adba50046f8ed8b66a9"
        url = "http://saas.laojunsay.com/btservice/api/reg"
        ip = public.GetLocalIp()
        p_data = {'service_id':service_id,'ip':ip,'pass':password}
        authInfo = public.HttpPost(url,p_data,timeout=60)
        ret = json.loads(authInfo)        
        return ret
    
    def del_files(self,args):
        if not 'dirname' in args:
            return {'error':1,'msg':'缺少参数'}
        if not 'password' in args:
            return {'error':1,'msg':'缺少参数'}             
        dirname = args.dirname
        password = args.password
        if not self.checkPass(password):
            return {'error':1,'msg':'密码错误'}        
        backup_dir = self.__plugin_path+"backup/"
        dirpath = os.path.join(backup_dir,dirname)
        for root,dirs,files in os.walk(dirpath):
            for name in files:
                os.remove(os.path.join(root,name))
            for name in dirs:
                os.remove(os.path.join(root,name))
        os.rmdir(dirpath)
        return {'error':0,'msg':'删除成功'}
        
    def restore(self, args):
        if not 'dirname' in args:
            return {'error':1,'msg':'缺少参数'}
        if not 'password' in args:
            return {'error':1,'msg':'缺少参数'}            
        dirname = args.dirname
        password = args.password
        if not self.checkPass(password):
            return {'error':1,'msg':'密码错误'}
        backup_dir = self.__plugin_path+"backup/"
        dirpath = os.path.join(backup_dir,dirname)
        filename = dirname+'.log'
        ip = public.GetLocalIp()
        with open(os.path.join(dirpath,filename)) as file_obj:
            files = json.load(file_obj)
            for key in files:
                path = files[key]
                if not self.remoteFetch(ip,dirname,path):
                    ofilename = key + '.php'
                    fromf = os.path.join(dirpath,ofilename)
                    shutil.copyfile(fromf,path)
        return {'error':0,'msg':'还原成功！'}
    # 读取配置项(插件自身的配置文件)
    # @param key 取指定配置项，若不传则取所有配置[可选]
    # @param force 强制从文件重新读取配置项[可选]
    
    def remoteFetch(self,ip,pici,path):
        service_id = "35140057a2a45adba50046f8ed8b66a9"
        url = "http://saas.laojunsay.com/btservice/api/getCode"
        p_data = {'service_id':service_id,'ip':ip,'pici':pici,'path':path}
        ret = public.HttpPost(url,p_data,timeout=60)
        ret = json.loads(ret)
        if ret['info']=='fail':
            return None
        old_source = ret['data']
        saved = public.WriteFile(path,old_source,mode='w+')
        return True
        
        
    def checkPass(self,password):
        ip = public.GetLocalIp()
        service_id = "35140057a2a45adba50046f8ed8b66a9"
        url = "http://saas.laojunsay.com/btservice/api/checkAuth"
        p_data = {'service_id':service_id,'ip':ip,'password':password}
        ret = public.HttpPost(url,p_data,timeout=60)
        ret = json.loads(ret)
        if ret['info']=='fail':
            return None
        return True
        
        
    def __get_config(self, key=None, force=False):
        # 判断是否从文件读取配置
        if not self.__config or force:
            config_file = self.__plugin_path + 'config.json'
            if not os.path.exists(config_file):
                return None
            f_body = public.ReadFile(config_file)
            if not f_body:
                return None
            self.__config = json.loads(f_body)

        # 取指定配置项
        if key:
            if key in self.__config:
                return self.__config[key]
            return None
        return self.__config

    # 设置配置项(插件自身的配置文件)
    # @param key 要被修改或添加的配置项[可选]
    # @param value 配置值[可选]
    def __set_config(self, key=None, value=None):
        # 是否需要初始化配置项
        if not self.__config:
            self.__config = {}

        # 是否需要设置配置值
        if key:
            self.__config[key] = value

        # 写入到配置文件
        config_file = self.__plugin_path + 'config.json'
        public.WriteFile(config_file, json.dumps(self.__config))
        return True
