<?php
//@author 阿修罗<610176732@qq.com>
require 'plugin.php';


class bt_main extends Main {

    public $post;
    public $get;

    public function __construct()
    {
        $this->post = _post();
        $this->get  = _get();
    }


    function get_dir(){
        $dirs =  db()->select('dirs','*');
        echo json_encode($dirs);
        exit;
    }
    function getdirsize(){
        $param = $this->post;
        $dir = $param['dir'];
        $file = new File();
        $size = $file->getDirSize($dir);
        exit($size);
    }
    public function add_dir(){
        try {
            $param = $this->post;
            $system_arr = [
                '/www',
                '/www/wwwroot',
                '/etc',
                'D:\BtSoft',
                'D:/BtSoft',
                'C:/BtSoft',
                'C:\BtSoft',
                'F:/BtSoft',
                'F:\BtSoft',
                '/bin',
                '/boot',
                '/data',
                '/home',
                '/opt',
                '/proc',
                '/var',
                '/usr',
                '/sys',
                '/root'
            ];
            $param['file_type'] = trim($param['file_type']);
            $param['path'] = trim($param['path']);
            $param['num'] = trim($param['num']);
            $param['way'] = trim($param['way']);
            if(empty($param['file_type'])){
                throw new \Exception('请设置文件格式');
            }
            if(!is_dir($param['path'])){
                throw new Exception('目录不存在,无法添加!');
            }
            if(empty($param['num'])){
                throw new Exception('请设置文件保留时间');
            }
            if(in_array($param['path'],$system_arr)){
                throw new Exception('为了您的安全,系统根目录无法操作!');
            }
            $res = db()->select('dirs','*',[
                'path'=> $param['path']
            ]);
            if(!empty($res)){
                throw new Exception('目录已经添加过，无法重复添加!');
            }
            db()->insert('dirs',[
                'path'=>$param['path'],
                'file_type'=>$param['file_type'],
                'num'=>$param['num'],
                'create_time'=>date('Y-m-d H:i:s'),
                'way'=>$param['way']
            ]);
            $this->success('success');
        }catch (\Exception $e){
            $this->error($e->getMessage());
        }
    }
    public function getPath(){
        $arr = [
            '71',
            '72',
            '73',
            '74',
            '80'
        ];
        $php_version = '';
        foreach ($arr as $v){
            $cc = PLU_PATH.'/php_cli_'.$v.'.ini';
            if(file_exists($cc)){
                $php_version  =  $v;
                break;
            }
        }
        if(empty($php_version)){
            $this->error('请安装php>=7.1');
        }
//        $php_version_str = substr(PHP_VERSION,0,3);
//        $php_version = str_replace('.','',$php_version_str);
        if(PHP_OS == 'Linux'){
            $os = 'Linux';
            $php_path = PLU_PATH."/../../../php/$php_version/bin/php";
        }else{
            $os = 'windows';
            $php_path = PLU_PATH."/../../../php/$php_version/php.exe";
        }

        $this->success('success',[
            'os'=>$os,
            'path'=>PLU_PATH.'/service.php',
            'dir'=> PLU_PATH,
            'php_path'=>$php_path,
            'shell'=>$php_path." ".PLU_PATH.'/service.php'
        ]);
    }
    function submit_dir()
    {
        try{
            $param = $this->post;
            if(empty($param['path'])  || empty($param['num']) ){
                throw new \Exception('[文件夹路径]和[保留时间]不能为空,请设置]');
            }
            unset($param['client_ip']);
            if(empty($param['file_type'])){
                $param['file_type'] = '全部文件';
            }
            $res =  db()->update('dirs',$param,[
                'id[=]'=>$param['id']
            ]);
            if(!$res){
                throw new \Exception('编辑失败!');
            }
            $this->success('保存成功!',$res);
        }catch (Exception $e){
            $this->error($e->getMessage());
        }
    }
    function get_logs(){
        $param = $this->post;
        $p= $param['p'];
        $pageSize = 6;
        $count = db()->count('log','*');
        if ( isset($param['p']) && $param['p'] >1) {
            $pageVal = $param['p'];
        }else {
            $pageVal = 1;
        }
        $start = ($p-1)*$pageSize;
        $totalPage   = ceil($count/$pageSize);
        $data = db()->select('log','*',[
            'LIMIT' => [$start, $pageSize],
            "ORDER" => [
                'id'=>'DESC'
            ]
        ]);
        $span = '<a class="Pnum" onclick="obj.get_logs(1)" >首页</a>';
        $span .= $this->page($totalPage,$p);
        $span .= '<a class="Pnum" onclick="obj.get_logs('.$totalPage.')" >尾页</a>';
        $span .= '<span class="Pcount">共'.$count.'条</span>';
        $this->success('success',[
            'data'=>$data,
            'page'=>$span
        ]);
    }
    function remove_log(){
        db()->delete('log',[]);
        $this->success('清空成功');
    }
    /**
     * [page description]  分页
     * @param  [type] $sum     [总页数]
     * @param  [type] $pagenum [页数]
     * @return [type]          [description]
     */
    function page($sum,$pagenum){
        $span = "";
        if($sum > 0){
            if($pagenum <=0){$pagenum = 1;}
            if($pagenum >= $sum){$pagenum = $sum;}

            $k = $pagenum-1 <= 0 ? 1:$pagenum-1;
            $m = $sum - 6 <= 0 ?1:$sum-6;
            $pageM = $pagenum == 1?$pagenum+2:$pagenum + 1;

            if($sum - $pagenum >= 6){
                for($i = $k; $i <= $pageM; $i++){
                    $class = $i == $pagenum?'Pcurrent':'Pnum';
                    $span .= '<a class="'.$class.'" onclick="obj.get_logs('.$i.')">'.$i.'</a>';
                }
                $span .= '<a class="Pnum"  >....</a>';
                for($i = $sum - 3; $i <= $sum; $i++){
                    $span .= '<a class="Pnum" onclick="obj.get_logs('.$i.')" >'.$i.'</a>';
                }
            }else{
                for($i = $m; $i <= $sum; $i++){
                    $class = $i == $pagenum?'Pcurrent':'Pnum';
                    $span .= '<a class="'.$class.'" onclick="obj.get_logs('.$i.')">'.$i.'</a>';
                }
            }
        }
        return $span;
    }
    function get_dir_info(){
        $id = $this->post['id'];
        $dir_info  = db()->get('dirs','*',[
            'id'=>$id
        ]);
        $this->success('success',$dir_info);
    }
    function about(){
        try{
            @$json = json_decode(file_get_contents('https://www.waytomilky.com/notice.php'),true);
            $msg  = $json[PLU_NAME]['msg'];
        }catch (Exception $e){
            $msg = '欢迎使用插件!觉得可以的话给个好评哦!';
        }
        $this->success($msg);
    }
    function del_dir()
    {
        $param = $this->post;
        $id = $param['id'];
        db()->delete('dirs',[
            'AND'=>[
                'id'=>$id
            ]
        ]);
        $this->success('success');
    }
}


?>