<?php
require 'vendor/autoload.php';
require 'lib/File.php';
require 'main.php';
use      Medoo\Medoo;
use      GuzzleHttp\Client;

define('DS',DIRECTORY_SEPARATOR);


function db()
{
    return new medoo([
        'database_type' => 'sqlite',
        'database_file' => __DIR__.'/database.db'
    ]);
}