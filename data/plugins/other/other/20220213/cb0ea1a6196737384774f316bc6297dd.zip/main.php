<?php
class Main {
    function __construct()
    {
        define('STATIC_FILE',"/www/server/panel/plugin/linuxsafe/static");
        define('PLUGIN_NAME',"/www/server/panel/plugin/linuxsafe");
    }
    function success($msg = 'success',$data = null){
        $this->json([
            'code'=>1,
            'msg'=>$msg,
            'data'=>$data
        ]);
    }
    //error
    function error($msg){
        $this->json([
            'code'=>2,
            'msg'=>$msg,
        ]);
    }
    //获取json数据jjk
    function json($data){
        echo json_encode($data);
        exit;
    }
    function about(){
        try{
            @$json = json_decode(file_get_contents('https://www.waytomilky.com/notice.php'),true);
            $msg  = $json[PLUGIN_NAME]['msg'];
        }catch (Exception $e){
            $msg = '欢迎使用插件!觉得可以的话给个好评哦!';
        }
        $this->success($msg);
    }
}
