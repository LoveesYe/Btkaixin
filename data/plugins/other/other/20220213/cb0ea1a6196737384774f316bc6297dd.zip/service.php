<?php
//@author 阿修罗<610176732@qq.com>
require 'plugin.php';


class service {
    public  function init(){
        $this->remove_files();
    }
    public function remove_files(){
        try {
            echo '开始执行'.PHP_EOL;
            $dirs = db()->select('dirs','*');
            $fileClass = new File();
            if(empty($dirs)){
                throw new Exception('请配置文件夹');
            }
            $count = 0;
            $size = 0;
            foreach($dirs as $dir){
                if($dir['way'] == 1){
                    $path = $dir['path'];
                    $files = scandir($path);
                    $num = $dir['num'];
                    $limit_time = strtotime("-$num minutes");
                    $ext_arr = explode('#',$dir['file_type']);
                    foreach ($files as $file){
                        if($file == '.' || $file == '..'){
                            continue;
                        }
                        $file_path = $path.DS.$file;
                        $ext = @pathinfo($file_path)['extension'];
                        $ctime = filectime($file_path);
                        if($ctime<$limit_time&&in_array($ext,$ext_arr)){
                            $count++;
                            $size += filesize($file_path);
                            $msg = $fileClass->delFile($file_path);
                            $this->add_log($path,$file_path,$msg);
                            echo '删除'.$file_path.PHP_EOL;
                        }
                    }
                }
                if($dir['way'] == 2){
                    $path = $dir['path'];
                    $files = scandir($path);
                    $num = $dir['num'];
                    $limit_time = strtotime("-$num minutes");
                    $ext_arr = explode('#',$dir['file_type']);
                    $dx =  $this->my_dir($dir['path']);
                    foreach ($dx as $file_path){
                        $ext = pathinfo($file_path)['extension'];
                        $ctime = filectime($file_path);
                        if($ctime<$limit_time&&in_array($ext,$ext_arr)){
                            $count++;
                            $size += filesize($file_path);
                            $msg = $fileClass->delFile($file_path);
                            $this->add_log($path,$file_path,$msg);
                            echo '删除'.$file_path.PHP_EOL;
                        }
                    }
                }
            }
            $file = new File();
            $size =  $file->getRealSize($size);
            echo '共清理'.$count.'条,释放空间'.$size.PHP_EOL;
        }catch (Exception $e){
            echo $e->getMessage();
        }
    }
    function my_dir($dir) {
        $files = array();
        if(@$handle = opendir($dir)) { //注意这里要加一个@，不然会有warning错误提示：）
            while(($file = readdir($handle)) !== false) {
                if($file != ".." && $file != ".") { //排除根目录；
                    if(is_dir($dir.DIRECTORY_SEPARATOR.$file)) { //如果是子文件夹，就进行递归
                        $arr = $this->my_dir($dir.DIRECTORY_SEPARATOR.$file);
                        //$files[$file] = $arr;
                        foreach ($arr as $v){
                            $files[] = $v;
                        }
                    } else { //不然就将文件的名字存入数组；
                        $files[] = $dir.DS.$file;
                    }

                }
            }
            closedir($handle);
            return array_unique($files);
        }
    }
    public function add_log($path,$file,$msg='删除成功')
    {
        db()->insert('log',[
            'path'=>$path,
            'file'=>$file,
            'create_time'=>date('Y-m-d H:i:s'),
            'msg'=>$msg
        ]);
    }
}

$service = new service();
$service->init();