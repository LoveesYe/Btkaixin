//第一次打开窗口时调用
var plugin_name = 'lotusweblog';
var cron_title = '【熊猫日志同步任务】请勿删除';
var load_msg = '读取大量数据中,请耐心等待...';
var load = '';
var modal;
show_log();
//定义窗口尺寸
$('.layui-layer-page').css({ 'width': '1200px' });
//左测菜单切换效果
$(".bt-w-menu p").click(function () {
    $(this).addClass('bgw').siblings().removeClass('bgw')
});
function get_index(){
    var load = layer.msg('加载中，请耐心等待...',{icon:16,time:0});
    request_plugin('index',{},function (rdata) {
        layer.close(load);
        var log_body = '';
        rdata.data.forEach(function (item) {
            log_body += '<tr><td><a target="_blank" href=http://'+item.host+' class="btlink">' + item.host + '</a></td>' +
                '<td><span   title="'+item.log_path+'">' + item.log_path + '</span></td>' +
                '<td>' + item.error_log_path + '</td>' +
                '<td><button data-id="'+item.id+'" data-host="'+item.host+'"  data-log-path="'+item.log_path+'" data-error-log-path="'+item.error_log_path+'"   onclick=edit_web_view(this) class="btn btn-success btn-xs">修改</button></td>  </tr>'
        })
        var plugin_body ='<div class="lotusweblog-table"><div class="divtable">'
            + '<p> <button onclick="show_web()" class="btn btn-sm btn-success">手动添加站点</button>  </p>' +
            '<p> 如果您没有手动修改过任何站点的【apache/nginx】访问日志路径，恭喜您不需要修改路径配置，插件会自动同步站点配置。 </p>' +
            '<p> 当然极个别用户手动修改过个别站点【apache/nginx】日志路径导致无法同步，可以手动添加站点</p>'
            +'<table class="table table-hover">'
            +'<thead>'
            +'<tr><th width="150">站点</th><th>访问日志路径</th><th>错误日志路径</th><th>操作栏</th></tr>'
            +'</thead>'
            +'<tbody>'+ log_body + '</tbody>'
            +'</table>'
            + '</div><div class="page" style="margin-top:15px">' + '' + '</div</div>';
        $('.plugin_body').html(plugin_body);
    })
}
function show_web()
{
    modal = layer.open({
        title:'修改',
        type: 1,
        area: ['600px', '420px'], //宽高
        skin: 'layui-layer-dialog',
        closeBtn: 2,
        content: '<div style="margin-top: 15px;margin-left: 15px" class="u_main layer-modal">' +
            // '<input  name="host_id"  type="hidden"   ></p>' +
            '<p><span class="lg-label">域名</span><input  name="host"  placeholder="必须为本面板的域名哦"  class="bt-input-text"></p>' +
            '<p><span class="lg-label">日志路径</span><input style="width: 400px" placeholder="请输入[日志路径]"   name="log_path" class="bt-input-text"></p>' +
            // '<p><label></label>说明:此路径是sitemap.xml保存的路径,一般是网站的运行目录.</p>' +
            '<p><span class="lg-label">错误日志路径</span><input style="width: 400px" placeholder="请输入[错误日志路径]"   name="error_log_path" class="bt-input-text"></p>' +
            // '<p><span class="lg-label"></span><a class="btlink" target="_blank" href="https://www.waytomilky.com/archives/1950.html">如何获取?</a></p>' +
            '<p><div style="text-align: center"><button class="btn btn-success"   onclick="add_web()">提交</button></div></p>' +
            '</div>'
    });
}
function  add_web()
{
    // var id = $("input[name=host_id]").val();
    var host = $("input[name=host]").val();
    var log_path = $("input[name=log_path]").val();
    var error_log_path = $("input[name=error_log_path]").val();
    var param = {
        host:host,
        log_path:log_path,
        error_log_path:error_log_path
    }
    loading();
    request_plugin('add_web',param,function (rdata) {
        loading_close();
        if(rdata.code === 0){
            close_modal();
            get_index();
        }
        tip(rdata);
    })
}
function show_config()
{
    var plugin_body ='<div class="u_main">' +
        '<p><label class="lg2">存储引擎</label><select name="default" class="bt-input-text"> <option value="plugin_db">本地存储</option> <option value="mysql">启用mysql</option>  </select>   </p>'+
        '<p><label class="lg2">Mysql配置</label> 以下选项非必填 , 由于插件默认是调用本地文件存储 , 如果插件性能不佳的话建议配置mysql数据库配置,可提高性能  </p>' +
        // '<p> (本选项非必填 , 由于插件默认是调用本地文件存储 . 如果插件性能不佳的话建议配置,可提高性能 . 当然如果您的主机性能爆表基本上可以无视此配置,无需填写任何信息.  )</p>' +
        '<p><label class="lg2">数据库</label> <input name="database" placeholder="mysql数据库" class="bt-input-text"></p>'+
        '<p><label class="lg2">用户名</label> <input name="username" class="bt-input-text" placeholder="数据库用户名"></p>'+
        '<p><label class="lg2">密码</label> <input name="password" class="bt-input-text" placeholder="数据库密码"></p>'+
        '<p><label class="lg2"></label><button onclick="save_config()" class="btn">保存</button> </p>'+
        '<p><label class="lg2"></label>注意： 切换数据库后，会重新记录数据哦。建议新建一个本地myql纯净数据库用于存储。<a class="btlink" target="_blank" href="/database">前往新建数据库</p>'+
        '</div> ';
    loading();
    request_plugin('get_db_config',{},function (rdata) {
            loading_close();
            $('.plugin_body').html(plugin_body);
            $("select[name=default]").val(rdata.data.default);
            $("input[name=database]").val(rdata.data.database);
            $("input[name=username]").val(rdata.data.username);
            $("input[name=password]").val(rdata.data.password);
    })
}
function save_config()
{
    var param = {
        default:$("select[name=default]").val(),
        database:$("input[name=database]").val(),
        username:$("input[name=username]").val(),
        password:$("input[name=password]").val()
    }
    loading();
    request_plugin('save_config',param,function (rdata) {
        loading_close();
        tip(rdata,function () {
            show_config();
        });
    })
}
// function open_file(obj)
// {
//     openEditorView(0, $(obj).attr('title'));
// }
function edit_web_view(obj)
{
    var id= $(obj).attr('data-id');
    var host= $(obj).attr('data-host');
    var log_path= $(obj).attr('data-log-path');
    var error_log_path= $(obj).attr('data-error-log-path');
    modal = layer.open({
        title:'修改',
        type: 1,
        area: ['600px', '420px'], //宽高
        skin: 'layui-layer-dialog',
        closeBtn: 2,
        content: '<div style="margin-top: 15px;margin-left: 15px" class="u_main layer-modal">' +
            '<input  name="host_id"  type="hidden"  value="'+id+'" ></p>' +
            '<p><span class="lg-label">域名</span><input  name="host"   value="'+host+'" class="bt-input-text"></p>' +
            '<p><span class="lg-label">日志路径</span><input style="width: 400px" placeholder="请输入[日志路径]" value="'+log_path+'"  name="log_path" class="bt-input-text"></p>' +
            // '<p><label></label>说明:此路径是sitemap.xml保存的路径,一般是网站的运行目录.</p>' +
            '<p><span class="lg-label">错误日志路径</span><input style="width: 400px" placeholder="请输入[错误日志路径]" value="'+error_log_path+'"  name="error_log_path" class="bt-input-text"></p>' +
            // '<p><span class="lg-label"></span><a class="btlink" target="_blank" href="https://www.waytomilky.com/archives/1950.html">如何获取?</a></p>' +
            '<p><div style="text-align: center"><button class="btn btn-success "   onclick="edit_web()">提交</button></div></p>' +
            '</div>'
    });
}
function  lotus_show($title,$content,width = 600,height = 450)
{
    modal = layer.open({
        title: $title,
        type: 1,
        area: [width+'px', height+'px'], //宽高
        skin: 'layui-layer-dialog',
        closeBtn: 2,
        content: $content
    });
    return modal;
}
function  tip(res,callback) {
    layer.msg(res.msg,{icon:res.code === 0?1:2,time:res.code === 0?500:3000},callback);
}
function edit_web()
{
    var id = $("input[name=host_id]").val();
    var host = $("input[name=host]").val();
    var log_path = $("input[name=log_path]").val();
    var error_log_path = $("input[name=error_log_path]").val();
    var param = {
        id:id,
        host:host,
        log_path:log_path,
        error_log_path:error_log_path
    }
    loading();
    request_plugin('edit_web',param,function (rdata) {
        loading_close();
        if(rdata.code === 0){
            close_modal();
            get_index();
        }
        tip(rdata);
    })
}
function close_modal()
{
    layer.close(layer.index);
    layer.close(layer.index - 1);
    layer.close(modal);
}
function loading()
{
    loading_close();
    load = layer.load();
}
function loading_msg()
{
    loading_close();
    load = layer.msg(load_msg,{icon:16,time:0});
}
function loading_close()
{
    layer.close(load);
}
function get_bad()
{
    var plugin_body = "";
}
function show_log()
{
    loading_msg();
    request_plugin('get_web_arr',{},function (rdata) {
       var option = get_web_option(rdata.data.web);
        var option2 = get_bot_option(rdata.data.bot);
       var plugin_body ='<div class="lotusweblog-table u_main"><div class="divtable">'
           +'<p><label>站点</label> <select onchange="fetch_detail()" name="host" class="bt-input-text">'+option+'</select>  &nbsp;&nbsp; ' +
           '<label>时间</label> <input style="width: 100px" name="day" class="day2 bt-input-text">' +
           // '<select onchange="fetch_detail()"  name="day" class="bt-input-text"><option value="1">今日</option><option value="2">昨日</option>  <option value="3">本周</option>  </select>   ' +
           '<label>类型</label><select onchange="fetch_detail()" name="ua_type" class="bt-input-text">'+option2+'</select> &nbsp;' +
           '统计 PV: <b class="pv_all btlink">0</b>&nbsp; UV: <b class="uv_all btlink">0</b>&nbsp; IP: <b class="ip_all btlink">0</b>' +
           '</p>' +
           '<div id="main" style="width: 1000px;height:500px;"></div> ' +
           ' </div> </div> ';
       $('.plugin_body').html(plugin_body);
       show_date('fetch_detail');
       remember_host();
       fetch_detail();
       add_sync_task();
   })
}
function show_date(callback)
{
    moment.locale();
    var today = moment().format('YYYY-MM-DD');
    laydate.render({
        elem: '.day2',
        type: 'date',
        min: -13,
        max: 0,
        value: today ,
        // theme: 'molv',
        done: function(value, date, endDate){
            eval(callback+'()');
        }
    });
}
function remember_host()
{
    var host =     localStorage.getItem('host');
    if(host !== false){
        $("select[name=host]").val(host);
    }
}
function fetch_detail(){
    loading();
    var host = $("select[name=host]").val();
    localStorage.setItem('host',host);
    var param = {
        host:host,
        day:$("input[name=day]").val(),
        ua_type:$("select[name=ua_type]").val()
    }
    // add_sync_task();
    // get_logs();
    request_plugin('fetch_detail',param,function (res) {
        loading_close();
        $('.pv_all').html(res.data.pv_all);
        $('.uv_all').html(res.data.uv_all);
        $('.ip_all').html(res.data.ip_all);
        if(res.data.x.length === 0){
            //如果一直出现此提示,尝试在【插件配置】修改"+host+'域名的日志路径!
            layer.msg("该段时间内记录为空，本插件会自动同步自本插件安装后的日志!",{icon:3,time:5000});
        }
        var myChart = echarts.init(document.getElementById('main'));
        // option = {
        //     title: {
        //         text: host+'站点统计图',
        //         left:'center',
        //         // top:'5%',
        //         // textStyle:{
        //         //     color:'green'
        //         // }
        //     },
        //     tooltip: {
        //         trigger: 'axis'
        //     },
        //     legend: {
        //         data: ['网站访问量']
        //     },
        //     grid: {
        //         left: '3%',
        //         right: '4%',
        //         bottom: '3%',
        //         containLabel: true
        //     },
        //     toolbox: {
        //         show: true,
        //         feature: {
        //             // dataZoom: {
        //             //     yAxisIndex: 'none'
        //             // },
        //             // dataView: {readOnly: true},
        //             magicType: {type: ['line', 'bar']},
        //             // restore: {},
        //             saveAsImage: {}
        //         }
        //     },
        //     xAxis: {
        //         type: 'category',
        //         boundaryGap: false,
        //         data: res.data.x,
        //         axisLabel: { //xAxis，yAxis，axis都有axisLabel属性对象
        //             show: true, //默认为true，设为false后下面都没有意义了
        //             interval: 0, //此处关键， 设置文本标签全部显示
        //             rotate: 60, //标签旋转角度，对于长文本标签设置旋转可避免文本重叠
        //         }
        //     },
        //     yAxis: {
        //         type: 'value'
        //     },
        //     series: [
        //         {
        //             name: '网站pv',
        //             type: 'line',
        //             stack: '总量',
        //             data: res.data.y,
        //             smooth: true,
        //             showSymbol: false,
        //             areaStyle: {
        //                 opacity: 0.6,
        //                 color: '#ef5b9c'
        //             },
        //         },
        //         {
        //             name: '网站uv',
        //             type: 'line',
        //             stack: '总量',
        //             data: res.data.uv,
        //             smooth: true,
        //             showSymbol: false,
        //             areaStyle: {
        //                 opacity: 0.6,
        //                 color: '#45b97c'
        //             },
        //         },
        //         {
        //             name: '网站ip',
        //             type: 'line',
        //             stack: '总量',
        //             data: res.data.ip,
        //             smooth: true,
        //             showSymbol: false,
        //             areaStyle: {
        //                 opacity: 0.6,
        //                 color: '#33a3dc'
        //             },
        //         }
        //     ]
        // };
        option = {
            color: ['#80FFA5', '#FF0087', '#FFBF00'],
            title: {
                text: host+'站点统计图',
                left:'center',
                // textStyle:{
                //     color:'#ccc'
                // }
            },
            tooltip: {
                trigger: 'axis',
                axisPointer: {
                    type: 'cross',
                    label: {
                        backgroundColor: '#6a7985'
                    }
                }
            },
            legend: {
                left:'2.5%',
                data: ['IP', 'UV','PV']
            },
            toolbox: {
                show: true,
                feature: {
                    // dataZoom: {
                    //     yAxisIndex: 'none'
                    // },
                    // dataView: {readOnly: true},
                    magicType: {type: ['line', 'bar']},
                    // restore: {},
                    saveAsImage: {}
                }
            },
            grid: {
                left: '3%',
                right: '4%',
                bottom: '3%',
                containLabel: true
            },
            xAxis: [
                {
                    type: 'category',
                    boundaryGap: false,
                    data: res.data.x
                }
            ],
            yAxis: [
                {
                    type: 'value'
                }
            ],
            series: [
                {
                    name: 'IP',
                    type: 'line',
                    stack: 'Total',
                    smooth: true,
                    lineStyle: {
                        width: 0
                    },
                    showSymbol: true,
                    areaStyle: {
                        opacity: 0.6,
                        color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                            {
                                offset: 0,
                                color: 'rgb(128, 255, 165)'
                            },
                            {
                                offset: 1,
                                color: 'rgb(1, 191, 236)'
                            }
                        ])
                    },
                    emphasis: {
                        focus: 'series'
                    },
                    label: {
                        show: true,
                        position: 'top'
                    },
                    itemStyle : { normal: {label : {show: true}}},
                    data: res.data.ip
                },
                {
                    name: 'UV',
                    type: 'line',
                    stack: 'Total',
                    smooth: true,
                    lineStyle: {
                        width: 0
                    },
                    showSymbol: true,
                    areaStyle: {
                        opacity: 0.6,
                        color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                            {
                                offset: 0,
                                color: 'rgb(255, 0, 135)'
                            },
                            {
                                offset: 1,
                                color: 'rgb(135, 0, 157)'
                            }
                        ])
                    },
                    emphasis: {
                        focus: 'series'
                    },
                    label: {
                        show: true,
                        position: 'top'
                    },
                    itemStyle : { normal: {label : {show: true}}},
                    data: res.data.uv
                },
                {
                    name: 'PV',
                    type: 'line',
                    stack: 'Total',
                    smooth: true,
                    lineStyle: {
                        width: 0
                    },
                    showSymbol: true,
                    areaStyle: {
                        opacity: 0.6,
                        color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                            {
                                offset: 0,
                                color: 'rgb(55, 162, 255)'
                            },
                            {
                                offset: 1,
                                color: 'rgb(116, 21, 219)'
                            }
                        ])
                    },
                    emphasis: {
                        focus: 'series'
                    },
                    label: {
                        show: true,
                        position: 'top'
                    },
                    itemStyle : { normal: {label : {show: true}}},
                    data: res.data.y
                },
            ]
        };
        // 使用刚指定的配置项和数据显示图表。
        myChart.setOption(option);
    })
}
function table_log() {
    request_plugin('get_web_arr',{},function (rdata) {
        var option = get_web_option(rdata.data.web);
        var option2 = get_bot_option(rdata.data.bot);
        var plugin_body = '<div class="u_main">' +
            '<p>' +
            '<label>站点</label><select onchange="get_table_log()" name="host" class="bt-input-text">'+option+'</select> &nbsp;' +
            // '<select onchange="get_table_log()"  name="day" class="bt-input-text"><option value="1">今日</option><option value="2">昨日</option>  <option value="3">本周</option></select>' +
            '<label>时间</label> <input style="width: 100px" name="day" class="day2 bt-input-text">' +
            '<label>类型</label><select onchange="get_table_log()" name="ua_type" class="bt-input-text">'+option2+'</select> &nbsp;' +
            '<label  class="lg">过滤</label><input style="width: 300px" class="bt-input-text" placeholder="ip/method/url/状态码/UserAgent" name="searach_value">' +
            '&nbsp;&nbsp; <button onclick="get_table_log()" class="btn btn-sm btn-success">查询</button>' +
            '&nbsp;&nbsp; <button onclick="export_txt()" class="btn btn-sm btn-success">导出链接</button>' +
            '</p>' +
            '<table class="table"> <thead><tr><th>时间</th><th>请求IP</th><th>Method</th><th>URL</th><th>状态码</th><th>UserAgent</th> <th>工具栏</th> </tr>  </thead> <tbody id="table_log_body">  </tbody>   ' +
            '</table> <div id="table_log_tfoot" class="page pull-right"> </div>  ' +
            '</div>';
        $('.plugin_body').html(plugin_body);
        show_date('get_table_log');
        remember_host();
        get_table_log();
    })
}
function show_ref()
{
    loading();
    request_plugin('get_web_arr',{},function (rdata) {
        var option = get_web_option(rdata.data.web);
        var plugin_body = '<div class="u_main">' +
            '<p>' +
            '<label>站点</label><select onchange="get_ref()" name="host" class="bt-input-text">'+option+'</select> &nbsp;' +
            // '<select onchange="get_ref()"  name="day" class="bt-input-text"><option value="1">今日</option><option value="2">昨日</option>  <option value="3">本周</option></select>' +
            '<label>时间</label> <input style="width: 100px" name="day" class="day2 bt-input-text">' +
            ' &nbsp; <select onchange="get_ref()"  name="http_referer" class="bt-input-text"><option value="1">全部</option><option value="2">仅显示外部来源</option> </select>' +
            '</p>' +
            '<table  class="table table-hover table-bordered"> <thead><tr> <th>来源页面</th> <th style="width: 80px;text-align: center">累计次数</th>  </tr>  </thead> <tbody id="table_log_body1">  </tbody>  </table> ' +
            '</div>';
        $('.plugin_body').html(plugin_body);
        show_date('get_ref')
        remember_host();
        get_ref();
    })
}
function get_ref()
{
    loading();
    var param = {
        host:$("select[name=host]").val(),
        day:$("input[name=day]").val(),
        http_referer:$("select[name=http_referer]").val()
    }
    request_plugin('get_ref',param,function (rdata) {
        loading_close();
        log_body = '';
        rdata.data.ref.forEach(function (item) {
            var http_referer = item.http_referer;
            log_body += "<tr>" +
                "<td> <a target='_blank' class='btlink' href='"+http_referer+"'> "+http_referer+"</a> </td>" +
                "<td style='text-align: center'><b style='color: red'>"+item.times+"</b></td>" +
                "</tr>";
        })
        $('#table_log_body1').html(log_body);
    },'get')
}
function export_txt(){
    var  host = $("select[name=host]").val();
    var  day = $("select[name=day]").val();
    var param = {
        host:host,
        day:day,
        searach_value:$("input[name=searach_value]").val(),
        ua_type:$("select[name=ua_type]").val()
    }
    localStorage.setItem('host',host);
    load_msg =  '1.链接会默认写入站点根目录 <br> 2.如果你想导出死链，您可以筛选状态码404进入导出';
    loading_msg();
    request_plugin('export_txt',param,function (rdata) {
        loading_close();
        console.log(rdata)
        lotus_show('导出链接txt',rdata.data.url)
    },'get')
}
function get_table_log(page = 1)
{
    var load = layer.msg(load_msg,{icon:16,time:0});
    var  host = $("select[name=host]").val();
    var  day = $("input[name=day]").val();
    var param = {
        host:host,
        day:day,
        page:page,
        searach_value:$("input[name=searach_value]").val(),
        ua_type:$("select[name=ua_type]").val()
    }
    localStorage.setItem('host',host);
    request_plugin('get_table_log',param,function (rdata) {
        layer.close(load);
        var log_body = '';
        rdata.data.log.data.forEach(function (item) {
            log_body += "<tr><td>"+item.time_local+"</td><td>"+item.remote_addr+
                "<td>"+item.method+"</td>" +
                "</td><td><span>"+item.url+"</span></td>" +
                "<td>"+item.status+"</td>" +
                "<td>"+item.ua_type+"</td>" +
                "<td> <a href='javascript:void(0)' onclick='detail("+item.id+")'>详情</a>  </td>" +
                "</tr>"
        })
        var paginate =  rdata.data.paginate;
        $('#table_log_body').html(log_body);
        $('#table_log_tfoot').html(paginate);
    },'get')
}
function detail(id)
{
    var param = {
        id:id
    }
    loading();
    request_plugin('get_log_detail',param,function (rdata) {
        console.log(rdata)
        loading_close();
        var info  = rdata.data.info;
        var content = '<div style="margin-top: 10px;margin-left: 10px" class="u_main layer-modal">' +
            '<p><label style="display: inline-block;width: 90px;margin-right: 10px;text-align: right;">域名</label>'+info.host+'</p>' +
            '<p><label style="display: inline-block;width: 90px;margin-right: 10px;text-align: right;">IP</label>'+info.remote_addr+'</p>' +
            '<p><label style="display: inline-block;width: 90px;margin-right: 10px;text-align: right;">时间</label>'+info.time_local+'</p>' +
            '<p><label style="display: inline-block;width: 90px;margin-right: 10px;text-align: right;">Method</label>'+info.method+'</p>' +
            '<p><label style="display: inline-block;width: 90px;margin-right: 10px;text-align: right;">url</label>'+info.url+'</p>' +
            '<p><label style="display: inline-block;width: 90px;margin-right: 10px;text-align: right;">大小</label>'+bytesToSize(info.body_bytes_sent)+'</p>' +
            '<p><label style="display: inline-block;width: 90px;margin-right: 10px;text-align: right;">状态</label>'+info.status+'</p>' +
            '<p><label style="display: inline-block;width: 90px;margin-right: 10px;text-align: right;">UA</label>'+info.http_user_agent+'</p>' +
            '<p><label style="display: inline-block;width: 90px;margin-right: 10px;text-align: right;">UA类型</label>'+info.ua_type+'</p>' +
            '<p><label style="display: inline-block;width: 90px;margin-right: 10px;text-align: right;">来源</label>'+info.http_referer+'</p>' +
            '</div>';
        lotus_show('详情',content,650,600)
    })
}
function bytesToSize(bytes) {
    if (bytes === 0) return '0 B';
    let k = 1024,
        sizes = ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'],
        i = Math.floor(Math.log(bytes) / Math.log(k));
    return (bytes / Math.pow(k, i)). toFixed(2) + ' ' + sizes[i];
}
function  show_bot()
{
    request_plugin('get_web_arr',{},function (rdata) {
        var option = get_web_option(rdata.data.web);
        var plugin_body = '<div class="u_main">' +
            '<p>' +
            '<label>站点</label><select onchange="get_bot()" name="host" class="bt-input-text">'+option+'</select> &nbsp;' +
            '<label>时间</label> <input style="width: 100px" name="day" class="day2 bt-input-text">' +
            // '<select onchange="get_bot()"  name="day" class="bt-input-text"><option value="1">今日</option><option value="2">昨日</option>  <option value="3">本周</option></select>' +
            '</p>' +
            '<div id="main2" style="width: 1000px;height:350px;"></div> ' +
            '<div id="shanxing" style="width: 1000px;height:280px;"></div> ' +
            '</div>';
        $('.plugin_body').html(plugin_body);
        show_date('get_bot');
        remember_host();
        get_bot();
    })
}
function add_sync_task(name)
{
    request_plugin("add_sync_task",{cron_title:cron_title},function (res) {
        if(res.code === 0){
            var shell = res.data.shell;
            //存储域名
            var args = {
                "name":cron_title,
                "type":"minute-n",
                "where1":1,
                "hour":"",
                "minute": "",
                "week":"",
                "sType": "toShell",
                "sBody": shell,
                "sName":"",
                "backupTo": "localhost",
                "save":"",
                "urladdress":""
            };
            $.ajax({
                type:'POST',
                url: '/crontab?action=AddCrontab',
                data: args,
                success: function(rdata) {
                    console.log(rdata);
                    //layer.msg(rdata.msg, { icon: rdata.status ? 1 : 2 });
                },
                error: function(ex) {
                    //layer.msg('请求过程发现错误!', { icon: 2 });
                }
            });
        }
    },'get');
}
function get_bot()
{
    var load = layer.msg(load_msg,{icon:16,time:0});
    var  host = $("select[name=host]").val();
    var  day = $("input[name=day]").val();
    localStorage.setItem('host',host);
    var param = {
        host:host,
        day:day
    }
    request_plugin('get_bot',param,function (res) {
        layer.close(load);
        var myChart2 = echarts.init(document.getElementById('main2'));
        var shanxing = echarts.init(document.getElementById('shanxing'));
        option = {
            title: {
                text: host+'爬虫分析',
                left:'center',
                // top:'10%',
                // textStyle:{
                //     color:'#ccc'
                // }
            },
            toolbox: {
                show: true,
                feature: {
                    // dataZoom: {
                    //     yAxisIndex: 'none'
                    // },
                    // dataView: {readOnly: true},
                    magicType: {type: [ 'bar','line']},
                    // restore: {},
                    saveAsImage: {}
                }
            },
            tooltip: {
                trigger: 'axis'
            },
            legend: {
                data: ['网站访问量']
            },
            grid: {
                left: '3%',
                right: '4%',
                bottom: '3%',
                containLabel: true
            },
            xAxis: {
                type: 'category',
                boundaryGap: false,
                data: res.data.x,
                axisLabel: { //xAxis，yAxis，axis都有axisLabel属性对象
                    show: true, //默认为true，设为false后下面都没有意义了
                    interval: 0, //此处关键， 设置文本标签全部显示
                    // rotate: 45, //标签旋转角度，对于长文本标签设置旋转可避免文本重叠
                }
            },
            yAxis: {
                type: 'value'
            },
            series: [
                {
                    name: '爬取次数',
                    type: 'bar',
                    // stack: '总量',
                    data: res.data.y,
                    // itemStyle: {
                    //     normal: {
                    //         // 定制显示（按顺序）
                    //         color: function(params) {
                    //             var colorList = ['#ef5b9c','#f05b72','#bd6758','#1d953f','#45b97c','#90d7ec','#00a6ac','#77787b','#2a5caa'];
                    //             return colorList[params.dataIndex]
                    //         }
                    //     }
                    // }
                    itemStyle: {
                        shadowBlur: 10,
                        shadowOffsetX: 0,
                        shadowColor: 'rgba(0, 0, 0, 0.5)',
                        normal: {label : {show: true}}
                    },
                    label: {
                        show: true,
                        position: 'top'
                    }
                }
            ]
        };
        var options = {
            title: {
                text: '总数据',
                left: 'center'
            },
            tooltip: {
                trigger: 'item'
            },
            legend: {
                orient: 'vertical',
                left: 'right'
            },
            series: [{
                name: '总抓取次数',
                type: 'pie',
                radius: '50%',
                data: res.data.shanxing,
                emphasis: {
                    itemStyle: {
                        shadowBlur: 10,
                        shadowOffsetX: 0,
                        shadowColor: 'rgba(0, 0, 0, 0.5)'
                    }
                }
            }]
    };
        // 使用刚指定的配置项和数据显示图表。
        myChart2.setOption(option);
        shanxing.setOption(options);
    },'get')
}
function page()
{
    $(".pagination li>a").each(function (item,element) {
        console.log(element);
        var href =  $(element).attr('href');
        href = href.split("=")[1];
        $(element).attr('href',"javascript:get_table_log("+href+");");
    })
}
function get_web_option(web_list,op =  true)
{
    var option = '';
    if(op){
        option = '<option>请选择站点</option>';
    }
    web_list.forEach(function (item) {
        option += '<option>'+item.host+'</option>';
    })
    return option;
}
function get_bot_option(web_list)
{
    var option = '<option value="">全部请求</option> <option value="all_brower">浏览器访问</option>  <option value="all_spider">全部爬虫</option>';
    web_list.forEach(function (item) {
        option += '<option value="'+item.name+'">'+item.alias+'</option>';
    })
    return option;
}
/**
 * 获取面板日志 废弃
 * @param p 被获取的分页
 */
 function get_logs(p) {
    if (p === undefined) p = 1;
    request_plugin('get_logs', { p: p, callback: 'get_logs' }, function (rdata) {
        var log_body = '';
        for (var i = 0; i < rdata.data.length; i++) {
            log_body += '<tr><td>' + rdata.data[i].addtime + '</td><td><span title="' + rdata.data[i].log + '">' + rdata.data[i].log + '</span></td></tr>'
        }

        var my_body = '<div class="lotusweblog-table"><div class="divtable">'
                    +'<table class="table table-hover">'
                        +'<thead>'
                            +'<tr><th width="150">时间</th><th>详情</th></tr>'
                        +'</thead>'
                        +'<tbody>'+ log_body + '</tbody>'
                    +'</table>'
            + '</div><div class="page" style="margin-top:15px">' + rdata.page + '</div</div>';

        $('.plugin_body').html(my_body);
    });
}
/**
 * 发送请求到插件
 * 注意：除非你知道如何自己构造正确访问插件的ajax，否则建议您使用此方法与后端进行通信
 * @param function_name  要访问的方法名，如：get_logs
 * @param args           传到插件方法中的参数 请传入数组，示例：{p:1,rows:10,callback:"colscript.get_logs"}
 * @param callback       请传入处理函数，响应内容将传入到第一个参数中
 * @param method         请求方法
 */
function request_plugin(function_name, args, callback, method = 'post') {
    if (!method)  method = 'POST';
    $.ajax({
        type:method,
        url: '/plugin?action=a&s=' + function_name + '&name=' + plugin_name,
        data: args,
        timeout:120*1000,
        dataType:'json',
        success: function(rdata) {
            if (!callback) {
                layer.msg(rdata.msg, { icon: rdata.status ? 1 : 2 });
                return;
            }
            return callback(rdata);
        },
        error: function(ex) {
            if (!callback) {
                layer.msg('请求过程发现错误!', { icon: 2 });
                return;
            }
            return callback(ex);
        }
    });
}
function about() {
    msg = "欢迎使用插件,觉得好的话给个好评哦!   <a class='btlink' target='_blank' href='https://www.bt.cn/?invite_code=MV9heHlhemM='>点我领劵享优惠</a>";
        var html =
            "  <div id=\"404_logo\" align=\"center\"><a target='_blank' href='https://www.waytomilky.com/'><img src='https://www.waytomilky.com/usr/uploads/2019/04/2930328315.png'></a></div><br/>\n" +
            "                <div id=\"404_dev\" >\n" +
            "                    <table align=\"left\"  style=\"position:absolute; left:10%\" border=\"0\">\n" +
            "                        <tr ><td>&nbsp;</td></tr>\n" +
            "                        <tr ><td><a target='_blank' href='https://www.waytomilky.com/'>开发人员： 旧雨楼</a></td></tr>\n" +
            "                        <tr ><td>&nbsp;</td></tr>\n" +
            "                        <tr ><td>官方网站： <a target='_blank' class='green' href='https://www.waytomilky.com/'>https://www.waytomilky.com/</a></td></tr>\n" +
            "                        <tr ><td>&nbsp;</td></tr>\n" +
            "                        <tr ><td>QQ群支持：<a target=\"_blank\" href=\"//shang.qq.com/wpa/qunwpa?idkey=289eaf4dfef0cc9220256b90ff502bef467767f6f790b817ce1cbe7658b5b3b3\"><img border=\"0\" src=\"//pub.idqqimg.com/wpa/images/group.png\" alt=\"PHP-LotusAdmin&amp;宝塔插件反\" title=\"PHP-LotusAdmin&amp;宝塔插件反\"></a></td></tr>\n" +
            "                        <tr ><td>&nbsp;</td></tr>\n" +
            "                        <tr ><td><b>使用说明,务必查看:</b></td></tr>\n" +
            "                        <tr ><td>&nbsp;</td></tr>\n" +
            "                        <tr ><td>1、插件运行依赖PHP7.1，不影响网站设置</td></tr>\n" +
            "                        <tr ><td>&nbsp;</td></tr>\n" +
            "                        <tr ><td>2、统计安装插件后的访问记录</td></tr>\n" +
            "                        <tr ><td>&nbsp;</td></tr>\n" +
            "                        <tr ><td><b>开发者公告:</b></td></tr>\n" +
            "                        <tr ><td>&nbsp;</td></tr>\n" +
            "                        <tr ><td>"+msg+"</td></tr>\n" +

            "                    </table>\n" +
            "                </div>\n" +
            "                </div>";

        $('.plugin_body').html(html);
}