<?php   
return [
    'default'=>'plugin_db',
    'hostname'=>'127.0.0.1',
    'database'=>'',
    'username'=>'',
    'password'=>'',
    'type'     => 'mysql',
    'charset'  => 'utf8'
]  ?>';