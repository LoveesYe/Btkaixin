#!/bin/bash
PATH=/www/server/panel/pyenv/bin:/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH

install_path=/www/server/panel/plugin/tencent_cdn

Install()
{
	bash /www/server/panel/plugin/tencent_cdn/scripts/service.sh uninstall
	if [ ! -f "/www/server/panel/pyenv/bin/python" ];then
		if ! [ -x "$(command -v python3)" ]; then
			yum install python3 -y
			echo '安装Python3！成功'
		fi
		pip3 install tencentcloud-sdk-python
	else
        echo '使用宝塔Python3版本，无需安装Python3！'
		/www/server/panel/pyenv/bin/pip install tencentcloud-sdk-python
	fi
	touch /www/server/panel/plugin/tencent_cdn/config/ip.txt
	touch /www/server/panel/plugin/tencent_cdn/config/url.txt
	touch /www/server/panel/plugin/tencent_cdn/logs/main.log
}

Uninstall()
{
	bash /www/server/panel/plugin/tencent_cdn/scripts/service.sh uninstall
	rm -rf $install_path
}

if [ "${1}" == 'install' ];then
	Install
elif [ "${1}" == 'uninstall' ];then
	Uninstall
else
	echo 'Error!';
fi
