#!/usr/bin/python
# coding: utf-8
import os
import json
import time
from tencentcloud.common import credential
from tencentcloud.common.profile.client_profile import ClientProfile
from tencentcloud.common.profile.http_profile import HttpProfile
from tencentcloud.common.exception.tencent_cloud_sdk_exception import TencentCloudSDKException
from tencentcloud.cdn.v20180606 import cdn_client, models

def tencentCloudRequest(secretId, secretKey):
    try:
        cred = credential.Credential(secretId, secretKey)
        httpProfile = HttpProfile()
        httpProfile.endpoint = "cdn.tencentcloudapi.com"
        clientProfile = ClientProfile()
        clientProfile.httpProfile = httpProfile
        client = cdn_client.CdnClient(cred, "", clientProfile)    
    except TencentCloudSDKException as err:
        return False
    return client

def getURLListExceedingThreshold(secretId, secretKey, domain, threshold):
    if(threshold == 0):
        return []
    try:
        client = tencentCloudRequest(secretId, secretKey)
        req = models.ListTopDataRequest()
        params = {
            "StartTime": time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time()-900)),
            "EndTime": time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()),
            "Metric": "url",
            "Filter": "flux",
            "Domains": [ domain ]
        }
        req.from_json_string(json.dumps(params))
        resp = client.ListTopData(req)
        apiReturn = json.loads(resp.to_json_string())
        urlList = []
        if(apiReturn['Data'] != []):
            for item in apiReturn['Data'][0]['DetailData']:
                if(item['Value']/1024/1024 > float(threshold)):
                    urlList.append(item['Name'])
    except TencentCloudSDKException as err:
        return []
    return urlList

def getBannedURLList(secretId, secretKey):
    try:
        client = tencentCloudRequest(secretId, secretKey)

        req = models.GetDisableRecordsRequest()
        params = {
            "StartTime": time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time()-518400)),
            "EndTime": time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()),
            "Limit": 1000
        }
        req.from_json_string(json.dumps(params))

        apiReturn = json.loads(client.GetDisableRecords(req).to_json_string())
        urlList = []
        if(apiReturn['UrlRecordList'] != []):
            for item in apiReturn['UrlRecordList']:
                if(item['Status'] == "disable"):
                    urlList.append(item['RealUrl'])
    except TencentCloudSDKException as err:
        return []
    return urlList

def banURL(secretId, secretKey, url):
    try:
        client = tencentCloudRequest(secretId, secretKey)

        req = models.DisableCachesRequest()
        params = {
            "Urls": [ "https://" + url, "http://" + url ]
        }
        req.from_json_string(json.dumps(params))
        apiReturn = json.loads(client.DisableCaches(req).to_json_string())
        if(apiReturn['CacheOptResult']['FailUrls'] == []):
            return True
        else:
            return False
    except TencentCloudSDKException as err:
        return False
    return True

def urlLogChange(domain, url, status):
    if(os.path.exists('/www/server/panel/plugin/tencent_cdn/logs/' + domain + '.url.json')):
        domainLogs = json.load(open('/www/server/panel/plugin/tencent_cdn/logs/' + domain + '.url.json'))
    else:
        domainLogs = []
    logDataNew = []
    flag = True
    for item in domainLogs:
        if(item['url'] == url):
            flag = False
            item['status'] = status
            item['timestamp'] = time.time()
        logDataNew.append(item)
    if(flag):
        logDict = {
            'url' : url,
            'status': status,
            'timestamp': time.time()
        }
        logDataNew.append(logDict)
    with open('/www/server/panel/plugin/tencent_cdn/logs/' + domain + '.url.json', "w") as f:
        json.dump(logDataNew, f)
    return True

with open('/www/server/panel/plugin/tencent_cdn/config/basic.json', "r") as f:
    configDict = json.loads(f.read())
secretId = configDict['secretId']
secretKey = configDict['secretKey']
whiteURLList = open("/www/server/panel/plugin/tencent_cdn/config/url.txt").read()

while(1):
    with open('/www/server/panel/plugin/tencent_cdn/config/domain.json', "r") as f:
        domainConfig = json.loads(f.read())
    for domain, config in domainConfig.items():
        URLList = getURLListExceedingThreshold(secretId, secretKey, domain, config['threshold_2'])
        if(URLList != []):
            bannedURLList = getBannedURLList(secretId, secretKey)
            bannedURLListNew = []
            for url in URLList: 
                if((not "http://" + url in bannedURLList) and (not url in whiteURLList)):
                    bannedURLListNew.append(url)
            if(bannedURLListNew != []):
                for url in bannedURLListNew:
                    if(not banURL(secretId, secretKey, url)):
                        with open('/www/server/panel/plugin/tencent_cdn/logs/main.log', "r") as f:
                            mainLog = f.read()
                        if(not url in mainLog):
                            with open('/www/server/panel/plugin/tencent_cdn/logs/main.log', "a") as f:
                                f.write("["+time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()) + "] 封禁URL[" + url + "]出现错误\n")
                    urlLogChange(domain, url, "banned")
    time.sleep(int(configDict['detectionInterval1'])*60)