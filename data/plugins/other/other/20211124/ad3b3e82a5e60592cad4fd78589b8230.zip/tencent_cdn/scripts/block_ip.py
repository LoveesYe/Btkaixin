#!/usr/bin/python
# coding: utf-8
import os
import json
import time
from tencentcloud.common import credential
from tencentcloud.common.profile.client_profile import ClientProfile
from tencentcloud.common.profile.http_profile import HttpProfile
from tencentcloud.common.exception.tencent_cloud_sdk_exception import TencentCloudSDKException
from tencentcloud.cdn.v20180606 import cdn_client, models

def tencentCloudRequest(secretId, secretKey):
    try:
        cred = credential.Credential(secretId, secretKey)
        httpProfile = HttpProfile()
        httpProfile.endpoint = "cdn.tencentcloudapi.com"
        clientProfile = ClientProfile()
        clientProfile.httpProfile = httpProfile
        client = cdn_client.CdnClient(cred, "", clientProfile)    
    except TencentCloudSDKException as err:
        return False
    return client

def getIPListExceedingThreshold(secretId, secretKey, domain, threshold):
    if(threshold == 0):
        return []
    try:
        client = tencentCloudRequest(secretId, secretKey)
        req = models.DescribeTopDataRequest()
        params = {
            "StartTime": time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time()-900)),
            "EndTime": time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()),
            "Metric": "ip",
            "Filter": "flux",
            "Domains": [ domain ],
            "Detail": True
        }
        req.from_json_string(json.dumps(params))
        apiReturn = json.loads(client.DescribeTopData(req).to_json_string())
        ipList = []
        if(apiReturn['Data'] != []):
            for item in apiReturn['Data'][0]['DetailData']:
                if(item['Value']/1024/1024 > float(threshold)):
                    ipList.append(item['Name'])
    except TencentCloudSDKException as err:
        return False
    return ipList

def getDomainIPBlackList(secretId, secretKey, domain):
    try:
        client = tencentCloudRequest(secretId, secretKey)
        req = models.DescribeDomainsConfigRequest()
        params = {
            "Filters": [
                {
                    "Name": "domain",
                    "Value": [ domain ]
                }
            ]
        }
        req.from_json_string(json.dumps(params))
        apiReturn = json.loads(client.DescribeDomainsConfig(req).to_json_string())
        if(apiReturn['Domains'][0]["IpFilter"]["FilterType"] == "blacklist" and apiReturn['Domains'][0]["IpFilter"]["Switch"] == "on"):
            blackIPList = apiReturn['Domains'][0]["IpFilter"]["Filters"]
        else:
            blackIPList = []
    except TencentCloudSDKException as err:
        return []
    return blackIPList

def updateDomainIPBlackList(secretId, secretKey, domain, blackIPList):
    try:
        client = tencentCloudRequest(secretId, secretKey)
        req = models.UpdateDomainConfigRequest()
        params = {
            "Domain": domain,
            "IpFilter": {
                "Switch": "on",
                "FilterType": "blacklist",
                "Filters": blackIPList
            }
        }
        req.from_json_string(json.dumps(params))
        client.UpdateDomainConfig(req)
    except TencentCloudSDKException as err:
        return False
    return True

def blockIPLogWrite(domain, ip):
    if(os.path.exists('/www/server/panel/plugin/tencent_cdn/logs/' + domain + '.ip.json')):
        with open('/www/server/panel/plugin/tencent_cdn/logs/' + domain + '.ip.json', "r") as f:
            logArr = json.loads(f.read())
    else:
        logArr = []
    logDict = {
        'ip' : ip,
        'status': 'banned',
        'timestamp': time.time()
    }
    logArr.append(logDict)
    with open('/www/server/panel/plugin/tencent_cdn/logs/' + domain + '.ip.json', "w") as f:
        json.dump(logArr, f)
    return True

with open('/www/server/panel/plugin/tencent_cdn/config/basic.json', "r") as f:
    configDict = json.loads(f.read())
whiteIPList = open("/www/server/panel/plugin/tencent_cdn/config/ip.txt").read()
secretId = configDict['secretId']
secretKey = configDict['secretKey']
while(1):
    with open('/www/server/panel/plugin/tencent_cdn/config/domain.json', "r") as f:
        domainConfig = json.loads(f.read())
    for domain, config in domainConfig.items():
        ipList = getIPListExceedingThreshold(secretId, secretKey, domain, config['threshold_1'])
        if(ipList != []):
            blackIPListOld  = getDomainIPBlackList(secretId, secretKey, domain)
            blackIPList = getDomainIPBlackList(secretId, secretKey, domain)
            for ip in ipList:
                if((not ip in blackIPList) and (not ip in whiteIPList)):
                    blackIPList.append(ip)
                    blockIPLogWrite(domain, ip)
            if(blackIPList != blackIPListOld):
                updateDomainIPBlackList(secretId, secretKey, domain, blackIPList)
    time.sleep(int(configDict['detectionInterval1'])*60)