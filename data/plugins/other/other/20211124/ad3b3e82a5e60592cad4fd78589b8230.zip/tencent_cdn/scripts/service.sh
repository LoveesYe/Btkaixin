#!/bin/bash

case $1 in
install)
    chmod -Rf 775 /www/server/panel/plugin/tencent_cdn/scripts/*.sh
    chmod -Rf 775 /www/server/panel/plugin/tencent_cdn/scripts/*.py
    if [ -d "/lib/systemd/system" ]; then
        cp /www/server/panel/plugin/tencent_cdn/scripts/service /usr/lib/systemd/system/tencent-cdn.service
        systemctl daemon-reload
        systemctl start tencent-cdn.service
        systemctl enable tencent-cdn.service
    elif [ -d "/etc/init.d" ]; then
        cp /www/server/panel/plugin/tencent_cdn/scripts/init.sh /etc/init.d/tencent_cdn
        chmod -Rf 775 /etc/init.d/tencent_cdn
        chkconfig --add tencent_cdn
        chkconfig --level 2345 tencent_cdn on
        systemctl enable tencent_cdn.service
        /etc/init.d/tencent_cdn start
    fi
    ;;
uninstall)
    if [ -d "/lib/systemd/system" ]; then
        systemctl stop tencent-cdn.service
        systemctl disable tencent-cdn.service
        rm -rf /usr/lib/systemd/system/tencent-cdn.service
        systemctl daemon-reload
    elif [ -d "/etc/init.d" ]; then
        /etc/init.d/tencent_cdn stop
        chkconfig --level 2345 tencent_cdn off
        chkconfig --del tencent_cdn
        systemctl disable tencent_cdn.service
        rm -rf /etc/init.d/tencent_cdn
    fi
    ;;
start)
    if [ ! -f "/www/server/panel/pyenv/bin/python" ]; then
        python3 /www/server/panel/plugin/tencent_cdn/scripts/block_ip.py &
        python3 /www/server/panel/plugin/tencent_cdn/scripts/block_url.py &
        python3 /www/server/panel/plugin/tencent_cdn/scripts/unblock_ip.py &
        python3 /www/server/panel/plugin/tencent_cdn/scripts/unblock_url.py &
        python3 /www/server/panel/plugin/tencent_cdn/scripts/auto_online.py
    else
        /www/server/panel/pyenv/bin/python /www/server/panel/plugin/tencent_cdn/scripts/block_ip.py &
        /www/server/panel/pyenv/bin/python /www/server/panel/plugin/tencent_cdn/scripts/block_url.py &
        /www/server/panel/pyenv/bin/python /www/server/panel/plugin/tencent_cdn/scripts/unblock_ip.py &
        /www/server/panel/pyenv/bin/python /www/server/panel/plugin/tencent_cdn/scripts/unblock_url.py &
        /www/server/panel/pyenv/bin/python /www/server/panel/plugin/tencent_cdn/scripts/auto_online.py
    fi
    ;;
stop)
    kill $(ps -ef | grep "tencent_cdn/scripts/block_ip.py" | grep -v grep | awk '{print $2}')
    kill $(ps -ef | grep "tencent_cdn/scripts/block_url.py" | grep -v grep | awk '{print $2}')
    kill $(ps -ef | grep "tencent_cdn/scripts/unblock_ip.py" | grep -v grep | awk '{print $2}')
    kill $(ps -ef | grep "tencent_cdn/scripts/unblock_url.py" | grep -v grep | awk '{print $2}')
    kill $(ps -ef | grep "tencent_cdn/scripts/auto_online.py" | grep -v grep | awk '{print $2}')
    ;;
esac
