#!/usr/bin/python
# coding: utf-8
import os
import json
import time
from tencentcloud.common import credential
from tencentcloud.common.profile.client_profile import ClientProfile
from tencentcloud.common.profile.http_profile import HttpProfile
from tencentcloud.common.exception.tencent_cloud_sdk_exception import TencentCloudSDKException
from tencentcloud.cdn.v20180606 import cdn_client, models

def tencentCloudRequest(secretId, secretKey):
    try:
        cred = credential.Credential(secretId, secretKey)
        httpProfile = HttpProfile()
        httpProfile.endpoint = "cdn.tencentcloudapi.com"
        clientProfile = ClientProfile()
        clientProfile.httpProfile = httpProfile
        client = cdn_client.CdnClient(cred, "", clientProfile)    
    except TencentCloudSDKException as err:
        return False
    return client

def startCDN(secretId, secretKey, domain):
    try:
        client = tencentCloudRequest(secretId, secretKey)
        if(not client):
            return False
        req = models.StartCdnDomainRequest()
        params = '{"Domain":"'+domain+'"}'
        req.from_json_string(params)
        resp = client.StartCdnDomain(req)
        cdn_start_result = resp.to_json_string()
    except TencentCloudSDKException as err:
        return False
    return True

def jsonLogWrite(domain):
    if(os.path.exists('/www/server/panel/plugin/tencent_cdn/logs/' + domain + '.auto_online.json')):
        with open('/www/server/panel/plugin/tencent_cdn/logs/' + domain + '.auto_online.json', "r") as f:
            logArr = json.loads(f.read())
    else:
        logArr = []
    logDict = {
        'domain' : domain,
        'timestamp': time.time()
    }
    logArr.append(logDict)
    with open('/www/server/panel/plugin/tencent_cdn/logs/' + domain + '.auto_online.json', "w") as f:
        json.dump(logArr, f)
    return True

basicConfig = json.load(open('/www/server/panel/plugin/tencent_cdn/config/basic.json'))
domainConfig = json.load(open('/www/server/panel/plugin/tencent_cdn/config/domain.json'))
domainList = []
for domain, config in domainConfig.items():
    if(config['auto_online_time']>0):
        domainList.append(domain)
secretId = basicConfig['secretId']
secretKey = basicConfig['secretKey']
while(1):
    try:
        client = tencentCloudRequest(secretId, secretKey)
        req = models.DescribeDomainsRequest()
        params = '{}'
        req.from_json_string(params)
        resp = client.DescribeDomains(req)
        results = json.loads(resp.to_json_string())['Domains']
        for result in results:
            if(result['Status'] == 'offline'):
                if(result['Domain'] in domainList):
                    dConfig = domainConfig[result['Domain']]
                    updateTime = time.mktime(time.strptime(result['UpdateTime'], '%Y-%m-%d %H:%M:%S'))
                    nowTime = time.time()
                    timeDifference = nowTime-updateTime
                    if(timeDifference >= int(dConfig['auto_online_time'])*60):
                        jsonLogWrite(result['Domain'])
                        startCDN(secretId, secretKey, result['Domain'])
    except TencentCloudSDKException as err:
        print(err)
    time.sleep(int(basicConfig['detectionInterval1'])*60)