#!/usr/bin/python
# coding: utf-8
import os
import json
import time
from tencentcloud.common import credential
from tencentcloud.common.profile.client_profile import ClientProfile
from tencentcloud.common.profile.http_profile import HttpProfile
from tencentcloud.common.exception.tencent_cloud_sdk_exception import TencentCloudSDKException
from tencentcloud.cdn.v20180606 import cdn_client, models

def tencentCloudRequest(secretId, secretKey):
    try:
        cred = credential.Credential(secretId, secretKey)
        httpProfile = HttpProfile()
        httpProfile.endpoint = "cdn.tencentcloudapi.com"
        clientProfile = ClientProfile()
        clientProfile.httpProfile = httpProfile
        client = cdn_client.CdnClient(cred, "", clientProfile)    
    except TencentCloudSDKException as err:
        return False
    return client

def unblockURL(secretId, secretKey, url):
    try:
        client = tencentCloudRequest(secretId, secretKey)
        if(not client):
            return False
        req = models.EnableCachesRequest()
        params = {
            "Urls": [ "https://" + url, "http://" + url ]
        }
        req.from_json_string(json.dumps(params))
        apiReturn = json.loads(client.EnableCaches(req).to_json_string())
        if(apiReturn['CacheOptResult']['FailUrls'] == []):
            return True
        else:
            return False
    except TencentCloudSDKException as err:
        return False

def modifyLog(logData, url, status):
    logDataNew = []
    for item in logData:
        if(item['url'] == url):
            item['status'] = status
            item['timestamp'] = time.time()
        logDataNew.append(item)
    return logDataNew

basicConfig = json.load(open('/www/server/panel/plugin/tencent_cdn/config/basic.json'))
domainConfig = json.load(open('/www/server/panel/plugin/tencent_cdn/config/domain.json'))
secretId = basicConfig['secretId']
secretKey = basicConfig['secretKey']
domainList = []
for domain, config in domainConfig.items():
    if(config['threshold_2']>0):
        domainList.append(domain)
while(1):
    for domain in domainList:
        if(not os.path.exists('/www/server/panel/plugin/tencent_cdn/logs/' + domain + '.url.json')):
            continue
        domainLogs = json.load(open('/www/server/panel/plugin/tencent_cdn/logs/' + domain + '.url.json'))
        for item in domainLogs:
            nowDay = time.strftime('%d')
            logDay = time.strftime("%d", time.localtime(item['timestamp']))
            if(nowDay != logDay and basicConfig['banTime2'] == "true"):
                unblockURL(secretId, secretKey, item['url'])
                modifyLog(domainLogs, item['url'], "unblock")
        with open('/www/server/panel/plugin/tencent_cdn/logs/' + domain + '.url.json', "w") as f:
            json.dump(domainLogs, f)
    time.sleep(int(basicConfig['detectionInterval1'])*60)