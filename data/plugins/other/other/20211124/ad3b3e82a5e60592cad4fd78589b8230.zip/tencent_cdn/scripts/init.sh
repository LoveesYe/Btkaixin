#!/bin/bash
### BEGIN INIT INFO
# Provides:          tencent_cdn
# Required-Start:    $all
# Required-Stop:
# Default-Start:     2 3 4 5
# Default-Stop:
# Short-Description: tencent-cdn
### END INIT INFO

#chkconfig: 2345 81 96
#description:tencent_cdn

case $1 in
start)
    :
    if [ ! -f "/www/server/panel/pyenv/bin/python" ]; then
        python3 /www/server/panel/plugin/tencent_cdn/scripts/block_ip.py &
        python3 /www/server/panel/plugin/tencent_cdn/scripts/block_url.py &
        python3 /www/server/panel/plugin/tencent_cdn/scripts/unblock_ip.py &
        python3 /www/server/panel/plugin/tencent_cdn/scripts/unblock_url.py &
        python3 /www/server/panel/plugin/tencent_cdn/scripts/auto_online.py &
    else
        /www/server/panel/pyenv/bin/python /www/server/panel/plugin/tencent_cdn/scripts/block_ip.py &
        /www/server/panel/pyenv/bin/python /www/server/panel/plugin/tencent_cdn/scripts/block_url.py &
        /www/server/panel/pyenv/bin/python /www/server/panel/plugin/tencent_cdn/scripts/unblock_ip.py &
        /www/server/panel/pyenv/bin/python /www/server/panel/plugin/tencent_cdn/scripts/unblock_url.py &
        /www/server/panel/pyenv/bin/python /www/server/panel/plugin/tencent_cdn/scripts/auto_online.py &
    fi
    ;;
stop)
    :
    kill $(ps -ef | grep "tencent_cdn/scripts/block_ip.py" | grep -v grep | awk '{print $2}')
    kill $(ps -ef | grep "tencent_cdn/scripts/block_url.py" | grep -v grep | awk '{print $2}')
    kill $(ps -ef | grep "tencent_cdn/scripts/unblock_ip.py" | grep -v grep | awk '{print $2}')
    kill $(ps -ef | grep "tencent_cdn/scripts/unblock_url.py" | grep -v grep | awk '{print $2}')
    kill $(ps -ef | grep "tencent_cdn/scripts/auto_online.py" | grep -v grep | awk '{print $2}')
    ;;
esac

exit 0
