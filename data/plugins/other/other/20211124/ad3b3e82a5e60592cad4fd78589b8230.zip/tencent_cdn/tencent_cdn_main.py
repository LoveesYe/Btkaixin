#!/usr/bin/python
# coding: utf-8
# +---------------------------------------------------------------------------
# | Attack Blocking
# +---------------------------------------------------------------------------
# | Copyright (c) 2015-2099 吴先森(http://www.wunote.cn) All rights reserved.
# +---------------------------------------------------------------------------
# | Author: 吴先森 <i@mr-wu.top>
# +---------------------------------------------------------------------------

import panelTask
import public
import sys
import os
import json
import re
import time
from tencentcloud.common import credential
from tencentcloud.common.profile.client_profile import ClientProfile
from tencentcloud.common.profile.http_profile import HttpProfile
from tencentcloud.common.exception.tencent_cloud_sdk_exception import TencentCloudSDKException
from tencentcloud.cdn.v20180606 import cdn_client, models

os.chdir("/www/server/panel")

sys.path.append("class/")

if __name__ != '__main__':
    from BTPanel import cache, session, redirect

class dictToObj(dict):
    __setattr__ = dict.__setitem__
    __getattr__ = dict.__getitem__

class tencent_cdn_main:
    __plugin_path = "/www/server/panel/plugin/tencent_cdn/"
    __config = None

    def __init__(self):
        pass

    def _check(self, args):
        return True



    def logWrite(self, log):
        logFile = open('/www/server/panel/plugin/tencent_cdn/logs/main.log', 'a')
        logFile.write("["+time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()) + "] " + log + "\n")
        logFile.close()

    def tencentCloudRequest(self):
        if(os.path.exists('/www/server/panel/plugin/tencent_cdn/config/basic.json')):
            config = json.load(open('/www/server/panel/plugin/tencent_cdn/config/basic.json'))
        else:
            return False
        try:
            cred = credential.Credential(config['secretId'], config['secretKey'])
            httpProfile = HttpProfile()
            httpProfile.endpoint = "cdn.tencentcloudapi.com"
            clientProfile = ClientProfile()
            clientProfile.httpProfile = httpProfile
            client = cdn_client.CdnClient(cred, "", clientProfile)    
        except TencentCloudSDKException as err:
            return False
        return client

    def getDomainIPBlackList(self, domain):
        try:
            client = self.tencentCloudRequest()
            req = models.DescribeDomainsConfigRequest()
            params = {
                "Filters": [
                    {
                        "Name": "domain",
                        "Value": [ domain ]
                    }
                ]
            }
            req.from_json_string(json.dumps(params))
            apiReturn = json.loads(client.DescribeDomainsConfig(req).to_json_string())
            if(apiReturn['Domains'][0]["IpFilter"]["FilterType"] == "blacklist" and apiReturn['Domains'][0]["IpFilter"]["Switch"] == "on"):
                blackIPList = apiReturn['Domains'][0]["IpFilter"]["Filters"]
            else:
                blackIPList = []
        except TencentCloudSDKException as err:
            return []
        return blackIPList

    def urlLogChange(self, domain, url, status):
        if(os.path.exists('/www/server/panel/plugin/tencent_cdn/logs/' + domain + '.url.json')):
            domainLogs = json.load(open('/www/server/panel/plugin/tencent_cdn/logs/' + domain + '.url.json'))
        else:
            domainLogs = []
        logDataNew = []
        flag = True
        for item in domainLogs:
            if(item['url'] == url):
                flag = False
                item['status'] = status
                item['timestamp'] = time.time()
            logDataNew.append(item)
        if(flag):
            logDict = {
                'url' : url,
                'status': status,
                'timestamp': time.time()
            }
            logDataNew.append(logDict)
        with open('/www/server/panel/plugin/tencent_cdn/logs/' + domain + '.url.json', "w") as f:
            json.dump(logDataNew, f)
        return True


    def ipLogChange(self, domain, ip, status):
        if(os.path.exists('/www/server/panel/plugin/tencent_cdn/logs/' + domain + '.ip.json')):
            domainLogs = json.load(open('/www/server/panel/plugin/tencent_cdn/logs/' + domain + '.ip.json'))
        else:
            domainLogs = []
        flag = True
        logDataNew = []
        for item in domainLogs:
            if(item['ip'] == ip):
                flag = False
                item['status'] = status
                item['timestamp'] = time.time()
            logDataNew.append(item)
        if(flag):
            logDict = {
                'ip' : ip,
                'status': status,
                'timestamp': time.time()
            }
            domainLogs.append(logDict)
        with open('/www/server/panel/plugin/tencent_cdn/logs/' + domain + '.ip.json', "w") as f:
            json.dump(domainLogs, f)

    def updateDomainIPBlackList(self, domain, blackIPList):
        try:
            client = self.tencentCloudRequest()
            req = models.UpdateDomainConfigRequest()
            params = {
                "Domain": domain,
                "IpFilter": {
                    "Switch": "on",
                    "FilterType": "blacklist",
                    "Filters": blackIPList
                }
            }
            req.from_json_string(json.dumps(params))
            client.UpdateDomainConfig(req)
        except TencentCloudSDKException as err:
            return False
        return True

    def getStatus(self, args):
        result = re.sub("\D", "", os.popen('echo `ps ax | grep -i \'tencent_cdn/scripts/auto_online.py\' | grep -v grep`').read())
        if(result == ''):
            return {'msg': '查询插件状态成功！', 'serviceStatus': 0, 'status': 1}
        else:
            return {'msg': '查询插件状态成功！', 'serviceStatus': 1, 'status': 1}

    def service(self, args):
        if(args.operating == 'start'):
            public.ExecShell('bash /www/server/panel/plugin/tencent_cdn/scripts/service.sh install')
            if(re.sub("\D", "", os.popen('echo `ps ax | grep -i \'tencent_cdn/scripts/auto_online.py\' | grep -v grep`').read()) == ""):
                public.ExecShell('bash /www/server/panel/plugin/tencent_cdn/scripts/service.sh start &')
                if(re.sub("\D", "", os.popen('echo `ps ax | grep -i \'tencent_cdn/scripts/auto_online.py\' | grep -v grep`').read()) == ""):
                    self.logWrite("服务启动失败")
                    return {'msg': '抱歉，无法启动服务！请通过关于页面的邮箱联系开发者', 'status': -1}
                else:
                    self.logWrite("服务启动成功，但添加自动开机失败")
                    return {'msg': '启动成功！但添加开机自动启失败！', 'status': 2}
            else:
                self.logWrite("服务启动成功")
                return {'msg': '启动成功！并且添加开机自动启成功！', 'status': 2}
        else:
            public.ExecShell('bash /www/server/panel/plugin/tencent_cdn/scripts/service.sh uninstall')
            public.ExecShell('bash /www/server/panel/plugin/tencent_cdn/scripts/service.sh stop')
            if(not re.sub("\D", "", os.popen('echo `ps ax | grep -i \'tencent_cdn/scripts/auto_online.py\' | grep -v grep`').read()) == ""):
                self.logWrite("服务无法停止")
                return {'msg': '无法关闭服务！请尝试手动kill进程！', 'status': -1}
            else:
                self.logWrite("服务成功停止")
                return {'msg': '成功关闭了程序！', 'status': 2}

    def saveBasicConfig(self, args):
        try:
            cred = credential.Credential(args.secretId, args.secretKey)
            httpProfile = HttpProfile()
            httpProfile.endpoint = "cdn.tencentcloudapi.com"
            clientProfile = ClientProfile()
            clientProfile.httpProfile = httpProfile
            client = cdn_client.CdnClient(cred, "", clientProfile)
            req = models.DescribeDomainsRequest()
            params = '{}'
            req.from_json_string(params)
            resp = client.DescribeDomains(req)
            apiReturn = json.loads(resp.to_json_string())
        except TencentCloudSDKException as err:
            return {'msg': '连接到腾讯云失败！请检查您的密钥是否正确', 'status':-1}
        configDict = {
            'secretId': args.secretId,
            'secretKey': args.secretKey,
            'banTime1': args.banTime1,
            'banTime2': args.banTime2,
            'detectionInterval1': args.detectionInterval1,
            'detectionInterval2': args.detectionInterval2
        }
        with open('/www/server/panel/plugin/tencent_cdn/config/basic.json', "w") as f:
            json.dump(configDict, f)
        return {'msg': '保存成功！', 'status': 2}
    
    def saveWhiteList(self, args):
        if(args.type=="ip"):
            with open('/www/server/panel/plugin/tencent_cdn/config/ip.txt', "w") as f:
                f.write(args.ip)
        else:
            with open('/www/server/panel/plugin/tencent_cdn/config/url.txt', "w") as f:
                f.write(args.url)
        return {'msg': '保存白名单成功！', 'status': 2}

    def getLogs(self, args):
        if(os.path.exists('/www/server/panel/plugin/tencent_cdn/logs/main.log')):
            return {'msg': '查询成功！', 'logs': open('/www/server/panel/plugin/tencent_cdn/logs/main.log').read(), 'status': 1}
        else:
            return {'msg': '查询成功！', 'logs': "抱歉，找不到日志！可能日志已经被清空？", 'status': 1}

    def getWhiteList(self, args):
        ipWhiteList = open("/www/server/panel/plugin/tencent_cdn/config/ip.txt").read()
        urlWhiteList = open("/www/server/panel/plugin/tencent_cdn/config/url.txt").read()
        rData = {
            'msg': "读取成功！",
            'ip': ipWhiteList,
            'url': urlWhiteList,
            'status': 1
        }
        return rData

    def deleteBasicConfig(self, args):
        self.logWrite("配置文件已被删除")
        if os.path.exists('/www/server/panel/plugin/tencent_cdn/config/basic.json'):
            os.remove('/www/server/panel/plugin/tencent_cdn/config/basic.json')
        return {'msg': '删除成功！', 'status': 2}

    def getBasicConfig(self, args):
        if(os.path.exists('/www/server/panel/plugin/tencent_cdn/config/basic.json')):
            with open('/www/server/panel/plugin/tencent_cdn/config/basic.json', "r") as f:
                configDict = json.loads(f.read())
            return {'status': 1, 'msg': '查询成功！', "data":configDict}
        else:
            return {'status': 1, 'msg': '抱歉！找不到配置文件！'}

    def getBannedIPLogs(self, args):
        if(os.path.exists('/www/server/panel/plugin/tencent_cdn/logs/' + args.domain + '.ip.json')):
            with open('/www/server/panel/plugin/tencent_cdn/logs/' + args.domain + '.ip.json', "r") as f:
                logData = json.loads(f.read())
            return {'status': 1, 'msg': '查询成功！', "data":logData}
        else:
            return {'status': -1, 'msg': '抱歉，找不到指定域名的IP封禁日志！'}

    def deleteLogs(self, args):
        os.system("rm -rf /www/server/panel/plugin/tencent_cdn/logs/*.log")
        os.system("rm -rf /www/server/panel/plugin/tencent_cdn/logs/*.json")
        self.logWrite("清空日志成功")
        return {'status': 2, 'msg': '日志清除成功！'}

    def getAutoOnlineLogs(self, args):
        if(os.path.exists('/www/server/panel/plugin/tencent_cdn/logs/' + args.domain + '.auto_online.json')):
            with open('/www/server/panel/plugin/tencent_cdn/logs/' + args.domain + '.auto_online.json', "r") as f:
                logData = json.loads(f.read())
            return {'status': 1, 'msg': '查询成功！', "data":logData}
        else:
            return {'status': -1, 'msg': '抱歉，找不到指定域名的CDN自动上线日志！'}

    def getBannedURLList(self, args):
        if(os.path.exists('/www/server/panel/plugin/tencent_cdn/logs/' + args.domain + '.url.json')):
            with open('/www/server/panel/plugin/tencent_cdn/logs/' + args.domain + '.url.json', "r") as f:
                logData = json.loads(f.read())
            return {'status': 1, 'msg': '查询成功！', "data":logData}
        else:
            return {'status': -1, 'msg': '抱歉，找不到指定域名的URL自动下线日志！'}

    def unblockAllURL(self, args):
        if(os.path.exists('/www/server/panel/plugin/tencent_cdn/logs/' + args.domain + '.url.json')):
            with open('/www/server/panel/plugin/tencent_cdn/logs/' + args.domain + '.url.json', "r") as f:
                logData = json.loads(f.read())
            for item in logData:
                if(item['status'] == "banned"):
                    self.unblockURL(dictToObj({"domain":args.domain, "url": item['url']}))
            return {'status': 2, 'msg': '操作成功！'}
        else:
            return {'status': -1, 'msg': '抱歉，找不到指定域名的URL自动下线日志！'}

    def banIP(self, args):
        blackIPList = self.getDomainIPBlackList(args.domain)
        if(not args.ip in blackIPList):
            blackIPList.append(args.ip)
            self.updateDomainIPBlackList(args.domain, blackIPList)
        self.ipLogChange(args.domain, args.ip, "banned")
        return {'status': 2, 'msg': '操作成功！'}

    def unblockIP(self, args):
        blackIPList = self.getDomainIPBlackList(args.domain)
        if(args.ip in blackIPList):
            blackIPList.remove(args.ip)
            self.updateDomainIPBlackList(args.domain, blackIPList)
        self.ipLogChange(args.domain, args.ip, "unblock")
        return {'status': 2, 'msg': '操作成功！'}

    def getBannedURLListOnline(self, args):
        try:
            client = self.tencentCloudRequest()
            if(not client):
                return {'msg': '连接到腾讯云失败！请检查您的密钥是否正确！', 'apiReturn': "", 'status': -1}
            req = models.GetDisableRecordsRequest()
            params = {
                "Limit": 1000,
                "StartTime": time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time()-518400)),
                "EndTime": time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()),
            }
            req.from_json_string(json.dumps(params))

            apiReturn = json.loads(client.GetDisableRecords(req).to_json_string())
            bannedURLArr = []
            for item in apiReturn['UrlRecordList']:
                if(args.domain in item['RealUrl'] or args.domain == "all"):
                    logData = {
                        'url': item['RealUrl'],
                        'status': item['Status'],
                        'timestamp': int(time.mktime(time.strptime(item['UpdateTime'], "%Y-%m-%d %H:%M:%S")))
                    }
                    if(item['Status'] == "disable"):
                        bannedURLArr.append(logData)
        except TencentCloudSDKException as err:
            return {'msg': '请求腾讯云时出现了一个致命的错误！', 'apiReturn': "", 'status': -1}
        if(bannedURLArr == []):
            return {'status': -1, 'msg': '抱歉，找不到指定域名的URL下线日志！'}
        else:
            return {'status': 1, 'msg': '查询成功！', "data":bannedURLArr}

    def unblockURL(self, args):
        try:
            client = self.tencentCloudRequest()
            if(not client):
                return {'msg': '连接到腾讯云失败！请检查您的密钥是否正确！', 'apiReturn': "", 'status': -1}
            req = models.EnableCachesRequest()
            if('http://' in args.url or 'https://' in args.url):
                params = {
                    "Urls": [ args.url ]
                }
            else:
                params = {
                    "Urls": [ "https://" + args.url, "http://" + args.url ]
                }
            req.from_json_string(json.dumps(params))
            apiReturn = json.loads(client.EnableCaches(req).to_json_string())
            self.urlLogChange(args.domain, args.url, "unblock")
            if(apiReturn['CacheOptResult']['FailUrls'] == []):
                return {'status': 2, 'msg': '操作成功！'}
            else:
                return {'status': -1, 'msg': '抱歉！操作失败！'}
        except TencentCloudSDKException as err:
            return {'status': -1, 'msg': '操作失败！'}
        
    def banURL(self, args):
        try:
            client = self.tencentCloudRequest()
            if(not client):
                return {'msg': '连接到腾讯云失败！请检查您的密钥是否正确！', 'apiReturn': "", 'status': -1}
            req = models.DisableCachesRequest()
            params = {
                "Urls": [ "https://" + args.url, "http://" + args.url ]
            }
            req.from_json_string(json.dumps(params))
            apiReturn = json.loads(client.DisableCaches(req).to_json_string())
            self.urlLogChange(args.domain, args.url, "banned")
            if(apiReturn['CacheOptResult']['FailUrls'] == []):
                return {'status': 2, 'msg': '操作成功！'}
            else:
                return {'status': -1, 'msg': '抱歉！操作失败！'}
        except TencentCloudSDKException as err:
            return {'status': -1, 'msg': '操作失败！'}
        

    def getAllDomains(self, args):
        try:
            client = self.tencentCloudRequest()
            if(not client):
                return {'msg': '连接到腾讯云失败！请检查您的密钥是否正确！', 'apiReturn': "", 'status': -1}
            req = models.DescribeTrafficPackagesRequest()
            params = '{}'
            req.from_json_string(params)
            resp = client.DescribeDomains(req)
            apiReturn = json.loads(resp.to_json_string())
        except TencentCloudSDKException as err:
            return {'msg': '连接到腾讯云失败！请检查您的密钥是否正确', 'apiReturn': "", 'status': -1}
        if (not 'Domains' in apiReturn):
            return {'msg': '连接到腾讯云失败！请检查您的密钥是否正确', 'apiReturn': apiReturn, 'status': -1}
        else:
            return {'msg': '查询成功！', 'apiReturn': apiReturn, 'status': 1}

    def saveDomainConfig(self, args):
        if(os.path.exists('/www/server/panel/plugin/tencent_cdn/config/domain.json')):
            with open('/www/server/panel/plugin/tencent_cdn/config/domain.json', "r") as f:
                domainConfig = json.loads(f.read())
        else:
            domainConfig = {}
        domainConfigDict = {
            'threshold_1': float(args.threshold_1),
            'threshold_2': float(args.threshold_2),
            'auto_online_time': int(args.auto_online_time)
        }
        domainConfig[args.domain] = domainConfigDict
        with open('/www/server/panel/plugin/tencent_cdn/config/domain.json', "w") as f:
            json.dump(domainConfig, f)
        return {'msg': '成功保存域名配置文件！', 'status': 2}

    def getAllDomainConfig(self, args):
        if(not os.path.exists('/www/server/panel/plugin/tencent_cdn/config/domain.json')):
            return {'msg': '找不到配置文件！', 'data':[],'status': -1}
        with open('/www/server/panel/plugin/tencent_cdn/config/domain.json', "r") as f:
            domainConfig = json.loads(f.read())
        domainConfigArr = []
        for domain, config in domainConfig.items():
            domainConfigDict = {
                'domain' : domain,
                'threshold_1': config['threshold_1'],
                'threshold_2': config['threshold_2'],
                'auto_online_time': config['auto_online_time']
            }
            domainConfigArr.append(domainConfigDict)
        return {'msg': '查询成功！', 'data':domainConfigArr, 'status': 1}