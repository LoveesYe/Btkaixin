/*
 Navicat Premium Data Transfer

 Source Server         : seotip
 Source Server Type    : SQLite
 Source Server Version : 3030001
 Source Schema         : main

 Target Server Type    : SQLite
 Target Server Version : 3030001
 File Encoding         : 65001

 Date: 27/10/2021 13:09:58
*/

PRAGMA foreign_keys = false;

-- ----------------------------
-- Table structure for config
-- ----------------------------
DROP TABLE IF EXISTS "config";
CREATE TABLE "config" (
  "name" TEXT,
  "value" TEXT
);

-- ----------------------------
-- Records of config
-- ----------------------------
INSERT INTO "config" VALUES ('email_config', '{"host":"smtp.qq.com","port":"465","username":"610176732@qq.com","password":"wzvkpfleyzgcbcch"}');
INSERT INTO "config" VALUES ('rec_config', '{"rec_username":"610176732@qq.com"}');

-- ----------------------------
-- Table structure for log
-- ----------------------------
DROP TABLE IF EXISTS "log";
CREATE TABLE "log" (
  "id" INTEGER PRIMARY KEY AUTOINCREMENT,
  "domain" INTEGER(100),
  "link" INTEGER(100),
  "title" TEXT(100),
  "des" TEXT(100),
  "index_time" TEXT(100),
  "type" TEXT(100),
  "is_tip" integer(10) DEFAULT 1
);

-- ----------------------------
-- Records of log
-- ----------------------------
INSERT INTO "log" VALUES (1244, 'www.waytomilky.com', 'https://www.waytomilky.com/', '银河源码 - 高品质源码分享', '银河源码,高品质源码分享', '1631336564', 'baidu', 2);
INSERT INTO "log" VALUES (1245, 'www.waytomilky.com', 'https://www.waytomilky.com/archives/2084.html', '宝塔插件:【网站采集器】发布 - 银河源码', '2020年4月27日 目前支持typecho程序采集', '1587916800', 'baidu', 2);
INSERT INTO "log" VALUES (1246, 'www.waytomilky.com', 'https://www.waytomilky.com/archives/1568.html', 'chrome最强插件-油猴tampermonkey插件 - 银河源码', '2020年2月5日 油猴插件有另外一个名字就是tampermonkey,谷歌最强插件,没有之一!支持自定义安装用户脚本,比如百度网盘直接下载,国内视频站直接观看等等。。。除了你想不到的,没有它不能做的!1.油猴...', '1580832000', 'baidu', 2);
INSERT INTO "log" VALUES (1247, 'www.waytomilky.com', 'https://www.waytomilky.com/archives/1554.html', 'LotusAdmin v6.0发布,帮开发者节省两天开发时间(站长自研)...', '底部下载!', '1632200564', 'baidu', 2);
INSERT INTO "log" VALUES (1248, 'www.waytomilky.com', 'https://www.waytomilky.com/archives/2001.html', 'FkAdmin后台静态模板 - 银河源码', '2020年4月9日 实时截图', '1586361600', 'baidu', 2);
INSERT INTO "log" VALUES (1249, 'www.waytomilky.com', 'https://www.waytomilky.com/archives/mxcrm.html', '一款功能齐全的客户管理系统MXCRM - 银河源码', '2020年4月21日 忽闻梅福来相访,笑着荷衣出草堂 登录 技术支持 联系站长 隐私政策 版权声明 首页 技术 SEO 模板 wp主题 整站 TP源码 pc工具首页TP源码一款功能齐全的客户管理系统MXCRM  一款功能齐...', '1587398400', 'baidu', 2);
INSERT INTO "log" VALUES (1250, 'www.waytomilky.com', 'https://www.waytomilky.com/archives/1705.html', '安装漂亮的命令行,Oh My ZSH! - 银河源码', '2020年2月18日 首先我很喜欢这个命名,独特又直接,总之很喜欢...Oh My ZSH!是一款美化zsh的插件,安装后shell会变得很漂亮,由于官网经常被墙,于是我写了个这个教程,避免脚本远程...', '1581955200', 'baidu', 2);
INSERT INTO "log" VALUES (1251, 'www.waytomilky.com', 'https://www.waytomilky.com/archives/1646.html', 'Unmask Password – 防止密码输入错误,可视化密码! - 银河...', '2020年2月10日 防止密码输入错误,可以显示正在输入的密码框!很实用的一款小插件!', '1581264000', 'baidu', 2);
INSERT INTO "log" VALUES (1252, 'www.waytomilky.com', 'https://www.waytomilky.com/tag/rufus/', 'rufus - 银河源码', '2020年2月23日 rufus文章 技术  轻量的U盘引导盘制作神器 Rufus 这是我见过最轻量的重装系统工具,没有之一推荐理由:程序文件仅仅1.1M,但是小不意味着功能少支持windows/Linux...', '1582387200', 'baidu', 2);
INSERT INTO "log" VALUES (1253, 'www.waytomilky.com', 'https://www.waytomilky.com/archives/911.html', 'PHP abstract与interface之间的区别 - 银河源码', '2019年8月22日 1、抽象类需要继承,用extends,而接口需要实现,用implements;2、一个类可以实现多个接口,但只能继承一个抽象类3、接口中每个方法都只有声明而没有实现,其中的每...', '1566403200', 'baidu', 2);
INSERT INTO "log" VALUES (1254, 'www.waytomilky.com', 'https://www.waytomilky.com/archives/929.html', '国内绿iPhone11抢断货 - 银河源码', '2019年9月15日 当地时间9月10日上午10点,苹果2019年秋季发布会在美国加州的史蒂夫·乔布斯剧院举行。本次发布会上,苹果推出了新的iPhone产品系列以及苹果新推出的服务。据悉,...', '1568476800', 'baidu', 2);
INSERT INTO "log" VALUES (1255, 'www.waytomilky.com', 'https://www.waytomilky.com/archives/2549.html', 'windows不可错过的实用电源小工具:完善微软 Win10 定时开...', '2021年4月25日 Win10 有很多不错的设计,不过对于定时开关机这点,体验并不尽如人意。', '1619280000', 'baidu', 2);
INSERT INTO "log" VALUES (1256, 'www.waytomilky.com', 'https://www.waytomilky.com/archives/1106.html', '支付宝全球用户数超12亿半年增长20%,跨境支付增长明显 - ...', '2019年9月25日 [PConline 资讯]9月24日下午消息,在阿里巴巴投资者大会上,蚂蚁金服董事长兼CEO井贤栋宣布,截至2019年6月,支付宝及其本地钱包合作伙伴已经服务全球超12亿用户。...', '1569340800', 'baidu', 2);
INSERT INTO "log" VALUES (1257, 'www.waytomilky.com', 'https://www.waytomilky.com/archives/2160.html', '云萌Win10 激活工具,秒杀不干净的KMS - 银河源码', '2020年8月5日 想用个干净的win10激活工具怎么就这么难呢?最近两年就爆出某些 KMS 激活工具不太干净,想篡改主页赠送大礼包倒是其次,附赠的病毒、木马、挖矿病毒是危害性是最大的。', '1596556800', 'baidu', 2);
INSERT INTO "log" VALUES (1258, 'www.waytomilky.com', 'https://www.waytomilky.com/archives/1853.html', '最新thinkphp6 Auth库使用(站长自研) - 银河源码', '2020年3月2日 606645328', '1583078400', 'baidu', 2);
INSERT INTO "log" VALUES (1259, 'www.waytomilky.com', 'https://www.waytomilky.com/archives/2183.html', '小旋风泛目录v5.4 无限制版 - 银河源码', '2020年8月31日 程序介绍 V5.4版本更新: 增加redis缓存功能(开启后性能提升30%) 增加仅蜘蛛爬行才生成缓存选项 增加禁止搜索引擎快照,可防止他人查看你的快照(在后台目录优化设置) 插件增加采集数据...', '1598803200', 'baidu', 2);
INSERT INTO "log" VALUES (1260, 'www.waytomilky.com', 'https://www.waytomilky.com/search/it/', '搜索结果 - 银河源码', 'it 找到9 篇文章  2021年9月23日  PHP解决跨域问题 Response to preflight request doesn‘t pass access control check: It does not have HTTP ok status. 2020年11月27日 ...', '1631509368', 'baidu', 2);
INSERT INTO "log" VALUES (1261, 'www.waytomilky.com', 'https://www.waytomilky.com/archives/1885.html', '20个PHP国际流行的开源CMS - 银河源码', '2020年3月10日 内容管理系统或CMS是一个用于管理新闻的应用程序,用户可以从后台管理系统发布、编辑和删除文章。HTML 和其他脚本语言不需要操作 CMS,尽管使用它们会增加更多优...', '1583769600', 'baidu', 2);
INSERT INTO "log" VALUES (1262, 'www.waytomilky.com', 'https://www.waytomilky.com/tag/wenyi/', '文艺阅读 - 银河源码', '文艺阅读文章 技术  仲夏已尽·凛冬将至 一、伸手不见五指的小巷子里,正值花季之年的少女被持刀歹徒胁迫脱衣服。少女无奈脱掉毛衣,心想着下面就该脱内衣了,不料歹徒又说穿上...', '1632027768', 'baidu', 2);
INSERT INTO "log" VALUES (1263, 'www.waytomilky.com', 'https://www.waytomilky.com/archives/1010.html', 'phpstudy被曝携带病毒? - 银河源码 - 高品质源码分享', '2019年9月21日 最近phpstudy带毒问题,我作为一个非官方站长,觉得还是贡献一篇帖子,来个说明下.此为作者@猪哥在PHP集成环境群内的说明(群号945939940):原文如下:这个事件早在20...', '1568995200', 'baidu', 2);
INSERT INTO "log" VALUES (1264, 'www.waytomilky.com', 'https://www.waytomilky.com/archives/hailuo.html', '苹果CMS V10海螺主题_带后台无限制版 - 银河源码', '2020年11月21日 文章信息:本文于2020年11月21日23:47:00,由 阿修罗 发表,共 372 字。 版权声明:第三方程序均收集于网络,仅供学习交流,如有侵权,请联系站长删除。 转载注明:苹果CMS V10海螺主题_带...', '1605888000', 'baidu', 2);
INSERT INTO "log" VALUES (1265, 'www.waytomilky.com', 'https://www.waytomilky.com/archives/1950.html', '百度推送API或者和神马站长推送API获取 - 银河源码', '2020年3月25日 https://ziyuan.baidu.com/linksubmit/index', '1585065600', 'baidu', 2);
INSERT INTO "log" VALUES (1266, 'www.waytomilky.com', 'https://www.waytomilky.com/archives/223.html', '比特币病毒xmrigMiner入侵服务器的解决方法 - 银河源码', '2018年10月29日 top命令杀掉xmrigMiner进程kill -9 pid', '1540742400', 'baidu', 2);
INSERT INTO "log" VALUES (1267, 'www.waytomilky.com', 'https://www.waytomilky.com/tag/mysql/', 'mysql - 银河源码 - 高品质源码分享', '2019年8月26日 标签mysql 技术 mysql索引优化 2019-08-26 阿修罗 阅读(20830) 评论(0) 作为免费又高效的数据库,mysql基本是首选。良好的安全连接,自带查询解析、sql语句优化,...', '1566748800', 'baidu', 2);
INSERT INTO "log" VALUES (1268, 'www.waytomilky.com', 'https://www.waytomilky.com/archives/2146.html#respond', 'thinkphp5验证器:复杂多场景验证 thinkphp5验证器实例 - ...', '2020年7月14日 验证器 UserPay&lt;?phpnamespace app\common\validate;use app\common\model\UserPayModel;use think\Vali...', '1594656000', 'baidu', 2);
INSERT INTO "log" VALUES (1269, 'www.waytomilky.com', 'https://www.waytomilky.com/archives/685.html', 'onedrive无法连接 - 银河源码 - 高品质源码分享', '2019年7月11日 OneNote(或者OneDrive)不能连接了解决方法:您可以尝试修改DNS来尝试更好的连接微软的服务器。尝试更改DNS:打开控制面板-网络共享中心,点击左侧的更改适配器设置...', '1562774400', 'baidu', 2);
INSERT INTO "log" VALUES (1270, 'www.waytomilky.com', 'https://www.waytomilky.com/archives/1589.html', '谷歌上网助手Ghelper - 银河源码', '2020年2月7日 科学上网,翻墙,谷歌vpn扩展无需介绍,科学上网,翻墙必备!不过要邮箱注册激活下,体验更好,挺稳定的', '1581004800', 'baidu', 2);
INSERT INTO "log" VALUES (1271, 'www.waytomilky.com', 'https://www.waytomilky.com/tag/xmrigMiner/', 'xmrigMiner - 银河源码', '2018年10月29日 标签xmrigMiner ﻿ 技术  比特币病毒xmrigMiner入侵服务器的解决方法2018-10-29 阿修罗 阅读(3384) 评论(2) 第一步top命令杀掉xmrigMiner进程kill -9 pid第二...', '1540742400', 'baidu', 2);
INSERT INTO "log" VALUES (1272, 'www.waytomilky.com', 'https://www.waytomilky.com/archives/Infinity.html', 'Infinity标签页扩展,高效管理常见网站 - 银河源码 - 高品...', '2020年2月29日 Infinity标签页扩展是一款针对chrome类浏览器推出的美化标签页的应用,站长自用,强烈推荐,不可多得的精品扩展快速高效的管理你的常用网站添加常用网站到新标签页...', '1582905600', 'baidu', 2);
INSERT INTO "log" VALUES (1273, 'www.waytomilky.com', 'https://www.waytomilky.com/archives/flashplayer.html', '绝不向业界毒瘤低头,拒绝中国特供版FlashPlayer - 银河源...', '2020年7月10日 优化点已经屏蔽删除反馈服务和升级服务程序解除中国大陆地区无法安装国际版 Flash 的限制安装过程无需断网,卸载过程也无需断网解除使用国际版 Flash 后提示地区...', '1594310400', 'baidu', 2);
INSERT INTO "log" VALUES (1274, 'www.waytomilky.com', 'https://www.waytomilky.com/tag/vpn/', 'vpn - 银河源码', '2020年2月7日 首页vpn文章  TP源码  谷歌上网助手Ghelper  推荐理由 科学上网,翻墙,谷歌vpn扩展无需介绍,科学上网,翻墙必备!不过要邮箱注册激活下,体验更好,挺稳定的 注意: 使用的时候请禁用下其他...', '1581004800', 'baidu', 2);
INSERT INTO "log" VALUES (1275, 'www.waytomilky.com', 'https://www.waytomilky.com/archives/1506.html', '莲花蜘蛛池出租 - 银河源码', '2020年1月12日 废话不说,直接看效果,专业蜘蛛池.支持直接提交链接,和帮忙养蜘蛛.', '1578758400', 'baidu', 2);
INSERT INTO "log" VALUES (1276, 'www.waytomilky.com', 'https://www.waytomilky.com/tag/CMS/', 'CMS - 银河源码', '2019年5月5日 标签CMS ﻿ 模板  一个值得玩味的老牌cms之thinkcmf2019-05-05 阿修罗 阅读(4688) 评论(0) 前台界面比较简洁,但是略显简陋缺点也是过于简洁,需要进行一下订制基...', '1556985600', 'baidu', 2);
INSERT INTO "log" VALUES (1277, 'www.waytomilky.com', 'https://www.waytomilky.com/archives/2394.html', '你讨厌正则表达式么?那你该看看 ihateregex 了 - 银河源码...', '2020年12月18日 今天看微信公众号的时候,偶然发现的一个碉堡了的网站,特此分享下,网站名字就叫做 ihateregex,是不是很骇客?这是一个很棒的正则表达式仓库,同时也是一个强大的...', '1608220800', 'baidu', 2);
INSERT INTO "log" VALUES (1278, 'www.waytomilky.com', 'https://www.waytomilky.com/tag/SEO/', 'SEO - 银河源码', '2019年8月3日 SEO 技术 thinkphp源码 云服务器 阿修罗 技术支持服务 个人介绍 作品展示 标签SEO SEO  泛目录程序如何设置Nginx目录反向代理2019-08-03 阿修罗 阅读(13618) 评...', '1564761600', 'baidu', 2);
INSERT INTO "log" VALUES (1279, 'www.waytomilky.com', 'https://www.waytomilky.com/tag/PHP/', 'PHP - 银河源码 - 高品质源码分享', '标签PHP 技术  期待已久的PHP8.0正式版发布,引入重磅功能JIT2020-11-27 阿修罗 阅读(719) 评论(0) 11月27日正好是每年的感恩节,正式版本的php8.0现在正式开放供下载。Php8.0...', '1631422977', 'baidu', 2);
INSERT INTO "log" VALUES (1280, 'www.waytomilky.com', 'https://www.waytomilky.com/search/apache/', 'apache - 银河源码 - 高品质源码分享', '银河源码,专注高品质网站源码,PHP技术博客', '1630126977', 'baidu', 2);
INSERT INTO "log" VALUES (1281, 'www.waytomilky.com', 'https://www.waytomilky.com/archives/738.html', '莲花泛目录程序(站长自研) - 银河源码', '2019年7月16日 ``### 请抓紧时间购买!再次强调,仅作为SEO辅助工具,请不要用于非法领域,后果自负。', '1563206400', 'baidu', 2);
INSERT INTO "log" VALUES (1282, 'www.waytomilky.com', 'https://www.waytomilky.com/tag/SEO%E5%85%A5%E9%97%A8/', 'SEO入门 - 银河源码', '高品质源码 银河系 模板 整站 SEO 技术 thinkphp源码 云服务器 阿修罗 技术支持服务 个人介绍 作品展示 标签SEO入门 ﻿ SEO SEO技巧 SEO入门 2019-09-27 阿修罗 阅读(2296) ...', '1630126977', 'baidu', 2);
INSERT INTO "log" VALUES (1283, 'www.waytomilky.com', 'https://www.waytomilky.com/archives/2254.html', '为什么搜狗引擎收录这么难? - 银河源码', '高品质源码 银河系 模板 整站 SEO 技术 thinkphp源码 云服务器 阿修罗 技术支持服务 个人介绍 作品展示 为什么搜狗引擎收录这么难? 2020-10-12 分类: SEO 阅读(2) 评论(0) 1...', '1632718977', 'baidu', 2);
INSERT INTO "log" VALUES (1284, 'www.waytomilky.com', 'https://www.waytomilky.com/archives/1554.html/comment-page-1', 'LotusAdmin v6.0发布,帮开发者节省两天开发时间(站长自研)...', '高品质源码 银河系 模板 整站 SEO 技术 thinkphp源码 云服务器 阿修罗 技术支持服务 个人介绍 作品展示 LotusAdmin v6.0发布,帮开发者节省两天开发时间(站长自研) 2020-02-04...', '1630472582', 'baidu', 2);
INSERT INTO "log" VALUES (1285, 'www.waytomilky.com', 'https://www.waytomilky.com/archives/1945.html', 'wordpress生成sitemap.xml地图 - 银河源码', '2020年3月24日 nginx设置如下伪静态规则:', '1584979200', 'baidu', 2);
INSERT INTO "log" VALUES (1286, 'www.waytomilky.com', 'https://www.waytomilky.com/archives/1240.html', 'Ubuntu 19.10“Eoan Ermine”正式版发布,带来ZFS文件系统 ...', 'ubuntu 19.10"eoan ermine"正式版发布,带来zfs文件系统 2019年10月18日 07:58:43 发表评论 39次浏览 canonical今天正式发布了代号为"eoan ermine"的ubuntu 19.10,此版本带来...', '1630472582', 'baidu', 2);
INSERT INTO "log" VALUES (1287, 'www.waytomilky.com', 'https://www.waytomilky.com/tag/%E8%B0%B7%E6%AD%8C%E6%8F%92%E4%BB%B6/', '谷歌插件 - 银河源码', '这个问题... 2021年8月11日 72次浏览 阅读全文', '1632718982', 'baidu', 2);
INSERT INTO "log" VALUES (1288, 'www.waytomilky.com', 'https://www.waytomilky.com/tag/%E4%BA%8C%E7%BA%A7%E7%9B%AE%E5%BD%95/', '二级目录 - 银河源码', '什么是泛目录 问题分成两个部分:1:什么是二级目录和泛目录?2:这里所说的反向代理是什么意思?1:什么是二级目录和泛目录?什么是二级目录?举个例子:www.xxx.com ,www.xxx.com/ap...', '1632114182', 'baidu', 2);
INSERT INTO "log" VALUES (1289, 'www.waytomilky.com', 'https://www.waytomilky.com/archives/%E8%AE%A9%E4%BD%A0%E6%9B%B4%E5%BF%AB%E4%B9%90%E7%9A%84%E5%B7%A5%E5%85%B7%E7%AE%B1-steam-%E5%B7%A5%E5%85%B7%E7%AE%B1.html', '让你更快乐的工具箱 Steam++ 工具箱 - 银河源码', '让你更快乐的工具箱 steam++工具箱 2021年8月18日 13:26:49 发表评论 40次浏览 steam++工具箱🧰 「steam++」是一个包含多种steam工具功能的工具箱,此工具的大部分功能都是需...', '1632718982', 'baidu', 2);
INSERT INTO "log" VALUES (1290, 'www.waytomilky.com', 'https://www.waytomilky.com/archives/mysql.html', 'mysql面试知识点 - 银河源码', 'mysql面试知识点 2019年9月17日 18:41:00 发表评论 132次浏览 mysql数据库——面试知识点整理 1.对查询进行优化,应尽量避免全表扫描,首先应考虑在 where及 order by涉及的列...', '1631941382', 'baidu', 2);
INSERT INTO "log" VALUES (1291, 'www.waytomilky.com', 'https://www.waytomilky.com/2597-2', '广告招租 - 银河源码', '广告招租 网站流量说明 本站主要流量渠道如下: 宝塔自写插件的跳转,来自于真实的站长用户 搜索引擎 第三方网站引流 数据如下(截图自网站后台4至5月数据) 日均ip 600-800左右 ...', '1631768582', 'baidu', 2);
INSERT INTO "log" VALUES (1292, 'www.waytomilky.com', 'https://www.waytomilky.com/tag/%E5%B0%91%E5%B9%B4/', '少年- 银河源码', '标签 少年 阿修罗 2018-10-7 0:0:0 ﻿版权归作者所有,任何形式转载请联系作者。作者:克洛伊的小镇(来自豆瓣)很久很久,没有一部电影担得起心旷神怡这四个字的评价了。光是景色...', '1631854982', 'baidu', 2);
INSERT INTO "log" VALUES (1293, 'www.waytomilky.com', 'https://www.waytomilky.com/tag/v6-0/', 'v6.0 - 银河源码', '技术lotusadmin v6.0发布,帮开发者节省两天开发时间(站长自研) 底部下载!运行环境运行环境要求php7.1+后端核心基于thinkphp6.0.2 ui框架核心基于最新layui2.5.5样式参考了oka...', '1630213382', 'baidu', 2);
INSERT INTO "log" VALUES (1294, 'www.waytomilky.com', 'https://www.waytomilky.com/tag/Edge-Chromium-beta/', 'Edge Chromium beta - 银河源码 - 高品质源码分享', '标签edge chromium beta 技术 microsoft edge insider(chromium)版深度体验(软粉福利) 2019-09-22 阿修罗 阅读(1254) 评论(0) 新版诸多新特性,软粉福利:首先不得不吐槽下图标...', '1630558986', 'baidu', 2);
INSERT INTO "log" VALUES (1295, 'www.waytomilky.com', 'https://www.waytomilky.com/tag/Teamviewer14%E7%A0%B4%E8%A7%A3%E7%89%88/', 'Teamviewer14破解版 - 银河源码', '高品质源码 银河系 模板 整站 SEO 技术 thinkphp源码 云服务器 阿修罗 技术支持服务 个人介绍 作品展示 标签Teamviewer14破解版 最新文章 05-23 Win10 自带的聚合搜索PowerTo...', '1630558986', 'baidu', 2);
INSERT INTO "log" VALUES (1296, 'www.waytomilky.com', 'https://www.waytomilky.com/archives/1688.html', '主动推送常识,新手必看,别再问我了! - 银河源码 - 高品质...', '主动推送常识,新手必看,别再问我了! 2020-02-17 分类: seo 阅读(929) 评论(0) 1,和原来的sitemap提交接口有什么区别? 答:状态反馈更及时了,原来提交后需要登录到站长平台查看...', '1632459786', 'baidu', 2);
INSERT INTO "log" VALUES (1297, 'www.waytomilky.com', 'https://www.waytomilky.com/hotzluvwogu.html', '榆林seo优化推广', '榆林seo优化推广 文章来源: 榆林seo优化推广发布时间: 2019年10月28日 12:55 【字号: 大中小】 榆林seo优化推广 榆林seo优化推广 莲花泛目录,网站快排技术,联系QQ 610176732 ...', '1632459786', 'baidu', 2);
INSERT INTO "log" VALUES (1298, 'www.waytomilky.com', 'https://www.waytomilky.com/hotmhojrjvc.html', '旺道seo优化工具', '旺道seo优化工具 文章来源: 旺道seo优化工具发布时间: 2019年10月28日 12:41 【字号: 大中小】 旺道seo优化工具 旺道seo优化工具 莲花泛目录,网站快排技术,联系QQ 610176732 ...', '1632546186', 'baidu', 2);
INSERT INTO "log" VALUES (1299, 'www.waytomilky.com', 'https://www.waytomilky.com/2375.html', '标签云 - 银河源码', '标签云', '1631163786', 'baidu', 2);
INSERT INTO "log" VALUES (1300, 'www.waytomilky.com', 'https://www.waytomilky.com/tag/%E6%BA%90%E7%A0%81/', '源码- 银河源码', '标签源码 模板 授权服务器专用源码,一键生成激活码 2019-04-29 阿修罗 阅读(7994) 评论(0) 特点:可以生成无限个唯一授权码设置授权码时间绑定机器mac地址用途授权服务器专用...', '1631941386', 'baidu', 2);
INSERT INTO "log" VALUES (1301, 'www.waytomilky.com', 'https://www.waytomilky.com/tag/%E5%A3%81%E7%BA%B8/', '壁纸- 银河源码 - 高品质源码分享', '技术 最美', '1631941386', 'baidu', 2);
INSERT INTO "log" VALUES (1302, 'www.waytomilky.com', 'https://www.waytomilky.com/tag/%E9%9B%B6%E8%B7%9D%E7%A6%BB%E6%B3%9B%E7%9B%AE%E5%BD%95/', '零距离泛目录 - 银河源码', '高品质源码 银河系 模板 整站 SEO 技术 thinkphp源码 云服务器 阿修罗 归档 标签云 技术支持服务 个人介绍 作品展示 标签 零距离泛目录 技术 零距离泛目录程序_亲测无病毒二...', '1631163786', 'baidu', 2);
INSERT INTO "log" VALUES (1303, 'www.waytomilky.com', 'https://www.waytomilky.com/archives/1306.html', '90后技术宅研发Magi一夜爆红,新一代知识化结构搜索新时代...', '90后技术宅研发magi一夜爆红,新一代知识化结构搜索新时代来了? 2019年11月12日 09:25:00 发表评论 magi仿佛"一夜爆红",访问量剧增,导致自 2012年就不再更新微博,其他社交媒体...', '1630558986', 'baidu', 2);
INSERT INTO "log" VALUES (1304, 'www.waytomilky.com', 'https://www.waytomilky.com/archives/928.html', 'Let''s Encrypt 网站推出中文版 - 银河源码 - 高品质源码分享', 'let''s encrypt网站推出中文版 2019-09-08 分类: 技术 阅读(14997) 评论(0) 旨在让每个网站都能使用 https加密的非营利组织 let''s encrypt发布了简体中文版,方便中文用户使用 ...', '1630731788', 'baidu', 2);
INSERT INTO "log" VALUES (1305, 'www.waytomilky.com', 'https://www.waytomilky.com/archives/1249.html', 'web开发利器之SessionBox - 银河源码 - 高品质源码分享', 'web开发利器之sessionbox 2019-10-19 分类: 技术 阅读(1002) 评论(0) sessionbox可以在同一个浏览器界面多开相同网站的账号,非常强大,标签级的多账号,对于开发者开发来说非常...', '1630904588', 'baidu', 2);
INSERT INTO "log" VALUES (1306, 'www.waytomilky.com', 'https://www.waytomilky.com/category/wordpress%E4%B8%BB%E9%A2%98/', 'wp主题 - 银河源码', '文章wp主题 wordpress dux v6.4主题下载 推荐理由非常经典的一款博客主题如果你愿意花时间设置,真的推荐这款主题,老少皆宜细节响应式非常到位字体非常适合阅读后台设置非常丰...', '1631077388', 'baidu', 2);
INSERT INTO "log" VALUES (1307, 'www.waytomilky.com', 'https://www.waytomilky.com/search/%E8%9C%98%E8%9B%9B%E6%B1%A0/', '蜘蛛池 - 银河源码', '高品质源码 银河系 模板 整站 SEO 技术 thinkphp源码 云服务器 阿修罗 技术支持服务 个人介绍 作品展示 搜索 蜘蛛池 整站,SEO 小霸王万能站群永久授权版 2020-02-05 阿修罗 ...', '1630990988', 'baidu', 2);
INSERT INTO "log" VALUES (1308, 'www.waytomilky.com', 'https://www.waytomilky.com/search/IT/', 'IT - 银河源码 - 高品质源码分享', '品质源码 技术博客 银河系 模板 整站 SEO 技术 wordpress主题 thinkphp源码 pc工具 关于 广告招租 技术支持 联系站长 归档 搜索IT 技术 中国开发者自行开发的远程桌面RustDes...', '1630818188', 'baidu', 2);
INSERT INTO "log" VALUES (1309, 'www.lotusadmin.top', 'http://www.lotusadmin.top/', '旧雨楼_LotusAdmin极速后台管理框架', 'LotusAdmin极速后台开发框架是一款基于ThinkPHP5.1+layui2+Mysql开发的PHP内容管理系统,PHP版本要求提升到5.6+', '1632027797', 'baidu', 2);

-- ----------------------------
-- Table structure for sqlite_sequence
-- ----------------------------
DROP TABLE IF EXISTS "sqlite_sequence";
CREATE TABLE "sqlite_sequence" (
  "name",
  "seq"
);

-- ----------------------------
-- Records of sqlite_sequence
-- ----------------------------
INSERT INTO "sqlite_sequence" VALUES ('log', 1309);

-- ----------------------------
-- Table structure for web
-- ----------------------------
DROP TABLE IF EXISTS "web";
CREATE TABLE "web" (
  "id" INTEGER DEFAULT 0,
  "domain" TEXT,
  "create_time" INTEGER,
  PRIMARY KEY ("id"),
  UNIQUE ("id" ASC)
);

-- ----------------------------
-- Records of web
-- ----------------------------
INSERT INTO "web" VALUES (1, 'www.waytomilky.com', 1635301578);
INSERT INTO "web" VALUES (2, 'www.lotusadmin.top', 1635301583);
INSERT INTO "web" VALUES (3, 'www.a.com', 1635302043);

-- ----------------------------
-- Auto increment value for log
-- ----------------------------
UPDATE "sqlite_sequence" SET seq = 1309 WHERE name = 'log';

PRAGMA foreign_keys = true;
