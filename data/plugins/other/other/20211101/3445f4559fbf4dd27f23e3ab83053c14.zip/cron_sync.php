<?php
require 'main.php';

class cron_sync extends main
{
    public function __construct()
    {
        $this->tip();
    }
    function tip()
    {
        $webs = $this->db()->select('web','*');
        foreach ($webs as $web){
            $this->search_cli($web['domain']);
        }
        echo "=======邮件通知如下收录信息========".PHP_EOL;
        $logs =  $this->db()->select('log','*',[
            'is_tip'=>1
        ]);
        $this->mail_by_log_cli($logs);
    }
}

$cron = new cron_sync();