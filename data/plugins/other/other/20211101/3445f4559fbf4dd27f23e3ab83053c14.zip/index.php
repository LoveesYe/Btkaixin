<?php
//linux杀毒插件
//@author 阿修罗<610176732@qq.com>
require 'main.php';
use QL\QueryList;
use QL\Ext\Baidu;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception as MailException;

class bt_main extends main {

    protected $get;
    protected $post;
    protected $name;
    public function __construct()
    {
        $this->get = _get();
        $this->post = _post();
        //定时任务名称
        $this->name = '【SEO收录通知】插件定时任务,请勿删除';
    }
    function xq(){
        $param = $this->post;
        $info =  $this->db()->get('log','*',[
            'id'=> $param['id']
        ]);
        $info['index_time'] = date('Y-m-d',$info['index_time']);
        $info['content'] = file_get_contents($info['link']);

        $this->success('success',$info);
    }
    function add_sync_task(){
        $path = $this->get_real_path();
        $shell = $path." ".PLU_PATH."/cron_sync.php";
        //判断是否存在定时任务
        $name = $this->name;
        $res =  $this->bt_db()->select('crontab',"*",[
            'name'=>$name
        ]);
        if(!empty($res)){
            $this->error('已经存在定时任务!');
        }
        $this->success('success',[
            'shell'=>$shell,
            'name'=>$name
        ]);
    }
    public function search()
    {
        try {
            $param = $this->post;
            $keyword = "site:".$param['domain'];
            $ql = QueryList::getInstance();
            $ql->use(Baidu::class);
            $baidu = $ql->baidu(10);
            $searcher = $baidu->search($keyword);
            $countPage = $searcher->getCountPage();
            $index = [];
            for ($page = 1; $page <= $countPage; $page++)
            {
                $one = $searcher
                    ->setHttpOpt([
                        'headers' => [
                            'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.81 Safari/537.36 Edg/94.0.992.50',
                            'Referer'=>'https://www.waytomilky.com/',
                            'Accept-Encoding'=>'gzip, deflate, br',
                            'Host'=>'www.baidu.com'
                        ]
                    ])
                    ->page($page,true);
                foreach ($one as $v){
                    $v['domain'] = $param['domain'];
                    $v['type'] = 'baidu';
                    $v['index_time'] = $this->handle_index_time($v['index_time']);
                    $index[] = $v;
                }
            }
            if(empty($index)){
                throw new Exception('未查询到收录！');
            }
            $this->add_log($index);
            $this->success('抓取百度收录成功!',$index);
        }catch (\Exception $e){
            $this->error($e->getMessage());
        }
    }
    public function get_web_list()
    {
        $web = $this->bt_web();
        foreach ($web as &$v){
            $res =  $this->db()->get('web',['domain'],[
                'domain'=>$v['name']
            ]);
            $v['status'] = !empty($res)?1:0;
            $logs = $this->db()->select('log','*',[
                'AND'=>[
                    'domain'=>$v['name'],
                    'type'=>'baidu'
                ]
            ]);
            $v['baidu_num'] = count($logs);
        }
        $this->success('success',$web);
    }
    public function get_logs()
    {
        $param = $this->post;
        $p= $param['p'];
        $pageSize = 15;
        $where['domain'] = $param['domain'];
        $count = $this->db()->count('log','*',$where);
        $start = ($p-1)*$pageSize;
        $totalPage   = ceil($count/$pageSize);
        $data = $this->db()->select('log','*',[
            'AND'=>$where,
            'LIMIT' => [$start, $pageSize],
            "ORDER" => [
                'index_time'=>'DESC'
            ]
        ]);
        foreach ($data as &$v){
            $v['index_time'] =  date('Y年m月d日',$v['index_time'] );
        }
        $span = '<a class="Pnum" onclick="get_logs(1)" >首页</a>';
        $span .= $this->page($totalPage,$p);
        $span .= '<a class="Pnum" onclick="get_logs('.$totalPage.')" >尾页</a>';
        $span .= '<span class="Pcount">共'.$count.'条</span>';
        $this->success('success',[
            'data'=>$data,
            'page'=>$span
        ]);
    }
    /**
     * [page description]  分页
     * @param  [type] $sum     [总页数]
     * @param  [type] $pagenum [页数]
     * @return [type]          [description]
     */
    function page($sum,$pagenum){
        $span = "";
        if($sum > 0){
            if($pagenum <=0){$pagenum = 1;}
            if($pagenum >= $sum){$pagenum = $sum;}

            $k = $pagenum-1 <= 0 ? 1:$pagenum-1;
            $m = $sum - 6 <= 0 ?1:$sum-6;
            $pageM = $pagenum == 1?$pagenum+2:$pagenum + 1;

            if($sum - $pagenum >= 6){
                for($i = $k; $i <= $pageM; $i++){
                    $class = $i == $pagenum?'Pcurrent':'Pnum';
                    $span .= '<a class="'.$class.'" onclick="get_logs('.$i.')">'.$i.'</a>';
                }
                $span .= '<a class="Pnum"  >....</a>';
                for($i = $sum - 3; $i <= $sum; $i++){
                    $span .= '<a class="Pnum" onclick="get_logs('.$i.')" >'.$i.'</a>';
                }
            }else{
                for($i = $m; $i <= $sum; $i++){
                    $class = $i == $pagenum?'Pcurrent':'Pnum';
                    $span .= '<a class="'.$class.'" onclick="get_logs('.$i.')">'.$i.'</a>';
                }
            }
        }
        return $span;
    }
    public function save_rec(){
        $param = $this->post;
        $value = [
            'rec_username'=>trim($param['rec_username'])
        ];
        try {
            $this->db()->update('config',[
                'value'=>json_encode($value)
            ],[
                'name'=>'rec_config'
            ]);
            $this->success('收件邮箱保存成功');
        }catch (\Exception $e){
            $this->error($e->getMessage());
        }
    }
    public function get_rec(){
        $res = $this->db()->get('config',"*",[
            "name"=>"rec_config"
        ]);
        $email_config =  json_decode($res['value'],true);
        $this->success('success',$email_config);
    }
    public function test_rec()
    {
        $param = $this->post;
        try {
            $to = $param['rec_username'];
            if(empty($to)){
                throw  new Exception('邮箱不能为空!');
            }
//            $subject = "测试邮件";
//            $message = PLUGIN_DES."插件发送的测试邮件,请勿回复!";
//            $from = PLUGIN_NAME."@gmail.com";
//            $headers = "From: $from";
//            @$res =  mail($to,$subject,$message,$headers);
//            if(!$res){
//                throw  new Exception('无法发送,原因如下:1.您的系统是windows,但是您未配置下面的发邮SMTP配置');
//            }
            $message = PLUGIN_DES."插件发送的测试邮件,请勿回复!";
            $this->send_mail($message);

            $this->success('发送成功!');
        }catch (MailException $e){
            $this->error($e->getMessage());
        }
    }
    public function test_email(){
        $param = $this->post;
        $mail = new PHPMailer(true);

        try {
            //获取发送邮箱
            $rec_config = $this->db()->get('config',"*",[
                "name"=>"rec_config"
            ]);
            $rec_config_value =  json_decode($rec_config['value'],true);
            if(empty($rec_config_value['rec_username'])){
                throw new MailException('收件箱为空,请配置上面[接收邮箱配置]邮箱!');
            }
            $mail->isSMTP();                                            //Send using SMTP
            $mail->Host       = 'smtp.qq.com';                     //Set the SMTP server to send through
            $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
            $mail->Username   = $param['username'];                     //SMTP username
            $mail->Password   = $param['password'];                               //SMTP password
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
            $mail->Port       = $param['port'];                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`
            $mail->setFrom($param['username'], 'SEO通知插件');
            $mail->addAddress($rec_config_value['rec_username'], 'seotip');     //Add a recipient
            $mail->CharSet = "utf-8";
            $mail->setLanguage('zh');
            //Content
            $mail->isHTML(true);                                  //Set email format to HTML
            $mail->Subject = 'SEO收录通知插件';
            $mail->Body    = '这是一封测试邮箱,来自[SEO收录通知插件],请勿回复!';
//            $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
            $mail->send();
            $this->success('测试邮件发送成功!');
        }  catch (MailException $e) {
            $this->error($e->getMessage());
        }
    }
    public function get_email()
    {
        $res = $this->db()->get('config','*',[
            'name'=>'email_config'
        ]);
        $email_config =  json_decode($res['value'],true);
        $this->success('success',$email_config);
    }
    public function save_email(){
        $param = $this->post;
        $value = [
            'host'=>trim($param['host']),
            'port'=>trim($param['port']),
            'username'=>trim($param['username']),
            'password'=>trim($param['password'])
        ];
        try {
            $this->db()->update('config',[
                'value'=>json_encode($value)
            ],[
                'name'=>'email_config'
            ]);
            $this->success('保存成功');
        }catch (\Exception $e){
            $this->error($e->getMessage());
        }
    }
    public function  change_domain()
    {
        $param = $this->post;
        $domain = $param['domain'];
        $res = $this->db()->get('web','*',[
           'domain'=>$domain
        ]);
        if(empty($res)){
            $this->db()->insert('web',[
                'domain'=>$domain,
                'create_time'=>time()
            ]);
        }else{
            $this->db()->delete('web',[
                'domain'=>$domain
            ]);
        }

        $this->success('增加成功!');
    }
    function about(){
        try{
            @$json = json_decode(file_get_contents('https://www.waytomilky.com/notice.php'),true);
            $msg  = $json[PLU_NAME]['msg'];
        }catch (Exception $e){
            $msg = '欢迎使用插件!觉得可以的话给个好评哦!';
        }
        $this->success($msg);
    }
}
?>