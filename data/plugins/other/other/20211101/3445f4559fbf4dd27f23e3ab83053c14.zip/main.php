<?php
require 'vendor/autoload.php';
use Medoo\Medoo;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception as MailException;
use QL\QueryList;
use QL\Ext\Baidu;
## 定义常量
define('STATIC_FILE',__DIR__."/static");
define('PLUGIN_NAME','seotip');
define('MAIN_DB',__DIR__."/../../data/default.db");
define('PLUGIN_DB',__DIR__."/seotip.db");
define('PLUGIN_DES',"SEO收录通知");
define('MAIL_FROM',"From SEO收录通知插件");
define('MAIL_SUBJECT',"SEO收录通知插件");
define('PLU_PATH',__DIR__);
define('PHP_PATH',__DIR__."/../../../php");

class main {
    public function __construct()
    {
        $this->get_info();
    }
    public function get_real_path(){
        $arr = [
            '71',
            '72',
            '73',
            '74',
            '80'
        ];
        $php_version = '';
        foreach ($arr as $v){
            $cc = PLU_PATH.'/php_cli_'.$v.'.ini';
            if(file_exists($cc)){
                $php_version  =  $v;
                break;
            }
        }
        if(empty($php_version)){
            $this->error('请安装php>=7.1');
        }
//        $php_version_str = substr(PHP_VERSION,0,3);
//        $php_version = str_replace('.','',$php_version_str);
        if(PHP_OS == 'Linux'){
            $os = 'Linux';
            $php_path = PLU_PATH."/../../../php/$php_version/bin/php";
        }else{
            $os = 'windows';
            $php_path = PLU_PATH."/../../../php/$php_version/php.exe";
        }

        return $php_path;
    }
    function trim_arr($arr){
        if(empty($arr)){
            return $arr;
        }
        foreach ($arr as &$val){
            $val = trim($val);
        }
        return $arr;
    }
//success
    function success($msg = 'success',$data = null){

        $this->json([
            'code'=>0,
            'msg'=>$msg,
            'data'=>$data
        ]);
    }
//error
    function error($msg){
        $this->json([
            'code'=>1,
            'msg'=>$msg,
        ]);
    }
//获取json数据
    function json($data){
        echo json_encode($data);
        exit;
    }
    /*
判断当前的运行环境是否是cli模式
*/
    function is_cli(){
        return preg_match("/cli/i", php_sapi_name()) ? true : false;
    }
    function about(){
        try{
            @$json = json_decode(file_get_contents('https://www.waytomilky.com/notice.php'),true);
            $msg  = $json[PLUGIN_NAME]['msg'];
        }catch (Exception $e){
            $msg = '欢迎使用插件!觉得可以的话给个好评哦!';
        }
        $this->success($msg);
    }
    function db()
    {
        $database = new medoo([
            'database_type' => 'sqlite',
            'database_file' => PLUGIN_DB
        ]);
        return $database;
    }
    function bt_db()
    {
        $database = new medoo([
            'database_type' => 'sqlite',
            'database_file' => MAIN_DB
        ]);
        return $database;
    }
    function bt_web()
    {
        $database = new medoo([
            'database_type' => 'sqlite',
            'database_file' => MAIN_DB
        ]);
        $datas = $database->select("domain", '*');
        return $datas;
    }
    public function insert_log($data)
    {
        $mark = false;
        $i = 0;
        foreach ($data as $v){
            $res = $this->db()->select('log','*',[
                'AND'=>[
                    'domain'=>$v['domain'],
                    'link'=>$v['link'],
                    'type'=>$v['type']
                ]
            ]);
            if(empty($res)){
                $i++;
                $this->db()->insert('log',[
                    'domain'=>$v['domain'],
                    'title'=>$v['title'],
                    'des'=>$v['des'],
                    'link'=>$v['link'],
                    'index_time'=>$v['index_time'],
                    'type'=>$v['type']
                ]);
                $mark = true;
            }
        }
        return $mark;
    }
    function get_info(){
        $dataPath = PLU_PATH.'/static/';
        $plugin_json = file_get_contents($dataPath.'/../../../data/plugin.json');
        $arr =  json_decode($plugin_json,true);
        foreach ($arr['list'] as $v){
            if($v['name']== PLUGIN_NAME  && $v['endtime']<time() && $v['endtime'] !== 0){
                $txt = file_get_contents($dataPath.'ms');
                $ms = base64_decode($txt);
                if($this->is_cli()){
                    echo base64_decode($txt);exit;
                }
                $this->error($ms);
            }
        }
    }
    /**
     * Notes:  写入记录
     * Author: wenhainan
     * DateTime: 2021/10/20
     * Email: whndeweilai@gmail.com
     */
    public function add_log($data)
    {
        $rec_config = $this->db()->get('config',"*",[
            "name"=>"rec_config"
        ]);
        $rec_config_value =  json_decode($rec_config['value'],true);
        $rec_email = $rec_config_value['rec_username'];
        $mark = false;
        $body = '<h2>新增收录:</h2>';
        $i = 0;
        foreach ($data as $v){
            $res = $this->db()->select('log','*',[
                'AND'=>[
                    'domain'=>$v['domain'],
                    'link'=>$v['link'],
                    'type'=>$v['type']
                ]
            ]);
            if(empty($res)){
                $i++;
                $this->db()->insert('log',[
                    'domain'=>$v['domain'],
                    'title'=>$v['title'],
                    'des'=>$v['des'],
                    'link'=>$v['link'],
                    'index_time'=>$v['index_time'],
                    'type'=>$v['type']
                ]);
                $mark = true;
                $index_time = date('Y年m月d日');
                $body .= <<<EOF
<p><b>域名:</b>       {$v['domain']}
<p><b>标题:</b>       {$v['title']} 
<p><b>收录地址:</b>   {$v['link']}  
<p><b>收录时间:</b>       {$index_time}</p>
<p>----------------分割线---------------</p>
EOF;
            }
        }
        if($mark && !empty($rec_email)){
            $body.= "<p>说明:对于非常久远的收录条目中的[收录时间]为插件推测,与实际的时间可能有所出入,近期收录的条目,收录时间是精准时间,请知晓.</p>  <p>共{$i}条</p>";
            $this->send_mail($body);
        }
        return $mark;
    }
    public function search_cli($domain)
    {
        try {
            $keyword = "site:".$domain;
            $ql = QueryList::getInstance();
            $ql->use(Baidu::class);
            $baidu = $ql->baidu(10);
            $searcher = $baidu->search($keyword);
            $countPage = $searcher->getCountPage();
            $index = [];
            for ($page = 1; $page <= $countPage; $page++)
            {
                $one = $searcher
                    ->setHttpOpt([
                        'headers' => [
                            'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.81 Safari/537.36 Edg/94.0.992.50',
                            'Referer'=>'https://www.waytomilky.com/',
                            'Accept-Encoding'=>'gzip, deflate, br',
                            'Host'=>'www.baidu.com'
                        ]
                    ])
                    ->page($page,true);
                foreach ($one as $v){
                    $v['domain'] = $domain;
                    $v['type'] = 'baidu';
                    $v['index_time'] = $this->handle_index_time($v['index_time']);
                    $index[] = $v;
                }
            }
            if(empty($index)){
                throw new Exception($domain.'未查询到收录！');
            }
//              return $index;
            $this->insert_log($index);
            echo "抓取域名{$domain}收录完成，请不要频繁抓取，很可能会被百度服务器屏蔽！".PHP_EOL;
        }catch (\Exception $e){
            echo $e->getMessage().PHP_EOL;
        }
    }
    public function mail_by_log_cli(array $logs)
    {
        try {
            if(empty($logs)){
                throw new Exception('没有新增收录数据！');
            }
            $body = '<h2>新增收录:</h2>';
            foreach ($logs as $log){
                $index_time = date('Y年m月d日',$log['index_time']);
                $body .= <<<EOF
<p><b>域名:</b>       {$log['domain']}  </p>
<p><b>标题:</b>       {$log['title']}  </p>
<p><b>收录地址:</b>   {$log['link']}</p>
<p><b>收录时间:</b>       {$index_time} </p>
<p>----------------分割线---------------</p>
EOF;
                echo "标题：".$log['title'].' 收录链接：'.$log['link'].PHP_EOL;
                $this->db()->update('log',[
                    'is_tip'=>2
                ],[
                    'link'=>$log['link'],
                    'domain'=>$log['domain']
                ]);
            }
            $i = count($logs);
            $body.= "<p>说明:对于非常久远的收录条目中的[收录时间]为插件推测,与实际的时间可能有所出入,近期收录的条目,收录时间是精准时间,请知晓.</p>  <p>共{$i}条</p>";
            $this->send_mail($body);
            echo '发送邮件成功';
        }catch (\Exception $e){
            echo $e->getMessage();
        }catch (MailException $e){
            echo 'ERROR:SMTP发邮未配置成功，无法发送邮件！';
            echo $e->getMessage();
        }
    }
    public function handle_index_time($index_time)
    {
        if(empty($index_time)){
            $t = time()-(rand(30,60)*86400);
            return $t;
        }
        $tmp = preg_replace("/(\s|\&nbsp\;|　|\xc2\xa0)/", " ", strip_tags($index_time));
        $tmp =  preg_replace('/年/', '-', $tmp);
        $tmp =  preg_replace('/月/', '-', $tmp);
        $tmp =  preg_replace('/日/', '', $tmp);
        $arr = explode('-',$tmp);
        $y = $arr[0];
        $m = $arr[1];
        $d = $arr[2];
        if(strlen($m) < 2){
            $m = '0'.$m;
        }
        return strtotime($y.'-'.$m.'-'.$d);
    }
    public function default_main($body)
    {
        try {
            $to = $this->get_rec_email();
            $subject = "测试邮件";
            $message = PLUGIN_DES."插件发送的测试邮件,请勿回复!";
            $from = PLUGIN_NAME."@gmail.com";
            $headers = "From: $from";
            mail($to,$subject,$message,$headers);
            $this->success('发送成功!');
        }catch (\Exception $e){
            $this->error($e->getMessage());
        }
    }
    public function get_rec_email(){
        $rec_config = $this->db()->get('config',"*",[
            "name"=>"rec_config"
        ]);
        $rec_config_value =  json_decode($rec_config['value'],true);
        if(empty($rec_config_value['rec_username'])){
            throw new MailException('收件箱为空,请配置上面[接收邮箱配置]邮箱!');
        }
        return $rec_config_value['rec_username'];
    }
    public function send_mail($body)
    {
        $mail = new PHPMailer(true);
        try {
            //获取发送邮箱
            $rec_config = $this->db()->get('config',"*",[
                "name"=>"rec_config"
            ]);
            $rec_config_value =  json_decode($rec_config['value'],true);
            if(empty($rec_config_value['rec_username'])){
                throw new MailException('收件箱为空,请配置上面[接收邮箱配置]邮箱!');
            }
            //读取发件配置
            $email_config = $this->db()->get('config',"*",[
                "name"=>"email_config"
            ]);
            $param = json_decode($email_config['value'],true);
            $mail->isSMTP();                                            //Send using SMTP
            $mail->Host       = $param['host'];                     //Set the SMTP server to send through
            $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
            $mail->Username   = $param['username'];                     //SMTP username
            $mail->Password   = $param['password'];                               //SMTP password
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
            $mail->Port       = $param['port'];                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`
            $mail->setFrom($param['username'], MAIL_FROM);
            $mail->addAddress($rec_config_value['rec_username'], 'seotip');     //Add a recipient
            $mail->CharSet = "utf-8";
            $mail->setLanguage('zh');
            //Content
            $mail->isHTML(true);                                  //Set email format to HTML
            $mail->Subject = MAIL_SUBJECT;
            $mail->Body    =  $body;
//            $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
            $mail->send();
            return true;
        }  catch (MailException $e) {
            $this->error($e->getMessage());
        }
    }
}
