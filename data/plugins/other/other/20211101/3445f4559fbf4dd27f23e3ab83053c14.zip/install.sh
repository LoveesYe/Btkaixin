#!/bin/bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH

#配置插件安装目录
install_path=/www/server/panel/plugin/seotip
plugin_name=SEO收录通知插件
#安装
Install()
{
  echo '================================================'
	echo '正在安装'$plugin_name
	echo "插件依赖PHP，推荐php7.1,如果没有请安装..."
  sleep 5s
	echo '================================================'
	echo '安装完成'
}
#卸载
Uninstall()
{
  cp -p install_path"/seotip.db" /tmp
	rm -rf $install_path
}

#操作判断
if [ "${1}" == 'install' ];then
	Install
	sleep 1s
	cp  /tmp/seotip.db  install_path
elif [ "${1}" == 'uninstall' ];then
	Uninstall
else
	echo 'Error!';
fi
