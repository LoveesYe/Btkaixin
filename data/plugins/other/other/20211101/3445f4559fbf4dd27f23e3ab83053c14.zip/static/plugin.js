
//定义窗口尺寸
$('.layui-layer-page').css({
    'width': '1000px',
    'height':'800px'
});

//左测菜单切换效果
$(".bt-w-menu p").click(function () {
    $(this).addClass('bgw').siblings().removeClass('bgw')
});
//第一次打开窗口时调用
show_search();
//站点配置
function  get_index() {
    var load = layer.load();
    add_sync_task();
    request_plugin('get_web_list',{},function (res){
        layer.close(load);
        var tbody  = "";
        res.data.forEach(function (value,key) {
            var cla = value.status == 1?'success':'danger';
            var status_str = value.status == 1?'<span style="color: green">开启</span>':'关闭';
            tbody += "<tr>" +
                "<td>"+value.name+"</td>" +
                "<td>"+status_str+"</td>" +
                "<td>"+value.baidu_num+"</td>" +
                "<td>" +
                "<button onclick='change_domain(this)' data-value='"+value.name+"' class='btn btn-normal  btn-xs'>修改状态</button>" +
                "</td>" +
                "</tr>";
        })
        var html =
            "<div class='u_main'>" +
            "<p>插件会自动创建定时任务，用于定时查询收录并推送至邮件。<a class='btlink' target='_blank' href='/crontab'>查看定时任务</a></p>" +
            "<table class='table table-hover'>" +
            "<thead>" +
            "<th>网站</th>" +
            "<th>状态(是否启用邮件通知)</th>" +
            "<th>百度收录数量(需[更新收录]后出现)</th>" +
            "<th width='120'>操作栏</th>" +
            "</thead>" +
            "<tbody>"+
            tbody +
            "</tbody>" +
            "</table>"+
            "</div>";
        $('.plugin_body').html(html);
    })
}
function remember() {
    var host  =  $("select[name = host]").val();
    localStorage.setItem("host",host);
}
function show_search()
{
    var html =
        "<div class='u_main'>" +
        '<p> <label>网站</label> <select onchange="get_logs(1)"   name="domain" class="bt-input-text"></select>&nbsp;&nbsp;' +
        '<button onclick="search()" class="btn btn-sm btn-success">更新收录</button> </p>' +
        "<div class='u_output'></div>" +
        "<div class='u_output_page page pull-right'></div>" +
        "</div>";
    $('.plugin_body').html(html);
    request_plugin('get_web_list',{},function (res) {
        var op = '<option>请选择网站</option>';
        res.data.forEach(function (value,key) {
            op+= "<option>"+value.name+"</option>";
        })
        $("select[name=domain]").html(op);
        var domain = localStorage.getItem('domain');
        console.log(domain);
        if(domain!==null){
            $("select[name=domain]").val(domain);
        }
        get_logs(1);
    })
}
function get_logs(p){
    var domain = $("select[name=domain]").val();
    localStorage.setItem("domain", domain);
    if (p == undefined){
        p = 1
    }
    var log_body = "<table class='table'><thead><th>标题</th><th>收录地址</th><th>时间</th><th>类型</th><th>操作</th></thead>";
    var  index = layer.load();
    request_plugin('get_logs',{p:p,domain:domain},function (rdata) {
        layer.close(index);
        var rdatas = rdata.data.data;
        rdatas.forEach(function(element) {
            log_body += '<tr>' +
                '<td>' + element.title.slice(0,15) + '</td>' +
                '<td><a class="btlink" target="_blank" href="'+element.link+'">' + element.link.slice(0,50) + '</a></td>' +
                '<td>' + element.index_time + '</td>' +
                '<td><span >' + element.type + '</span></td>' +
                '<td><button onclick="xq('+element.id+')"  class="btn btn-xs btn-success">详情</button></td>' +
                '</tr>';
        })
        log_body += '</table>';
        //console.log(log_body);
        $(".u_output").html(log_body);
        $(".u_output_page").html(rdata.data.page);
    })
}
function xq(id){
    var load = layer.load();
    request_plugin('xq',{id:id},function (res) {
        layer.close(load);
        var info = res.data;
        layer.open({
            title:'请求详情',
            type: 1,
            area: ['820px', '750px'], //宽高
            skin: 'layui-layer-dialog',
            closeBtn: 2,
            content: '<div style="margin-top: 10px;margin-left: 10px" class="u_main layer-modal">' +
                '<p><label style="display: inline-block;width: 90px;margin-right: 10px;text-align: right;">链接</label><a class="btlink" target="_blank" href="'+'info.link">'+info.link+'</a></p>' +
                '<p><label style="display: inline-block;width: 90px;margin-right: 10px;text-align: right;">标题</label>'+info.title+'</p>' +
                // '<p><label style="display: inline-block;width: 90px;margin-right: 10px;text-align: right;">域名</label>'+info.domain+'</p>' +
                '<p><label style="display: inline-block;width: 90px;margin-right: 10px;text-align: right;">描述</label>'+info.des+'</p>' +
                // '<iframe height="500px" width="100%" src="'+info.link+'" ></iframe>' +
                '</div>'
        })
    })
}
function search()
{
    var domain = $("select[name=domain]").val();
    var load = layer.msg('正在抓取已收录数据，并写入插件本地数据库...<br>但请不要频繁抓取,很可能会被百度封禁ip <br>如果被封禁,请过一段时间再使用此功能<br>[站点配置]完善后，会自动创建定时任务',{
        icon:16,
        time:0,
        area: [500,300]
    });
    request_plugin('search',{domain:domain},function (res) {
        layer.close(load);
        console.log(res);
        var datas = res.data;
        if(res.code === 0 && datas.length > 0){
            datas.forEach(function (v,k,arr) {
                console.log(v);
            })
        }
        tip(res,function () {
                get_logs(1);
        });
    })
}
function add_sync_task()
{
    request_plugin("add_sync_task",{},function (res) {
        if(res.code === 0){
            var shell = res.data.shell;
            //存储域名
            var args = {
                "name":res.data.name,
                "type":"hour-n",
                "where1":3,
                "hour":3,
                "minute": 30,
                "week":"",
                "sType": "toShell",
                "sBody": shell,
                "sName":"",
                "backupTo": "localhost",
                "save":"",
                "urladdress":""
            };
            $.ajax({
                type:'POST',
                url: '/crontab?action=AddCrontab',
                data: args,
                success: function(rdata) {
                    console.log(rdata);
                    //layer.msg(rdata.msg, { icon: rdata.status ? 1 : 2 });
                },
                error: function(ex) {
                    //layer.msg('请求过程发现错误!', { icon: 2 });
                }
            });
        }

    });
}
function get_rec(){
    var html =
        "<div class='u_main'>" +
        "<p><label>接收邮箱</label> <input placeholder='请输入接收邮箱，可与发送邮箱相同，建议QQ邮箱，方便接收' id='rec_username' name='rec_username' class='bt-input-text'></p>" +
        "<p><label></label> <button onclick='save_rec()' class='btn btn-success'>保存</button>&nbsp;&nbsp;<button onclick='test_rec()' class='btn '>测试接收</button> </p>" +
        "<p><label></label>[接收邮箱]可与[发送邮箱]一致哦,也可降低拦截概率.</p>" +
        "<p><label></label>邮件也可能被分类到垃圾箱中了,请留意哦!</p>" +
        "</div>";
    $('.plugin_body').html(html);
    var load = layer.load();
    request_plugin('get_rec',{},function (res) {
        console.log(res);
        layer.close(load);
        $("input[name=rec_username]").val(res.data.rec_username);
    })
}
function save_rec(){
    var rec_username = $("input[name=rec_username]").val();
    var load = layer.load();
    request_plugin('save_rec',{rec_username:rec_username},function (res) {
        layer.close(load);
        tip(res);
    })
}
function test_rec(){
    var rec_username = $("input[name=rec_username]").val();
    var load = layer.load();
    request_plugin('test_rec',{rec_username:rec_username},function (res) {
        layer.close(load);
        tip(res);
    })
}
function change_domain(obj)
{
    var domain = $(obj).attr('data-value');
    var index = layer.load(0, {shade: false});
    request_plugin('change_domain',{domain:domain},function (res) {
        console.log(res);
        tip(res,function () {
            layer.close(index);
            get_index();
        });
    })
}
function show_email()
{
    var html =
        "<div class='u_main'>" +
        "<p><label>SMTP服务器</label> <input  name='host' placeholder='发邮服务器,例如qq邮箱为smtp.qq.com,网易smtp.163.com'  class='bt-input-text'></p>" +
        "<p><label>端口</label> <input  name='port'  placeholder='SMTP发送服务端口一般为465' class='bt-input-text'></p>" +
        "<p><label>邮箱账号</label> <input placeholder='请输入邮箱账号' name='username' class='bt-input-text'></p>" +
        "<p><label>授权码</label> <input name='password' placeholder='请输入邮箱smtp授权码' class='bt-input-text'> <a class='btlink' target='_blank' href='https://service.mail.qq.com/cgi-bin/help?subtype=1&&id=28&&no=1001607'>如何获取QQ邮箱授权码</a> </p>" +
        "<p><label></label> <button onclick='save_email()' class='btn btn-success'>保存</button>&nbsp;&nbsp;" +
        // "<button onclick='test_email()' class='btn '>测试发送</button> " +
        "</p>" +
        "<p><label></label>1.默认显示的是<a class='btlink' target='_blank' href='https://service.mail.qq.com/cgi-bin/help?subtype=1&&id=14&&no=1000898'>QQ邮箱配置</a>,其余邮箱如网易邮箱需要参考对应SMTP发邮配置</p>" +
        "<p><label></label>2.此为邮箱发送服务的高级配置,性能更高更可靠,不容易被拦截.</p>" +
        "<p><label></label>3.windows服务器默认没有集成发邮服务,需要配置此项.Linux服务器默认直接本服务器发送,但是如果需要提高可靠性,建议配置此项</p>" +
        "</div>";
    $('.plugin_body').html(html);
    var load = layer.load();
    request_plugin('get_email',{},function (res) {
        layer.close(load);
        $("input[name=host]").val(res.data.host);
        $("input[name=port]").val(res.data.port);
        $("input[name=username]").val(res.data.username);
        $("input[name=password]").val(res.data.password);
    })
}
function test_email(){
    var host = $("input[name=host]").val();
    var port = $("input[name=port]").val();
    var username = $("input[name=username]").val();
    var password = $("input[name=password]").val();
    var load = layer.load();
    request_plugin('test_email',{host:host,port:port,username:username,password:password},function (res) {
        layer.close(load);
        tip(res);
    })
}
function save_email(){
    var host = $("input[name=host]").val();
    var port = $("input[name=port]").val();
    var username = $("input[name=username]").val();
    var password = $("input[name=password]").val();
    var load = layer.load();
    request_plugin('save_email',{host:host,port:port,username:username,password:password},function (res) {
        layer.close(load);
        tip(res);
    })
}
function about() {
    var tip = layer.msg('处理中...',{icon:16,time:0});
    request_plugin('about',{},function (res) {
        console.log(res);
        var msg = res.msg;
        if(msg == null){
            msg = "欢迎使用插件,觉得好的话给个好评哦!";
        }
        layer.close(tip);
        var html =
            "  <div id=\"404_logo\" align=\"center\"><a target='_blank' href='https://www.waytomilky.com/'><img src='https://www.waytomilky.com/usr/uploads/2019/04/2930328315.png'></a></div><br/>\n" +
            "                <div id=\"404_dev\" >\n" +
            "                    <table align=\"left\"  style=\"position:absolute; left:10%\" border=\"0\">\n" +
            "                        <tr ><td>&nbsp;</td></tr>\n" +
            "                        <tr ><td><a target='_blank' href='https://www.waytomilky.com/'>开发人员： 阿修罗</a></td></tr>\n" +
            "                        <tr ><td>&nbsp;</td></tr>\n" +
            "                        <tr ><td>官方网站： <a target='_blank' class='green' href='https://www.waytomilky.com/'>https://www.waytomilky.com/</a></td></tr>\n" +
            "                        <tr ><td>&nbsp;</td></tr>\n" +
            "                        <tr ><td>QQ群支持：<a target=\"_blank\" href=\"//shang.qq.com/wpa/qunwpa?idkey=289eaf4dfef0cc9220256b90ff502bef467767f6f790b817ce1cbe7658b5b3b3\"><img border=\"0\" src=\"//pub.idqqimg.com/wpa/images/group.png\" alt=\"PHP-LotusAdmin&amp;宝塔插件反\" title=\"PHP-LotusAdmin&amp;宝塔插件反\"></a></td></tr>\n" +


            "                        <tr ><td>&nbsp;</td></tr>\n" +
            "                        <tr ><td><b>使用说明,务必查看:</b></td></tr>\n" +

            "                        <tr ><td>&nbsp;</td></tr>\n" +
            "                        <tr ><td>1.插件依赖PHP7.1,不影响网站设置</td></tr>\n" +


            "                        <tr ><td>&nbsp;</td></tr>\n" +
            "                        <tr ><td><b>开发者公告:</b></td></tr>\n" +

            "                        <tr ><td>&nbsp;</td></tr>\n" +
            "                        <tr ><td>"+msg+"</td></tr>\n" +

            "                    </table>\n" +
            "                </div>\n" +
            "                </div>";

        $('.plugin_body').html(html);
    })


}


