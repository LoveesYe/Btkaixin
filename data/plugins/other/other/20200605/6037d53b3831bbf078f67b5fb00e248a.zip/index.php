<?php
class bt_main{
    //不允许被面板访问的方法请不要设置为公有方法
    protected $config_IP_wanted = "192.168.1.1";
    protected $x_email = 'test@test.com';
    protected $x_auth_key = '123c7592f7a9143441a91401904fac3513941';
    protected $json_file_with_domains_and_zone_id = 'json.txt';
    protected $url_list = '';
    protected $domainArr = array();

    public function geturl($url, $my_head_array = array()){
        $headerArray =array("Content-Type: application/json;","Accept: application/json");
        if(is_array($my_head_array) && count($my_head_array)){
            $headerArray = $my_head_array;
        }
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch,  CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headerArray);
        $output = curl_exec($ch);
        curl_close($ch);
        return $output;
    }

    public function posturl($url,$data = array(),$my_head_array = array()){
        $data = (is_array($data)) ? json_encode($data,JSON_UNESCAPED_UNICODE) : $data;

        $headerArray =array("Content-type:application/json;charset='utf-8'","Accept:application/json");
        if(is_array($my_head_array) && count($my_head_array)){
            $headerArray = $my_head_array;
        }
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        //curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
        //curl_setopt($curl, CURLOPT_SSL_VERIFYHOST,FALSE);
        curl_setopt($curl, CURLOPT_POST, 1);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
        curl_setopt($curl, CURLOPT_HTTPHEADER, $headerArray);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        $output = curl_exec($curl);
        curl_close($curl);
        return $output;
    }


    public function puturl($url,$data = array(),$my_head_array = array()){
        $data = (is_array($data)) ? json_encode($data,JSON_UNESCAPED_UNICODE) : $data;
        $headerArray =array("Content-type:application/json;charset='utf-8'","Accept:application/json");
        if(is_array($my_head_array) && count($my_head_array)){
            $headerArray = $my_head_array;
        }
        $ch = curl_init(); //初始化CURL句柄
        curl_setopt($ch, CURLOPT_URL, $url); //设置请求的URL
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headerArray);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER,1); //设为TRUE把curl_exec()结果转化为字串，而不是直接输出
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST,"PUT"); //设置请求方式
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);//设置提交的字符串
        $output = curl_exec($ch);
        curl_close($ch);
        return $output;
    }
    public function delurl($url, $my_head_array = array()){
        $headerArray =array('Content-type:application/json');
        if(is_array($my_head_array) && count($my_head_array)){
            $headerArray = $my_head_array;
        }
        $ch = curl_init();
        curl_setopt ($ch, CURLOPT_URL, $url);
        curl_setopt ($ch, CURLOPT_HTTPHEADER, $headerArray);
        curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt ($ch, CURLOPT_CUSTOMREQUEST, "DELETE");
        $output = curl_exec($ch);
        curl_close($ch);
        return $output;
    }
    public function p ($v = '-Your-Variable-Here-') {
        header('Content-Type: text/css; charset=utf-8');
        print_r($v);
        die;
    }

    public function exec(){
        $data = json_decode(_post('set_param'),true);
        $this->config_IP_wanted = $data['config_IP_wanted'];
        $this->x_email = $data['x_email'];
        $this->x_auth_key = $data['x_auth_key'];
        $this->url_list = $data['url_list'];
        $config_IP_wanted = $this->config_IP_wanted;
        $x_email = $this->x_email;
        $x_auth_key = $this->x_auth_key;

        $getJson = $this->getJson();
        if($getJson!==1){
            die($getJson);
        }
        if(!is_file($this->json_file_with_domains_and_zone_id)){
            die('缺少json文件');
        }
        $arr_domain_and_id = json_decode(file_get_contents($this->json_file_with_domains_and_zone_id), true);

        if(!is_array($arr_domain_and_id) || !count($arr_domain_and_id)){
            die('Invalid array for domains and zone ID');
        }

        /* Loop and check */
        $conf_wanted = array(
            'type' => 'A',
            'name' => '', // Your domain name
            'content' => $config_IP_wanted,
            'ttl' => 1,
            'proxied' => true
        );
        foreach ($arr_domain_and_id as $cur_domain => $cur_zone_id) {
            $childDomain = '';
            $cur_domain = strtolower(rtrim($cur_domain));
            $curl_head = array(
                "X-Auth-Email: {$x_email}",
                "X-Auth-Key: {$x_auth_key}",
                "Content-Type: application/json"
            );
            /* Get the list of DNS record at first */
            $curl_url_base = "https://api.cloudflare.com/client/v4/zones/{$cur_zone_id}/dns_records?type=A&page=1&per_page=20&order=type&direction=desc&match=any"; // 注意！结尾没有斜杠！
            $q_str = '';

            $curl_url_list = $curl_url_base.$q_str;

            $res_str = $this->geturl($curl_url_list, $curl_head);
            $res_arr = json_decode($res_str, true);
            if(!is_array($res_arr) || !count($res_arr) || !key_exists('success', $res_arr) || !$res_arr['success']){
                error_log('ERROR for '.$cur_domain.': '.$res_str.PHP_EOL);
                file_put_contents("fail.txt", $cur_domain.PHP_EOL, FILE_APPEND);
                continue;
            }
            $list_of_record = $res_arr['result'];

            foreach ($this->domainArr as $item){
                $headCheck = str_replace($cur_domain,"",strtolower($item));

                $headArr = explode(".",$headCheck);
                $doExec = 0;

                if((count($headArr)==2)&&(strlen($headArr[1])==0)){
                    //除根域名外的其他域名 有可能是www 有可能是其他的
                    $childDomain = $headCheck;
                    $doExec = 1;
                }else if(strlen($headCheck)==0){
                    //根域名
                    $doExec = 1;
                }
                if($doExec){
                    $childFlag = 0;
                    for($i=0;$i<count($list_of_record);$i++){
                        $putUrl = 'https://api.cloudflare.com/client/v4/zones/'.$list_of_record[$i]['zone_id'].'/dns_records/'.$list_of_record[$i]['id'];
                        if(($childFlag==1)){
                            break;
                        }
                        if(($list_of_record[$i]['name']==$childDomain.$cur_domain)&&($childFlag==0)){
                            $conf_wanted['name'] = $childDomain.$cur_domain;
                            echo $this->puturl($putUrl,$conf_wanted,$curl_head).PHP_EOL;
                            $childFlag = 1;
                        }
                    }
                    $postUrl = "https://api.cloudflare.com/client/v4/zones/{$cur_zone_id}/dns_records";
                    if($childFlag==0){
                        $conf_wanted['name'] = $childDomain.$cur_domain;
                        echo $this->posturl($postUrl,$conf_wanted,$curl_head);
                    }
                }
            }

        }
    }

    public function getJson()
    {
        $domains = explode(PHP_EOL,$this->url_list);

        for($i=0;$i<count($domains);$i++){
            $domains[$i] = strtolower(trim($domains[$i]));
            $this->domainArr[] = $domains[$i];
            $domainCheck = explode(".",$domains[$i]);
            if((count($domainCheck)==3)&&($domainCheck[0]!="www")){
                $domains[$i] = $domainCheck[1].'.'.$domainCheck[2];
            }
            $domains[$i] = strtolower(trim($domains[$i]));

        }

        $x_email = $this->x_email;
        $x_auth_key = $this->x_auth_key;
        $how_many_domains_you_have = 1000;  // Will be used as "per_page" in "Pagination"
        $final_list = array();
        for($pageCount=1;$pageCount<2;$pageCount++){
            $curl_url = "https://api.cloudflare.com/client/v4/zones?page={$pageCount}&per_page={$how_many_domains_you_have}&order=type&direction=asc";
            $curl_head = array(
                "X-Auth-Email: {$x_email}",
                "X-Auth-Key: {$x_auth_key}",
                "Content-Type: application/json"
            );


            $response_json_str = $this->geturl($curl_url, $curl_head);
            $res_arr = json_decode($response_json_str, TRUE);
//file_put_contents("result.txt",$response_json_str);
            if(!is_array($res_arr) || !count($res_arr)){
                die('Sorry, invalid response：<br />'.$response_json_str);
            }
            if(!key_exists('success', $res_arr) || !$res_arr['success']){
                die('Failed to get the list of zones: <br />'.$response_json_str);
            }

            if(!key_exists('result', $res_arr)){
                die('Missing key `result`: <br />'.$response_json_str);
            }

            $list_ori = $res_arr['result'];

            foreach ($list_ori as $k => $oneZone) {
                for($i=0;$i<count($domains);$i++){
                    if($oneZone['name'] === rtrim($domains[$i])){
                        $final_list[] = array(
                            'domain' => strtolower($oneZone['name']),
                            'id' => $oneZone['id']
                        );
                    }
                }
            }
        }

        $count_zones = count($final_list);
        //print_r("共有：".$count_zones);
        $i = 1;
        $result = '{';

        foreach ($final_list as $oneZone) {
            $result .= '    "'.$oneZone['domain'].'":"'.$oneZone['id'].'"';
            if($i != $count_zones){
                $result .= ',';
            }

            $i++;
        }
        $result .= '}';
        file_put_contents("json.txt",$result);
        return 1;
    }

}
?>