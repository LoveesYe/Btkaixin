<?php
//宝塔Linux面板插件demo for PHP
//@author 阿良<287962566@qq.com>

//必需面向对象编程，类名必需为bt_main
//允许面板访问的方法必需是public方法
//通过_get函数获取get参数,通过_post函数获取post参数
//可在public方法中直接return来返回数据到前端，也可以任意地方使用echo输出数据后exit();
//可在./php_version.json中指定兼容的PHP版本，如：["56","71","72","73"]，没有./php_version.json文件时则默认兼容所有PHP版本，面板将选择 已安装的最新版本执行插件
//允许使用模板，请在./templates目录中放入对应方法名的模板，如：test.html，请参考插件开发文档中的【使用模板】章节
//支持直接响应静态文件，请在./static目录中放入静态文件，请参考插件开发文档中的【插件静态文件】章节
class bt_main
{
    //不允许被面板访问的方法请不要设置为公有方法
    private $sqlPath = PLU_PATH;

    public function portblast()
    {
        $ip = _post('ip');
        $dk = _post('dk');
        if ($ip == '' || $dk == '') {
            return ['state' => '0'];
        }
        //IP拆分为数组之后判断是否为正确的IP
        $ips = explode(".", $ip);

        if (intval($ips[0]) < 1 or intval($ips[0]) > 255 or intval($ips[3]) < 1 or intval($ips[3] > 255)) {
            return ['state' => '0'];
        }

        if (intval($ips[1]) < 0 or intval($ips[1]) > 255 or intval($ips[2]) < 0 or intval($ips[2] > 255)) {
            return ['state' => '0'];
        }

        $fp = @fsockopen($ip, $dk, $errno, $errstr, 1); //打开数据流

        if (!$fp) {
            //如果打开出错
            $arr = array('ip' => $ip, 'dk' => $dk, 'state' => '0');
            return $arr; //输出内容
        } else {
            //如果成功打开
            $arr = array('ip' => $ip, 'dk' => $dk, 'state' => '1');
            fclose($fp);
            return $arr;
        }
    }

    // 获取常用端口及服务器IP
    public function get_portblast()
    {
        $portList = '21.22.23.25.79.80.110.135.137.138.139.143.443.445.888.1433.3306.3311.3312.3389.8888';
        $serverIp = $_SERVER['HTTP_HOST'] ? $_SERVER['HTTP_HOST'] : '127.0.0.1';
        return $this->buildSuccess('请求成功', ['portList' => $portList, 'serverIp' => $serverIp]);
    }

    /**
     * 获取IP
     * @Author   Youngxj
     * @DateTime 2019-08-08
     * @return   [type]     [description]
     */
    public function getip()
    {
        $unknown = '127.0.0.1';
        if (isset($_SERVER['HTTP_X_FORWARDED_FOR']) && $_SERVER['HTTP_X_FORWARDED_FOR'] && strcasecmp($_SERVER['HTTP_X_FORWARDED_FOR'], $unknown)) {
            $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        } elseif (isset($_SERVER['REMOTE_ADDR']) && $_SERVER['REMOTE_ADDR'] && strcasecmp($_SERVER['REMOTE_ADDR'], $unknown)) {
            $ip = $_SERVER['REMOTE_ADDR'];
        }
        $ip = preg_match("/[\d\.]{7,15}/", $ip, $matches) ? $matches[0] : $unknown;
        if (false !== strpos($ip, ',')) {
            $ip = reset(explode(',', $ip));
        }

        return $ip;
    }

    /**
     * 获取网站状态码采用curl
     * @return array
     */
    public function webCode()
    {
        $url = _post('url');
        if (!$url) {
            return $this->buildError('请输入网址');
        }
        if (!$this->is_http($url)) {
            $url = 'http://' . $url;
        }
        $state = $this->curl_StatusCode($url);
        if ($state) {
            return $this->buildSuccess('请求成功', ['url' => $url, 'code' => $state]);
        } else {
            return $this->buildError();
        }
    }

    /**
     * 获取网页源代码
     * @return array
     */
    public function webViewSource()
    {
        $url = _post('url');
        if (!$this->is_http($url)) {
            $url = 'http://' . $url;
        }
        if ($post = _post('post')) {
            $b = explode("&", $post);
            $arr1 = array();
            foreach ($b as $a) {
                $tmp = explode('=', $a);
                $arr1[$tmp[0]] = $tmp[1];
            }
            $post = $arr1;
        }
        $cookie = _post('cookie');
        $re_cookie = _post('re_cookie');
        $ua = _post('ua');
        $referer = _post('post.referer');
        $string = $this->curl_request($url, $post, $cookie, $re_cookie, $ua, $referer);
        if (!$string) {
            return $this->buildError();
        }

        return $this->buildSuccess('请求成功', ['ViewSource' => $string]);

    }

    /**
     * 百度查询链接是否收录
     * @return array
     */
    public function urlBaiduUrl()
    {
        $url = _post('url');
        if (!$this->is_http($url)) {
            $url = 'http://' . $url;
        }
        $query = $this->baiduWd($url);
        if (!$query) {
            return $this->buildError('未收录');
        }
        return $this->buildSuccess('已收录');

    }

    /**
     * 百度site查询域名收录数量
     * @return array
     */
    public function urlBaiduSite()
    {
        $domain = _post('domain');
        // 百度搜索地址http://www.baidu.com/s?wd=site:www.youngxj.cn
        $baidu = 'http://www.baidu.com/s?wd=site:' . $domain;

        $rs = $this->curl_request($baidu);

        $str = preg_match_all('/<b>找到相关结果数约(.*?)个<\/b>/', $rs, $baidu);

        if (!empty($str)) {
            // 没有站点信息
            return $this->buildSuccess('请求成功', ['domain' => $domain, 'num' => $baidu['1']['0']]);
        } else {
            // 有站点信息
            $str = preg_match_all('/<b style="color:#333">(.*?)<\/b>/', $rs, $baidu);

            if ($str) {
                return $this->buildSuccess('请求成功', ['domain' => $domain, 'num' => $baidu['1']['0']]);
            } else {
                return $this->buildError('该域名暂时未收录', ['domain' => $domain, 'num' => 0]);
            }

        }
    }

    // 百度关键词排行
    public function domainRank()
    {
        $k = _post('keyword');// 关键词
        $u = _post('domain');// 域名
        if (empty($k) || empty($u)) {
            return $this->buildError('请填写关键词和域名');
        }
        $rn = '50';
        // 百度查询地址
        $url = "https://www.baidu.com/s?ie=utf-8&wd=" . $k . "&rn=" . $rn;

        $ch = curl_init();

        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HEADER, false);

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.1 Safari/537.11');

        $res = curl_exec($ch);

        $rescode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

        curl_close($ch);

        preg_match_all('/<div class=\"f13\">(.*?)<\/div>/si', $res, $p);

        for ($ii = 0; $ii < COUNT($p[1]); $ii++) {

            $pos = strpos($p[1][$ii], $u);
            // 循环判断是否有域名关键词
            if (is_integer($pos)) {
                $rn = $ii + 1;
                break;
            }
        }
        return $this->buildSuccess('请求成功', ['domain' => $u, 'keyword' => $k, 'rank' => $rn]);
    }

    // 获取网页状态码
    private function curl_StatusCode($url)
    {
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_HEADER, 1);
        curl_setopt($curl, CURLOPT_NOBODY, true);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        $data = curl_exec($curl);
        return curl_getinfo($curl, CURLINFO_HTTP_CODE);
        curl_close($curl);
    }

    // 判断是否为链接
    private function is_url($str)
    {
        //域名正则匹配
        return preg_match("/^((https?|ftp|news):\/\/)?([a-z]([a-z0-9\-]*[\.。])+([a-z]{2}|aero|arpa|biz|com|coop|edu|gov|info|int|jobs|mil|museum|name|nato|net|org|pro|travel|vip|xyz)|(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5]))(\/[a-z0-9_\-\.~]+)*(\/([a-z0-9_\-\.]*)(\?[a-z0-9+_\-\.%=&]*)?)?(#[a-z][a-z0-9_]*)?$/", $str);
    }

    // 判断是否为http/https
    private function is_http($url)
    {
        //判断网址后否包含http || https
        if (preg_match("/^(http:\/\/|https:\/\/).*$/", $url)) {
            return 1;
        } else {
            return 0;
        }
    }

    // 返回成功
    private function buildSuccess($msg = '请求成功', $data = [])
    {
        header('content-type:application/json;charset=utf-8');
        return ['code' => 1, 'msg' => $msg, 'data' => $data];
    }

    // 返回失败
    private function buildError($msg = '请求失败', $data = [])
    {
        header('content-type:application/json;charset=utf-8');
        return ['code' => 0, 'msg' => $msg, 'data' => $data];
    }

    /**
     * curl模拟请求
     * 参数1：访问的URL，参数2：post数据(不填则为GET)，参数3：提交的$cookies,参数4：是否返回$cookies，参数5：自定义UA，参数6：自定义来路
     * @param  [type]  $url          [description]
     * @param string  $post [description]
     * @param string  $cookie [description]
     * @param integer $returnCookie [description]
     * @param string  $ua [description]
     * @return [type]                [description]
     */
    public function curl_request($url, $post = '', $cookie = '', $returnCookie = 0, $ua = 'Mozilla/5.0 (compatible; Baiduspider/2.0; +http://www.baidu.com/search/spider.html)', $referer = 'https://www.baidu.com')
    {
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_USERAGENT, $ua);
        curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($curl, CURLOPT_AUTOREFERER, 1);
        curl_setopt($curl, CURLOPT_REFERER, $referer);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
        if ($post) {
            curl_setopt($curl, CURLOPT_POST, 1);
            curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($post));
        }
        if ($cookie) {
            curl_setopt($curl, CURLOPT_COOKIE, $cookie);
        }
        curl_setopt($curl, CURLOPT_HEADER, $returnCookie);
        curl_setopt($curl, CURLOPT_TIMEOUT, 10);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        $data = curl_exec($curl);
        if (curl_errno($curl)) {
            return curl_error($curl);
        }
        curl_close($curl);
        if ($returnCookie) {
            list($header, $body) = explode("\r\n\r\n", $data, 2);
            preg_match_all("/Set\-Cookie:([^;]*);/", $header, $matches);
            $info['cookie'] = substr($matches[1][0], 1);
            $info['content'] = $body;
            return $info;
        } else {
            return $data;
        }
    }

    // 百度收录查询
    private function baiduWd($url)
    {
        $url = 'http://www.baidu.com/s?wd=' . $url;
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        $rs = curl_exec($curl);
        curl_close($curl);
        if (!strpos($rs, '没有找到')) {
            return 1;
        } else {
            return 0;
        }
    }

}
