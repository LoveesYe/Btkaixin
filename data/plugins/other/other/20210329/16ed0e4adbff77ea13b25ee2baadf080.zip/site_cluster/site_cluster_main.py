#!/usr/bin/python
# coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: xxx <xxxx@qq.com>
# +-------------------------------------------------------------------

#+--------------------------------------------------------------------
#|   宝塔第三方应用开发site_cluster
#+--------------------------------------------------------------------
import sys,os,json,time

#设置运行目录
os.chdir("/www/server/panel")

#添加包引用位置并引用公共包
sys.path.append("class/")
import public,crontab

#from common import dict_obj
#get = dict_obj();


#在非命令行模式下引用面板缓存和session对象
if __name__ != '__main__':
    from BTPanel import cache,session,redirect

    #设置缓存(超时10秒) cache.set('key',value,10)
    #获取缓存 cache.get('key')
    #删除缓存 cache.delete('key')

    #设置session:  session['key'] = value
    #获取session:  value = session['key']
    #删除session:  del(session['key'])


class site_cluster_main:
    __plugin_path = "/www/server/panel/plugin/site_cluster/"
    __scan_log = __plugin_path + "map_log.json"
    config_file = __plugin_path + 'config.json'
    __config = {'site_data':[],"map_interval":"day","scan_log":__scan_log,"site_type":"1","mip_status":"no"}
    __data_path = __plugin_path + 'site_data/'
    __robots_template =  __plugin_path + "robots-template"
    __robots_history = ""
    #构造方法
    def  __init__(self):
        if not os.path.exists(self.config_file):
            self.__set_config()
        if not os.path.exists(self.__data_path):
            os.mkdir(self.__data_path)
        if os.path.exists("/www/server/panel/pyenv/bin/python"):
            self.pypath="/www/server/panel/pyenv/bin/python"
        else:
            self.pypath="python"


    def create_del_update(self,args):
        tmp={}
        type=args.b_type
        web_url=args.web_url.strip().split("/")[0:3]
        web_url = web_url[0] +"//" + web_url[2]

        token=args.token.strip()
        create_time = time.strftime("%Y-%m-%d %H:%M:%S")
        site_data=self.__get_config('site_data')
        msg = "未知错误"
        if type =='1': #创建或更新
            tmp['web_url'] = web_url
            tmp['token'] = token
            tmp['addtime'] = create_time
            msg = '添加成功'
            if site_data:#更新
                flag=True
                for index,value in enumerate(site_data):
                    if value['web_url'] == web_url:#更新
                        site_data[index]=tmp
                        msg = '更新成功'
                        flag=False
                if flag:site_data.append(tmp)
            else:   #创建
                site_data.append(tmp)
        elif type == '2': #删除
            msg = '删除成功'
            for index,value in enumerate(site_data):
                if value['web_url'] == web_url:
                    del site_data[index]
        self.__set_config('site_data',site_data)
        return {'status':True,'msg':msg}

    #批量创建site robots
    def create_site_robots(self,args):
        if sys.version_info[0] == 2:
            from urlparse import urlparse
        else:
            from urllib.parse import urlparse
        site_data=self.__get_config('site_data')
        bt_data = public.M('sites').field('name,addtime,path').order('id desc').select()
        tmp=[]
        for site in site_data:
            domain = urlparse(site["web_url"]).netloc
            site_in_db = public.M("sites").field('name,addtime,path').where("name=?",domain).select()
            if len(site_in_db) >0: ##代表是本地网站
                site_base_path=site_in_db[0]['path'] + "/"
                robots_path= site_base_path + "robots.txt"
                robots_content = "error"
                try:
                    file = open(self.__robots_template,mode="r")
                    robots_content = file.readlines()
                    file.close()
                except Exception as e:
                    if sys.version_info[0] != 2:
                        try:
                            file = open(self.__robots_template, mode="r", encoding="utf-8")
                            robots_content = file.readlines()
                            file.close()
                        except Exception as ex2:
                            return {"status":False,'msg':"读取文件错误%s"%str(ex2)}
                new_content = ""
                sitemap_path = site_base_path + domain + "1.xml"
                if os.path.exists(sitemap_path):
                    path_tmp = site["web_url"].split("/")[0:3]
                    path_tmp = path_tmp[0] + "//" + path_tmp[2] + "/" + domain + "1.xml"
                    for i in robots_content:
                        if i.find("Sitemap") != -1:
                            i = "Sitemap: %s"%path_tmp
                        new_content += i
                else: #未找到 扫描的sitemap文件 直接使用模板
                    new_content = "".join(robots_content)
                public.WriteFile(robots_path,new_content)
                now = time.strftime("%Y-%m-%d %H:%M:%S")
                data = site["web_url"].split("/")[0:3]
                link_path = data[0]+"//"+data[2]+"/" + "robots.txt"
                tmp.append({"addtime":now,"name":site["web_url"],"link":link_path})
        self.__set_config("data",tmp,config_file=self.__plugin_path +"robots-history.json")
        self.write_logs("一键生成所有站点robots文件完成")
        return {"status":True,'msg':"创建成功,请查看记录","data":bt_data}

    def delete_robots_history(self,args):
        name = args.sitename
        history_data = self.__get_config("data",config_file=self.__plugin_path +"robots-history.json")
        for item in history_data:
            if item['name'] == name:
                history_data.remove(item)
        self.__set_config("data",history_data, config_file=self.__plugin_path + "robots-history.json")
        return {"status": True, 'msg': "删除成功"}
    def delete_map_history(self,args):
        name=args.sitename
        scan_type=args.scan_type
        all_history_data = self.__get_config("data", config_file=self.__plugin_path + "map_log.json")
        for item in all_history_data:
            if item['name'] == name and item['scan_type']==scan_type:
                all_history_data.remove(item)
        self.__set_config("data",all_history_data,config_file=self.__plugin_path + "map_log.json")
        return {"status": True, 'msg': "删除成功"}

    def del_log(self,args):
        ret=public.M('logs').where('type=?', (u'site_cluster',)).delete()
        return public.returnMsg(True, '清理成功')

    def sync_bt_data(self,args):
        # 2020-07-07 16:39:58
        default_token= self.__get_config("baidu_token")
        bt_data=public.M('sites').field('name,addtime,path').order('id desc').select()
        site_data=self.__get_config('site_data')
        success_num=0
        for item in bt_data:
            is_exist=False
            if not item['name'].startswith("http://"):
                try:
                    port = public.M("domain").field("port").where("name=?", (item['name'])).select()[0]['port']
                except Exception as e:
                    port="80"
                else:
                    port = "80"
                if port == "80":
                    web_url = "http://" + item['name']
                else:
                    web_url = "https://" + item['name']
            else:
                web_url = item['name']
            for key in site_data:
                if web_url == key['web_url']:is_exist=True
            if not is_exist:
                success_num+=1
                site_data.append({"web_url":web_url,"token":default_token,"addtime":item['addtime'],"path":item["path"]})
        self.__set_config('site_data',site_data)
        self.write_logs("成功同步%d个网站到插件"%success_num)
        return {"status": True, 'data': bt_data,"msg":"同步成功"}

    def scan_site_map(self,args):
        task_num = public.ExecShell("ps -aux|grep '%ssite_task.py'|grep -v grep|wc -l"%self.__plugin_path)[0].strip()
        if "time_interval" in args: #定时任务
            task={}
            time_interval = args.time_interval
            time_interval_txt = args.time_interval_txt
            task_name = '[站群管理插件][定时每' + time_interval_txt+"]扫描网站"
            task['type'] = time_interval
            task['sBody'] = "%s %ssite_task.py 定时扫描"%(self.pypath,self.__plugin_path)
            if time_interval == 'week':
                task['week']='6'
            elif time_interval == 'month':
                task['where1']='15'
            result = self.crontab_task(task_name,task)
            return result
        else:
            if task_num != "0": #说明任务运行中
                return {"status": False, 'msg': "任务运行中,请稍后重试"}
            #构造临时参数文件
            shell='''nohup %s %ssite_task.py 一键扫描 &''' % (self.pypath, self.__plugin_path)
            ret = public.ExecShell(shell)
            return {"status": True, 'msg': "任务创建成功","debug":shell}

    def baidu_push(self,args):
        ret = {"status":True,"msg":"任务运行中，请勿重复执行"}
        tip={"day":"日",'week':"周","month":"月"}
        push_type = args.push_type
        push_site = args.push_site
        task_type = args.task_type
        push_time = args.push_time
        if task_type == "time_interval": #定时任务
            task = {}
            task_name = '[站群管理插件][定时每' + tip[push_time] + "]推送网站:"+push_site +'推送类型:'+push_type
            task['type'] = push_time
            task['sBody'] = "%s %sweb_push.py %s %s" % (self.pypath,self.__plugin_path,push_site,push_type)
            if push_time == 'week':
                task['week']='6'
            elif push_time == 'month':
                task['where1']='15'
            result = self.crontab_task(task_name,task)
            if result['status']:
                self.write_logs("定时任务%s网址，推送类型%s"%(push_site,push_type))
            return result
        else:
            shell = "%s %sweb_push.py %s %s"%(self.pypath,self.__plugin_path,push_site,push_type)
            result = public.ExecShell(shell)
            self.write_logs("手动推送%s网址，推送类型%s"%(push_site,push_type))
            return ret

    def custom_filter(self,item_list,name,filter_str):
        new_list=[]
        for item in item_list:
            if item[filter_str].find(name) != -1:
                new_list.append(item)
        return new_list

    def get_site_data(self,args):
        if not 'p' in args: args.p = 1
        if not 'rows' in args: args.rows = 100
        if not 'callback' in args: args.callback = ''
        if "sort_by_time" not in args:
            args.sort_by_time="asc"
        if args.sort_by_time == "asc":
            sort_type=False
        else:sort_type=True
        search_str = args.search_name
        args.p = int(args.p)
        args.rows = int(args.rows)
        site_data = self.__get_config('site_data')
        site_data = sorted(site_data, key = lambda i: i['addtime'],reverse=sort_type)
        count = len(site_data)
        page_data = public.get_page(count, args.p, args.rows, args.callback)
        site_data = site_data[args.p * args.rows - args.rows:args.p * args.rows]
        if search_str != "":
            site_data = self.custom_filter(site_data,search_str,"web_url")
        return {"status":True,"page":page_data['page'],'data':site_data,"rows":args.rows}

    def scan_site_data(self,args):
        tmp={'status':True,'data':[]}
        if len(os.listdir(self.__data_path)) > 0:
            for site_name in os.listdir(self.__data_path):
                tmp['data'].append(site_name)
        else:
            tmp['status']=False
        return tmp

    def get_push_log(self,args):
        tmp = {'status': True,"log":""}
        if os.path.exists(self.__plugin_path+"push.log"):
            log_file=public.ReadFile(self.__plugin_path+"push.log")
            tmp['log']=log_file
        return tmp

    def get_robots_history(self,args):
        if not 'p' in args: args.p = 1
        if not 'rows' in args: args.rows = 100
        if not 'callback' in args: args.callback = ''
        if "sort_by_time" not in args:
            args.sort_by_time="asc"
        if args.sort_by_time == "asc":
            sort_type=False
        else:sort_type=True
        args.p = int(args.p)
        args.rows = int(args.rows)
        history_data = self.__get_config("data",config_file=self.__plugin_path+"robots-history.json")
        try:
            history_data = sorted(history_data, key=lambda i: i['addtime'], reverse=sort_type)
        except Exception as e:
            history_data= []
        count = len(history_data)
        page_data = public.get_page(count, args.p, args.rows, args.callback)
        history_data = history_data[args.p * args.rows - args.rows:args.p * args.rows]
        return {"status": True, "page": page_data['page'], 'data': history_data, "rows": args.rows}

    def crontab_task(self,task_name,task_list):
        cronInfo = public.M('crontab').where('name=?',(task_name,)).getField ('id')
        if cronInfo:
            return {"status":False,'msg':"任务已存在"}
        else:
            task_obj = crontab.crontab()
            task={}
            task['name']=task_name
            task['type']='day'
            task['where1']=""
            task['hour']="23"
            task['minute']="30"
            task['week']=""
            task['sType']="toShell"
            task['sBody']=""
            task['sName']=""
            task['backupTo']="backupTo"
            task['save']=""
            task['urladdress']="undefined"
            if "type" in task_list:
                task['type']=task_list['type']
            if "week" in task_list:
                task['week'] = task_list['week']
            if "sBody" in task_list:
                task['sBody']= task_list['sBody']
            if "where1" in task_list:
                task['where1']=task_list['where1']
            ret = task_obj.AddCrontab(task)
            self.write_logs('定时推送%s' % task['type'])
            return ret
    def get_map_history(self,args):
        if not 'p' in args: args.p = 1
        if not 'rows' in args: args.rows = 100
        if not 'callback' in args: args.callback = ''
        if "sort_by_time" not in args:
            args.sort_by_time="asc"
        if args.sort_by_time == "asc":
            sort_type=False
        else:sort_type=True
        map_type = args.map_type
        args.p = int(args.p)
        args.rows = int(args.rows)
        all_history_data = self.__get_config("data", config_file=self.__plugin_path + "map_log.json")
        try:
            history_data = sorted(all_history_data, key=lambda i: i['addtime'], reverse=sort_type)
        except Exception as e:
            history_data=[]
        count = len(history_data)
        page_data = public.get_page(count, args.p, args.rows, args.callback)
        history_data = history_data[args.p * args.rows - args.rows:args.p * args.rows]
        if map_type != "" and map_type != "全部":
            history_data = self.custom_filter(history_data, map_type, "scan_type")
        return {"status": True, "page": page_data['page'], 'data': history_data, "rows": args.rows}
    def get_map_status(self,args):
        task_num = public.ExecShell("ps -aux|grep '%ssite_task.py'|grep -v grep|wc -l" % self.__plugin_path)[0].strip()
        map_interval = self.__get_config("map_interval")
        return {"status":True,"task_num":task_num,"map_interval":map_interval}

    def get_config_data(self,args):
        data={}
        if "token" in args:
            token=self.__get_config("baidu_token")
            data['token'] = token
        if "map_interval" in args:
            map_interval=self.__get_config("map_interval")
            data['map_interval'] = map_interval
        if "mip_status" in args:
            mip_status=self.__get_config("mip_status")
            data['mip_status']=mip_status

        return {"status":True,"data":data}

    def set_config_data(self,args):
        ret = {"status":True,"msg":"保存成功"}
        if "token" in args:
            token = args.token
            self.__set_config("baidu_token",token)
        if "map_interval" in args:
            map_interval=args.map_interval
            self.__set_config("map_interval",map_interval)
        if "mip_status" in args:
            mip_status=args.mip_status
            self.__set_config("mip_status",mip_status)
        return ret
    def write_logs(self,logstr):
        public.WriteLog('site_cluster',logstr)
    #获取面板日志列表
    def get_logs(self,args):
        #处理前端传过来的参数
        if not 'p' in args: args.p = 1
        if not 'rows' in args: args.rows = 12
        if not 'callback' in args: args.callback = ''
        args.p = int(args.p)
        args.rows = int(args.rows)
        #取日志总行数
        count = public.M('logs').where('type=?',(u'site_cluster',)).count()
        #获取分页数据
        page_data = public.get_page(count,args.p,args.rows,args.callback)
        #获取当前页的数据列表
        log_list = public.M('logs').where('type=?',(u'site_cluster',)).order('id desc').limit(page_data['shift'] + ',' + page_data['row']).field('id,type,log,addtime').select()
        #返回数据到前端
        return {'data': log_list,'page':page_data['page'] }

    def get_version(self, args):
        import platform
        data = json.loads(public.ReadFile(self.__plugin_path + "info.json"))
        data['pyversion'] = platform.python_version()
        return data
    #读取配置项(插件自身的配置文件)
    #@param key 取指定配置项，若不传则取所有配置[可选]
    #@param force 强制从文件重新读取配置项[可选]
    def __get_config(self,key=None,config_file=None):
        if not config_file:  #默认为插件配置文件
            config_file = self.config_file

        if not os.path.exists(config_file): return None

        f_body = public.ReadFile(config_file)
        if not f_body: return None
        tmp_config = json.loads(f_body)
        #取指定配置项
        if key:
            if key in tmp_config: return tmp_config[key]
            return None
        return None

    #设置配置项(插件自身的配置文件)
    #@param key 要被修改或添加的配置项[可选]
    #@param value 配置值[可选]
    def __set_config(self,key=None,value=None,config_file=None):
        if not config_file:
            config_file = self.config_file
        #是否需要初始化配置项
        if os.path.exists(config_file):
            f_body = public.ReadFile(config_file)
            tmp_config = json.loads(f_body)
            #是否需要设置配置值
        else: #不存在文件就为空
            tmp_config = {}
        if key:
            tmp_config[key] = value
        else: #初始化参数
            tmp_config = self.__config
        #写入到配置文件
        public.WriteFile(config_file,json.dumps(tmp_config))
        return True

