# -*- coding: utf-8 -*-
import requests, logging, json, time, sys, os, io, glob

if sys.version_info[0] == 2:
    reload(sys)
    sys.setdefaultencoding('utf8')


class Logging():
    __flag = None
    def __new__(cls, *args, **kwargs):
        if not cls.__flag:
            cls.__flag = super().__new__(cls)
        return cls.__flag
    def __init__(self):
        if 'logger' not in self.__dict__:
            logger = logging.getLogger()
            logger.setLevel(level=logging.INFO)
            handler = logging.FileHandler(plugin_path + "/push.log", encoding='utf-8', mode='w+')
            console = logging.StreamHandler()
            formatter = logging.Formatter('%(asctime)s - %(module)s - %(levelname)s - %(message)s', "%Y/%m/%d-%H:%M:%S")
            handler.setFormatter(formatter)
            console.setFormatter(formatter)
            logger.addHandler(handler)
            logger.addHandler(console)
            self.logger = logger

    def Write_error_log(self, msg):
        logging.error(str(msg), exc_info=True)

    def Write_info_log(self, msg):
        logging.info(str(msg))


def read_file(token,file_data,web_domain,mip=False):
    global push_success, remain_num, not_same_site, not_valid,flag
    num = push_num if not mip else push_mip_num
    tmp = split_list_average_n(file_data,num)
    url_list = ""
    for data in tmp:
        if flag:
            url = "".join(data)
            url_list += url
            push_site(token=token, site_url=url, web_domain=web_domain, mip=mip)
    if not flag:
        custom_log.Write_info_log("终止推送，请检查参数")
    custom_log.Write_info_log("当前推送url:\n" + url_list)
    if mip:
        custom_log.Write_info_log("mip成功推送 :%s个" % push_success)
        custom_log.Write_info_log("mip当天剩余额度: %s个" % remain_num)
    else:
        custom_log.Write_info_log("PC端成功推送 :%s个" % push_success)
        custom_log.Write_info_log("PC端当天剩余额度: %s个" % remain_num)
    if len(not_same_site) > 0:
        custom_log.Write_info_log('非本站网址:' + "".join(not_same_site))
    if len(not_valid) > 0:
        custom_log.Write_info_log('不合法的url列表:' + "".join(not_valid))

def split_list_average_n(origin_list, n):
    for i in range(0, len(origin_list), n):
        yield origin_list[i:i + n]

def push_site(token, site_url, web_domain, mip=False):
    global push_success, remain_num, not_same_site, not_valid, flag
    try:
        site_url = site_url.encode("utf-8")
    except Exception as e:
        pass
    if mip:
        push_url = MIP_URL.format(token=token,site=web_domain)
        resp = requests.get(push_url, data=site_url)
    else:
        push_url = URL.format(token=token, site=web_domain)
        headers = {
            'Referer': web_domain,
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36',
            "Content-Type": "text/plain"
        }
        resp = requests.get(push_url, data=site_url, headers=headers)
    if resp.status_code == 200:
        js_content = json.loads(resp.text)
        if mip:
            remain = js_content['remain_mip']
            success = js_content['success_mip']
            push_success += int(success)
        else:
            remain = js_content['remain']
            success = js_content['success']
            push_success += int(success)
        if remain == 0:
            custom_log.Write_info_log("推送额度为0,退出推送")
            flag = False  # 退出推送
        remain_num = remain
        if 'not_same_site' in js_content:
            not_same_site = not_same_site + js_content['not_same_site']
        if 'not_valid' in js_content:
            not_valid = not_valid + js_content['not_valid']
    else:
        message = json.loads(resp.text)['message']
        custom_log.Write_info_log('推送%s异常token可能错误:'%web_domain + message)
        flag = False
    time.sleep(time_interval)

def get_local_plugin_info(info):
    m_version = info['versions'].split(".")
    if len(m_version) < 2: return None
    if len(m_version) > 2:
        tmp = m_version[:]
        del (tmp[0])
        m_version[1] = '.'.join(tmp)

    try:
        if not 'author' in info: info['author'] = '未知'
        if not 'home' in info: info['home'] = '#'
        pluginInfo = {
            "id": 10000,
            "pid": 0,
            "type": 10,
            "price": 0,
            "author": info['author'],
            "home": info['home'],
            "name": info['name'],
            "title": info['title'],
            "panel_pro": 1,
            "panel_free": 1,
            "panel_test": 1,
            "ps": info['ps'],
            "version": info['versions'],
            "s_version": "0",
            "manager_version": "1",
            "c_manager_version": "1",
            "dependnet": "",
            "mutex": "",
            "install_checks": "/www/server/panel/plugin/" + info['name'],
            "uninsatll_checks": "/www/server/panel/plugin/" + info['name'],
            "compile_args": 0,
            "version_coexist": 0,
            "versions": [
                {
                    "m_version": m_version[0],
                    "version": m_version[1],
                    "dependnet": "",
                    "mem_limit": 32,
                    "cpu_limit": 1,
                    "os_limit": 0,
                    "setup": True
                }
            ],
            "setup": True,
            "status": True
        }
    except:
        pluginInfo = None
    return pluginInfo

def push_sm(push_url, file_path):
    header = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36',
        "Content-Type": "text/plain"
    }
    if os.path.exists(file_path):
        data = ""
        with io.open(file_path, 'r', encoding='utf-8')as f:
            lines = f.readlines()
            data = "".join(lines)
            response = requests.post(push_url, data=data, headers=header).text
            code = json.loads(response)['returnCode']
            errorMsg = json.loads(response)["errorMsg"]
            custom_log.Write_info_log("---------------------------")
            if code == 200:
                custom_log.Write_info_log("神马mip推送成功")
            else:
                custom_log.Write_info_log("神马mip推送失败,原因 %s" % errorMsg)


    else:
        custom_log.Write_info_log("文件不存在")

def get_local_plugin(sList):
    for name in os.listdir('plugin/'):
        isExists = False
        for softInfo in sList:
            if name == softInfo['name']:
                isExists = True
                break
        if isExists: continue
        filename = 'plugin/' + name + '/info.json'
        if not os.path.exists(filename): continue
        tmpInfo = public.ReadFile(filename).strip()
        if not tmpInfo: continue
        try:
            info = json.loads(tmpInfo)
        except:
            continue
        pluginInfo = get_local_plugin_info(info)
        if not pluginInfo: continue
        sList.append(pluginInfo)
    return sList

def get_types(sList, sType):
    if sType <= 0: return sList
    newList = []
    for sInfo in sList:
        if sInfo['type'] == sType: newList.append(sInfo)
    return newList

def get_cloud_list():
    lcoalTmp = 'data/plugin.json'
    softList = None
    listTmp = public.readFile(lcoalTmp)
    try:
        if listTmp: softList = json.loads(listTmp)
    except:
        if os.path.exists(lcoalTmp): os.remove(lcoalTmp)
    focre = 0
    if not softList or focre > 0:
        cloudUrl = public.GetConfigValue('home') + '/api/panel/get_soft_list_test'
        import panelAuth
        pdata = panelAuth.panelAuth().create_serverid(None)
        listTmp = public.httpPost(cloudUrl, pdata, 10)
        if not listTmp or len(listTmp) < 200:
            listTmp = public.readFile(lcoalTmp)
        try:
            softList = json.loads(listTmp)
        except:
            pass
        if softList: public.writeFile(lcoalTmp, json.dumps(softList))
    sType = 0
    softList['list'] = get_local_plugin(softList['list'])
    softList['list'] = get_types(softList['list'], sType)
    return softList

def check_accept():
    p_list = get_cloud_list()
    for p in p_list['list']:
        if p['name'] == 'site_cluster':
            if not 'endtime' in p: continue
            if p['endtime'] < 0: return False
            break
    return True

def get_config(key):
    if os.path.exists(plugin_path + '/config.json'):
        f_body = public.ReadFile(plugin_path + '/config.json')
        data = json.loads(f_body)[key]
    else:
        data = None
    return data


# 时间间隔
time_interval = 0.01
# 普通推送次数
push_num = 2000
# mip推送次数
push_mip_num = 100
# mip接口
MIP_URL = "http://data.zz.baidu.com/urls?site={site}&token={token}&type=mip"
# 普通接口
URL = "http://data.zz.baidu.com/urls?site={site}&token={token}"

push_success = remain_num = 0
not_same_site = not_valid = []
plugin_path = os.path.abspath(os.path.dirname(__file__))  # /www/server/panel/plugin/site_cluster

flag = True

if __name__ == '__main__':
    custom_log = Logging()
    sys.path.append("/www/server/panel/class/")
    sys.path.append("/www/server/panel/")
    os.chdir("/www/server/panel")
    import public
    custom_log.Write_info_log("开始推送")
    try:
        push_site_name = sys.argv[1]  #  www.xftcl.com
        push_type = sys.argv[2]  # new  sitemap
        mip = get_config('mip_status')
    except Exception as e:
        custom_log.Write_error_log('参数输入错误' + str(e))
        sys.exit(1)
    if not check_accept():
        custom_log.Write_info_log('插件未购买或已过期')
    else:
        config_data = get_config("site_data")
        site_data_path = plugin_path + "/site_data/"
        token = ""
        if push_site_name == "all":
            all_site=os.listdir(site_data_path)
            for web_domain in all_site:
                flag = True
                data=""
                if push_type =="sitemap":
                    file_names = glob.glob('%s/%s/%s?.txt'%(site_data_path,web_domain,web_domain))
                else:
                    file_names = glob.glob('%s/%s/new_html.txt' % (site_data_path,web_domain))
                for item in config_data:
                    if item['web_url'].find(web_domain)!= -1:
                        token = item['token']
                if not token:
                    custom_log.Write_info_log("%s未发现token"%web_domain)
                    continue
                for file_name in file_names:
                    data+= public.ReadFile(file_name)
                if not data:
                    custom_log.Write_info_log("%s未发现推送数据"%web_domain)
                    continue
                push_success = remain_num = 0
                not_same_site = not_valid = []
                read_file(token,data,web_domain)
                if mip =="yes":
                    push_success = remain_num = 0
                    not_same_site = not_valid = []
                    read_file(token,data,web_domain,mip=mip)
        else: #单独推送站点
            if os.path.exists(plugin_path+"/site_data/" + push_site_name):
                all_site = os.listdir(site_data_path)
                if push_type =="sitemap":
                    file_names = glob.glob('%s/%s/%s?.txt' % (site_data_path,push_site_name,push_site_name))
                else:
                    file_names = glob.glob('%s/%s/new_html.txt' % (site_data_path, push_site_name))
                for item in config_data:
                    if item['web_url'].find(push_site_name)!= -1:
                        token = item['token']
                if token:
                    data = ""
                    for file_name in file_names:
                        data += public.ReadFile(file_name)
                    if not data:
                        custom_log.Write_info_log("%s未发现推送数据"%push_site_name)
                    else:
                        push_success = remain_num = 0
                        not_same_site = not_valid = []
                        read_file(token,data,push_site_name)
                    if mip == "yes":
                        push_success = remain_num = 0
                        not_same_site = not_valid = []
                        read_file(token, data, push_site_name,mip=mip)
                else:
                    custom_log.Write_info_log("%s未发现token" % push_site_name)
