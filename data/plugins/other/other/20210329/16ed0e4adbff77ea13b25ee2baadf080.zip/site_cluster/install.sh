#!/bin/bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH

#配置插件安装目录
install_path=/www/server/panel/plugin/site_cluster

#安装
Install()
{

	echo '正在安装...'
	#==================================================================
	#依赖安装开始

    if [ -f "/www/server/panel/pyenv/bin/python" ];then
        /www/server/panel/pyenv/bin/python  -m pip install -r requirement.txt -i http://mirrors.aliyun.com/pypi/simple/ --trusted-host mirrors.aliyun.com  > /tmp/install.log 2>&1
        /www/server/panel/pyenv/bin/python  -m pip install aiohttp asyncio -i http://mirrors.aliyun.com/pypi/simple/ --trusted-host mirrors.aliyun.com
    else
        python -m pip install -r requirement.txt -i http://mirrors.aliyun.com/pypi/simple/ --trusted-host mirrors.aliyun.com  > /tmp/install.log 2>&1
    fi
    alias cp=cp && cp -rf $install_path/icon.png "/www/server/panel/BTPanel/static/img/soft_ico/ico-site_cluster.png"

	#依赖安装结束
	#==================================================================

	echo '================================================'
	echo '安装完成'
}

#卸载
Uninstall()
{
	rm -rf $install_path
}

#操作判断
if [ "${1}" == 'install' ];then
	Install
elif [ "${1}" == 'uninstall' ];then
	Uninstall
else
	echo 'Error!';
fi
