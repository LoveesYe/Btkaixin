# -*- coding: utf-8 -*-



headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.121 Safari/537.36"
}


class site_manager:
    def __init__(self,domain,is_analyse):
        self.path_list={
            "txt":[],
            "xml":[],
            "deadchain":[]
        }
        self.domain=domain
        self.n = 1
        self.is_analyse=is_analyse
        self.date=time.strftime('%Y-%m-%d',time.localtime())
        self.site_data= plugin_path + '/site_data/'+self.domain
        if not os.path.exists(self.site_data):
            os.makedirs(self.site_data)
            # shutil.rmtree(self.site_data)

    def name(self,c):
        opxml = open('%s/%s%s.xml' % (self.site_data,self.domain,c), 'w+')
        opxml.write('''<?xml version="1.0" encoding="utf-8"?>
<urlset>\n''')
        return opxml
    def zhizuo(self,urllist):
        print('开始写入文件')
        xmldata = self.name(self.n)
        m = 0
        for i in urllist:
            i = i.strip()
            m += 1
            sitemaps = '''    <url>
        <loc>''' + str(i) + '''</loc>
        <lastmod>''' + self.date + '''</lastmod>
        <priority>0.8</priority>
    </url>\n'''
            xmldata.write(sitemaps)
            if m == 50000:
                self.n += 1
                xmldata.write('</urlset>\n')
                xmldata.close()  ##test
                xmldata = self.name(self.n)
                m = 0
            else:
                pass
        self.n=1
        xmldata.write('</urlset>\n')
        xmldata.close()
        self.writetxt(urllist)
        file_names = glob.glob('%s/*.xml' % (self.site_data))
        is_local_site= os.path.exists(local.local_site_path)
        for file_name in file_names:
            try:
                if is_local_site:  # 本地网站复制文件
                    shutil.copy(file_name, local.local_site_path)
                    path_tmp = local.site["web_url"].split("/")[0:3]
                    link_path = path_tmp[0] + "//" + path_tmp[2] + "/" + os.path.basename(file_name)
                    print(link_path, "-----------")
                    self.path_list['xml'].append(link_path)
                else:
                    self.path_list['xml'].append(file_name)
                    self.path_list['redirect']=True
            except Exception as e:
                print(str(e))


    def writetxt(self,urllist):
        tmp=''
        if len(urllist)<50000:
            f = open('%s/%s%s.txt' % (self.site_data, self.domain, self.n), 'w+')
            for k in urllist:
                tmp=tmp +k+"\n"
            f.write(tmp)
            f.close()
        else:
            m=0
            for i in urllist:
                i = i.strip()
                m += 1
                tmp=tmp+i+'\n'
                if m == 50000:
                    f = open('%s/%s%s.txt' % (self.site_data, self.domain, self.n), 'w+')
                    f.write(tmp)
                    f.close()
                    m=0
                    tmp=''
                    self.n+=1
            self.n =1

    def writetxt404(self,urllist):
        tmp2=''
        if len(urllist)<50000 and len(urllist)>0:
            f = open('%s/%slost%s.txt' % (self.site_data, self.domain, self.n), 'w+')
            for k in urllist:
                tmp2=tmp2 +k+"\n"
            f.write(tmp2)
            f.close()
        else:
            m=0
            for i in urllist:
                i = i.strip()
                m += 1
                tmp2=tmp2+i+'\n'
                if m == 50000:
                    f = open('%s/%s%s.txt' % (self.site_data, self.domain, self.n), 'w+')
                    f.write(tmp2)
                    f.close()
                    m=0
                    tmp2=''
                    self.n+=1
            self.n =1
        is_local_site= os.path.exists(local.local_site_path)
        file_names = glob.glob('%s/*lost?.txt'%(self.site_data))
        for file_name in file_names:
            try:
                if is_local_site:  # 本地网站复制文件
                    shutil.copy(file_name,local.local_site_path)
                    path_tmp = local.site["web_url"].split("/")[0:3]
                    link_path = path_tmp[0] + "//" + path_tmp[2] + "/" + os.path.basename(file_name)
                    print(link_path, "-----------")
                    self.path_list['deadchain'].append(link_path)
                else:
                    self.path_list['xml'].append(file_name)
            except Exception as e:
                print(str(e))

    def write_kw(self,kw_dic):
        f=open("%s/kw.config"%self.site_data,mode='w+')
        f.write(json.dumps(kw_dic))
        f.close()

def get_ele_obj(data,ele=True):
    try:
        if type(data).__name__ == 'unicode':
            data = data.encode("utf-8",'ingore')
        if type(data).__name__!='str':
            codding = chardet.detect(data)['encoding']
            data = data.decode(codding,'ignore')
        if ele:
            data = etree.HTML(data)
        return data
    except Exception as e:
        raise e

def get_href_li(url):
    global is_analyse
    try:
        s = requests.session()
        response=s.get(url,headers=headers,timeout=local.time_out)
        response_text = get_ele_obj(response.content,ele=False)
        if response.status_code == 404 and url not in local.die_url:
            local.die_url.add(url)
            print(url,'404')
        if response.status_code !=200:
            return [],response.status_code
        source_obj=get_ele_obj(response.text)
        if is_analyse:
            set_kw(response.text)
        urls_li = list(set(source_obj.xpath("//a/@href")))
    except Exception as e:
        local.die_url.add(url)
        print(str(e)+"==="+url)
        return [],str(str(e)+"===="+url)
    return urls_li,response_text

def set_kw(html):
    global kw_dic
    kw_tmp=analyse.textrank(html,topK=10, withWeight=False)
    for item in kw_tmp:
        if item in kw_dic:
            kw_dic[item]+=1
        else:
            kw_dic[item]=1
def get_loop_url(urls,first=False):   #/news  /product
    global is_analyse
    if sys.version_info[0] == 2:
        if len(local.list_href)>200:
            return
        # print(list_href,'每次循环',num)
        for url in urls:
            urls_li,resp = get_href_li(url)
            complete_url=check_replace_url(urls_li,abs_url=url)
            if not first:
                complete_url=complete_url-local.list_href
            if len(complete_url)>1:
                get_loop_url(complete_url)
    else:
        print('python3')
        from s_tools import spider_main
        obj = spider_main()
        obj.run(urls)
        for key in obj.result:
            try:
                source_obj = get_ele_obj(key[1])
            except Exception as e:
                continue
            if not source_obj:continue
            if is_analyse:
                set_kw(key[1])
            urls_li = list(set(source_obj.xpath("//a/@href")))
            complete_url = check_replace_url(urls_li,abs_url=key[2])
            if not first:
                complete_url = complete_url - local.list_href
            if len(complete_url) > 1:
                get_loop_url(complete_url)
        if obj.die_url:
            local.die_url.update(obj.die_url)
        # obj.clean_result()
def check_replace_url(urls_li,abs_url=""):
    tmp=set()
    for item in urls_li:
        if re.match('^/.*[^/]$',item): #匹配不完全路径/开头路径
            tmp.add(local.web_url+item)
        elif re.search('%s'%local.domain,item): #匹配主域名url
            tmp.add(item)
        elif re.search('^(?!(index)).*\.(html|xml|php)$',item):  #匹配相对路径
            tmp.add(abs_url+'/'+item)
    local.list_href.update(tmp)
    return tmp

def get_first_url(url,site_type):
    urls_li,resp=get_href_li(url)
    if len(urls_li)<1:
        raise Exception('【无法扫描站点地图】'+str(resp))
    complete_url=check_replace_url(urls_li,abs_url=url)
    for url in complete_url:
        if check_404(url):local.list_href.remove(url)
    if site_type == '1':  #全站扫描
        get_loop_url(complete_url,first=True)
    print(local.die_url,'404')
def check_404(url):
    try:
        req=requests.get(url,headers=headers,timeout=local.time_out)
        if req.status_code == 404:
            local.die_url.add(url)
            return True
        else:
            return False
    except requests.Timeout as e:
        local.timeout_url.add(url)
        return True
    except Exception as e:
        return True
def check_new_html(set_url):
    set_url= set(set_url)
    old_data=set()
    site_data_path= plugin_path + '/site_data/'+local.domain
    file_names = glob.glob('%s/%s?.txt'%(site_data_path,local.domain))
    if len(file_names)>0:
        for file_name in file_names:
            try:
                datas = open(file_name,'r').readlines()
                for data in datas:
                    old_data.add(data.strip())
            except Exception as e:
                print(str(e),"=====")
        print(old_data)
        print(set_url)
        new_data = set_url - old_data
        if len(new_data)>0:
            new_txt = "\n".join(new_data)
            f = open("%s/%s"%(site_data_path,"new_html.txt"),'w+')
            f.write(new_txt)
            f.close()
def write_logs(logstr):
    public.WriteLog('site_cluster',logstr)
def set_config(key=None,value=None,config_file=None):
    if not config_file:
        config_file = setting_data["scan_log"]
        # print("日志文件为",config_file)
    if os.path.exists(config_file):
        f_body = public.ReadFile(config_file)
        tmp_config = json.loads(f_body)
    else:
        tmp_config = {}
    #是否需要设置默认值
    if key and value:#新增数据
        is_fund=False
        for index,item in enumerate(tmp_config[key]): #[{"name":"xf"},{"name":"lisi"}]
            if item['name'] == value['name'] and item['scan_type'] == value['scan_type']:
                tmp_config[key][index] = value
                print("更新日志")
                is_fund =True
        if not is_fund:
            print("append value")
            tmp_config[key].append(value)
    else:
        if key not in tmp_config:
            tmp_config[key]=value

    public.WriteFile(config_file,json.dumps(tmp_config))
    return True
def get_local_plugin_info(info):
    m_version = info['versions'].split(".")
    if len(m_version) < 2: return None
    if len(m_version) > 2:
        tmp = m_version[:]
        del (tmp[0])
        m_version[1] = '.'.join(tmp)

    try:
        if not 'author' in info: info['author'] = '未知'
        if not 'home' in info: info['home'] = '#'
        pluginInfo = {
            "id": 10000,
            "pid": 0,
            "type": 10,
            "price": 0,
            "author": info['author'],
            "home": info['home'],
            "name": info['name'],
            "title": info['title'],
            "panel_pro": 1,
            "panel_free": 1,
            "panel_test": 1,
            "ps": info['ps'],
            "version": info['versions'],
            "s_version": "0",
            "manager_version": "1",
            "c_manager_version": "1",
            "dependnet": "",
            "mutex": "",
            "install_checks": "/www/server/panel/plugin/" + info['name'],
            "uninsatll_checks": "/www/server/panel/plugin/" + info['name'],
            "compile_args": 0,
            "version_coexist": 0,
            "versions": [
                {
                    "m_version": m_version[0],
                    "version": m_version[1],
                    "dependnet": "",
                    "mem_limit": 32,
                    "cpu_limit": 1,
                    "os_limit": 0,
                    "setup": True
                }
            ],
            "setup": True,
            "status": True
        }
    except:
        pluginInfo = None
    return pluginInfo
def get_local_plugin(sList):
    for name in os.listdir('plugin/'):
        isExists = False
        for softInfo in sList:
            if name == softInfo['name']:
                isExists = True
                break
        if isExists: continue
        filename = 'plugin/' + name + '/info.json'
        if not os.path.exists(filename): continue
        tmpInfo = public.ReadFile(filename).strip()
        if not tmpInfo: continue
        try:
            info = json.loads(tmpInfo)
        except:
            continue
        pluginInfo = get_local_plugin_info(info)
        if not pluginInfo: continue
        sList.append(pluginInfo)
    return sList
def get_types(sList, sType):
    if sType <= 0: return sList
    newList = []
    for sInfo in sList:
        if sInfo['type'] == sType: newList.append(sInfo)
    return newList
def get_cloud_list():
    lcoalTmp = 'data/plugin.json'
    softList = None
    listTmp = public.readFile(lcoalTmp)
    try:
        if listTmp: softList = json.loads(listTmp)
    except:
        if os.path.exists(lcoalTmp): os.remove(lcoalTmp)
    focre = 0
    if not softList or focre > 0:
        cloudUrl = public.GetConfigValue('home') + '/api/panel/get_soft_list_test'
        import panelAuth
        pdata = panelAuth.panelAuth().create_serverid(None)
        listTmp = public.httpPost(cloudUrl, pdata, 10)
        if not listTmp or len(listTmp) < 200:
            listTmp = public.readFile(lcoalTmp)
        try:
            softList = json.loads(listTmp)
        except:
            pass
        if softList: public.writeFile(lcoalTmp, json.dumps(softList))
    sType = 0
    softList['list'] = get_local_plugin(softList['list'])
    softList['list'] = get_types(softList['list'], sType)
    return softList
def check_accept():
    p_list = get_cloud_list()
    for p in p_list['list']:
        if p['name'] == 'site_cluster':
            if not 'endtime' in p: continue
            if p['endtime'] < 0: return False
            break
    return True

def get_config(key=None,config_file=None):
    if not config_file:  # 默认为插件配置文件
        config_file = plugin_path + "/config.json"
    if not os.path.exists(config_file): return None
    f_body = public.ReadFile(config_file)
    if not f_body: return None
    tmp_config = json.loads(f_body)
    # 取指定配置项
    if key:
        if key in tmp_config: return tmp_config[key]
        return None
    return None

def task(site):
    try:
        local.list_href = set()
        local.die_url = set()
        local.timeout_url = set()
        local.kw_dic = {}
        local.time_out = 10
        local.site= site
        url = site['web_url']
        try:#同步宝塔的才会有本地path路径
            local.local_site_path= site['path']
        except:
            local.local_site_path=""
        find = re.match('(\w+:\/\/)([^/:]+)(:\d*)?', url)
        local.web_url = find.group()
        local.domain = find.group(2)
        print(local.domain)
        get_first_url(url,site_type)
        p = site_manager(local.domain,is_analyse)
        local.list_href = local.list_href - local.die_url
        local.list_href = sorted(list(local.list_href))
        local.die_url = sorted(list(local.die_url))
        check_new_html(local.list_href)
        p.zhizuo(local.list_href)
        p.writetxt404(local.die_url)
        print("关键词结果", local.kw_dic)
        p.write_kw(local.kw_dic)
        path_list = p.path_list
        print(local.timeout_url, 'timeout_url')
        now = time.strftime("%Y-%m-%d %H:%M:%S")
        lock.acquire()
        try:
            set_config("data", {"scan_type": scan_type, "name": site['web_url'], "addtime": now, "error": path_list})
        finally:lock.release()
    except Exception as e:
        print("网站扫描错误:"+str(e))
        now = time.strftime("%Y-%m-%d %H:%M:%S")
        lock.acquire()
        try:
            print(str(e),'结束单任务')
            set_config("data",{"scan_type": scan_type, "name": site['web_url'], "addtime": now, "error": str(e)})
        finally:
            lock.release()
if __name__ =='__main__':
    import requests,json
    from lxml import etree
    import chardet, re
    import time, sys, os, shutil
    import threadpool
    import threading
    import glob
    import psutil
    # 添加包引用位置并引用公共包
    sys.path.append("/www/server/panel/class/")
    os.chdir("/www/server/panel")
    import public
    plugin_path = os.path.abspath(os.path.dirname(__file__))  #/www/server/panel/plugin/site_cluster
    setting_path=plugin_path+"/config.json"
    cpu_num = psutil.cpu_count()
    if not check_accept():
        print('插件未购买或已过期')
        sys.exit(1)
    if cpu_num <4:
        thread_num=2
    else:
        thread_num = 4
    local = threading.local()
    lock = threading.Lock()
    if os.path.exists(setting_path):
        setting_data = public.ReadFile(setting_path)
        setting_data = json.loads(setting_data)
        all_data = get_config("site_data")
        set_config("data",[]) #初始化日志
        try:
            import jieba.analyse as analyse
        except Exception as e:
            is_analyse = False
        try:
            is_analyse = False
            scan_log = setting_data['scan_log']
            #一键扫描或者 定时扫描
            scan_type= sys.argv[1]
            # 1 代表全局扫描  2单页，废弃
            site_type = setting_data['site_type']
            write_logs('%s所有站点'%scan_type)
            if sys.version_info[0] == 2:
                pool = threadpool.ThreadPool(2)
                all_requests = threadpool.makeRequests(task,all_data)
                [pool.putRequest(req) for req in all_requests]
                pool.wait()
            else:#python3
                for site in all_data:
                    task(site)
            write_logs('%s完成' % scan_type)
        except Exception as e:  # 处理报错
            print("终止扫描,原因: %s"%str(e))
            write_logs("终止扫描,原因: %s"%str(e))
    else:
        print("扫描出错，未发现配置文件！")
        write_logs("扫描出错，未发现配置文件！")



