var ftpLimit = {
    user : function () {
        request_plugin('user',{},function( res ){
            var html = '';
            $('.plugin_body').html(html);
            if( res.list.length <= 0 )
                html = '未创建FTP用户';
            else
            {
                html += '<div class="divtable mtb10">';
                html += '<div class="divtable">';
                html += '<table class="table table-hover">';
                html += '<thead>';
                html += '<tr><th>用户</th><th>目录</th><th>目录大小</th><th>实际大小</th><th>已用</th><th>可用</th><th>使用率</th><th width="150">操作</th></tr>';
                html += '</thead>';
                html += '<tbody>';
                for( var i in res.list )
                {
                    var r = res.list[i];
                    html += '<tr>';
                    html += '<td>'+r.name+'</td>';
                    html += '<td>'+r.path+'</td>';
                    html += '<td>'+r.limit+'M</td>';
                    html += '<td>'+r.conf.limit+'</td>';
                    html += '<td>'+r.conf.used+'</td>';
                    html += '<td>'+r.conf.surplus+'</td>';
                    html += '<td>'+r.conf.use_rate+'</td>';
                    html += '<td>';
                    html += '<button class="btn btn-primary btn-xs" onclick="ftpLimit.setting(\''+r.id+'\',\''+r.name+'\',\''+r.path+'\')">设置</button>';
                    html += '</td>';
                    html += '</tr>';
                }
                html += '</tbody></table>';
                html += '</div><div class="page" style="margin-top:15px">'+res.page.page+'</div></div>';
            }
            $('.plugin_body').html(html);
        });
    },
    setting : function( id, name , path )
    {
        layer.prompt({title: '输入配额(纯数字-M单位)'}, function(pass, index){
            request_plugin('setting',{
                ftp_name  : name ,
                num : pass ,
                path : path ,
                id : id
            } ,function( res ){
                if( res.status === '1' )
                {
                    layer.close(index);
                    ftpLimit.user();
                    layer.msg( '设置成功' , { icon: 1 });
                }
                else
                {
                    layer.msg( res.msg , { icon: 2 });
                }
            });
        });
    },
    about : function ()
    {
        var html = 'QQ群提交问题：200160601';
        $('.plugin_body').html(html);
    },
    uplog()
    {
        var html = '';
        html += '<div class="divtable mtb10">';
        html += '<div class="divtable">';
        html += '<table class="table table-hover">';
        html += '<thead>';
        html += '<tr><th>版本号</th><th>时间</th><th>详情</th></tr>';
        html += '</thead>';
        html += '<tbody>';
        res = { list : [
            { version : '1.0' , time : '2020-09-15' , desc : '初始版本~新增目录限额功能' },
            { version : '1.1' , time : '2020-09-21' , desc : '修复python3部分代码不兼容问题' }
        ] };
        for( var i in res.list )
        {
            var r = res.list[i];

            html += '<tr>';
            html += '<td>'+r.version+'</td>';
            html += '<td>'+r.time+'</td>';
            html += '<td>'+r.desc+'</td>';
            html += '</tr>';
        }
        html += '</tbody></table>';
        html += '</div></div>';
        $('.plugin_body').html(html);
    }
};

function request_plugin( function_name, args, callback, timeout) {
    if (!timeout) timeout = 180000;
    var loading;
    $.ajax({
        type:'POST',
        url: '/plugin?action=a&s=' + function_name + '&name=ftplimit',
        data: args,
        timeout:timeout,
        beforeSend : function(){
            loading = layer.load( 1 , {
                shade: [0.1,'#fff'] //0.1透明度的白色背景
            });
        },
        success: function(rdata) {
            layer.close(loading);
            if (!callback) {
                layer.msg(rdata.msg, { icon: rdata.status ? 1 : 2 });
                return;
            }
            return callback(rdata);
        },
        error: function(ex) {
            layer.close(loading);
            if (!callback) {
                layer.msg('请求过程发现错误!', { icon: 2 });
                return;
            }
            return callback(ex);
        }
    });
}

ftpLimit.user();