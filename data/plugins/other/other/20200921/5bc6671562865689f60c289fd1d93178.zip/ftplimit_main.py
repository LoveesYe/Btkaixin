#!/usr/bin/python
# coding: utf-8
# +-------------------------------------------------------------------
# | WSSGO FTP限额插件
# +-------------------------------------------------------------------
# | Copyright (c) 2020-2099 (http://wssgo.com) All rights reserved.
# +-------------------------------------------------------------------
# | Author: dev@wssgo.com
# +-------------------------------------------------------------------

import sys,os,json

#设置运行目录
os.chdir("/www/server/panel")

#添加包引用位置并引用公共包
sys.path.append("class/")
import public,re

#from common import dict_obj
#get = dict_obj();


#在非命令行模式下引用面板缓存和session对象
if __name__ != '__main__':
    from BTPanel import cache,session,redirect

    #设置缓存(超时10秒) cache.set('key',value,10)
    #获取缓存 cache.get('key')
    #删除缓存 cache.delete('key')

    #设置session:  session['key'] = value
    #获取session:  value = session['key']
    #删除session:  del(session['key'])


class ftplimit_main:
    __plugin_path = "/www/server/panel/plugin/ftplimit/"
    __config = None

    #构造方法
    def  __init__(self):
        pass

    def user(self,args):
        if not 'p' in args: args.p = 1
        if not 'rows' in args: args.rows = 12
        args.p = int(args.p)
        args.rows = int(args.rows)
        ftp_users = public.M('ftps').select()
        ftp_count = public.M('ftps').count()
        new_users = []
        if ftp_count > 0 :
            for ftp in ftp_users :
                detail = self.__get_config( ftp['name'] )
                if detail is None:
                    detail = { 'limit' : '-1' }
                merge = { 'conf': self.__get_dir_used(ftp['id']) }
                new_users.append(dict( list(ftp.items()) + list(detail.items()) + list(merge.items()) ))
        page_data = public.get_page(ftp_count,args.p,args.rows,'user')
        return {'list': new_users , 'page':page_data}

    def setting(self,args):
        if not 'ftp_name' in args: return { 'status' : '0' , 'msg':'参数错误' }
        if not 'num' in args: return { 'status' : '0' , 'msg':'参数错误' }
        if not 'id' in args : return { 'status' : '0' , 'msg':'参数错误' }
        if not 'path' in args : return { 'status' : '0' , 'msg':'参数错误' }
        if int(args.num) == 0 :
            if self.__umount_device( args.ftp_name ) is True and self.__set_config(args.ftp_name) is True :
                return { 'status' : '1' }
            return { 'status' : '0' , 'msg': '设置失败' }
        sets = {
        'limit': args.num ,
        'img' : '_loop_'+str( args.ftp_name )+'.img' ,
        'name' : args.ftp_name ,
        'id' : int(args.id),
        'path' : args.path
        }
        if self.__set_config( args.ftp_name , sets ) is True :
            if self.__umount_device(args.ftp_name) is True and self.__mount_device(args.ftp_name) is True :
                return { 'status' : '1' }
        return { 'status' : '0' , 'msg': '设置失败' }

    def __get_dir_used(self,dirId):
       res = public.ExecShell('df -h | grep loop'+str(dirId))[0]
       resParse = res.strip().split(" ")
       arr = []
       for item in resParse:
            if len(item) > 0 :
                arr.append(str(item))
       if len(arr) > 3 :
            return {  'device': arr[0] , 'limit' : arr[1] , 'used' : arr[2] , 'surplus' : arr[3] , 'use_rate' : arr[4] , 'path' : arr[5] }
       return { 'device': '/dev/loop' , 'limit' : '0M' , 'used' : '0M' , 'surplus' : '0M' , 'use_rate' : '0%' , 'path' : '/' }

    def __mount_device(self,ftp_name) :
        detail = self.__get_config(ftp_name)
        if detail is None :
            return False
        imgPath = str(self.__plugin_path)+'data/'+detail['img']
        public.ExecShell('dd if=/dev/zero ibs=1M count='+detail['limit']+' of='+imgPath)
        public.ExecShell('losetup /dev/loop'+str(detail['id'])+' '+imgPath)
        public.ExecShell('mkfs.ext3 /dev/loop'+str(detail['id']))
        public.ExecShell('mount -t ext3 /dev/loop'+str(detail['id'])+' '+detail['path'])
        return True

    def __umount_device(self,ftp_name):
        detail = self.__get_config(ftp_name)
        if detail is not None :
            imgPath = str(self.__plugin_path)+'data/'+detail['img']
            public.ExecShell('umount '+detail['path'])
            public.ExecShell('losetup -d /dev/loop'+str(detail['id']))
            public.ExecShell('rm -rf '+imgPath)
            return True
        return False

    #读取配置项(插件自身的配置文件)
    #@param key 取指定配置项，若不传则取所有配置[可选]
    #@param force 强制从文件重新读取配置项[可选]
    def __get_config(self,key=None,force=False):
        #判断是否从文件读取配置
        if not self.__config or force:
            config_file = self.__plugin_path + 'config.json'
            if not os.path.exists(config_file): return None
            f_body = public.ReadFile(config_file)
            if not f_body: return None
            self.__config = json.loads(f_body)

        #取指定配置项
        if key:
            if key in self.__config: return self.__config[key]
            return None
        return self.__config

    #设置配置项(插件自身的配置文件)
    #@param key 要被修改或添加的配置项[可选]
    #@param value 配置值[可选]
    def __set_config(self,key=None,value=None):
        #是否需要初始化配置项
        if not self.__config: self.__config = self.__get_config()

        #是否需要设置配置值
        if key:
            self.__config[key] = value
        if value is None and key in self.__config:
            del self.__config[key]

        #写入到配置文件
        config_file = self.__plugin_path + 'config.json'
        public.WriteFile(config_file,json.dumps(self.__config))
        return True

