#!/usr/bin/python
# coding: utf-8
#chkconfig: 2345 80 90
#description:auto_run
import sys,os,json

#设置运行目录
os.chdir("/www/server/panel")

#添加包引用位置并引用公共包
sys.path.append("class/")
import public

ftp_users = public.M('ftps').select()
__plugin_path = '/www/server/panel/plugin/ftplimit/'

for u in ftp_users:
    config_file = __plugin_path + 'config.json'
    if not os.path.exists(config_file): continue
    f_body = public.ReadFile(config_file)
    if not f_body: continue
    conf = json.loads(f_body)
    if not u['name'] in conf : continue
    detail = conf[u['name']]
    imgPath = str(__plugin_path)+'data/'+detail['img']
    public.ExecShell('dd if=/dev/zero ibs=1M count='+detail['limit']+' of='+imgPath)
    public.ExecShell('losetup /dev/loop'+str(detail['id'])+' '+imgPath)
    public.ExecShell('mkfs.ext3 /dev/loop'+str(detail['id']))
    public.ExecShell('mount -t ext3 /dev/loop'+str(detail['id'])+' '+detail['path'])
