#!/usr/bin/python
# coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: xf <1196323914@qq.com>
# +-------------------------------------------------------------------

#+--------------------------------------------------------------------

#+--------------------------------------------------------------------
import sys,os,json,time,re

#设置运行目录
os.chdir("/www/server/panel")

#添加包引用位置并引用公共包
sys.path.append("class/")
import public



class disk_main:
    __plugin_path = "/www/server/panel/plugin/disk/"
    __config = None
    __mount_file="/etc/fstab"
    __check_file = __plugin_path + 'check_file.sh'
    __system_path = ['/etc','/','/root','/var','/boot','/home','/bin','/dev','/srv','/usr','/lib','/lib64','/sys','/proc','/sbin']
    #构造方法
    def __init__(self):
        # os.system('echo "- - -" > /sys/class/scsi_host/host1/scan ')
        # os.system('echo "- - -" > /sys/class/scsi_host/host2/scan ')
        # os.system('echo "- - -" > /sys/class/scsi_host/host3/scan ')
        if not os.path.exists(self.__plugin_path + 'config.json'):
            self.__set_config('force_format',True)


    def ToSize(self,size):
            ds = ['b','KB','MB','GB','TB']
            for d in ds:
                if size < 1024: return str(size)+d
                size = size / 1024
            return '0b';


    def disk_format(self,path):#/dev/sdb
        index=public.ExecShell("export LANG='en_US.UTF-8' && parted %s print|grep 'Partition Table:'|awk '{print $3}'"%path)[0]
        ret=public.ExecShell("export LANG='en_US.UTF-8' && cat /etc/fstab |grep %s|awk '{print $3}'|head -1"%path)[0]
        if len(ret)>1:
           ret=index+'/'+ret
        else:
           ret=""
        return ret.strip()
    def get_info(self,args):

        data = []
        import re
        dev=public.ExecShell('fdisk -l |grep -E "Disk /dev/.*?:|磁盘 /dev/.*?："|grep -v  -E "/dev/loop|/dev/mapper"')[0].strip().split('\n')
        #中英文不一样****
        if sys.version_info[0] == 2:
            dev = [re.compile("/.*?：|/.*?:").findall(i.encode("utf-8"))[0].replace(":","").replace("：","") for i in dev]
        else:
            dev = [re.compile("/.*?：|/.*?:").findall(i)[0].replace(":","").replace("：", "") for i in dev]
        #LVM判断是否已挂载
        pvs = public.ExecShell("pvs")[0]

        for i in dev:
            if i.find("swap") !=-1:continue
            tmp={}
            tmp['path']=i
            tmp['disk_format']=self.disk_format(i)
            tmp['status']=self.check_mount_status(i)
            tmp['name']=self.check_mount_name(i)
            if pvs.find(i)!=-1 and tmp['status']==1:
                tmp['status']=0
                tmp['name']=self.check_lvm_point(i)
                tmp['disk_format']="LVM"
            if tmp['name'].find("和")!=-1:
                tmp['size']=self.check_mount_size(i)
            else:
                tmp_name=tmp['path'] if len(tmp['name'])>=1 else tmp['name']
                tmp['size'] = self.check_mount_size(tmp_name)
            data.append(tmp)
        return sorted(data,key=lambda x:x['path'])

    def check_lvm_point(self,name):
        VG_name = public.ExecShell("pvs |grep %s |awk '{print $2}'"%name)[0].strip()
        point = public.ExecShell("lvdisplay |grep %s|grep LV|awk '{print $3}'"%VG_name)[0]
        point = point.replace("\n","还有",1)
        return point

    def check_mount_size(self,path):
        size=public.ExecShell('''export LANG='en_US.UTF-8' && df -lh |grep %s |awk 'NR==1{print $3,"/",$2}' '''%path)[0]
        if len(size)<2:
            size =public.ExecShell('''export LANG='en_US.UTF-8' && fdisk -l |grep %s |awk '{print $3,$4}'  '''%path)[0]
        size=size.split(",")[0]
        return size
    def check_mount_status(self,path):#0表示挂载 1表示未挂载
        status=os.system("df -lh |grep %s"%path)
        if status==0:
            return 0
        else:return 1

    def check_mount_name(self,path):
        name=public.ExecShell("df -lh |grep %s |awk '{print $NF}'"%path)[0].strip()
        name=name.replace("\n","和")
        if not name:name=path
        return name

    def get_file_size(self,name):
        if os.path.exists(name):
            size = public.ExecShell("du -s %s |awk '{print $1}'" % name)[0].strip()
        else:size=0
        return size

    def CheckFilename(self,get):
        name=get.path  #/opt
        addr=get.addr  #/dev/sdb
        import re
        name = re.compile('\/?[a-zA-Z]+|\/').findall(name)
        if len(name) != 1:
            return {'status':False,'msg': '文件名错误'}
        name=name[0]
        if name.find('/') == -1:
            name = "/" + name
        if name in self.__system_path:
            return {'status': False, 'msg': '系统文件禁止操作'}
        if addr.find("swap") !=-1:
            return {'status': False, 'msg': 'swap分区无法挂载'}
        handle=get.handel
        if handle=="挂载":
            #准备挂载
            if name=='/www':
                name_size=int(public.ExecShell("du -bs %s |awk '{print $1}'"%name)[0].strip())
                disk_size=int(public.ExecShell("export LANG='en_US.UTF-8' && fdisk -l |grep -E 'Disk %s'|awk '{print $5}'"%(addr))[0].strip())*8
                if not disk_size:
                    return {'status': True, 'msg': "无法检测磁盘大小，请确保磁盘容量足够"}
                if name_size>disk_size:
                    return {'status': False, 'msg': "新磁盘容量不够，无法迁移",'debug':{"www":name_size,'disk':disk_size}}
                return {'status': True,'msg':"即将迁移数据到新硬盘!请确保停止web服务和mysql服务"}
            if os.system("df -lh |grep %s"%name)==0:
                return {'status':False,'msg': '无法覆盖挂载'}

            ret=os.path.exists(name)
            if ret:
                return {'status': True,'msg':'%s文件名已存在，挂载后将覆盖数据，请确保%s里数据已备份！'%(name,name)}
            force = self.__get_config("force_format")
            if force:
                return {"status":True,'msg':"如果%s里面有数据请取消格式化挂载"%addr}
            return {'status': True,'msg':""}
        else:
            if name == '/www':
                return {'status': False, 'msg': "请手动卸载"}
            return {'status':True,'msg':"请确保卸载目录%s已备份"%name}

    def MountFile(self,get):
        #判断gpt模式
        if get.formats.find('/')!=-1:
            disk_type,formats = get.formats.split("/")
        else:
            disk_type=""
            formats=get.formats
        path=get.path  #/opt
        dev_name=get.addr  #/dev/sdb
        handle = get.handel
        if not path.startswith("/"): #补全路径
            path = "/" + path
        t_name = dev_name + "1"
        t_name = str(t_name).replace("　","")
        if handle == "挂载":
            if not os.path.exists(path):
                os.mkdir(path)
            if disk_type.find('gpt') != -1:
                public.ExecShell("parted -s %s rm 1" % dev_name)
                public.ExecShell('''parted -s %s mklabel gpt'''%dev_name)
                public.ExecShell('''parted -s {0} mkpart primary 0 100%'''.format(dev_name))
            else:
                #删除原有分区后统一创建一个分区
                public.ExecShell('''echo -e "d\nd\nd\nd\nn\np\n\n\n\nt\\n8e\nw"| fdisk %s '''%dev_name)
            force=self.__get_config("force_format")
            if force or path == '/www':
                os.system("mkfs.%s %s "%(formats,t_name))
            public.ExecShell("e2fsck -p %s"%t_name)
            if path == '/www':
                if not os.path.exists('/disktmp'):
                    os.mkdir("/disktmp")
                status = os.system("mount %s /disktmp"%t_name)
                if status != 0 :
                    return {'msg': '挂载失败，无法挂载临时目录', 'status': False}
                tmp_sh = '''
echo "`date` 开始执行脚本"
date > /tmp/copy_www.pid
alias cp=cp &&  cp -arf /www/* /disktmp/  
if [ $? != 0 ];then
rm -f /tmp/copy_www.pid 
echo "`date` 复制失败！！！"
exit 999
fi
sleep 3
echo "`date` 复制完成"
rm -f /tmp/copy_www.pid 
echo "%s %s  %s  defaults 0 0 \n">> /etc/fstab
umount /disktmp
rm -f /www_backup
mv /www  /www_backup
mkdir /www
mount -a
/etc/init.d/bt restart
sleep 2
/etc/init.d/mysqld restart
/etc/init.d/bt restart
echo "`date` 结束脚本"
                '''%(t_name, path, formats)
                public.WriteFile(self.__check_file,tmp_sh)
                public.ExecShell('bash %s  >> /tmp/disk.log 2>&1 & '%self.__check_file)
                self.__write_logs("迁移数据%s 到新硬盘%s" % (path,t_name))

                return {'msg': '正在备份数据请稍等', 'status': True, 'copyfile': True}
            if os.system('mount %s %s'%(t_name,path))==0:
                if os.system("cat /etc/fstab | grep '%s '"%path)==0:
                    public.ExecShell("sed -i 's@^#%s %s@%s %s@g' /etc/fstab && mount -a"%(t_name,path,t_name,path))
                else:
                    public.ExecShell("echo '%s %s  %s  defaults 0 0 \n'>> /etc/fstab && mount -a"%(t_name,path,formats))
            else:
                return {'msg': '挂载失败，请重试', 'status': False}
            self.__write_logs("用户挂载磁盘[%s]到[%s]" % (dev_name,path))
            return {'msg':'挂载成功！请在首页查看','status':True}
        else:
            if os.system("cat /etc/fstab | grep '%s '" % path) == 0:
                public.ExecShell("sed -i 's@^%s %s  %s  defaults 0 0@@g' /etc/fstab && mount -a" % (t_name,path,formats))
                public.ExecShell("fuser -km %s"%path)
                public.ExecShell("umount %s && echo 'y'"%(path))
            else:
                public.ExecShell("fuser -km %s" % path)
                public.ExecShell("umount %s && echo 'y'" % (path))
            self.__write_logs("用户卸载磁盘[%s]" % path)
            return {'msg':"卸载%s成功"%path,'status':True}

  # 获取进度
    def GetSpeed(self,get):
        try:
            path= "/www"
            tmp_path= '/disktmp'
            if os.path.exists(path) and os.path.exists(tmp_path):
                used=int(public.ExecShell("du -bs %s |awk '{print $1}'"%tmp_path)[0].strip())
                total=int(public.ExecShell("du -bs %s |awk '{print $1}'"%path)[0].strip())
                pre = int((100.0 * used / total))
                if used>=total or pre>=99:
                    return {'status':False,'use':used,'total':total,'msg':'成功迁移'}
                return {'status':True,'total':total,'used':used,'pre':pre,'name':'正在迁移文件'}
            else:
                return {'status':False,'msg':"未知错误"}
        except Exception as e:
            return {'name': '准备部署', 'total': 0, 'used': 0, 'pre': 0, 'speed': 0,"debug":str(e)}

    def search_log(self,get):
        info={'Refile':[],'Redir':[]}
        info['system_log'] = []
        path=get.path
        tmp =public.ExecShell("find %s -type f -size +1M 2>/dev/null|grep -E '*.\.log$|*.tar$|*.gz$'|xargs du -b --exclude=." % path)[0].strip()
        if len(tmp)==0:
            return info
        else:tmp=tmp.split("\n")
        for i in tmp:
            size,path=i.split()
            line={"size":size,"path":path}
            info['system_log'].append(line)

        return info

    def remove_file(self,get):
        ret = []
        data = json.loads(get.data)
        if 'system_log' in data:
            system_log=data['system_log']
            if len(system_log)!=0:
                for i in system_log:
                    # 统计
                    count_size=int(i['size'])
                    ret.append(count_size)
                    # 清理系统日志
                    os.remove(i['path'])
                # 进度条
                time.sleep(0.1)

        return self.ToSize(sum(ret))

    def GetToStatus(self,get):
        pass

    # 查看挂载
    def Getnfs(self,get):
        type='system'
        if type == 'system':
            cmd_get_hd_use = '/bin/df -h'
        elif type == 'Inode':
            cmd_get_hd_use = '/bin/df -i'
        else:
            return public.ReturnMsg(False, '类型错误')
        try:
            fp = os.popen(cmd_get_hd_use)
        except:
            ErrorInfo = r'get_hd_use_error'
            return (ErrorInfo)
        re_obj = re.compile(r'^\d+.\d+.\d+.\d+(?P<used>.+)%\s+(?P<mount>.+)')
        hd_use = {}
        for line in fp:
            match = re_obj.search(line)
            if match:
                hd_use[match.groupdict()['mount']] = match.groupdict()['used']
        fp.close()
        return public.returnMsg(True, hd_use)
    def Client(self,get):
        path=get.path
        ip=get.ip
        remote_dir=get.remote_dir
        if not os.path.exists(remote_dir):
            public.ExecShell('mkdir -p %s'%remote_dir)
        ret = os.system("mount -t nfs %s:%s %s" % (ip,remote_dir,path))
        if ret==0:
            public.ExecShell("echo '%s:%s %s  nfs  defaults,_netdev 0 0 \n'>> /etc/fstab"%(ip,remote_dir,path))
            self.__write_logs("用户nfs挂载[%s:%s]--%s" %(ip,remote_dir,path))
            return public.returnMsg(True, '挂载成功')
        else:
            return public.returnMsg(False, '挂载失败!,请检查端口是否开放，是否有权限访问')

    # 查看ossfs 是否安装
    def Check_install_ossfs(self):
        ret=int(public.ExecShell('which ossfs |grep ossfs|wc -l')[0])
        if ret==0:return public.returnMsg(False,'未安装ossfs')
        return True

    def GetOssData(self,get):
        data = self.__get_config("oss")
        return public.returnMsg(True,data)

    def MountOss(self,get):
        ret=self.Check_install_ossfs()
        if not ret:return ret
        try:
            access_id=get.access_id.strip()
            access_key=get.access_key.strip()
            bucket = get.bucket.strip()
            local_path = get.local_path.strip()
            domain = get.domain.strip()
        except:
            return public.returnMsg(False,'参数错误！')
        if local_path in self.__system_path:
            return public.returnMsg(False, '系统目录无法挂载')
        if not local_path.startswith("/"):
            local_path = "/" + local_path
        if not os.path.exists(local_path):
            os.mkdir(local_path)
        if not os.path.exists(local_path):
            return public.returnMsg(False, "挂载目录错误，请更换挂载路径")
        if len(os.listdir(local_path))>0:
            return public.returnMsg(False,"%s存在数据，请更换挂载路径"%local_path)
        #写入认证文件
        public.ExecShell("echo '%s:%s:%s' >> /etc/passwd-ossfs" % (bucket, access_id, access_key))
        public.ExecShell('chmod 640 /etc/passwd-ossfs')
        if not os.path.exists('/etc/passwd-ossfs'):return public.returnMsg(False,'oss认证文件不存在')
        mount_sh = '/usr/local/bin/ossfs %s %s -ourl=%s'%(bucket,local_path,domain)
        status = os.system(mount_sh)
        if status != 0:
            public.ExecShell("sed -i 's@^%s:%s:%s@@g' /etc/passwd-ossfs"% (bucket, access_id, access_key))
            return public.returnMsg(False, '挂在失败，请检查参数！code:%s, debug %s'%(status,mount_sh))
        public.ExecShell("echo %s  >>/etc/rc.local "%mount_sh)
        #验证挂载是否成功
        ret = os.system("df |grep oss|grep %s"%local_path)
        if ret == 0:
            self.__write_logs("OSS 挂载到目录%s成功"%local_path)
            oss_data = self.__get_config('oss') if self.__get_config('oss') else []
            oss_data.append({
                "bucket":bucket,
                "access_id":access_id,
                "access_key":access_key,
                "domain":domain,
                "local_path":local_path
            })
            self.__set_config('oss',oss_data)
            return public.returnMsg(True,'挂载%s成功'%local_path)
        else:
            self.__write_logs("OSS 挂载到目录%s失败！！" % local_path)
            return public.returnMsg(True,'挂载%s失败 请检查参数'%local_path)
    def UmountOSS(self,get):
        local_path = get.local_path.strip()
        public.ExecShell("umount %s" % local_path)
        tmp={}
        oss_data =self.__get_config('oss')
        for item in oss_data:
            if item['local_path']==local_path:
                tmp = item
                oss_data.remove(item)
        self.__set_config('oss',oss_data)
        bucket = tmp["bucket"]
        domain = tmp["domain"]
        mount_sh = '/usr/local/bin/ossfs %s %s -ourl=%s'%(bucket,local_path,domain)
        public.ExecShell("sed -i 's@^%s@@g' /etc/rc.local && mount -a" %mount_sh)
        self.__write_logs("oss 卸载目录%s"%local_path)
        return public.returnMsg(True,'卸载成功')

    def check_task(self,get):
        if os.path.exists('/tmp/copy_www.pid'):
            return {'msg': "正在迁移数据", 'status': True}
        else:return {'msg':"未发现任务",'status':False}
    def Umount(self,get):
        path=get.path
        if not os.path.exists(path):return public.returnMsg(False, '文件夹不存在')
        public.ExecShell('umount -lf %s'%path)
        self.__write_logs("用户卸载nfs目录[%s]" % path)
        return public.returnMsg(True, '卸载成功')
    #获取面板日志列表
    #示例已登录面板的情况下访问get_logs方法：/plugin?action=a&name=demo&s=get_logs
    def get_logs(self,args):
        #处理前端传过来的参数
        if not 'p' in args: args.p = 1
        if not 'rows' in args: args.rows = 12
        if not 'callback' in args: args.callback = ''
        args.p = int(args.p)
        args.rows = int(args.rows)

        #取日志总行数
        count = public.M('logs').where('type=?',(u'磁盘操作',)).count()

        #获取分页数据
        page_data = public.get_page(count,args.p,args.rows,args.callback)

        #获取当前页的数据列表
        log_list = public.M('logs').where('type=?',(u'磁盘操作',)).order('id desc').limit(page_data['shift'] + ',' + page_data['row']).field('id,type,log,addtime').select()
        
        #返回数据到前端
        return {'data': log_list,'page':page_data['page'] }
    def del_log(self,get):
        ret=public.M('logs').where('type=?', (u'磁盘操作',)).delete()
        return public.returnMsg(True, '清理成功')

    def __write_logs(self,logstr):
        public.WriteLog('磁盘操作',logstr)

    #读取配置项(插件自身的配置文件)
    #@param key 取指定配置项，若不传则取所有配置[可选]
    #@param force 强制从文件重新读取配置项[可选]
    def __get_config(self,key=None,force=False):
        #判断是否从文件读取配置
        if not self.__config or force:
            config_file = self.__plugin_path + 'config.json'
            if not os.path.exists(config_file): return None
            f_body = public.ReadFile(config_file)
            if not f_body: return None
            self.__config = json.loads(f_body)

        #取指定配置项
        if key:
            if key in self.__config:
                return self.__config[key]
            return None
        return self.__config

    #设置配置项(插件自身的配置文件)
    #@param key 要被修改或添加的配置项[可选]
    #@param value 配置值[可选]
    def __set_config(self,key=None,value=None):
        #是否需要初始化配置项
        if not self.__config: self.__config = {}

        #是否需要设置配置值
        if key:
            self.__config[key] = value

        #写入到配置文件
        config_file = self.__plugin_path + 'config.json'
        public.WriteFile(config_file,json.dumps(self.__config))
        return True

    def get_force(self,get):
        status=self.__get_config("force_format")
        return {'status':status}

    def set_force(self,get):
        status = not self.__get_config("force_format")
        self.__set_config('force_format',status)
        return {"msg":"修改成功"}