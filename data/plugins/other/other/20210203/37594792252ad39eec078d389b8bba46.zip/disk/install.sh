#!/bin/bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH

#配置插件下载地址和安装目录

install_path=/www/server/panel/plugin/disk

#安装
Install()
{
	echo '正在安装...'
	#==================================================================
	#打包插件目录上传的情况下
	#依赖安装开始
	cd $install_path
	if [ -f "/usr/bin/yum" ]; then
    yum install -y e4fsprogs xfsprogs
	elif [ -f "/usr/bin/apt-get" ]; then
	apt-get install xfsprogs -y
	fi
	modprobe ext4
	modprobe xfs

    if [ ! -f "/usr/local/bin/ossfs" ];then
        ubuntu16Pack="ossfs_1.80.6_ubuntu16.04_amd64.deb"
        if [ -f "/usr/bin/yum" ] && [ -f "/usr/bin/rpm" ]; then
            centos_version=$(cat /etc/redhat-release | grep ' 7.' | grep -i centos)
            if [ "${centos_version}" != '' ]; then
                centosPack="ossfs_1.80.6_centos7.0_x86_64.rpm"
            fi
            yum localinstall ${centosPack} -y
            rm -f ${centosPack}
        elif [ -f "/usr/bin/apt-get" ]; then
            ubuntu16=$(cat /etc/issue|awk '{print $2}'|grep -oE '16.04')
            if [ "${ubuntu16}" != '' ]; then
                apt-get update
                apt-get install gdebi-core -y
                gdebi ${ubuntu16Pack} -n
                rm -f ${ubuntu16Pack}
            else
                exit;
            fi
        fi
    fi
	#依赖安装结束
	#==================================================================

	#==================================================================
	#使用命令行安装的情况下，如果使用面板导入的，请删除以下代码
	
	#创建插件目录
	mkdir -p $install_path

	#开始下载文件
	#文件下载结束
	cp -rf $install_path/icon.png "/www/server/panel/BTPanel/static/img/soft_ico/ico-disk.png"
	cp -rf $install_path/ing.gif "/www/server/panel/BTPanel/static/img/ing.gif"
	#==================================================================
	echo '================================================'
	echo '安装完成'
}

#卸载
Uninstall()
{
	rm -rf $install_path
}

#操作判断
if [ "${1}" == 'install' ];then
	Install
elif [ "${1}" == 'uninstall' ];then
	Uninstall
else
	echo 'Error!';
fi

##this is xf