#!/bin/bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH

#配置插件安装目录
install_path=/www/server/panel/plugin/west_fss

Check_OS()
{
	if [ -e /etc/redhat-release ]; then
		OS=CentOS
		[ -n "$(grep ' 7\.' /etc/redhat-release 2> /dev/null)" ] && OS_Ver=7
		[ -n "$(grep ' 6\.' /etc/redhat-release 2> /dev/null)" ] && OS_Ver=6
		[ -n "$(grep ' 8\.' /etc/redhat-release 2> /dev/null)" ] && OS_Ver=8
	elif [ -n "$(grep -i 'Debian' /etc/issue 2> /dev/null)" ]; then
		OS=Debian
	elif [ -n "$(grep -i 'Ubuntu' /etc/issue 2> /dev/null)" ] && [ -z "$(grep -i 'Ubuntu 20' /etc/issue 2> /dev/null)" ]; then
		OS=Ubuntu
	else
		Echo "failure" "不支持此系统" "Log"
		Exit
	fi

}
#安装
Install()
{
	
	echo '正在安装...'
	#==================================================================
	#依赖安装开始
	#检查操作系统
	Check_OS
	if [ "${OS}" == "CentOS" ] ; then
		yum install davfs2 -y
	else
		apt-get install davfs2 -y
	fi
	if ["${OS_Ver}"=="8"];then
		systemctl start rc-local
		systemctl enable rc-local
		chmod +x /etc/rc.local
		echo '[Install]' >> /usr/lib/systemd/system/rc-local.service
		echo 'WantedBy=multi-user.target' >> /usr/lib/systemd/system/rc-local.service
	fi
	#依赖安装结束
	#==================================================================
	echo '================================================'
	echo '安装完成'
}

#卸载
Uninstall()
{
	python /www/server/panel/plugin/west_fss/west_fss_main.py uninstall
	rm -rf $install_path
}

#操作判断
if [ "${1}" == 'install' ];then
	Install
elif [ "${1}" == 'uninstall' ];then
	Uninstall
else
	echo 'Error!';
fi
