#!/usr/bin/python
# coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: xxx <xxxx@qq.com>
# +-------------------------------------------------------------------

# +--------------------------------------------------------------------
# |   宝塔第三方应用开发west_fss
# +--------------------------------------------------------------------
import public
import sys
import os
import json

os.chdir("/www/server/panel")

sys.path.append("class/")


if __name__ != '__main__':
    from BTPanel import cache, session, redirect


class west_fss_main:
    __plugin_path = "/www/server/panel/plugin/west_fss/"
    __config = None
    __davfs2 = '/etc/davfs2/secrets'
    __start = '/etc/rc.local'
    __davfs2_path = '/www/server/panel/plugin/west_fss/fss.json'
    # 构造方法

    def __init__(self):
        if not os.path.exists(self.__davfs2_path):
            os.system(r"touch {}".format(self.__davfs2_path))

    def _check(self, args):
        return True

    def index(self, args):
        return self.get_logs(args)

    def fss_main(self, args):
        rest = public.ReadFile(self.__davfs2).split('\n')
        return rest
    # 添加davfs2
    def add_fss(self, args):
        if not 'url' in args:
            return
        rest = public.ReadFile(self.__davfs2).split('\n')
        rest.append(args.url+' '+args.username+' '+args.password)
        result = public.WriteFile(self.__davfs2, '\n'.join(rest), mode='w+')

        rest_path = public.ReadFile(self.__davfs2_path).split('\n')
        rest_path.append(str(len(rest))+'| '+args.url+' ' + args.username+' '+args.password+' '+args.path)
        result = public.WriteFile(
            self.__davfs2_path, '\n'.join(rest_path), mode='w+')
        public.WriteLog('fss','添加桶{}'.format(args.url.strip()))
        return {'status': 1, 'msg': '添加成功！'}

    def modify_fss(self, args):
        rest_path = public.ReadFile(self.__davfs2_path).split('\n')
        if not 'url' in args :
            for i in range(len(rest_path)):
                if str(int(args.num)+1)+'|' in rest_path[i] :
                    data=rest_path[i]
        else:
            rest = public.ReadFile(self.__davfs2).split('\n')
            rest[int(args.num)] = args.url+' '+args.username+' '+args.password
            result = public.WriteFile(self.__davfs2, '\n'.join(rest), mode='w+')
            rest_path = public.ReadFile(self.__davfs2_path).split('\n')
            for i in range(len(rest_path)):
                if str(int(args.num)+1)+'|' in rest_path[i]:
                    rest_path[i]=str(int(args.num)+1)+'| '+args.url+' ' + args.username+' '+args.password+' '+args.path
            result = public.WriteFile(self.__davfs2_path, '\n'.join(rest_path), mode='w+')
            public.WriteLog('fss','修改桶{}'.format(args.url.strip()))
            return {'status': 1, 'msg': '修改成功！'}
        return data

    def del_fss(self, args):
        if not 'num' in args:
            return {'status': 0, 'msg': '没有选择删除目标！'}
        rest = public.ReadFile(self.__davfs2).split('\n')
        del rest[int(args.num)]
        result = public.WriteFile(self.__davfs2, '\n'.join(rest), mode='w+')

        rest_path = public.ReadFile(self.__davfs2_path).split('\n')
        for i in range(len(rest_path)):
            if str(int(args.num)+1)+'|' in rest_path[i]:
                del_msg=rest_path[i].split(' ')
                del rest_path[i]
        result = public.WriteFile(
            self.__davfs2_path, '\n'.join(rest_path), mode='w+')
        public.WriteLog('fss','删除桶{}'.format(del_msg[1].strip()))
        return {'status': 1, 'msg': '删除成功！'}

    def davfs2_edit(self, args):
        rest = public.ReadFile(self.__davfs2)
        return rest

    def get_mount(self, args):
        rest_path = public.ReadFile(self.__davfs2_path).split('\n')
        for i in range(len(rest_path)):
            if str(int(args.num)+1)+'|' in rest_path[i]:
                id=i
                result = public.ExecShell('df | grep "{}"|grep "{}"'.format(rest_path[i].split(' ')[1].strip(), rest_path[i].split(' ')[4].strip()))
        try:
            if result[0].strip('\n').split(' ')[0] != '' and result[0].strip('\n').split(' ')[-1].strip() in rest_path[i].split(' ')[4]:
                return {'id': args.num, 'status': 1}
            else:
                return {'id': args.num, 'status': 2}
        except:
            return {'id': args.num, 'status': 3}

    def mount_fss(self, args):
        rest_path = public.ReadFile(self.__davfs2_path).split('\n')
        for i in range(len(rest_path)):
            if str(int(args.num)+1)+'|' in rest_path[i]:
                result = rest_path[i].split(' ')
        if args.type == 'start':
            if not os.path.isdir(result[4].strip()):
                os.makedirs(result[4].strip())
            restshell = public.ExecShell('mount -t davfs {} {}'.format(result[1].strip(), result[4].strip()))
            if restshell[1]!='' and not 'Mounting failed' in restshell[1]  :
                public.WriteLog('fss','挂载{}'.format(result[1].strip()))
                return {'status':1,'msg':'挂载成功'}
            msg='请联系管理员'
            if '404' in restshell[1]:
                msg='账号错误'
            if '401' in restshell[1]:
                msg='密码错误'
            if 'Host not found' in restshell[1]:
                msg='桶地址错误'
            return {'status':0,'msg':'挂载失败 {}'.format(msg)}
        if args.type == 'stop':
            restshell = public.ExecShell('umount {}'.format(result[4].strip()))
            if restshell[1]=='':
                public.WriteLog('fss','取消挂载{}'.format(result[1].strip()))
                return {'status':1,'msg':'取消挂载成功'}
            return {'status':0,'msg':'取消挂载失败{}'.format(restshell[1])}

    def auto_mount(self,args):
        rest_path = public.ReadFile(self.__davfs2_path).split('\n')
        for i in range(len(rest_path)):
            if str(int(args.num)+1)+'|' in rest_path[i]:
                result=rest_path[i].split(' ')
        if not 'type' in args:
            restshell = public.ExecShell('cat /etc/rc.local | grep "{}"|grep "{}"'.format(result[1].strip(), result[4].strip()))
            if restshell[0]!='':
                return {'id': args.num, 'status': 1}
            else:
                return {'id': args.num, 'status': 0}
        else:
            rest = public.ReadFile(self.__start).split('\n')
            if args.type=='off':
                for i in range(len(rest)):
                    if 'mount -t davfs {} {}'.format(result[1].strip(), result[4].strip()) in rest[i] :
                        del rest[i]
                        restshell = public.WriteFile(self.__start, '\n'.join(rest), mode='w+')
                        public.WriteLog('fss','取消自动挂载{}'.format(result[1].strip()))
                        return {'status':1,'msg':'取消自动挂载'}               
            if args.type=='on':
                rest.append('mount -t davfs {} {}'.format(result[1].strip(), result[4].strip()))
                restshell = public.WriteFile(self.__start, '\n'.join(rest), mode='w+')
                public.WriteLog('fss','开启自动挂载{}'.format(result[1].strip()))
                return {'status':1,'msg':'开启自动挂载'}
            

    def get_logs(self, args):
        if not 'p' in args:
            args.p = 1
        if not 'rows' in args:
            args.rows = 12
        if not 'callback' in args:
            args.callback = ''
        args.p = int(args.p)
        args.rows = int(args.rows)
        count = public.M('logs').where('type=?',('fss',)).count()
        page_data = public.get_page(count, args.p, args.rows, args.callback)
        log_list = public.M('logs').where('type=?',('fss',)).order('id desc').limit(
            page_data['shift'] + ',' + page_data['row']).field('id,type,log,addtime').select()
        return {'data': log_list, 'page': page_data['page']}
    def uninstall(self):
        rest = public.ReadFile(self.__start).split('\n')
        for i in range(len(rest)):
            if 'mount -t davfs'in rest[i]:
                del rest[i]
                restshell = public.WriteFile(self.__start, '\n'.join(rest), mode='w+')
        public.WriteLog('fss','卸载插件取消自动挂载')
if __name__ == "__main__":
    chk = sys.argv[1]
    if chk =='uninstall':
        west_fss=west_fss_main()
        west_fss.uninstall()