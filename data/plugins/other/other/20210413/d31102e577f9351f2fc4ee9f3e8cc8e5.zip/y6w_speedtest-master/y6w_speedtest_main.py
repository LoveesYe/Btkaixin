#!/usr/bin/python
# coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: 猪在天上飞 <1057916173@qq.com>
# +-------------------------------------------------------------------

#+--------------------------------------------------------------------
#|   宝塔第三方应用开发y6w_speedtest
#+--------------------------------------------------------------------
import sys,os,json

#设置运行目录
os.chdir("/www/server/panel")

#添加包引用位置并引用公共包
sys.path.append("class/")
import public



#在非命令行模式下引用面板缓存和session对象
if __name__ != '__main__':
    from BTPanel import cache,session

class y6w_speedtest_main:
    __plugin_path = "/www/server/panel/plugin/y6w_speedtest/"
    __config = None

    #构造方法
    def  __init__(self):
        pass

    def get_result(self,args):
        #p = os.popen("python speedtest.py");

        res = os.popen("python "+os.getcwd()+"/plugin/y6w_speedtest/speedtest.py")
        x=res.read()
        x=x.replace("\n","<br>")
        #res = os.popen("ls -al");
        return {"code":1,"data":x}

    def start_speedtest(self,args):
        public.WriteFile(self.__plugin_path+"t.log","")
        cmd = "python "+self.__plugin_path+"speedtest.py > "+self.__plugin_path+"t.log &"
        #import panelTask
        #t = panelTask.bt_task()
        #res = t.create_task("网速测试",0,cmd)
        res = os.system(cmd)
        return {'code':1,"data":res}

    def speedtest_status(self,args):
        text = public.ReadFile(self.__plugin_path+"t.log").replace("\n","<br>")
        return {'code':1,'data':text}