<?php

class bt_main{
    private $__settings_file;
    
    # 构造方法
    public function __construct() {
        $this->__settings_file = dirname(__FILE__) . "/settings.json";
    }

    # 获取宝塔部署的站点列表
    public function sites_list() {
        $page = intval( _post('page') );
        $size = intval( _post('size') );
        if( $page < 1 ) {
            $page = 1;
        }
        if( $size < 1 ) {
            $size = 10;
        }
        $db = new db;
        $sql = "select count(*) from domain";
        $ret = $db->query( $sql );
        $count = $ret->fetchArray(SQLITE3_NUM);

        $sql = "select * from domain limit %d offset %d";
        $sql = sprintf( $sql, $size, ($page - 1) * $size );
        $ret = $db->query( $sql );
        
        $names = array();
        $data = array();
        while( $row = $ret->fetchArray(SQLITE3_ASSOC) ) {
            $names[] = $row['name']; 
            $data[] = $row;
        }
        $userId = '';
        $sign = '';
        if( file_exists($this->__settings_file) ) {
            $content = json_decode( file_get_contents($this->__settings_file), true ); 
            if( isset($content['userId']) ) {
                $userId = trim( $content['userId'] );
            }
            if( isset($content['sign']) ) {
                $sign = trim( $content['sign'] ); 
            }
        }
        if( $userId == '' || $sign == '' ) {
            _return( array('status' => 403, 'errmsg' => '请先设置用户参数') );
        }
        $url = "https://www.616seo.com/home/api2/seofirst";
        $post_data = array('userId' => $userId, 'sign' => $sign, 'site' => implode(',', $names));
        $json = _httpPost( $url, $post_data );
        $content = json_decode( $json, true );
        if(!isset($content['errcode'])) {
            _return( array('status' => false, 'errmsg' => '接口请求异常') );
        }
        if( $content['errcode'] !== 0 ) {
            _return( array('status' => false, 'errmsg' => $content['errmsg']) );
        }
        foreach( $data as & $item ) {
            $item['seoinfo'] = array();
            if( isset($content['data'][$item['name']]) ) {
                $item['seoinfo'] = $content['data'][$item['name']];
            }
        }
        unset($item);
        _return( array('status' => true, 'data' => $data, 'count' => $count[0]));
    }
    //-------------------------------------------------------------------------
    
    # 新站同步
    public function siteupdate() {
        $page = intval( _post('page') );
        $size = intval( _post('size') );
        if( $page < 1 ) {
            $page = 1;
        }
        if( $size < 1 ) {
            $size = 10;
        }
        $db = new db;
        $sql = "select count(*) from domain";
        $ret = $db->query( $sql );
        $count = $ret->fetchArray(SQLITE3_NUM);

        $sql = "select * from domain limit %d offset %d";
        $sql = sprintf( $sql, $size, ($page - 1) * $size );
        $ret = $db->query( $sql );
        
        $names = array();
        $data = array();
        while( $row = $ret->fetchArray(SQLITE3_ASSOC) ) {
            $names[] = $row['name']; 
            $data[] = $row;
        }
        $userId = '';
        $sign = '';
        if( file_exists($this->__settings_file) ) {
            $content = json_decode( file_get_contents($this->__settings_file), true ); 
            if( isset($content['userId']) ) {
                $userId = trim( $content['userId'] );
            }
            if( isset($content['sign']) ) {
                $sign = trim( $content['sign'] ); 
            }
        }
        if( $userId == '' || $sign == '' ) {
            _return( array('status' => 403, 'errmsg' => '请先设置用户参数') );
        }
        $url = "https://www.616seo.com/home/api2/seoupdate";
        $post_data = array('userId' => $userId, 'sign' => $sign, 'site' => implode(',', $names) );
        $json = _httpPost( $url, $post_data );
        $content = json_decode( $json, true );
        if(!isset($content['errcode'])) {
            _return( array('status' => false, 'errmsg' => '接口请求异常'));
        }
        if( $content['errcode'] !== 0 ) {
            _return( array('status' => false, 'errmsg' => $content['errmsg']) );
        }
        foreach( $data as & $item ) {
            $item['seoinfo'] = array();
            if( isset($content['data'][$item['name']]) ) {
                $item['seoinfo'] = $content['data'][$item['name']];
            }
        }
        unset($item);
        _return( array('status' => true, 'data' => $data, 'count' => $count[0]) );
    }
    //新站同步-------------------------------------------------------------------------
    # 获取设置
    public function get_settings() {
        $data = array('userId' => '', 'sign' => '' );
        if( file_exists( $this->__settings_file ) ) {
            $content = json_decode( file_get_contents( $this->__settings_file ), true );
            if( isset($content['userId']) ) {
                $data['userId'] = trim( $content['userId'] ); 
            }
            if( isset($content['sign']) ) {
                $data['sign'] = trim( $content['sign'] );
            }
        }
        _return( array('status' => true, 'data' => $data) );
    }
    //-------------------------------------------------------------------------
    
    # 保存配置
    public function set_settings() {
        $sign = trim( _post('sign') );
        $userId = trim( _post('userId') );
        if( $sign == '' ) {
            _return( array('status' => false, 'errmsg' => '密钥不能为空'));
        }
        if( $userId == '' ) {
            _return( array('status' => false, 'errmsg' => '用户编号不能为空') );
        }
        $data = array('sign' => $sign, 'userId' => $userId );
        if( !@file_put_contents($this->__settings_file, json_encode($data)) ) {
            _return( array('status' => false, 'errmsg' => '保存失败') );            
        }
        _return( array('status' => true) );
    }
    //-------------------------------------------------------------------------
    
    # 获取数据
    public function data_list() {
        $id = intval( _post('id') );
        $page = intval( _post('page') );
        $size = intval( _post('size') );
        if( $page < 1 ) {
            $page = 1;
        }
        if( $size < 1 ) {
            $size = 10;
        }
        if( $id < 1 ) {
            _return(array('status' => false, 'errmsg' => '参数错误') );
        }
        $db = new db;
        $sql = "select id, name from sites where id = '%d'";
        $sql = sprintf( $sql, $id );
        $ret = $db->query($sql);
        $row = $ret->fetchArray(SQLITE3_ASSOC);
        if( !isset($row['name']) ) {
            _return( array('status' => false, 'errmsg' => '参数错误:2') );
        }

        $userId = '';
        $sign = '';
        if( file_exists($this->__settings_file) ) {
            $content = json_decode( file_get_contents($this->__settings_file), true ); 
            if( isset($content['userId']) ) {
                $userId = trim( $content['userId'] );
            }
            if( isset($content['sign']) ) {
                $sign = trim( $content['sign'] ); 
            }
        }
        if( $userId == '' || $sign == '' ) {
            _return( array('status' => 403, 'errmsg' => '请先设置用户参数') );
        }
        
        $url = "https://www.616seo.com/home/api2/seolist";
        $data = array("site" => $row['name'], "sign" => $sign, "userId" => $userId, "page" => $page, "size" => $size);
        $json = _httpPost( $url, $data );
        $content = json_decode( $json, true );
        if(!isset($content['errcode'])) {
            _return( array('status' => false, 'errmsg' => '接口请求异常' ) );
        }
        if( $content['errcode'] !== 0 ) {
            _return( array('status' => false, 'errmsg' => $content['errmsg']) );
        }
        _return( array('status' => true, 'count' => $content['count'], 'data' => $content['list']) );

    }
    //-------------------------------------------------------------------------

}
