import json
import os
import time
import global_map
import sys
import random
import traceback
if 'win' in sys.platform:
    try:
        from bs4 import BeautifulSoup
    except:
        os.system('pip install bs4')
        from bs4 import BeautifulSoup
    try:
        import requests
    except:
        os.system('pip install requests')
        import requests
    try:
        import sqlite3
    except:
        os.system('pip install sqlite3')
        import sqlite3
    try:
        import re
    except:
        os.system('pip install re')
        import re
    try:
        import urllib.request
        from urllib.parse import quote
        import urllib.parse
    except:
        os.system('pip install urllib')
        import urllib.request
        from urllib.parse import quote
        import urllib.parse
        opener = urllib.request.build_opener()
else:
    from bs4 import BeautifulSoup
    import requests
    import sqlite3
    import re
    import urllib.request
    from urllib.parse import quote
    import urllib.parse
    opener = urllib.request.build_opener()


# 设置运行目录
basedir = os.path.abspath(os.path.dirname(__file__))
try:
    os.chdir("/www/server/panel")
except :
    os.chdir(os.path.join(basedir, '..', '..', '..'))
# 添加包引用位置并引用公共包
sys.path.append("class/")
import public

sqlconnect=basedir+'/db/tsdb.db'
site_cache_lj=basedir+'/site_cache/'
huancunwenjianming=basedir+'/sitemaptuisong.txt'
config_file=basedir+'/config_cache/config.json'

def connect_select():
    sqlite3conn = sqlite3.connect(sqlconnect)
    daaaa = "select * from tuisong where tslx=2"
    cur = sqlite3conn.cursor()
    cur.execute(daaaa)
    iplist = cur.fetchall()
    cur.close()
    sqlite3conn.close()
    return iplist
def connect_select_chaxun(id):
    sqlite3conn = sqlite3.connect(sqlconnect)
    daaaa = "select * from tuisong where id='"+id+"'"
    cur = sqlite3conn.cursor()
    cur.execute(daaaa)
    iplist = cur.fetchall()
    cur.close()
    sqlite3conn.close()
    return iplist
def connect_updata(id,open):
    sqlite3conn = sqlite3.connect(sqlconnect)
    daaaa = "update `tuisong` SET open='"+open+"' where id='"+id+"'"
    cur = sqlite3conn.cursor()
    cur.execute(daaaa)
    sqlite3conn.commit()
    cur.close()
    sqlite3conn.close()
def connect_updatatime(id):
    t = time.time()
    sqlite3conn = sqlite3.connect(sqlconnect)
    daaaa = "update `tuisong` SET ts_shart_time='"+str(int(t))+"' where id='"+id+"'"
    cur = sqlite3conn.cursor()
    cur.execute(daaaa)
    sqlite3conn.commit()
    cur.close()
    sqlite3conn.close()
def connect_mun(id,shuliang):
    sqlite3conn = sqlite3.connect(sqlconnect)
    daaaa = "update `tuisong` SET tijiaoshu=tijiaoshu+'" + shuliang + "' where id='" + id + "'"
    cur = sqlite3conn.cursor()
    cur.execute(daaaa)
    sqlite3conn.commit()
    cur.close()
    sqlite3conn.close()
    
def connect_sougoumun(id,shuliang):#更新搜狗推送数量
    sqlite3conn = sqlite3.connect(sqlconnect)
    daaaa = "update `tuisong` SET ts_sougouts_shuliang=ts_sougouts_shuliang+" + shuliang + " where id='" + id + "'"
    cur = sqlite3conn.cursor()
    cur.execute(daaaa)
    sqlite3conn.commit()
    cur.close()
    sqlite3conn.close()
def connect_sougou_msg(id,neirong):#更新搜狗API的msg
    sqlite3conn = sqlite3.connect(sqlconnect)
    daaaa = "update `tuisong` SET ts_sougou_msg='" + neirong + "' where id='" + id + "'"
    cur = sqlite3conn.cursor()
    cur.execute(daaaa)
    sqlite3conn.commit()
    cur.close()
    sqlite3conn.close()
    
def getheaders():
    user_agent_list = ['Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/14.0.835.163 Safari/535.1',
                      'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:6.0) Gecko/20100101 Firefox/6.0',
                      'Opera/9.80 (Windows NT 6.1; U; zh-cn) Presto/2.9.168 Version/11.50',
                      'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; WOW64; Trident/5.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; InfoPath.3; .NET4.0C; .NET4.0E; SE 2.X MetaSr 1.0)',
                      'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/534.3 (KHTML, like Gecko) Chrome/6.0.472.33 Safari/534.3 SE 2.X MetaSr 1.0',
                      'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; InfoPath.3; .NET4.0C; .NET4.0E)',
                      'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:17.0) Gecko/20100101 Firefox/17.0.6',
                      'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/13.0.782.41 Safari/535.1 QQBrowser/6.9.11079.201',
                      'Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2224.3 Safari/537.36',
                      'Mozilla/5.0 (X11; CrOS i686 3912.101.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36']
    UserAgent=random.choice(user_agent_list)
    return UserAgent



def get_new_url():
    # """获取新的待爬取url"""
    new_url = global_map.news_url_list.pop()
    global_map.old_mapurl_list.append(new_url)
    return new_url

def download(url):
    # """ 通过urllib.request请求url ，请求有效则下载网页内容"""
    if not os.path.isfile(config_file):
        headers = {'User-Agent': getheaders()}
    else:
        f_body = public.ReadFile(config_file)
        __config = json.loads(f_body)
        if __config['sougou_spider']=="1":
            #普通浏览器
            headers = {'User-Agent': getheaders()}
        elif  __config['sougou_spider']=="2":
            #百度
            headers = {'User-Agent': 'Mozilla/5.0 (compatible; Baiduspider/2.0;+http://www.baidu.com/search/spider.html)'}
        elif  __config['sougou_spider']=="3":
            # 神马蜘蛛 
            headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.81 YisouSpider/5.0 Safari/537.36'}
        elif  __config['sougou_spider']=="4":
            #搜狗蜘蛛
            headers = {'User-Agent': 'Sogou web spider/3.0(+http://www.sogou.com/docs/help/webmasters.htm#07)'}
        elif  __config['sougou_spider']=="5":
            #360蜘蛛
            headers = {'User-Agent': 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0); 360Spider'}
        elif  __config['sougou_spider']=="6":
            #头条蜘蛛 
            headers = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181;Bytespider;https://zhanzhang.toutiao.com/'}
        elif  __config['sougou_spider']=="7":
            #BING蜘蛛 
            headers = {'User-Agent': 'Mozilla/5.0 (compatible; bingbot/2.0; +http://www.bing.com/bingbot.htm)'}
        else:
            #普通浏览器
            headers = {'User-Agent': getheaders()}
    if url is None:
        return
    url = quote(url, safe="?#/:=@")
    # print('开始download=='+url)
    req = requests.get(url=url, headers=headers, timeout=20)
    if req.status_code != 200:
        return None
    # print('完成download=='+url)
    return req.content

def parse(html_cnt): #"""网页数据解析"""
    soup = BeautifulSoup(html_cnt, 'html.parser', from_encoding='utf-8')
    new_urls = soup.find_all('loc')
    return new_urls

#添加遍历每个页面抓取的url列表
def add_new_urls(urls):
    if urls is None or len(urls) == 0:
        return
    for url in urls:
        add_new_url(url.get_text())


def has_new_url():
    # """判断url管理器中是否还有url"""
    return len(global_map.news_url_list) != 0

def _get_new_urls(page_url, soup):
#"""从页面数据中获取新的url"""
    new_urls = set()
    links = soup.find_all('a', href=re.compile(r".*"))
    base_url = global_map.host
    for link in links:
        new_url = link['href']
        new_url_full = urllib.parse.urljoin(page_url,new_url)
        if new_url_full.find(base_url) < 0:
            continue
        new_urls.add(new_url_full)
    return new_urls

#新URL过滤，去除图片这类的url
def add_new_url(url):
    base_url = global_map.host
    if url.find(".xml") > 0:
        if url is None:
            return
        if url.find("http") > -1 and url.find(base_url) < 0:
            return
        if url not in global_map.old_mapurl_list:
            global_map.news_url_list.append(url)
    else:
        # 将新的 url 加入 url管理器前先进行过滤处理
        if url is None:
            return
        if url.find("http") > -1 and url.find(base_url) < 0:
            return
        if re.compile(r":[a-zA-Z0-9();]").findall(url) \
                or url.find("#") > 0 or url.find(".js") > 0 \
                or url.find(".apk") > 0 or url.find(".txt") > 0 \
                or url.find(".exe") > 0 or url.find(".pptx") > 0 \
                or url.find("xlsx") > 0 or url.find(".ppt") > 0 \
                or url.find("flv") > 0 or url.find(".rmvb") > 0 \
                or url.find(".mp4") > 0 or url.find(".mvb") > 0 \
                or url.find(".jpg") > 0 or url.find(".png") > 0 \
                or url.find(".gif") > 0 or url.find(".zip") > 0 \
                or url.find(".rar") > 0 or url.find(".bmp") > 0 \
                or url.find(".doc") > 0 or url.find(".doc") > 0 \
                or url.find(".pdf") > 0 or url.find(".xls") > 0 \
                or url.find(".docx") > 0 or url.find(".xlsx") > 0:
            return
        if url not in global_map.old_url_list:
            global_map.old_url_list.append(url)
            global_map.meitui_url_list.append(url)
            global_map.sougoutui_url_list.append(url)
def output_html():

    f1 = open(site_cache_lj+global_map.id+'_'+global_map.site+'_1.txt', 'w', encoding='utf8')
    for each1 in global_map.news_url_list:

        f1.writelines(each1 + '\n')

    f1.close()
    f2 = open(site_cache_lj+global_map.id+'_'+global_map.site+'_2.txt', 'w', encoding='utf8')
    for each2 in global_map.old_url_list:

        f2.writelines(each2 + '\n')

    f2.close()
    f3 = open(site_cache_lj+global_map.id+'_'+global_map.site+'_3.txt', 'w', encoding='utf8')
    for each3 in global_map.yitui_url_list:

        f3.writelines(each3 + '\n')

    f3.close()
    f4 = open(site_cache_lj+global_map.id+'_'+global_map.site+'_4.txt', 'w', encoding='utf8')
    for each4 in global_map.meitui_url_list:

        f4.writelines(each4 + '\n')

    f4.close()
    f6 = open(site_cache_lj+global_map.id+'_'+global_map.site+'_5.txt', 'w', encoding='utf8')
    for each6 in global_map.sougoutui_url_list:

        f6.writelines(each6 + '\n')

    f6.close()
    if len(global_map.site_log)<=1200:
        f5 = open(site_cache_lj+global_map.id + '_' + global_map.site + '_log.txt', 'w', encoding='utf8')
        for each5 in global_map.site_log:

            f5.writelines(each5 + '\n')

        f5.close()
    else:
        lisad=[]
        in5=len(global_map.site_log)-1
        for i in range(6):
            lisad.append(global_map.site_log[in5])
            in5-=1
        f5 = open(site_cache_lj+global_map.id + '_' + global_map.site + '_log.txt', 'w', encoding='utf8')
        for each5 in lisad:
            f5.writelines(each5 + '\n')
        f5.close()


def craw():
    count = 1
    while has_new_url():
        try:
            new_url = get_new_url()  # 从 url管理器中获取新的待爬取 url
            html_cnt = download(new_url)  # 下载指定 url 页面内容，判断请求头是否200
            new_urls = parse(html_cnt)  # 解析页面内容，获取新的 url
            add_new_urls(new_urls)  # 将新获取的url 加入到 url管理器中
            # 若有 url 爬取数量限制，则当达到数量限制时终止爬虫继续爬取数据
            if 0 < global_map.num == count:
                break
            count = count + 1
        except Exception as e:
            print('爬取失败 %s  '% new_url + str(e))  # 爬取失败提示
            



 #读取文件
def readtxt(wjnama):
    f = open(site_cache_lj+wjnama, 'r', encoding='utf8')
    data = f.read().splitlines()
    f.close()
    return data

def newfile(id,site):
    name=[id+'_'+site+'_1.txt',id+'_'+site+'_2.txt',id+'_'+site+'_3.txt',id+'_'+site+'_4.txt',id+'_'+site+'_log.txt']
    for i in name:
        if not os.path.isfile(site_cache_lj+i):
            fp = open(site_cache_lj+i,'w')
            fp.close()
    if not os.path.isfile(site_cache_lj+id+'_'+site+'_5.txt'):
        fp3 = open(site_cache_lj+id+'_'+site+'_2.txt','r')
        data = fp3.read()
        fp3 = open(site_cache_lj+id+'_'+site+'_5.txt','w')
        fp3.write(data)
        fp3.close()
def jiance(sda):
    for i in sda:
        tempUrl = i
        try:
            headers = {
                'User-Agent': 'Mozilla/5.0 (compatible; Baiduspider/2.0;+http://www.baidu.com/search/spider.html)'
            }
            r = requests.get(tempUrl + '/jiance/', headers=headers, timeout=5)
            code = r.status_code
            if code == 200:
                return tempUrl
        except:
            time.sleep(2)

def tuisong(sql_nr,id):
    headers = {'User-Agent': 'User-Agent:' + getheaders()}
    if sql_nr[21] == 1:
        URLTS=jiance(global_map.TBS_HTTPS)
        if len(global_map.sougoutui_url_list) >0:
            sougoulste = []
            
            if len(global_map.sougoutui_url_list) >=20:
                for i in range(20):
                    sougoulste.append(global_map.sougoutui_url_list.pop())
                try:
                    dataew={'sougou_ts_api':sql_nr[20],'ts_mun':'20','pc_wap':sql_nr[22],'ts_web_list':str(sougoulste).replace("""'""", '''"''')}
                    r = requests.post(URLTS+'/API/sougou_ts_api/set_sougoutuisong_cache.php', data=dataew,headers=headers)
                    json1 = json.loads(r.text)
                    if json1['code'] == 0:
                        connect_sougoumun(id,"20")#更新搜狗推送数量
                        global_map.site_log.append('########### map地图搜狗提交时间：' + time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()) + '###########')
                        global_map.site_log.append('推送数量：20条')
                        connect_sougou_msg(id,json1['msg2'])
                    else:
                        global_map.site_log.append('########### map地图搜狗提交时间：' + time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()) + '###########')
                        global_map.site_log.append('推送失败：'+json1['msg'])
                        connect_sougou_msg(id,json1['msg'])
                        for eww2 in sougoulste:
                            global_map.sougoutui_url_list.append(eww2)
                except:
                    for eww2 in sougoulste:
                        global_map.sougoutui_url_list.append(eww2)
            else:
                try:
                    data432={'sougou_ts_api':sql_nr[20],'ts_mun':len(global_map.sougoutui_url_list),'pc_wap':sql_nr[22],'ts_web_list':str(global_map.sougoutui_url_list).replace("""'""", '''"''')}
                    r = requests.post(URLTS+'/API/sougou_ts_api/set_sougoutuisong_cache.php', data=data432,headers=headers)
                    json1 = json.loads(r.text)
                    if json1['code'] == 0:
                        global_map.site_log.append('########### map地图搜狗提交时间：' + time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()) + '###########')
                        global_map.site_log.append('推送数量：' + str(len(global_map.sougoutui_url_list)) + '条')
                        connect_sougoumun(id,str(len(global_map.sougoutui_url_list)))#更新搜狗推送数量
                        global_map.sougoutui_url_list.clear()
                    else:
                        global_map.site_log.append('########### map地图搜狗提交时间：' + time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()) + '###########')
                        global_map.site_log.append('推送失败：'+json1['msg'])
                        connect_sougou_msg(id,json1['msg'])
                except Exception as e:
                    print('搜狗推送出错')
                    print(e)
                    
                    
                    

    ints = global_map.num

    lste = []
    if(len(global_map.meitui_url_list)>0):
        if len(global_map.meitui_url_list) >= ints:
            for i in range(ints):
                lste.append(global_map.meitui_url_list.pop())
        else:
            while len(global_map.meitui_url_list) != 0:
                lste.append(global_map.meitui_url_list.pop())
        urldata = '\n'.join(lste)
        if sql_nr[10]==1:
            r = requests.post(sql_nr[13].replace('＆', '&'), data=urldata)
            json1 = json.loads(r.text)
            try:
                if json1['success'] > 0:
                    for eww in lste:
                        global_map.yitui_url_list.append(eww)
            except:
                for eww in lste:
                    global_map.meitui_url_list.append(eww)
            global_map.site_log.append('########### map地图百度普通提交时间：' + time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()) + '###########')
            
            mun=str(len(lste))
            global_map.site_log.append('推送数量：' + mun + '条-推送响应：' + str(json1) +'')
    
        if sql_nr[11] == 1:
            baidukuaisu=[]
            if len(lste)>=10:
                for i in range(10):
                    baidukuaisu.append(lste[i])
            else:
                baidukuaisu =lste
            urldata32 = '\n'.join(baidukuaisu)
            r = requests.post(sql_nr[14].replace('＆', '&'), data=urldata32)
            json1 = json.loads(r.text)
            global_map.site_log.append('########### map地图百度快速提交时间：' + time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()) + '###########')
            mun = len(baidukuaisu)
            global_map.site_log.append('推送数量：'+str(mun) +'条-推送响应：' + str(json1))
        if sql_nr[12] == 1:
            r = requests.post(sql_nr[15].replace('＆', '&'), data=urldata)
            json1 = json.loads(r.text)
            global_map.site_log.append('########### map地图神马提交时间：'+time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())+'###########')
            mun = len(lste)
            global_map.site_log.append('推送数量：'+str(mun) +'条-推送响应：'+ str(json1))
        if sql_nr[10]==1 or sql_nr[12]==1:
            connect_mun(id,str(len(lste)))
    else:
        global_map.site_log.append('########### map地图提交时间：' + time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()) + '###########')
        global_map.site_log.append('没有新的未推送URL')
if __name__ == "__main__":
    if not os.path.isfile(huancunwenjianming):
        fp = open(huancunwenjianming,'w')#创建缓存
        fp.close()
        try:
            connect_list= connect_select()
            for i in connect_list:
                chaxun=connect_select_chaxun(str(i[0]))
                if chaxun[0][18] == 0:
                    miaoshu=(i[16]*60)
                    tmie=int(time.time())-miaoshu
                    if tmie>i[17]:
                        connect_updata(str(i[0]),'1')
                        if i[2]=='1':
                            global_map.host = 'http://' +i[1] + '/'
                        else:
                            global_map.host = 'https://' + i[1] + '/'
                        
                        global_map.id = str(i[0])
                        global_map.site = i[1]
                        try:
                            newfile(global_map.id,global_map.site)
                            global_map.news_url_list = readtxt(global_map.id+'_'+global_map.site+'_1.txt')#未爬取过的url
                            global_map.old_url_list = readtxt(global_map.id+'_'+global_map.site+'_2.txt')  # 采集到的url
                            global_map.yitui_url_list = readtxt(global_map.id+'_'+global_map.site+'_3.txt')#已推送
                            global_map.meitui_url_list = readtxt(global_map.id+'_'+global_map.site+'_4.txt')#未推送
                            global_map.sougoutui_url_list = readtxt(global_map.id+'_'+global_map.site+'_5.txt')#sougou
                            global_map.site_log = readtxt(global_map.id + '_' + global_map.site + '_log.txt')  # 推送日记
                            global_map.url_guolv = i[7].split('+')
                            for aa in global_map.url_guolv:
                                global_map.news_url_list.append(aa)
                            craw()
                            tuisong(i,str(i[0]))
                            output_html()
                            connect_updata(str(i[0]),'0')#更新任务开关
                            connect_updatatime(str(i[0]))#更新执行时间
                            print('=============================================================')
                            print('=                                                           =')
                            print('=   '+global_map.host+'=====map地图推送完成=====')
                            print('=                                                           =')
                            print('=============================================================')
                        except Exception as e:
                            print(e)
                            connect_updata(str(i[0]),'0')#更新任务开关
            try:                
                os.remove(huancunwenjianming) 
            except:
                pass
        except:
            os.remove(huancunwenjianming)
    else:
        print('正在运行中····')
        