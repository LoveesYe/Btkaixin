# coding: utf-8
import json
import os
import time
import global_val
import sys
import random
import traceback
import datetime
if 'win' in sys.platform:
    try:
        import psutil
    except:
        os.system('pip install psutil')
        import psutil
    
    try:
        from bs4 import BeautifulSoup
    except:
        os.system('pip install bs4')
        from bs4 import BeautifulSoup
    try:
        import requests
    except:
        os.system('pip install requests')
        import requests
    try:
        import sqlite3
    except:
        os.system('pip install sqlite3')
        import sqlite3
    try:
        import re
    except:
        os.system('pip install re')
        import re
    try:
        import urllib.request
        from urllib.parse import quote
        import urllib.parse
    except:
        os.system('pip install urllib')
        import urllib.request
        from urllib.parse import quote
        import urllib.parse
        opener = urllib.request.build_opener()
else:
    import psutil
    from bs4 import BeautifulSoup
    import requests
    import sqlite3
    import re
    import urllib.request
    from urllib.parse import quote
    import urllib.parse
    opener = urllib.request.build_opener()

# 设置运行目录
basedir = os.path.abspath(os.path.dirname(__file__))
try:
    os.chdir("/www/server/panel")
except :
    os.chdir(os.path.join(basedir, '..', '..', '..'))
# 添加包引用位置并引用公共包
sys.path.append("class/")
import public

sqlconnect=basedir+'/db/tsdb.db'
site_cache_lj=basedir+'/site_cache/'
huancunwenjianming=basedir+'/zidongtuisong.txt'
config_file=basedir+'/config_cache/config.json'

# def xieru(sda):
#     now_time = datetime.datetime.now()
#     fp = open(basedir+'/log11.txt', 'a+')  # 创建缓存
#     fp.writelines(sda+'=='+str(now_time)+'\n')
#     fp.close()

def connect_select():
    sqlite3conn = sqlite3.connect(sqlconnect)
    daaaa = "select * from tuisong where tslx=1"
    cur = sqlite3conn.cursor()
    cur.execute(daaaa)
    iplist = cur.fetchall()
    cur.close()
    sqlite3conn.close()
    return iplist


def connect_select_chaxun(id):
    sqlite3conn = sqlite3.connect(sqlconnect)
    daaaa = "select * from tuisong where id='" + id + "'"
    cur = sqlite3conn.cursor()
    cur.execute(daaaa)
    iplist = cur.fetchall()
    cur.close()
    sqlite3conn.close()
    return iplist


def connect_updata(id, open):
    sqlite3conn = sqlite3.connect(sqlconnect)
    daaaa = "update `tuisong` SET open='" + open + "' where id='" + id + "'"
    cur = sqlite3conn.cursor()
    cur.execute(daaaa)
    sqlite3conn.commit()
    cur.close()
    sqlite3conn.close()


def connect_updatatime(id):
    t = time.time()
    sqlite3conn = sqlite3.connect(sqlconnect)
    daaaa = "update `tuisong` SET ts_shart_time='" + str(int(t)) + "' where id='" + id + "'"
    cur = sqlite3conn.cursor()
    cur.execute(daaaa)
    sqlite3conn.commit()
    cur.close()
    sqlite3conn.close()


def connect_mun(id, shuliang):
    sqlite3conn = sqlite3.connect(sqlconnect)
    daaaa = "update `tuisong` SET tijiaoshu=tijiaoshu+'" + shuliang + "' where id='" + id + "'"
    cur = sqlite3conn.cursor()
    cur.execute(daaaa)
    sqlite3conn.commit()
    cur.close()
    sqlite3conn.close()


def connect_sougoumun(id, shuliang):  # 更新搜狗推送数量
    sqlite3conn = sqlite3.connect(sqlconnect)
    daaaa = "update `tuisong` SET ts_sougouts_shuliang=ts_sougouts_shuliang+" + shuliang + " where id='" + id + "'"
    cur = sqlite3conn.cursor()
    cur.execute(daaaa)
    sqlite3conn.commit()
    cur.close()
    sqlite3conn.close()


def connect_sougou_msg(id, neirong):  # 更新搜狗API的msg
    sqlite3conn = sqlite3.connect(sqlconnect)
    daaaa = "update `tuisong` SET ts_sougou_msg='" + neirong + "' where id='" + id + "'"
    cur = sqlite3conn.cursor()
    cur.execute(daaaa)
    sqlite3conn.commit()
    cur.close()
    sqlite3conn.close()


def getheaders():
    user_agent_list = [
        'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/14.0.835.163 Safari/535.1',
        'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:6.0) Gecko/20100101 Firefox/6.0',
        'Opera/9.80 (Windows NT 6.1; U; zh-cn) Presto/2.9.168 Version/11.50',
        'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; WOW64; Trident/5.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; InfoPath.3; .NET4.0C; .NET4.0E; SE 2.X MetaSr 1.0)',
        'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/534.3 (KHTML, like Gecko) Chrome/6.0.472.33 Safari/534.3 SE 2.X MetaSr 1.0',
        'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; InfoPath.3; .NET4.0C; .NET4.0E)',
        'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:17.0) Gecko/20100101 Firefox/17.0.6',
        'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/13.0.782.41 Safari/535.1 QQBrowser/6.9.11079.201',
        'Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2224.3 Safari/537.36',
        'Mozilla/5.0 (X11; CrOS i686 3912.101.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36']
    UserAgent = random.choice(user_agent_list)
    return UserAgent


def get_new_url():
    new_url = global_val.news_url_list.pop()
    return new_url


def parse(page_url, html_cnt):
    # xieru('开始parse')
    if page_url is None or html_cnt is None:
        return
    soup = BeautifulSoup(html_cnt, 'html.parser', from_encoding='utf-8')
    new_urls = _get_new_urls(page_url, soup)
    return new_urls


# 添加遍历每个页面抓取的url列表
def add_new_urls(urls):
    # xieru('开始add_new_urls')
    if urls is None or len(urls) == 0:
        return
    for url in urls:
        add_new_url(url)


def has_new_url():
    return len(global_val.news_url_list) != 0


def _get_new_urls(page_url, soup):
    new_urls = set()
    links = soup.find_all('a', href=re.compile(r".*"))
    base_url = global_val.host
    for link in links:
        new_url = link['href']
        new_url_full = urllib.parse.urljoin(page_url, new_url)
        if new_url_full.find(base_url) < 0:
            continue
        new_urls.add(new_url_full)
    return new_urls


def add_new_url(url):
    base_url = global_val.host
    if url is None:
        return
    if url.find("http") > -1 and url.find(base_url) < 0:
        return
    if re.compile(r":[a-zA-Z0-9();]").findall(url) \
            or url.find("#") > 0 or url.find(".xml") > 0 \
            or url.find(".jpg") > 0 or url.find(".png") > 0 \
            or url.find(".gif") > 0 or url.find(".zip") > 0 \
            or url.find(".rar") > 0 or url.find(".bmp") > 0 \
            or url.find(".doc") > 0 or url.find(".doc") > 0 \
            or url.find(".pdf") > 0 or url.find(".xls") > 0 \
            or url.find(".css") > 0 or url.find(".xml") > 0 \
            or url.find(".docx") > 0 or url.find(".xlsx") > 0:
        return
    if len(global_val.url_guolv) > 0:
        for i in global_val.url_guolv:
            if url.find(i) > 0:
                return
    if url not in global_val.old_url_list:
        global_val.old_url_list.append(url)
        global_val.news_url_list.append(url)
        global_val.meitui_url_list.append(url)
        global_val.sougoutui_url_list.append(url)


def output_html():
    # xieru('开始output_html')
    f1 = open(site_cache_lj + global_val.id + '_' + global_val.site + '_1.txt', 'w', encoding='utf8')
    for each1 in global_val.news_url_list:
        f1.writelines(each1 + '\n')

    f1.close()
    f2 = open(site_cache_lj + global_val.id + '_' + global_val.site + '_2.txt', 'w', encoding='utf8')
    for each2 in global_val.old_url_list:
        f2.writelines(each2 + '\n')

    f2.close()
    f3 = open(site_cache_lj + global_val.id + '_' + global_val.site + '_3.txt', 'w', encoding='utf8')
    for each3 in global_val.yitui_url_list:
        f3.writelines(each3 + '\n')

    f3.close()
    f4 = open(site_cache_lj + global_val.id + '_' + global_val.site + '_4.txt', 'w', encoding='utf8')
    for each4 in global_val.meitui_url_list:
        f4.writelines(each4 + '\n')

    f4.close()
    f6 = open(site_cache_lj + global_val.id + '_' + global_val.site + '_5.txt', 'w', encoding='utf8')
    for each6 in global_val.sougoutui_url_list:
        f6.writelines(each6 + '\n')

    f6.close()
    if len(global_val.site_log) <= 1200:
        f5 = open(site_cache_lj + global_val.id + '_' + global_val.site + '_log.txt', 'w', encoding='utf8')
        for each5 in global_val.site_log:
            f5.writelines(each5 + '\n')

        f5.close()
    else:
        lisad = []
        in5 = len(global_val.site_log) - 1
        for i in range(6):
            lisad.append(global_val.site_log[in5])
            in5 -= 1
        f5 = open(site_cache_lj + global_val.id + '_' + global_val.site + '_log.txt', 'w', encoding='utf8')
        for each5 in lisad:
            f5.writelines(each5 + '\n')
        f5.close()


def craw(root_url):
    # xieru('开始craw')
    count = 1
    global_val.news_url_list.append(root_url)
    while has_new_url():
        try:
            new_url = get_new_url()

            html_cnt = global_val.download(new_url)
            # print(html_cnt)
            new_urls = parse(new_url, html_cnt)
            # print(new_urls)
            add_new_urls(new_urls)
            if 0 < global_val.num == count:
                break
            count = count + 1
        except Exception as e:
            # traceback.print_exc()
            # print('craw出错')
            print('')



# 读取文件
def readtxt(wjnama):
    f = open(site_cache_lj + wjnama, 'r', encoding='utf8')
    data = f.read().splitlines()
    f.close()
    return data


def newfile(id, site):
    name = [id + '_' + site + '_1.txt', id + '_' + site + '_2.txt', id + '_' + site + '_3.txt',
            id + '_' + site + '_4.txt', id + '_' + site + '_log.txt']
    for i in name:
        if not os.path.isfile(site_cache_lj + i):
            fp = open(site_cache_lj + i, 'w')
            fp.close()
    if not os.path.isfile(site_cache_lj + id + '_' + site + '_5.txt'):
        fp3 = open(site_cache_lj + id + '_' + site + '_2.txt', 'r')
        data = fp3.read()
        fp3 = open(site_cache_lj + id + '_' + site + '_5.txt', 'w')
        fp3.write(data)
        fp3.close()


def jiance(sda):
    for i in sda:
        tempUrl = i
        try:
            headers = {
                'User-Agent': 'Mozilla/5.0 (compatible; Baiduspider/2.0;+http://www.baidu.com/search/spider.html)'
            }
            r = requests.get(tempUrl + '/jiance/', headers=headers, timeout=5)
            code = r.status_code
            if code == 200:
                return tempUrl
        except:
            time.sleep(2)


def tuisong(sql_nr, id):
    # xieru('开始tuisong')
    headers = {'User-Agent': 'User-Agent:' + getheaders()}
    if sql_nr[21] == 1:
        URLTS = jiance(global_val.TBS_HTTPS)
        if len(global_val.sougoutui_url_list) > 0:
            sougoulste = []
            if len(global_val.sougoutui_url_list) >= 20:
                for i in range(20):
                    sougoulste.append(global_val.sougoutui_url_list.pop())
                try:
                    dataew = {'sougou_ts_api': sql_nr[20], 'ts_mun': '20', 'pc_wap': sql_nr[22],
                              'ts_web_list': str(sougoulste).replace("""'""", '''"''')}

                    r = requests.post(URLTS + '/API/sougou_ts_api/set_sougoutuisong_cache.php', data=dataew,
                                      headers=headers)
                    # print(URLTS)
                    # print(dataew)
                    # print(r.text)
                    json1 = json.loads(r.text)
                    if json1['code'] == 0:
                        connect_sougoumun(id, "20")  # 更新搜狗推送数量
                        global_val.site_log.append('########### 自动搜狗提交时间：' + time.strftime("%Y-%m-%d %H:%M:%S",
                                                                                           time.localtime()) + '###########')
                        global_val.site_log.append('推送数量：20条')
                        connect_sougou_msg(id, json1['msg2'])
                    else:
                        global_val.site_log.append('########### 自动搜狗提交时间：' + time.strftime("%Y-%m-%d %H:%M:%S",
                                                                                           time.localtime()) + '###########')
                        global_val.site_log.append('推送失败：' + json1['msg'])
                        connect_sougou_msg(id, json1['msg'])
                        for eww2 in sougoulste:
                            global_val.sougoutui_url_list.append(eww2)
                except Exception as e:
                    # traceback.print_exc()
                    # print('tuisong出错')
                    for eww2 in sougoulste:
                        global_val.sougoutui_url_list.append(eww2)
            else:
                try:
                    data432 = {'sougou_ts_api': sql_nr[20], 'ts_mun': len(global_val.sougoutui_url_list),
                               'pc_wap': sql_nr[22],
                               'ts_web_list': str(global_val.sougoutui_url_list).replace("""'""", '''"''')}
                    r = requests.post(URLTS + '/API/sougou_ts_api/set_sougoutuisong_cache.php', data=data432,
                                      headers=headers)
                    json1 = json.loads(r.text)
                    if json1['code'] == 0:
                        global_val.site_log.append('########### 自动搜狗提交时间：' + time.strftime("%Y-%m-%d %H:%M:%S",
                                                                                           time.localtime()) + '###########')
                        global_val.site_log.append('推送数量：' + str(len(global_val.sougoutui_url_list)) + '条')
                        connect_sougoumun(id, str(len(global_val.sougoutui_url_list)))  # 更新搜狗推送数量
                        global_val.sougoutui_url_list.clear()
                    else:
                        global_val.site_log.append('########### 自动搜狗提交时间：' + time.strftime("%Y-%m-%d %H:%M:%S",
                                                                                           time.localtime()) + '###########')
                        global_val.site_log.append('推送失败：' + json1['msg'])
                        connect_sougou_msg(id, json1['msg'])
                except Exception as e:
                    traceback.print_exc()
                    print('搜狗推送出错')
                    print(e)

    ints = global_val.num

    lste = []
    if len(global_val.meitui_url_list) > 0:
        if len(global_val.meitui_url_list) >= ints:
            for i in range(ints):
                lste.append(global_val.meitui_url_list.pop())
        else:
            while len(global_val.meitui_url_list) != 0:
                lste.append(global_val.meitui_url_list.pop())
        urldata = '\n'.join(lste)
        if sql_nr[10] == 1:
            r = requests.post(sql_nr[13].replace('＆', '&'), data=urldata)
            json1 = json.loads(r.text)
            try:
                if json1['success'] > 0:
                    for eww in lste:
                        global_val.yitui_url_list.append(eww)
            except:
                for eww in lste:
                    global_val.meitui_url_list.append(eww)
            global_val.site_log.append(
                '########### 自动推送百度普通提交时间：' + time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()) + '###########')
            # print(''+str(len(lste)))
            mun = str(len(lste))
            global_val.site_log.append('推送数量：' + mun + '条-推送响应：' + str(json1) + '')

        if sql_nr[11] == 1:
            baidukuaisu = []
            if len(lste) >= 10:
                for i in range(10):
                    baidukuaisu.append(lste[i])
            else:
                baidukuaisu = lste
            urldata32 = '\n'.join(baidukuaisu)
            r = requests.post(sql_nr[14].replace('＆', '&'), data=urldata32)
            json1 = json.loads(r.text)
            global_val.site_log.append(
                '########### 自动推送百度快速提交时间：' + time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()) + '###########')
            mun = len(baidukuaisu)
            global_val.site_log.append('推送数量：' + str(mun) + '条-推送响应：' + str(json1))
        if sql_nr[12] == 1:
            r = requests.post(sql_nr[15].replace('＆', '&'), data=urldata)
            json1 = json.loads(r.text)
            global_val.site_log.append(
                '########### 自动推送神马提交时间：' + time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()) + '###########')
            mun = len(lste)
            global_val.site_log.append('推送数量：' + str(mun) + '条-推送响应：' + str(json1))
        if sql_nr[10] == 1 or sql_nr[12] == 1:
            connect_mun(id, str(len(lste)))
        # print('推送数量：'+str(len(lste)) +'条')
    else:
        global_val.site_log.append(
            '########### 自动推送提交时间：' + time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()) + '###########')
        global_val.site_log.append('没有新的未推送URL')
def read_pid():
    if os.path.exists(huancunwenjianming):
        fp = open(huancunwenjianming,'r')
        pid = fp.read()
        fp.close()
        return pid
    else:
        return False

if __name__ == "__main__":
    
    if not os.path.isfile(huancunwenjianming):
        pid = os.getpid()
        fp = open(huancunwenjianming, 'w')  # 创建缓存
        fp.writelines(str(pid))
        fp.close()
        try:
            connect_list = connect_select()
            for i in connect_list:
                chaxun = connect_select_chaxun(str(i[0]))
                if chaxun[0][18] == 0:
                    miaoshu = (i[16] * 60)
                    tmie = int(time.time()) - miaoshu
                    if tmie > i[17]:
                        connect_updata(str(i[0]), '1')
                        if i[2] == '1':
                            global_val.host = 'http://' + i[1] + '/'
                        else:
                            global_val.host = 'https://' + i[1] + '/'
                        global_val.num = i[5]
                        global_val.id = str(i[0])
                        global_val.site = i[1]

                        try:
                            if i[6] not in '':
                                global_val.url_guolv = i[6].split('|')
                        except:
                            print('')
                        try:
                            newfile(global_val.id, global_val.site)
                            global_val.news_url_list = readtxt(global_val.id + '_' + global_val.site + '_1.txt')
                            global_val.old_url_list = readtxt(global_val.id + '_' + global_val.site + '_2.txt')
                            global_val.yitui_url_list = readtxt(global_val.id + '_' + global_val.site + '_3.txt')
                            global_val.meitui_url_list = readtxt(global_val.id + '_' + global_val.site + '_4.txt')
                            global_val.sougoutui_url_list = readtxt(global_val.id + '_' + global_val.site + '_5.txt')
                            global_val.site_log = readtxt(global_val.id + '_' + global_val.site + '_log.txt')

                            craw(i[4])
                            tuisong(i, str(i[0]))
                            output_html()
                            connect_updata(str(i[0]), '0')
                            connect_updatatime(str(i[0]))

                            print('=============================================================')
                            print('=                                                           =')
                            print('=   ' + global_val.host + '=====自动推送推送完成=====')
                            print('=                                                           =')
                            print('=============================================================')
                        except Exception as e:
                            traceback.print_exc()
                            print('爬取出错。请联系群主')
                            print(e)
                            print('__name__出错')
                            connect_updatatime(str(i[0]))
                            connect_updata(str(i[0]), '0')  # 1622981065
            try:
                os.remove(huancunwenjianming)
            except Exception as e:
                traceback.print_exc()
                print('__name__2出错')
        except Exception as e:
            traceback.print_exc()
            os.remove(huancunwenjianming)
    else:
        pid = read_pid()
        #print pid
        pid = int(pid)
        if pid:
            running_pid = psutil.pids()
        if pid in running_pid:
            print('正在运行中····')
        else:
            os.remove(huancunwenjianming)
        