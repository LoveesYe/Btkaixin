# coding: utf-8
import json
import os
import time
import sys
import random
import traceback
import datetime
if 'win' in sys.platform:
    
    try:
        import requests
    except:
        os.system('pip install requests')
        import requests
    try:
        from urllib.parse import quote
        
    except:
        os.system('pip install urllib')
        from urllib.parse import quote
        
else:
    
    import requests
    from urllib.parse import quote
    

# 设置运行目录
basedir = os.path.abspath(os.path.dirname(__file__))
try:
    os.chdir("/www/server/panel")
except :
    os.chdir(os.path.join(basedir, '..', '..', '..'))
# 添加包引用位置并引用公共包
sys.path.append("class/")
import public

sqlconnect=basedir+'/db/tsdb.db'
site_cache_lj=basedir+'/site_cache/'
huancunwenjianming=basedir+'/zidongtuisong.txt'
config_file=basedir+'/config_cache/config.json'

host = None
num = 20
id=None
site=None
news_url_list = []
old_url_list = []
yitui_url_list = []
meitui_url_list = []
sougoutui_url_list= []
site_log = []
url_guolv=[]
TBS_HTTPS=['https://api.tbsoe.top','http://api2.tbsoe.top','http://api3.tbsoe.top','http://api4.tbsoe.top']


def getheaders():
    user_agent_list = [
        'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/14.0.835.163 Safari/535.1',
        'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:6.0) Gecko/20100101 Firefox/6.0',
        'Opera/9.80 (Windows NT 6.1; U; zh-cn) Presto/2.9.168 Version/11.50',
        'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; WOW64; Trident/5.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; InfoPath.3; .NET4.0C; .NET4.0E; SE 2.X MetaSr 1.0)',
        'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/534.3 (KHTML, like Gecko) Chrome/6.0.472.33 Safari/534.3 SE 2.X MetaSr 1.0',
        'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; InfoPath.3; .NET4.0C; .NET4.0E)',
        'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:17.0) Gecko/20100101 Firefox/17.0.6',
        'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/13.0.782.41 Safari/535.1 QQBrowser/6.9.11079.201',
        'Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2224.3 Safari/537.36',
        'Mozilla/5.0 (X11; CrOS i686 3912.101.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36']
    UserAgent = random.choice(user_agent_list)
    return UserAgent
def download(url):
    
    if not os.path.isfile(config_file):
        headers = {'User-Agent': getheaders()}
    else:
        f_body = public.ReadFile(config_file)
        __config = json.loads(f_body)
        if __config['sougou_spider'] == "1":
            # 普通浏览器
            headers = {'User-Agent': getheaders()}
        elif __config['sougou_spider'] == "2":
            # 百度
            headers = {
                'User-Agent': 'Mozilla/5.0 (compatible; Baiduspider/2.0;+http://www.baidu.com/search/spider.html)'}
        elif __config['sougou_spider'] == "3":
            # 神马蜘蛛
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.81 YisouSpider/5.0 Safari/537.36'}
        elif __config['sougou_spider'] == "4":
            # 搜狗蜘蛛
            headers = {'User-Agent': 'Sogou web spider/3.0(+http://www.sogou.com/docs/help/webmasters.htm#07)'}
        elif __config['sougou_spider'] == "5":
            # 360蜘蛛
            headers = {'User-Agent': 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0); 360Spider'}
        elif __config['sougou_spider'] == "6":
            # 头条蜘蛛
            headers = {
                'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181;Bytespider;https://zhanzhang.toutiao.com/'}
        elif __config['sougou_spider'] == "7":
            # BING蜘蛛
            headers = {'User-Agent': 'Mozilla/5.0 (compatible; bingbot/2.0; +http://www.bing.com/bingbot.htm)'}
        else:
            # 普通浏览器
            headers = {'User-Agent': getheaders()}

    # print(headers)

    if url is None:
        return
    url = quote(url, safe="?#/:=@")
    # print('开始download=='+url)
    req = requests.get(url=url, headers=headers, timeout=20)
    if req.status_code != 200:
        return None
    # print('完成download=='+url)
    return req.content