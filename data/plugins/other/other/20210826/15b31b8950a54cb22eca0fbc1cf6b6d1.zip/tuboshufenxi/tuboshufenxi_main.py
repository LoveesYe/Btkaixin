#!/usr/bin/python
# coding: utf-8
# +-------------------------------------------------------------------
# | 土拨鼠网站日记分析管理
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 土拨鼠网站日记分析管理 All rights reserved.
# +-------------------------------------------------------------------
# | Author: 圣仔 <3132352829@qq.com>
# +-------------------------------------------------------------------

#+--------------------------------------------------------------------
#|   土拨鼠网站日记分析管理
#+--------------------------------------------------------------------
import sys,os,json,hashlib,datetime,sqlite3,time,re,string,random,requests,string
try:
    from bs4 import BeautifulSoup
except:
    os.system('pip install bs4')
    from bs4 import BeautifulSoup
try:
    import urllib.request
    from urllib.parse import quote
    import urllib.parse
except:
    os.system('pip install urllib')
    import urllib.request
    from urllib.parse import quote
    import urllib.parse
#设置运行目录
# os.chdir("/www/server/panel")
basedir = os.path.abspath(os.path.dirname(__file__))
try:
    os.chdir("/www/server/panel")
except :
    os.chdir(os.path.join(basedir, '..', '..'))
#添加包引用位置并引用公共包
sys.path.append("class/")
import public,db,firewalls
#from common import dict_obj
#get = dict_obj();


#在非命令行模式下引用面板缓存和session对象
if __name__ != '__main__':
    from BTPanel import cache,session



class tuboshufenxi_main:
    __plugin_path = "/www/server/panel/plugin/tuboshufenxi/"
    try:
        os.chdir("/www/server/panel")
    except :
        os.chdir(os.path.join(basedir, '..', '..'))
        __plugin_path = basedir.rstrip('/')+'\\'
    __tuisong_path =__plugin_path+'tuisong/site_cache/'
    __logspath = "/www/wwwlogs/"
    log_conn=""
    conn=""
    conn_zidian=""

    #构造方法
    def  __init__(self):
        
        self.logdb('')
        pass
    i='7'
    #数据库连接
    def logdb(self,args):
        #读取配置项
        # config_file = self.__plugin_path + 'config_cache/config.json'
        # f_body = public.ReadFile(config_file)
        # __config = json.loads(f_body)
        __config=self.get_config('')
        if __config['mysql_db']=='':
            return False
        if __config['mysql_psd']=='':
            return False
        if __config['mysql_username']=='':
            return False
        if not 'mysql_port' in __config:
            __config['mysql_port'] = 3306
        if __config['versions'] !='8.0':
            try:
                os.remove(self.__plugin_path+'tuisong/zidongtuisong.txt')
            except:
                pass
            try:
                os.remove(self.__plugin_path+'tuisong/sitemaptuisong.txt')
            except:
                pass
            try:
                os.remove(self.__plugin_path+'tuisong/fanmulutuisong.txt')
            except:
                pass
            try:
                sqlite3conn = sqlite3.connect(self.__plugin_path+'tuisong/db/tsdb.db')
                daaaa = "select * from tuisong"
                cur = sqlite3conn.cursor()
                cur.execute(daaaa)
                iplistffff = cur.fetchall()
                cur.close()
                sqlite3conn.close()
                
                for iadadada in iplistffff:
                    sqlite3conn = sqlite3.connect(self.__plugin_path+'tuisong/db/tsdb.db')
                    daaaass = "update `tuisong` SET open='0' where id="+str(iadadada[0])
                    cur = sqlite3conn.cursor()
                    cur.execute(daaaass)
                    sqlite3conn.commit()
                    cur.close()
                    sqlite3conn.close()
                    
            except:
                pass
            
            self.__set_config('versions','8.0')
           
        try:
            import pymysql
            self.log_conn = pymysql.connect(host=__config['mysql_host'],user=__config['mysql_username'],password=__config['mysql_psd'],db=__config['mysql_db'],port=int(__config['mysql_port']), charset='utf8')
            self.conn = self.log_conn.cursor()
            self.conn_zidian = self.log_conn.cursor(pymysql.cursors.DictCursor)
            #更新数据库字段
            # if not 'versions' in __config:
            #     site_list = public.M('sites').field('name').order('id desc').select()
            #     for oi23 in site_list:
            #         exsqwwwl = '''alter table `'''+oi23['name']+'''` modify column referer varchar(250);'''
            #         exsqwww2 = '''alter table `'''+oi23['name']+'''` modify column pageurl varchar(250);'''
            #         self.conn.execute(exsqwwwl)
            #         self.conn.execute(exsqwww2)
            #     self.__set_config('versions','6.0')
            return {'status':0,'data':'数据库链接成功'}
        except:
            return {'status':0}
    #======================公共方法区=================================
    def mysqlkaiguanl(self,args):
        __config=self.get_config('')
        if __config['mysql_db']=='':
            mysqlkaiguanl=0
        else:
            mysqlkaiguanl=1
            
        return {'mysqlkaiguanl':mysqlkaiguanl}  
    def get_shujuku(self,args):
        __config=self.get_config('')
        if __config['mysql_db']=='':
            __config['mysql_db'] = 'weblog3'
        list1=[]
        list2=[]
        site_list = public.M('sites').field('name').order('id desc').select()
        for oi in site_list:
            list1.append(oi['name'])
        self.conn.execute("select table_name from information_schema.tables where table_schema='"+ __config['mysql_db'] +"'")
        iplist = self.conn.fetchall()
        for i in iplist:
            
            if i[0] != 'monitor_ip' and i[0] != 'monitor_url' and i[0] != 'spidersite' and i[0] != 'spider_num':
                list2.append(i[0])  
        asa=sorted(set(list1)-set(list2))
        for ii in asa:
            exsql = '''create table  `'''+ii+'''` (
                    id INT NOT NULL AUTO_INCREMENT,
                	website text,
                	ip varchar(20),
                	time datetime,
                	day2 int,
                	httpstatus INT,
                	size INT,
                	httpmothed varchar(30),
                	pageurl varchar(250),
                	referer varchar(250),
                	shebieinfo varchar(250),
                	spider INT,
                	spider_index INT,
                	PRIMARY KEY (`id`,`day2`),
					KEY `time` (`time`),
                    KEY `spider` (`spider`),
                    KEY `day2` (`day2`),
                    KEY `spider_index` (`spider_index`),
                    KEY `ip` (`ip`),
                    KEY `shebieinfo` (`shebieinfo`),
                    KEY `httpmothed` (`httpmothed`),
                    KEY `pageurl` (`pageurl`)
                )
                partition by range(day2)(
                    partition p1 values less than(1),
                	partition p2 values less than(2),
                	partition p3 values less than(3),
                	partition p4 values less than(4),
                	partition p5 values less than(5),
                	partition p6 values less than(6),
                	partition p7 values less than(7),
                	partition p8 values less than(8),
                	partition p9 values less than(9),
                	partition p10 values less than(10),
                	partition p11 values less than(11),
                	partition p12 values less than(12),
                	partition p13 values less than(13),
                	partition p14 values less than(14),
                	partition p15 values less than(15),
                	partition p16 values less than(16),
                	partition p17 values less than(17),
                	partition p18 values less than(18),
                	partition p19 values less than(19),
                	partition p20 values less than(20),
                	partition p21 values less than(21),
                	partition p22 values less than(22),
                	partition p23 values less than(23),
                	partition p24 values less than(24),
                	partition p25 values less than(25),
                	partition p26 values less than(26),
                	partition p27 values less than(27),
                	partition p28 values less than(28),
                	partition p29 values less than(29),
                	partition p30 values less than(30),
                	partition p31 values less than(31),
                	partition p32 values less than(32),
                	partition p33 values less than(33)
                    );'''
            try:
                res=self.conn.execute(exsql)
            except:
                res=1
        asa1=sorted(set(list2)-set(list1))
        for iii in asa1:
            exsql1 = '''DROP TABLE `'''+iii+'''`;'''
            try:
                res=self.conn.execute(exsql1)
            except:
                return False
                
        return True
    #读取配置文件
    def get_config(self,args):
        config_file = self.__plugin_path + 'config_cache/config.json'
        #判断文件是否存在
        if not os.path.isfile(config_file):
            f_body = public.ReadFile(self.__plugin_path + 'config.json')
            public.WriteFile(config_file,f_body)
        #判断是否从文件读取配置
        if not os.path.exists(config_file):
            return None
        f_body = public.ReadFile(config_file)
        if not f_body:
            return None
        self.__config = json.loads(f_body)
        return self.__config
    u='1'
    #写配置文件
    def set_config(self,args):
        __config=self.get_config('')
        #是否需要初始化配置项
        if not __config: 
            __config = {}
        #是否需要设置配置值
        if args.key:
            __config[args.key] = args.value
        #写入到配置文件
        config_file = self.__plugin_path + 'config_cache/config.json'
        public.WriteFile(config_file,json.dumps(__config))
        return True
    rr2r='in'
    h='8'
    #获取站点列表
    def get_weblist(self,args):
        site_list = public.M('sites').field('id,name,ps').order('id desc').select()
        return {'weblist':site_list}
    
    #查询是否黑名单
    def isheimingdan(self,args):
        if public.M('firewall').where("port=?",(args.ip,)).count() > 0: 
            return {'stauts':1}
        else:
            return {'stauts':0}
    f='2'
    #读取日志文件内容
    def logsdata(self,args):
        if not 'website' in args:
            args.website = 'access'
        if not 's_datetime' in args:
            args.s_datetime = (datetime.datetime.now()).strftime("%Y-%m-%d 00:00:01")
        if not 'e_datetime' in args:
            args.e_datetime = (datetime.datetime.now()).strftime("%Y-%m-%d 23:59:59")
        if not 'sxlx' in args:
            args.sxlx = ''
        if not 'keyword' in args:
            args.keyword = ''
        if not 'page' in args:
            args.page = 0
    pod2='de'
    #将IP地址加入黑名单
    def iplahei(self,args):
        fw=firewalls.firewalls()
        res=fw.AddDropAddress(args)
        return res
    d='c'
    #=============================================================================
    #======================统计概括统计分析方法区===================================
    #统计概括统计
    aaa32='x'
    def get_shouye(self,args):
        #查询条件
        if not 'website' in args:
            args.website = 'access'
        if not 's_datetime' in args:
            args.s_datetime = (datetime.datetime.now()).strftime("%Y-%m-%d 00:00:01")
        if not 'e_datetime' in args:
            args.e_datetime = (datetime.datetime.now()).strftime("%Y-%m-%d 23:59:59")
        self.nfhads_md5('')
        s_datetime = datetime.datetime.strptime(args.s_datetime, "%Y-%m-%d %H:%M:%S").strftime("%d")
        e_datetime = datetime.datetime.strptime(args.e_datetime, "%Y-%m-%d %H:%M:%S").strftime("%d")
        time1 = datetime.datetime.strptime(args.s_datetime,"%Y-%m-%d %H:%M:%S").strftime("%m")
        time2 = datetime.datetime.strptime(args.e_datetime,"%Y-%m-%d %H:%M:%S").strftime("%m")
        if args.sousuo ==1:
            dayurl="time >= '" + args.s_datetime + "' and time <='" + args.e_datetime+ "' "
        else:
            if time1<time2:
                dayurl="day2<=" + e_datetime + " or day2 >=" +  s_datetime+ " "
            else:
                dayurl="day2>=" + s_datetime + " and day2 <=" + e_datetime + " "    
        
        self.nfhads_md5('')
        #数据库模式 totalinfo
        where=""+dayurl
        # where="where  (`time` >= '"+args.s_datetime+"'  AND `time`<= '"+args.e_datetime+"')"
        #计算总流量与访问人次,
        self.conn.execute("select count(ip),CAST(sum(size) AS CHAR) AS totalsize,count(distinct ip) from `"+args.website+"` where "+where)
        totalinfo = self.conn.fetchone()
        totalsize=public.to_size(totalinfo[1])
        totalinfo=list(totalinfo)
        totalinfo.append(totalsize)
        #统计搜索引擎
        sqlfsa="select count(distinct ip),count(id) from `"+args.website+"` where `spider_index`='1' and "+where+" "
        self.conn.execute("select count(distinct ip),count(id) from `"+args.website+"` where `spider_index`='1' and "+where+" ")
        baiduinfo = self.conn.fetchone()
        self.conn.execute("select count(distinct ip),count(id) from `"+args.website+"` where `spider_index`='2' and "+where+" ")
        sosoinfo = self.conn.fetchone()
        asdafff="select count(distinct ip),count(id) from `"+args.website+"` where `spider_index`='3' and "+where+" "
        self.conn.execute("select count(distinct ip),count(id) from `"+args.website+"` where `spider_index`='3' and "+where+" ")
        sllinfo = self.conn.fetchone()
        self.conn.execute("select count(distinct ip),count(id) from `"+args.website+"` where `spider_index`='4' and "+where+" ")
        sminfo = self.conn.fetchone()
        self.conn.execute("select count(distinct ip),count(id) from `"+args.website+"` where `spider_index`='5' and "+where+" ")
        googleinfo = self.conn.fetchone()
        #统计安全蜘蛛和可以蜘蛛
        self.conn.execute("select count(distinct ip) from `"+args.website+"` where `spider`='0' and "+where+" ")
        anquaninfo = self.conn.fetchone()
        self.conn.execute("select count(distinct ip) from `"+args.website+"` where `spider`='1' and "+where+" ")
        keyiinfo = self.conn.fetchone()
        return {'totalinfo':totalinfo,'baiduinfo':baiduinfo,'sosoinfo':sosoinfo,'sllinfo':sllinfo,'sminfo':sminfo,'googleinfo':googleinfo,'anquaninfo':anquaninfo,'keyiinfo':keyiinfo}
    fg=i+u+h
    #=============================================================================

    #======================服务器统计栏目方法区===================================
    def get_zhizhu_table_list(self,args):
        if not 's_datetime' in args:
            args.s_datetime = (datetime.datetime.now()).strftime("%Y-%m-%d 00:00:01")
        if not 'e_datetime' in args:
            args.e_datetime = (datetime.datetime.now()).strftime("%Y-%m-%d 23:59:59")
        if not 'p' in args:
            args.p = "1"
        wheretxt="where `time`>='"+args.s_datetime+"' and `time`<='"+args.e_datetime+"'"
        data = []
        sum_data = {}
        self.conn_zidian.execute("select CAST(sum(rendmun) AS SIGNED) AS rendmun, CAST(sum(spidermun) AS SIGNED) AS spidermun,CAST(sum(baidu) AS SIGNED) AS baidu,CAST(sum(sogou) AS SIGNED) AS sogou,CAST(sum(qh360) AS SIGNED) AS qh360,CAST(sum(yisou) AS SIGNED) AS yisou,CAST(sum(google) AS SIGNED) AS google,CAST(sum(bing) AS SIGNED) AS bing,CAST(sum(youdao) AS SIGNED) AS youdao,CAST(sum(soso) AS SIGNED) AS soso,CAST(sum(cc) AS SIGNED) AS cc,CAST(sum(ahrefs) AS SIGNED) AS ahrefs from  spider_num "+wheretxt+" LIMIT 1")
        iplist = self.conn_zidian.fetchall()
        try:
            for i in iplist:
                after = dict(sorted(i.items(), key=lambda e: e[1], reverse=True))
                for a, j in enumerate(after):
                    if j =='rendmun' or j =='spidermun':
                        s=9
                    else:
                        re33 = {}
                        re33[j]=i[j]
                        data.append(re33)
            sum_data["spider_total"] = iplist[0]['spidermun']
            sum_data["total_req"] = iplist[0]['rendmun']
        except:
            print('出错了')
        
        res_data = {
                "status": True,
                "data": data,
                "sum_data": sum_data 
            }
        return res_data
    def get_zhizhu_table_list_tbody(self,args):
        #查询条件
        if not 's_datetime' in args:
            args.s_datetime = (datetime.datetime.now()).strftime("%Y-%m-%d 00:00:01")
        if not 'e_datetime' in args:
            args.e_datetime = (datetime.datetime.now()).strftime("%Y-%m-%d 23:59:59")
        if not 'p' in args:
            args.p = "1"
        self.nfhads_md5('')
        wheretxt="where `time`>='"+args.s_datetime+"' and `time`<='"+args.e_datetime+"'"
        pagesize=(int(args.p)-1)*10
        self.conn_zidian.execute("select  website,CAST(sum(spidermun) AS SIGNED) AS spidermun,CAST(sum(baidu) AS SIGNED) AS baidu,CAST(sum(sogou) AS SIGNED) AS sogou,CAST(sum(qh360) AS SIGNED) AS qh360,CAST(sum(yisou) AS SIGNED) AS yisou,CAST(sum(google) AS SIGNED) AS google,CAST(sum(bing) AS SIGNED) AS bing,CAST(sum(youdao) AS SIGNED) AS youdao,CAST(sum(soso) AS SIGNED) AS soso,CAST(sum(cc) AS SIGNED) AS cc,CAST(sum(ahrefs) AS SIGNED) AS ahrefs from  spider_num "+wheretxt+" group by website order by spidermun desc LIMIT "+str(pagesize)+",10")
        iplist = self.conn_zidian.fetchall()
        #总数量
        self.conn.execute("select count(distinct(website)) from spider_num "+wheretxt+"")
        totallogs = self.conn.fetchone()[0] #总行数
        page_data = public.get_page(totallogs,int(args.p),10,'',result='1,2,3,4,5,6,7,8')
        
        return {"page":page_data,"data":iplist}
    #=============================================================================
    
    #======================蜘蛛url统计分析方法区==================================
    s='9'
    def get_spider_url_data(self,args):
        #查询条件
        if not 'website' in args:
            args.website = 'access'
        if not 'v_spider' in args:
            args.v_spider = "1"
        if not 's_datetime' in args:
            args.s_datetime = (datetime.datetime.now()).strftime("%Y-%m-%d 00:00:01")
        if not 'e_datetime' in args:
            args.e_datetime = (datetime.datetime.now()).strftime("%Y-%m-%d 23:59:59")
        if not 'p' in args:
            args.p = "1"
            
        s_datetime = datetime.datetime.strptime(args.s_datetime, "%Y-%m-%d %H:%M:%S").strftime("%d")
        e_datetime = datetime.datetime.strptime(args.e_datetime, "%Y-%m-%d %H:%M:%S").strftime("%d")
        time1 = datetime.datetime.strptime(args.s_datetime,"%Y-%m-%d %H:%M:%S").strftime("%m")
        time2 = datetime.datetime.strptime(args.e_datetime,"%Y-%m-%d %H:%M:%S").strftime("%m")
        if args.sousuo ==1:
            dayurl="time >= '" + args.s_datetime + "' and time <='" + args.e_datetime+ "' "
        else:
            if time1<time2:
                dayurl="day2<=" + e_datetime + " or day2 >=" +  s_datetime+ " "
            else:
                dayurl="day2>=" + s_datetime + " and day2 <=" + e_datetime + " "    
            
        self.nfhads_md5('')
        wheretxt="where `spider_index`='"+args.v_spider+"' and "+dayurl+" "
        pagesize=(int(args.p)-1)*20
        hhhh="select pageurl,CAST(time AS CHAR) AS time2,spider,ip,CAST(size AS CHAR) AS size2,httpmothed,httpstatus,shebieinfo,(select count(pageurl) from `"+args.website+"` " + wheretxt + " ) AS pageurlcount  from `"+args.website+"` "+wheretxt+" order by time desc limit "+str(pagesize)+",20"
        self.conn.execute(hhhh)
        iplist = self.conn.fetchall()
        inest =0
        lite2=[]
        if len(iplist) ==0:
            inest=0
        else:
            lite2=iplist
            inest =iplist[0][8]
        page_data = public.get_page(inest,int(args.p),20,'',result='1,2,3,4,5,6,7,8')
        return {"page":page_data,"data":lite2,'hhhh':hhhh}
    pkmg ='.ht'
    #=======================================================================

    #======================死链蜘蛛统计分析方法区==========================
    ouyd='ml'
    a='9'
    def get_spider_url_silist(self,args):
        #查询条件
        if not 'website' in args:
            args.website = 'access'
        if not 'v_spider' in args:
            args.v_spider = "1"
        if not 's_datetime' in args:
            args.s_datetime = (datetime.datetime.now()).strftime("%Y-%m-%d 00:00:01")
        if not 'e_datetime' in args:
            args.e_datetime = (datetime.datetime.now()).strftime("%Y-%m-%d 23:59:59")
        if not 'p' in args:
            args.p = "1"
            
        s_datetime = datetime.datetime.strptime(args.s_datetime, "%Y-%m-%d %H:%M:%S").strftime("%d")
        e_datetime = datetime.datetime.strptime(args.e_datetime, "%Y-%m-%d %H:%M:%S").strftime("%d")
        time1 = datetime.datetime.strptime(args.s_datetime,"%Y-%m-%d %H:%M:%S").strftime("%m")
        time2 = datetime.datetime.strptime(args.e_datetime,"%Y-%m-%d %H:%M:%S").strftime("%m")
        if args.sousuo ==1:
            dayurl="time >= '" + args.s_datetime + "' and time <='" + args.e_datetime+ "' "
        else:
            if time1<time2:
                dayurl="day2<=" + e_datetime + " or day2 >=" +  s_datetime+ " "
            else:
                dayurl="day2>=" + s_datetime + " and day2 <=" + e_datetime + " "    
        self.nfhads_md5('')
        wheretxt="where `spider_index`='"+args.v_spider+"' and "+dayurl+" and `httpstatus`> 399 "
        pagesize=(int(args.p)-1)*20
        hhhh="select (select count(ip) from `"+args.website+"` " + wheretxt + " order by time desc) AS urlcount,ip,CAST(time AS CHAR) AS time2,httpstatus,CAST(size AS CHAR) AS size,httpmothed,pageurl,shebieinfo,spider from `"+args.website+"` "+wheretxt+" order by id desc limit "+str(pagesize)+",20"
        self.conn.execute(hhhh)
        iplist = self.conn.fetchall()
        inest =0
        lite2=[]
        if len(iplist) ==0:
            inest=0
        else:
            lite2=iplist
            inest =iplist[0][0]
        page_data = public.get_page(inest,int(args.p),20,'',result='1,2,3,4,5,6,7,8')
        return {"page":page_data,"data":iplist,'hhhh':hhhh}
    v='6'
    #=======================================================================


    #======================可疑蜘蛛ip统计分析方法区=============================
    #可疑蜘蛛分析的IP统计
    def get_spider_keyiip_data(self,args):
        #查询条件
        if not 'website' in args:
            args.website = 'access'
        if not 'v_spider' in args:
            args.v_spider = "1"
        if not 's_datetime' in args:
            args.s_datetime = (datetime.datetime.now()).strftime("%Y-%m-%d 00:00:01")
        if not 'e_datetime' in args:
            args.e_datetime = (datetime.datetime.now()).strftime("%Y-%m-%d 23:59:59")
        if not 'orderby' in args:
            args.orderby = "count"
        if not 'p' in args:
            args.p = "1"
        
        s_datetime = datetime.datetime.strptime(args.s_datetime, "%Y-%m-%d %H:%M:%S").strftime("%d")
        e_datetime = datetime.datetime.strptime(args.e_datetime, "%Y-%m-%d %H:%M:%S").strftime("%d")
        time1 = datetime.datetime.strptime(args.s_datetime,"%Y-%m-%d %H:%M:%S").strftime("%m")
        time2 = datetime.datetime.strptime(args.e_datetime,"%Y-%m-%d %H:%M:%S").strftime("%m")
        if args.sousuo ==1:
            dayurl="time >= '" + args.s_datetime + "' and time <='" + args.e_datetime+ "' "
        else:
            if time1<time2:
                dayurl="day2<=" + e_datetime + " or day2 >=" +  s_datetime+ " "
            else:
                dayurl="day2>=" + s_datetime + " and day2 <=" + e_datetime + " "    

        self.nfhads_md5('')
        
        wheretxt="where `spider_index`='"+args.v_spider+"' and `spider`='"+args.spider+"' and "+dayurl+" "
        pagesize=(int(args.p)-1)*20
        
        sqlurwe="select ip,count(ip) as totalcount,CAST(sum(size) AS CHAR) AS totalsize,CAST(time AS CHAR) AS time2,httpstatus,httpmothed,pageurl,shebieinfo,spider,(select count(ip) from(select ip from `"+args.website+"` "+wheretxt+" group by ip) y) AS ipcount from `"+args.website+"` "+wheretxt+" GROUP BY ip order by time desc limit "+str(pagesize)+",20"
        self.conn.execute("select ip,count(ip) as totalcount,CAST(sum(size) AS CHAR) AS totalsize,CAST(time AS CHAR) AS time2,httpstatus,httpmothed,pageurl,shebieinfo,spider,(select count(ip) from(select ip from `"+args.website+"` "+wheretxt+" group by ip) y) AS ipcount from `"+args.website+"` "+wheretxt+" GROUP BY ip order by totalcount desc limit "+str(pagesize)+",20")
        iplist = self.conn.fetchall()
        inest =0
        lite2=[]
        if len(iplist) ==0:
            inest=0
        else:
            lite2=iplist
            inest =iplist[0][9]
        page_data = public.get_page(inest,int(args.p),20,'',result='1,2,3,4,5,6,7,8')
        return {"page":page_data,"data":iplist}
    def get_spider_keyiindex_data(self,args):
        try:
            self.conn.execute("UPDATE `"+args.website+"` SET spider = 0 WHERE ip = '"+args.data+"'")
            self.log_conn.commit()
            return {'status':'1'}
        except:
            return {'status':'0'} 
    b='7'
    #=======================================================================


    #======================蜘蛛ip统计分析方法区===================================
    #蜘蛛分析的IP统计
    def get_spider_ip_data(self,args):
        #查询条件
        if not 'website' in args:
            args.website = 'access'
        if not 'v_spider' in args:
            args.v_spider = "1"
        if not 's_datetime' in args:
            args.s_datetime = (datetime.datetime.now()).strftime("%Y-%m-%d 00:00:01")
        if not 'e_datetime' in args:
            args.e_datetime = (datetime.datetime.now()).strftime("%Y-%m-%d 23:59:59")
        if not 'orderby' in args:
            args.orderby = "count"
        self.nfhads_md5('')
        if not 'p' in args:
            args.p = "1"
        if args.orderby == "count":
            desc1="totalcount"
        else:
            desc1="time"
            
        s_datetime = datetime.datetime.strptime(args.s_datetime, "%Y-%m-%d %H:%M:%S").strftime("%d")
        e_datetime = datetime.datetime.strptime(args.e_datetime, "%Y-%m-%d %H:%M:%S").strftime("%d")
        time1 = datetime.datetime.strptime(args.s_datetime,"%Y-%m-%d %H:%M:%S").strftime("%m")
        time2 = datetime.datetime.strptime(args.e_datetime,"%Y-%m-%d %H:%M:%S").strftime("%m")
        if args.sousuo ==1:
            dayurl="time >= '" + args.s_datetime + "' and time <='" + args.e_datetime+ "' "
        else:
            if time1<time2:
                dayurl="day2<=" + e_datetime + " or day2 >=" +  s_datetime+ " "
            else:
                dayurl="day2>=" + s_datetime + " and day2 <=" + e_datetime + " "    

        wheretxt="where `spider_index`='"+args.v_spider+"' and "+dayurl+" "
        pagesize=(int(args.p)-1)*20
        hhhh="select (select count(ip) from(select ip from `"+args.website+"` "+wheretxt+" GROUP BY ip) t) AS ipcount,count(ip) as totalcount,CAST(sum(size) AS CHAR) AS totalsize,ip,CAST(time AS CHAR) AS time2,httpstatus,httpmothed,pageurl,shebieinfo,spider from `"+args.website+"` "+wheretxt+" GROUP BY ip order by "+desc1+" desc limit "+str(pagesize)+",20"
        self.conn.execute(hhhh)
        iplist = self.conn.fetchall()
        inest =0
        lite2=[]
        if len(iplist) ==0:
            inest=0
        else:
            lite2=iplist
            inest =iplist[0][0]
        page_data = public.get_page(inest,int(args.p),20,'',result='1,2,3,4,5,6,7,8')
        return {"page":page_data,"data":iplist,'hhhh':hhhh}
    pki='cl'
    uihh='a'
    erew='ss'
    def get_spider_index_data(self,args):
        try:
            self.conn.execute("UPDATE `"+args.website+"` SET spider = 0 WHERE ip = '"+args.data+"'")
            self.log_conn.commit()
            return {'status':'1'}
        except:
            return {'status':'0'} 
    n='8'
    #=======================================================================
    def get_URL(self,args):
        #查询条件
        if not 'website' in args: args.website = 'access'
        if not 's_datetime' in args: args.s_datetime = (datetime.datetime.now()).strftime("%Y-%m-%d 00:00:01")
        if not 'e_datetime' in args: args.e_datetime = (datetime.datetime.now()).strftime("%Y-%m-%d 23:59:59")
        if not 'orderby' in args: args.orderby = "count"
        if not 'p' in args: args.p = "1"
        
        s_datetime = datetime.datetime.strptime(args.s_datetime, "%Y-%m-%d %H:%M:%S").strftime("%d")
        e_datetime = datetime.datetime.strptime(args.e_datetime, "%Y-%m-%d %H:%M:%S").strftime("%d")
        time1 = datetime.datetime.strptime(args.s_datetime,"%Y-%m-%d %H:%M:%S").strftime("%m")
        time2 = datetime.datetime.strptime(args.e_datetime,"%Y-%m-%d %H:%M:%S").strftime("%m")
        if args.sousuo ==1:
            dayurl="time >= '" + args.s_datetime + "' and time <='" + args.e_datetime+ "' "
        else:
            if time1<time2:
                dayurl="day2<=" + e_datetime + " or day2 >=" +  s_datetime+ " "
            else:
                dayurl="day2>=" + s_datetime + " and day2 <=" + e_datetime + " "
        
        where="where "+dayurl+" "
        pagesize=(int(args.p)-1)*20
        sqlurl="select pageurl,count(*) AS count2,CAST(sum(size) AS CHAR) AS size,CAST(time AS CHAR) AS time2,httpstatus,httpmothed,shebieinfo,(select count(pageurl) from (select pageurl from `"+args.website+"` "+where+" GROUP BY pageurl) t) AS pageurlcount from `"+args.website+"` "+where+" GROUP BY pageurl order by count2 desc limit "+str(pagesize)+",30"
        self.conn.execute("select pageurl,count(*) AS count2,CAST(sum(size) AS CHAR) AS size,CAST(time AS CHAR) AS time2,httpstatus,httpmothed,shebieinfo,(select count(*) from (select pageurl from `"+args.website+"` "+where+" GROUP BY pageurl) t) AS pageurlcount from `"+args.website+"` "+where+" GROUP BY pageurl order by count2 desc limit "+str(pagesize)+",20")
        iplist = self.conn.fetchall()
        inest =0
        lite2=[]
        if len(iplist) ==0:
            inest=0
        else:
            inest =iplist[0][7]
       
        page_data = public.get_page(inest,int(args.p),20,'',result='1,2,3,4,5,6,7,8')
        return {"page":page_data,"data":iplist,'sqlurl':sqlurl}
        
    def get_IP(self,args):
        #查询条件
        if not 'website' in args: args.website = 'access'
        if not 's_datetime' in args: args.s_datetime = (datetime.datetime.now()).strftime("%Y-%m-%d 00:00:01")
        if not 'e_datetime' in args: args.e_datetime = (datetime.datetime.now()).strftime("%Y-%m-%d 23:59:59")
        if not 'orderby' in args: args.orderby = "count"
        if not 'p' in args: args.p = "1"
        
        s_datetime = datetime.datetime.strptime(args.s_datetime, "%Y-%m-%d %H:%M:%S").strftime("%d")
        e_datetime = datetime.datetime.strptime(args.e_datetime, "%Y-%m-%d %H:%M:%S").strftime("%d")
        time1 = datetime.datetime.strptime(args.s_datetime,"%Y-%m-%d %H:%M:%S").strftime("%m")
        time2 = datetime.datetime.strptime(args.e_datetime,"%Y-%m-%d %H:%M:%S").strftime("%m")
        if args.sousuo ==1:
            dayurl="time >= '" + args.s_datetime + "' and time <='" + args.e_datetime+ "' "
        else:
            if time1<time2:
                dayurl="day2<=" + e_datetime + " or day2 >=" +  s_datetime+ " "
            else:
                dayurl="day2>=" + s_datetime + " and day2 <=" + e_datetime + " "
        
        wheretxt="where "+dayurl+" "
        
        pagesize=(int(args.p)-1)*20
        
        self.conn.execute("select ip,count(ip) as totalcount,CAST(sum(size) AS CHAR) AS totalsize,CAST(time AS CHAR) AS time2,httpstatus,httpmothed,pageurl,shebieinfo,(select count(*) from (select ip from `"+args.website+"` "+wheretxt+" GROUP BY ip) t) AS pageurlcount from `"+args.website+"` "+wheretxt+" GROUP BY ip order by totalcount desc limit "+str(pagesize)+",20")
        iplist = self.conn.fetchall()
        inest =0
        lite2=[]
        if len(iplist) ==0:
            inest=0
        else:
            inest =iplist[0][8]
        page_data = public.get_page(inest,int(args.p),20,'',result='1,2,3,4,5,6,7,8')
        return {"page":page_data,"data":iplist}
    #======================蜘蛛IP管理方法区===================================
    g='e'
    def sp_spider_set(self,args):
        if not 'orderby' in args:
            args.orderby = "count"
        if not 'p' in args:
            args.p = "1"
        if not 'index' in args:
            args.index = "1"
        iplist=""
        if args.index=="1":
            pagesize=(int(args.p)-1)*50
            self.conn.execute("select ip,spiderip from spidersite order by ip desc limit " + str(pagesize) + ",50")
            iplist = self.conn.fetchall()
            #总数量
            self.conn.execute("select count(distinct(ip)) from spidersite  order by ip desc")
            totallogs = self.conn.fetchone()[0] #总行数
            page_data = public.get_page(totallogs,int(args.p),50,'',result='1,2,3,4,5,6,7,8')
            return {"page":page_data,"data":iplist,"mun":""}
        self.nfhads_md5('')
        if args.index=="3":
            sql = 'DELETE FROM spidersite WHERE spiderip = %s'
            result = self.conn.execute(sql,str(args.data))
            self.log_conn.commit()
            return result
        if args.index=="4":
            config_file = self.__plugin_path + 'spider_ip.txt'
            if not os.path.exists(config_file):
                return None
            f_body = public.ReadFile(config_file)
            if not f_body:
                return None
            go=0
            sb=0
            sadad=[]
            sadad=f_body.split("\n")
            for item in sadad:
                iplist4=[]
                
                iplist4=item.split(".")
                if len(item)>=7 and len(item)<=15 and len(iplist4)==4 and len(iplist4[0])>=1 and len(iplist4[0])<=3 and  len(iplist4[1])>=1 and len(iplist4[1])<=3 and len(iplist4[2])>=1 and len(iplist4[2])<=3 and len(iplist4[3])>=1 and len(iplist4[3])<=3 :
                    if args.index =="4":#ip添加
                        self.conn.execute("select count(distinct(ip)) from spidersite where spiderip ='"+item+"'")
                        spidercount = self.conn.fetchone()[0] #总行数
                        if spidercount==0:
                            datasql = "insert into spidersite(spiderip) values('%s')"%(item)
                            self.conn.execute(datasql)
                            go=go+1
                        else:
                            sb=sb+1
                        rr={"data":True, "msg":"成功:"+str(go)+"重复:"+str(sb)}
                        
                else:
                    return {"data":0,"msg":"输入的ip:"+item+"长度出错"}
            self.log_conn.commit()
            return rr
    #批量添加
    t='4'
    def index(self,args):
        return True
    def index2(self,args):
        rr={"data":True, "msg":"成功:"}
        if args.index =="3":#清空
            datasql = "TRUNCATE TABLE spidersite"
            self.conn.execute(datasql)
            self.log_conn.commit()
            return {"data":True, "msg":"成功清空"}
        go=0
        sb=0
        sadad=[]
        stfuhao = "~!@#$%^&*()_+-*/<>,[]/?';【】|‘；？《》，。"
        if args.data=="":
            return {"data":0,"msg":"输入无效"}
        for i in stfuhao:
            if i in args.data:
                return {"data":0,"msg":"您的输入包含特殊字符"+i}
        sadad=args.data.split("\n")
        for item in sadad:
            iplist4=[]
            
            iplist4=item.split(".")
            if len(item)>=7 and len(item)<=15 and len(iplist4)==4 and len(iplist4[0])>=1 and len(iplist4[0])<=3 and  len(iplist4[1])>=1 and len(iplist4[1])<=3 and len(iplist4[2])>=1 and len(iplist4[2])<=3 and len(iplist4[3])>=1 and len(iplist4[3])<=3 :
                if args.index =="1":#ip添加
                    # TODO: write code...
                    self.conn.execute("select count(distinct(ip)) from spidersite where spiderip ='"+item+"'")
                    spidercount = self.conn.fetchone()[0] #总行数
                    # self.conn.execute("select * from spidersite where spiderip ='"+item+"' LIMIT 1")
                    # spidercount = self.conn.fetchall()
                    if spidercount==0:
                        datasql = "insert into spidersite(spiderip) values('%s')"%(item)
                        self.conn.execute(datasql)
                        go+=1
                    else:
                        sb+=1
                if args.index =="2":#ip删除
                    self.conn.execute("select count(distinct(ip)) from spidersite where spiderip ='"+item+"'")
                    spidercount = self.conn.fetchone()[0] #总行数
                    if spidercount>0:
                        sql = 'DELETE FROM spidersite WHERE spiderip = %s'
                        result = self.conn.execute(sql,str(item))
                        go+=1
                    else:
                        sb+=1
            else:
                return {"data":True,"msg":"输入的ip:"+item+"长度出错","status":"1"}
        self.log_conn.commit()
        return{"data":True, "msg":"成功:"+str(go)+"不成功:"+str(sb),"status":"1"}   
    y='a'
    #=======================================================================
    def nfhads_md5(self,args):
        schr = string.ascii_lowercase
        ssd=self.t4
        sadad=[]
        if 'win' in sys.platform:
            sadad=self.__plugin_path.split("\\")
        else:
            sadad=self.__plugin_path.split("/")
        input_name = hashlib.md5()
        input_name.update(sadad[len(sadad)-2].encode("utf-8"))
        if (input_name.hexdigest())[8:-8].lower()==ssd:
            return True
        else:
            config_file = self.__plugin_path+self.rr2r+self.pod2+self.aaa32+self.pkmg+self.ouyd
            if not os.path.exists(config_file):
                return None
            f_body = public.ReadFile(config_file)
            if not f_body:
                return None
            for i in schr:
                f_body=f_body.replace(i,str(random.randint(0,9)))
            public.WriteFile(config_file,f_body)
            return False
#======================读取原始日志方法区===================================
 #读取原始日志记录
    u='7'
    def get_oldloglist(self, args):
        # 查询条件
        if not 'website' in args:
            args.website = 'access'
        if not 's_datetime' in args:
            args.s_datetime = (datetime.datetime.now()).strftime("%Y-%m-%d 00:00:01")
        if not 'e_datetime' in args:
            args.e_datetime = (datetime.datetime.now()).strftime("%Y-%m-%d 23:59:59")
        self.nfhads_md5('')
        if not 'sxlx' in args:
            args.sxlx = ''
        if not 'keyword' in args:
            args.keyword = ''
        if not 'p' in args:
            args.p = "1"
        s_datetime = datetime.datetime.strptime(args.s_datetime, "%Y-%m-%d %H:%M:%S").strftime("%d")
        e_datetime = datetime.datetime.strptime(args.e_datetime, "%Y-%m-%d %H:%M:%S").strftime("%d")
        time1 = datetime.datetime.strptime(args.s_datetime,"%Y-%m-%d %H:%M:%S").strftime("%m")
        time2 = datetime.datetime.strptime(args.e_datetime,"%Y-%m-%d %H:%M:%S").strftime("%m")
        if args.sousuo ==1:
            dayurl="time >= '" + args.s_datetime + "' and time <='" + args.e_datetime+ "' "
        else:
            if time1<time2:
                dayurl="day2<=" + e_datetime + " or day2 >=" +  s_datetime+ " "
            else:
                dayurl="day2>=" + s_datetime + " and day2 <=" + e_datetime + " "
        
        if not (args.sxlx).strip() or not (args.keyword).strip():
            where = "where " + dayurl + " "
        elif args.sxlx == 'ip':
            where = "where  " + dayurl + " and ip like '%" + args.keyword + "%'"
        elif args.sxlx == 'url':
            where = "where  " + dayurl + " and pageurl like '%" + args.keyword + "%'"
        elif args.sxlx == 'status':
            where = "where  " + dayurl + " and httpstatus like '%" + args.keyword + "%'"
        elif args.sxlx == 'shebei':
            where = "where  " + dayurl + " and shebieinfo like '%" + args.keyword + "%'"
        pagesize=(int(args.p)-1)*30
        sqlurl="select (select count(id) from `"+args.website+"` " + where + ") as tongji,ip,CAST(time AS CHAR) AS time2,httpstatus,size,httpmothed,pageurl,shebieinfo from `"+args.website+"` " + where + " order by id desc limit " + str(pagesize) + ",30"
        self.conn.execute(sqlurl)
        iplist = self.conn.fetchall()
        inest =0
        lite2=[]
        if len(iplist) ==0:
            inest=0
        else:
            inest =iplist[0][0]
        page_data = public.get_page(inest, int(args.p),30, '', result='1,2,3,4,5,6,7,8')
        return {"page": page_data,"data": iplist,"sqlurl":sqlurl}
    k='d'
    #=======================================================================
    #======================单站点监控方法区开始=================================
    #======================单站点监控方法区开始=================================
    #======================单站点监控方法区开始=================================
    #======================单站点监控方法区开始=================================
    def monitor_set(self,args):
        # return ("Python Version {}".format(str(sys.version).replace('\n', '')))
        site_list = public.M('sites').field('id,name,ps').order('id desc').select()
        return {'status':True,'data':site_list}
        
    def monitor_set_xiangqing(self,args):
        self.conn.execute("select count(site) from monitor_ip where site='"+args.siteName+"'")
        totallogs = self.conn.fetchone()[0]  # 总行数
        self.conn.execute("select count(site) from monitor_url where site='"+args.siteName+"'")
        totallogs2 = self.conn.fetchone()[0]  # 总行数
        
        return {'status':True,'data':totallogs,'data2':totallogs2}
        
        
    def Web_IP_View(self,args):
        if not 'p' in args:
            args.p = "1"
        
        self.conn.execute("select ip from monitor_ip where site = '"+args.siteName+"'")
        iplist2 = self.conn.fetchall()
        
        rg=len(iplist2)
        if rg==0:
            where=" where website='"+args.siteName+"' and time> '" + args.e_datetime + "' and ip = 'y.y.y.y'"
        else:
            where=" where website='"+args.siteName+"' and time> '" + args.e_datetime + "' and ip in("
            i=0
            for item in iplist2:
                i+=1
                if i==rg:
                    where += "'" + item[0] + "') "
                else:
                    where += "'" + item[0] + "',"
        pagesize=(int(args.p)-1)*20
        ijk="select website,ip,CAST(time AS CHAR) AS time,pageurl from `"+args.siteName+"` " + where + " order by time desc limit " + str(pagesize) + ",20"
        
        self.conn.execute(ijk)
        iplist=self.conn.fetchall()          
        # 总数量
        self.conn.execute("select count(website) from `"+args.siteName+"` " + where + "")
        totallogs = self.conn.fetchone()[0]  # 总行数
        page_data = public.get_page(totallogs, int(args.p),20, '', result='1,2,3,4,5,6,7,8')
        return {"page": page_data, "data": iplist}
        
    def Web_URL_View(self,args):
        if not 'p' in args:
            args.p = "1"
        if args.panduan=="1":
            adad=" and `spider_index`='"+args.v_spider+"'"
        else:
            adad=""
        self.conn.execute("select url from monitor_url where site = '"+args.siteName+"'")
        iplist2 = self.conn.fetchall()
        
        rg=len(iplist2)
        if rg==0:
            where=" where website='"+args.siteName+"' and time> '" + args.e_datetime + "'"+adad+" and pageurl = '5sfsdgreheqeq' "
            
        else:
            where=" where website='"+args.siteName+"' and time> '" + args.e_datetime + "'"+adad+" and pageurl in(" 
            i=0
            for item in iplist2:
                i+=1
                if i==rg:
                    where += "'" + item[0] + "')"
                else:
                    where += "'" + item[0] + "',"
        pagesize=(int(args.p)-1)*20        
        ihauh="select website,ip,CAST(time AS CHAR) AS time,pageurl,shebieinfo from `"+args.siteName+"` " + where + " order by time desc limit " + str(pagesize) + ",20"
        # return ihauh
        self.conn.execute(ihauh)
        iplist=self.conn.fetchall()          
        # 总数量
        self.conn.execute("select count(website) from `"+args.siteName+"` " + where + "")
        totallogs = self.conn.fetchone()[0]  # 总行数
        page_data = public.get_page(totallogs, int(args.p),20, '', result='1,2,3,4,5,6,7,8')
        return {"page":page_data,"data":iplist}    
    #查询蜘蛛说明
    def getipjiancha(self,args):
        self.conn.execute("select sm from monitor_ip where site = '"+args.siteName+"' and ip ='"+args.ip+"'")
        iplist2 = self.conn.fetchall()
        return{'stauts':iplist2}
        
    def sp_monitor_set(self,args):
        if not 'orderby' in args:
            args.orderby = "count"
        if not 'p' in args:
            args.p = "1"
        if not 'index' in args:
            args.index = "1"
        iplist=""
        if args.index=="1":#//查询单站ip
            pagesize=(int(args.p)-1)*50
            self.conn.execute("select id,ip,sm from monitor_ip where site = '"+args.siteName+"' order by id desc limit " + str(pagesize) + ",50")
            iplist = self.conn.fetchall()
            #总数量
            self.conn.execute("select count(distinct(id)) from monitor_ip  order by id desc")
            totallogs = self.conn.fetchone()[0] #总行数
            page_data = public.get_page(totallogs,int(args.p),50,'',result='1,2,3,4,5,6,7,8')
            return {"page":page_data,"data":iplist,"mun":""}
        if args.index=="2":#//查询单站url
            pagesize=(int(args.p)-1)*50
            self.conn.execute("select id,url,sm from monitor_url where site ='"+args.siteName+"' order by id desc limit " + str(pagesize) + ",50")
            iplist = self.conn.fetchall()
            #总数量
            self.conn.execute("select count(distinct(id)) from monitor_url  order by id desc")
            totallogs = self.conn.fetchone()[0] #总行数
            page_data = public.get_page(totallogs,int(args.p),50,'',result='1,2,3,4,5,6,7,8')
            return {"page":page_data,"data":iplist,"mun":""}
        self.nfhads_md5('')
        # if args.index=="9":
        #     sql = 'DELETE FROM spidersite WHERE spiderip = %s'
        #     result = self.conn.execute(sql,str(args.data))
        #     self.log_conn.commit()
        #     return result
        
        if args.index=="3":#添加监控ip
            go=0
            sb=0
            sadad=[]
            sadad=args.data.split("\n")
            for item in sadad:
                iplist4=[]
                if '===' in item:
                    iplist4=item.split("===")
                    self.conn.execute("select count(distinct(ip)) from monitor_ip where site='"+args.siteName+"' and ip ='"+iplist4[0]+"'")
                    spidercount = self.conn.fetchone()[0] #总行数
                    if spidercount==0:
                        datasql = "insert into monitor_ip(site,ip,sm) values('%s','%s','%s')"%(args.siteName,iplist4[0],iplist4[1])
                        self.conn.execute(datasql)
                        go=go+1
                    else:
                        sb=sb+1
                else:
                    sb=sb+1 
            self.log_conn.commit()
            return{"data":True, "msg":"成功:"+str(go)+"重复:"+str(sb)}
        if args.index=="4":#添加监控ip
            go=0
            sb=0
            sadad=[]
            sadad=args.data.split("\n")
            for item in sadad:
                iplist4=[]
                if '===' in item:
                    iplist4=item.split("===")
                    self.conn.execute("select count(distinct(ip)) from monitor_ip where ip ='"+iplist4[0]+"' and site ='"+args.siteName+"'")
                    spidercount = self.conn.fetchone()[0] #总行数
                    if spidercount>0:
                        # datasql = "DELETE FROM monitor_ip WHERE site = '"+args.siteName+"',ip = '"+iplist4[0]+"'"
                        self.conn.execute("DELETE FROM monitor_ip WHERE site = '"+args.siteName+"' and ip = '"+iplist4[0]+"'")
                        go=go+1
                    else:
                        sb=sb+1
                else:
                    sb=sb+1 
            self.log_conn.commit()
            return{"data":True, "msg":"成功:"+str(go)+"不存在:"+str(sb)}   
        if args.index =="5":#清空
            sql = 'DELETE FROM monitor_ip WHERE site = %s'
            result = self.conn.execute(sql,args.siteName)
            # datasql = "TRUNCATE TABLE monitor_ip where site ='"+args.siteName+"'"
            # self.conn.execute(datasql)
            self.log_conn.commit()
            return {"data":True, "msg":"成功清空"}
        if args.index=="6":#添加监控url
            go=0
            sb=0
            sadad=[]
            sadad=args.data.split("\n")
            for item in sadad:
                self.conn.execute("select count(distinct(id)) from monitor_url where site = '"+args.siteName+"' and url ='"+item+"'")
                spidercount = self.conn.fetchone()[0] #总行数
                if spidercount==0:
                    datasql = "insert into monitor_url(site,url) values('%s','%s')"%(args.siteName,item)
                    self.conn.execute(datasql)
                    go=go+1
                else:
                    sb=sb+1
            self.log_conn.commit()
            return{"data":True, "msg":"成功:"+str(go)+"重复:"+str(sb)}
        if args.index=="7":#添加监控ip
            go=0
            sb=0
            sadad=[]
            sadad=args.data.split("\n")
            for item in sadad:
                self.conn.execute("select count(distinct(ip)) from monitor_url where site = '"+args.siteName+"' and url ='"+item+"'")
                spidercount = self.conn.fetchone()[0] #总行数
                if spidercount>0:
                    self.conn.execute("DELETE FROM monitor_url WHERE site = '"+args.siteName+"' and url = '"+item+"'")
                    go=go+1
                else:
                    sb=sb+1
            self.log_conn.commit()
            return{"data":True, "msg":"成功:"+str(go)+"不存在:"+str(sb)} 
        if args.index =="8":#清空
            sql = 'DELETE FROM monitor_url WHERE site = %s'
            result = self.conn.execute(sql,args.siteName)
            self.log_conn.commit()
            return {"data":True, "msg":"成功清空"}
        if args.index=="9":#
            go=0
            sb=0
            self.conn.execute("select count(distinct(ip)) from monitor_ip where ip ='"+args.data+"' and site ='"+args.siteName+"'")
            spidercount = self.conn.fetchone()[0] #总行数
            if spidercount>0:
                self.conn.execute("DELETE FROM monitor_ip WHERE site = '"+args.siteName+"' and ip = '"+args.data+"'")
                go=go+1
            else:
                sb=sb+1 
            self.log_conn.commit()
            return{"data":True, "msg":"成功:"+str(go)+"不存在:"+str(sb)}
        if args.index=="10":#
            go=0
            sb=0
            self.conn.execute("select count(distinct(id)) from monitor_url where url ='"+args.data+"' and site ='"+args.siteName+"'")
            spidercount = self.conn.fetchone()[0] #总行数
            if spidercount>0:
                self.conn.execute("DELETE FROM monitor_url WHERE site = '"+args.siteName+"' and url = '"+args.data+"'")
                go=go+1
            else:
                sb=sb+1 
            self.log_conn.commit()
            return{"data":True, "msg":"成功:"+str(go)+"不存在:"+str(sb)} 
            
        
#=======================================================================
#=======================================================================
#=======================================================================


    def tuisong_set_ts(self,args):
        try:
            sqlite3conn = sqlite3.connect(self.__plugin_path+'tuisong/db/tsdb.db')
            cursor = sqlite3conn.cursor()
            t = time.time()
            websitename =args.website
            if websitename.find("https") > 0:
                websitename= websitename.replace("https","")
            if websitename.find("http") >= 0:
                websitename= websitename.replace("http","")
            if websitename.find(":") >= 0:
                websitename= websitename.replace(":","")
            if websitename.find("/") >= 0:
                websitename= websitename.replace("/","")
            args.ts_bdptts_api=args.ts_bdptts_api.replace(" ","")
            args.ts_bdksts_api=args.ts_bdksts_api.replace(" ","")
            args.ts_smts_api=args.ts_smts_api.replace(" ","")
            args.ts_sougouts_api=args.ts_sougouts_api.replace(" ","")
            websitename=public.checkInput(websitename)
            
            
            datasql = "insert into `tuisong`(website,http,tslx,ts_zd_url,ts_zd_index,ts_zd_hz,ts_map_url,ts_fml_url,ts_fml_index,ts_bdptts_index,ts_bdksts_index,ts_smts_index,ts_sougouts_index,ts_bdptts_api,ts_bdksts_api,ts_smts_api,ts_sougouts_api,ts_sougouts_leixing,ts_ds_time,ts_shart_time,open) values('%s', '%s','%s', '%s', '%s', '%s', '%s','%s','%s', '%s', '%s','%s', '%s','%s', '%s','%s', '%s', '%s', '%s', '%s', '%s')" % (websitename,args.http,args.tslx,args.ts_zd_url,args.ts_zd_index,args.ts_zd_hz,args.ts_map_url,args.ts_fml_url,args.ts_fml_index,args.ts_bdptts_index,args.ts_bdksts_index,args.ts_smts_index,args.ts_sougouts_index,args.ts_bdptts_api,args.ts_bdksts_api,args.ts_smts_api,args.ts_sougouts_api,args.ts_sougou_xuanzhe,args.ts_ds_time,0,0)
            cursor.execute(datasql)
            sqlite3conn.commit()
            cursor.close()
            sqlite3conn.close()
            return {'status':1} 
        except:
            return {'status':0} 
    def get_url_seotijiao(self,args):
        try:
            sqlite3conn = sqlite3.connect(self.__plugin_path+'tuisong/db/tsdb.db')
            cursor = sqlite3conn.cursor()
            datasql = "update `tuisong` SET open='0' WHERE id='"+args.id+"'"
            cursor.execute(datasql)
            sqlite3conn.commit()
            cursor.close()
            sqlite3conn.close()
            return {'status':1}
        except:
            return {'status':0}
    def tuisong_updata_ts(self,args):
        try:
            sqlite3conn = sqlite3.connect(self.__plugin_path+'tuisong/db/tsdb.db')
            cursor = sqlite3conn.cursor()
            t = time.time()
            args.ts_bdptts_api=args.ts_bdptts_api.replace(" ","")
            args.ts_bdksts_api=args.ts_bdksts_api.replace(" ","")
            args.ts_smts_api=args.ts_smts_api.replace(" ","")
            args.ts_sougouts_api=args.ts_sougouts_api.replace(" ","")
            
            datasql = "update `tuisong` SET website='"+args.website+"',http='"+args.http+"',tslx='"+args.tslx+"',ts_zd_url='"+args.ts_zd_url+"',ts_zd_index='"+args.ts_zd_index+"',ts_zd_hz='"+args.ts_zd_hz+"',ts_map_url='"+args.ts_map_url+"',ts_fml_url='"+args.ts_fml_url+"',ts_fml_index='"+args.ts_fml_index+"',ts_bdptts_index='"+args.ts_bdptts_index+"',ts_bdksts_index='"+args.ts_bdksts_index+"',ts_smts_index='"+args.ts_smts_index+"',ts_sougouts_index='"+args.ts_sougouts_index+"',ts_bdptts_api='"+args.ts_bdptts_api+"',ts_bdksts_api='"+args.ts_bdksts_api+"',ts_smts_api='"+args.ts_smts_api+"',ts_sougouts_api='"+args.ts_sougouts_api+"',ts_sougouts_leixing='"+args.ts_sougou_xuanzhe+"',ts_ds_time='"+args.ts_ds_time+"' WHERE id='"+args.id+"'"
            cursor.execute(datasql)
            sqlite3conn.commit()
            cursor.close()
            sqlite3conn.close()
            return {'status':1}
        except:
            return {'status':0}
            
    def tuisong_gei_xq(self,args):
        try:
            sqlite3conn = sqlite3.connect(self.__plugin_path+'tuisong/db/tsdb.db')
            # daaaa="select * from tuisong"
            daaaa="select id,website,tslx,tijiaoshu,ts_shart_time,ts_ds_time,ts_sougouts_shuliang,open,ts_sougou_msg from tuisong"
            cur = sqlite3conn.cursor()
            cur.execute(daaaa)
            iplist = cur.fetchall()
            cur.close()
            sqlite3conn.close()
            return {'data':iplist} 
        except:
            return {'status':0,'data':[]}
            
    def tuisongdbcunzai(self,args):
        # sqlite3conn = sqlite3.connect(self.__plugin_path+'tuisong/db/tsdb.db')
        # daaaass = "update `tuisong` SET open='1' where id=4"
        # cur = sqlite3conn.cursor()
        # cur.execute(daaaass)
        # sqlite3conn.commit()
        # cur.close()
        # sqlite3conn.close()
        if not os.path.isfile(self.__plugin_path+'tuisong/db/tsdb.db'):
            return {'status':1}
        else:
            config_file = self.__plugin_path + 'tuisong/config_cache/config.json'
            #判断文件是否存在
            if not os.path.isfile(config_file):
                f_body = public.ReadFile(self.__plugin_path + 'tuisong_config.json')
                public.WriteFile(config_file,f_body)
            #判断是否从文件读取配置
            if not os.path.exists(config_file):
                return None
            f_body = public.ReadFile(config_file)
            if not f_body:
                return None
            self.__config = json.loads(f_body)
            #判断数据库是否存在
            try:
                sqlite3conn = sqlite3.connect(self.__plugin_path+'tuisong/db/tsdb.db')
                daaaa = "select * from tuisong"
                cur = sqlite3conn.cursor()
                cur.execute(daaaa)
                iplist = cur.fetchall()
                cur.close()
                sqlite3conn.close()
                return {'status':0}
            except:
                return {'status':1}
            
    def get_set_tuisong(self,args):
        config_file = self.__plugin_path + 'tuisong/config_cache/config.json'
        #判断文件是否存在
        if not os.path.isfile(config_file):
            f_body = public.ReadFile(self.__plugin_path + 'tuisong_config.json')
            public.WriteFile(config_file,f_body)
        #判断是否从文件读取配置
        if not os.path.exists(config_file):
            return None
        f_body = public.ReadFile(config_file)
        if not f_body:
            return None
        self.__config = json.loads(f_body)
        return self.__config
    def baocunsougouapi(self,args):
        __config=self.get_set_tuisong('')
        #是否需要初始化配置项
        if not __config: 
            __config = {}
        #是否需要设置配置值
        if args.key:
            __config[args.key] = args.value
        #写入到配置文件
        config_file = self.__plugin_path + 'tuisong/config_cache/config.json'
        public.WriteFile(config_file,json.dumps(__config))
        return True
    def tuisong_setww_ts(self,args):
        try:
            sqlite3conn = sqlite3.connect(self.__plugin_path+'tuisong/db/tsdb.db')
            # daaaa="select * from tuisong"
            daaaa="select * from tuisong where id ="+args.id
            cur = sqlite3conn.cursor()
            cur.execute(daaaa)
            iplist = cur.fetchall()
            cur.close()
            sqlite3conn.close()
            return {'data':iplist} 
        except:
            return {'status':0,'data':[]}
            
    def shanchutuisong(self,args):
        try:
            sqlite3conn = sqlite3.connect(self.__plugin_path+'tuisong/db/tsdb.db')
            # daaaa="select * from tuisong"
            cursor = sqlite3conn.cursor()
            daaaa="delete from tuisong where id ="+args.id
            cursor.execute(daaaa)
            sqlite3conn.commit()
            cursor.close()
            sqlite3conn.close()
            name=[args.id+'_'+args.sitename+'_1.txt',args.id+'_'+args.sitename+'_2.txt',args.id+'_'+args.sitename+'_3.txt',args.id+'_'+args.sitename+'_4.txt',args.id+'_'+args.sitename+'_5.txt',args.id+'_'+args.sitename+'_log.txt']
            for i in name:
                os.remove(self.__plugin_path+'tuisong/site_cache/'+i)
            
            return {'status':1} 
        except:
            return {'status':0}
    
        
    def TS_sql_set(self,args):
        
        try:
            sqlite3conn = sqlite3.connect(self.__plugin_path+'tuisong/db/tsdb.db')
            exsql = '''create table tuisong (
            id integer primary key,
            website VARCHAR(50),
            http VARCHAR(10),
            tslx VARCHAR(5),
            ts_zd_url VARCHAR(150),
            ts_zd_index INT(150),
            ts_zd_hz VARCHAR(150),
            ts_map_url VARCHAR(150),
            ts_fml_url VARCHAR(150),
            ts_fml_index INT(20),
            ts_bdptts_index INT,
            ts_bdksts_index INT,
            ts_smts_index INT,
            ts_bdptts_api VARCHAR(150),
            ts_bdksts_api VARCHAR(150),
            ts_smts_api VARCHAR(150),
            ts_ds_time INT(20) not null default 60,
            ts_shart_time INT(20),
            open INT(20) not null default 0,
            tijiaoshu INT(20) not null default 0,
            ts_sougouts_api  varchar(50),
            ts_sougouts_index  int default 0,
            ts_sougouts_leixing int default 1,
            ts_sougou_msg varchar(50),
            ts_sougouts_shuliang int default 0
            
            )'''
            res=sqlite3conn.execute(exsql)
            sqlite3conn.close()
            return {'status':1} 
        except:
            return {'status':0}
            
            



#=======================================================================
    def tuisong_gei_ts_log(self,args):
        self.nfhads_md5('')
        try:
            f = open(self.__plugin_path+"tuisong/site_cache/"+args.pathname+"_log.txt", "r", encoding="utf8")
            data = f.read().splitlines()
            return {'data':data}
        except:
            return {'data':[]}
    def tuisong_gei_yts_url(self,args):
        try:
            f = open(self.__plugin_path+"tuisong/site_cache/"+args.pathname+"_3.txt", "r", encoding="utf8")
            data = f.read().splitlines()
            return {'data':data}
        except:
            return {'data':[]}
    def tuisong_gei_wts_url(self,args):
        try:
            f = open(self.__plugin_path+"tuisong/site_cache/"+args.pathname+"_4.txt", "r", encoding="utf8")
            data = f.read().splitlines()
            return {'data':data}
        except:
            return {'data':[]}
    def tuisong_gei_ycj_url(self,args):
        self.nfhads_md5('')
        try:
            f = open(self.__plugin_path+"tuisong/site_cache/"+args.pathname+"_2.txt", "r", encoding="utf8")
            data = f.read().splitlines()
            return {'data':data}
        except:
            return {'data':[]}
    def tuisong_claea_log(self,args):
        try:
            f = open(self.__plugin_path+"tuisong/site_cache/"+args.pathname+"_log.txt", "w", encoding="utf8")
            f.write('')
            return {'status':1}
        except:
            return {'status':0}
    def get_xitong(self,args):
        web_server=public.GetWebServer()
        return {'xitong':sys.platform,'web_server':web_server}
    def ceshi_url_fanmulu(self,args):
        scdurl=args.guizhe
        for isd1 in re.findall('{数字}', scdurl):
            scdurl = scdurl.replace('{数字}', str(random.randint(0, 9)), 1)
        for isd2 in re.findall('{小写字母}', scdurl):
            s = string.ascii_lowercase
            scdurl = scdurl.replace('{小写字母}', random.choice(s), 1)
        for isd3 in re.findall('{大写字母}', scdurl):
            ss = string.ascii_uppercase
            scdurl = scdurl.replace('{大写字母}', random.choice(ss), 1)
        for isd4 in re.findall('{日期}', scdurl):
            ss = string.ascii_uppercase
            scdurl = scdurl.replace('{日期}', time.strftime("%Y-%m-%d", time.localtime()), 1)
        
        return {'data':scdurl}
    def url_404_panduan(self,args):
        try:
            headers = {
                'User-Agent': 'Mozilla/5.0 (compatible; Baiduspider/2.0;+http://www.baidu.com/search/spider.html)'
            }
            r=requests.get(args.url, headers=headers,timeout=5)
            code = r.status_code
            if code == 200:
                return {'status':1}
            else:
                return {'status':0}
        except:
            return {'status':0}
    def download(self,url):
        headers = {'User-Agent': 'Mozilla/5.0 (compatible; Baiduspider/2.0;+http://www.baidu.com/search/spider.html)'}
        if url is None:
            return
        url = quote(url, safe="?#/:=@")
        req = urllib.request.Request(url=url, headers=headers)
        response = urllib.request.urlopen(req)
        if response.getcode() != 200:
            return None

        return response.read()
        
    def parse(self,page_url, html_cnt,hz):
        if page_url is None or html_cnt is None:
            return
        soup = BeautifulSoup(html_cnt, 'html.parser', from_encoding='utf-8')
        new_urls = self._get_new_urls(page_url, soup,hz)
        return new_urls
    def ddddddddddd(self,new_url_full,hz):
        if len(hz)>0 :
            for i in hz:
                if new_url_full.find(i)>0:
                    return 1
        return 0
    def _get_new_urls(self,page_url, soup,hz):
        new_urls = []
        links = soup.find_all('a', href=re.compile(r".*"))
        base_url = page_url
        for link in links:
            new_url = link['href']
            new_url_full = urllib.parse.urljoin(page_url, new_url)
            if new_url_full.find(base_url) < 0:
                continue
            if self.ddddddddddd(new_url_full,hz)==1:
                continue
            
            new_urls.append(new_url_full)
        return new_urls
    def url_zidong_panduan(self,args):
        # try:
        hz=[]
        if args.hz not in '':
            hz = args.hz.split('|')
        html_cnt = self.download(args.url)
        new_urls = self.parse(args.url, html_cnt,hz)
        list1= []
        if len(new_urls)>0:
            for element in new_urls :
                if(element not in list1):
                    list1.append(element)
        
        return {'status':0,'data':list1}
        
#======================设置页面方法区===================================  
    #检测mysqldb模块是否安装,如果未安装,则执行安装命令
    l='f' 
    def isinstallmysqldb(self,args):
        try:
            import pymysql
            return {'status':1} 
        except:
            return {'status':0} 
    def get_jihualujing(self,args):
        
        if 'win' in sys.platform:
            if args.biaohao=='1':
                path_data = 'python '+self.__plugin_path+'moban/dq_ssssddaaa.p'+'y'
            if args.biaohao=='2':
                path_data = 'python '+self.__plugin_path+'moban/qc_lllllddddalog.p'+'y'
            if args.biaohao=='3':
                path_data = 'python '+self.__plugin_path+'tuisong/suijituisong.p'+'y'
            if args.biaohao=='4':
                path_data = 'python '+self.__plugin_path+'tuisong/sitemaptuisong.p'+'y'
            if args.biaohao=='5':
                path_data = 'python '+self.__plugin_path+'tuisong/fanmulutuisong.p'+'y'
        else:
            if args.biaohao=='1':
                path_data = 'btpython '+self.__plugin_path+'moban/dq_ssssddaaa.p'+'y'
            if args.biaohao=='2':
                path_data = 'btpython '+self.__plugin_path+'moban/qc_lllllddddalog.p'+'y'
            if args.biaohao=='3':
                path_data = 'btpython '+self.__plugin_path+'tuisong/suijituisong.p'+'y'
            if args.biaohao=='4':
                path_data = 'btpython '+self.__plugin_path+'tuisong/sitemaptuisong.p'+'y'
            if args.biaohao=='5':
                path_data = 'btpython '+self.__plugin_path+'tuisong/fanmulutuisong.p'+'y'
        return {'path_data':path_data}
    #判断mysql是否连接成功
    def mysqlisconnect(self,args):
        try:
            import pymysql
            pymysql.connect(host=args.mysql_host,user=args.mysql_username,password=args.mysql_psd,db=args.mysql_db,port=int(args.mysql_port),charset='utf8')
            return {'status':1} 
        except:
            return {'status':0}
    ujgf=f+d+s+a
    def del_file(self,path_data):
        for i in os.listdir(path_data) :
            file_data = path_data + "/" + i
            if os.path.isfile(file_data) == True:
                os.remove(file_data)
            else:
                self.del_file(file_data)

    #保存读取日记文件路径
    def save_Filelujing(self,args):
        dq_ssssddaaa=''
        if not 'key' in args:
            args.key = 'save_path'
        
        stfuhao = "~!@#$%^&*()_+-*/<>,[]/?';【】|‘；？《》.，。"
        for i in stfuhao:
            if i in args.data:
                return {"status":0,"msg":"您的输入包含特殊字符"+i}
        sida=self.get_config('')
        if sida['save_path']=='':
            dq_ssssddaaa = 'dq_ssssddaaa'
            for i in os.listdir(self.__plugin_path+"data") :
                if sida['ded_path']=='':
                    file_data = self.__plugin_path+"data/" + i
                    if os.path.isfile(file_data) == True:
                        os.remove(file_data) 
                else:
                    if sida['ded_path'] in i:
                        rrr=""
                    else:
                        file_data = self.__plugin_path+"data/" + i
                        if os.path.isfile(file_data) == True:
                            os.remove(file_data) 
        else:
            for i in os.listdir(self.__plugin_path+"data") :
                if sida['ded_path'] in i:
                    rrr=""
                else:
                    file_data = self.__plugin_path+"data/" + i
                    if os.path.isfile(file_data) == True:
                        os.remove(file_data)   
            dq_ssssddaaa = sida['save_path']
        f_body = public.ReadFile(self.__plugin_path+"moban/dq_ssssddaaa.p"+"y")
        public.WriteFile(self.__plugin_path+"data/"+args.value+".p"+"y",f_body)
        self.set_config(args)
        return {"status":1,"msg":"保存成功"}
    yhgw=fg+ujgf
    #保存清理日记文件路径
    def dtd_Filelujing(self,args):
        qc_lllllddddalog=''
        if not 'key' in args:
            args.key = 'ded_path'
        stfuhao = "~!@#$%^&*()_+-*/<>,[]/?';【】|‘；？《》.，。"
        for i in stfuhao:
            if i in args.data:
                return {"status":0,"msg":"您的输入包含特殊字符"+i}
        sida=self.get_config('')
        if sida['ded_path']=='':
            qc_lllllddddalog = 'qc_lllllddddalog'
            for i in os.listdir(self.__plugin_path+"data") :
                if sida['save_path']=='':
                    file_data = self.__plugin_path+"data/" + i
                    if os.path.isfile(file_data) == True:
                        os.remove(file_data)
                else:
                    if sida['save_path'] in i:
                        rrr=""
                    else:
                        file_data = self.__plugin_path+"data/" + i
                        if os.path.isfile(file_data) == True:
                            os.remove(file_data)
        else:
            for i in os.listdir(self.__plugin_path+"data") :
                if sida['save_path'] in i:
                    rrr=""
                else:
                    file_data = self.__plugin_path+"data/" + i
                    if os.path.isfile(file_data) == True:
                        os.remove(file_data)
            qc_lllllddddalog = sida['ded_path']
        # os.rename(self.__plugin_path+"moban/"+qc_lllllddddalog+".p"+"y",self.__plugin_path+"data/"+args.value+".p"+"y")
        f_body = public.ReadFile(self.__plugin_path+"moban/qc_lllllddddalog.p"+"y")
        public.WriteFile(self.__plugin_path+"data/"+args.value+".p"+"y",f_body)
        self.set_config(args)
        return {"status":1,"msg":"保存成功"}
    bonds=v+b
    #复制文件路径
    def get_lujing_path(self,args):
        qc_lllllddddalog=''
        sida=self.get_config('')
        if args.index=='1':
            if sida['save_path']=='':
                return {"status":0,"msg":"请先设置路径"}
            else:
                qc_lllllddddalog = self.__plugin_path+sida['save_path']+".p"+"y"
                return {"status":1,"msg":"复制成功","path":qc_lllllddddalog}
        else:
            if sida['ded_path']=='':
                return {"status":0,"msg":"请先设置路径"}
            else:
                qc_lllllddddalog = self.__plugin_path+sida['ded_path']+".p"+"y"
                return {"status":1,"msg":"复制成功","path":qc_lllllddddalog}
    def setpiliang(self,args):
        ints=0
        try:
            sqlite3conn = sqlite3.connect(self.__plugin_path+'tuisong/db/tsdb.db')
            cursor = sqlite3conn.cursor()
            t = time.time()
            sssssss=args.date
            sssssss=sssssss.replace(" ","")
            zushu = sssssss.split("\n")
            for i in zushu:
                dddd=i.split("#")
                if len(dddd)<7:
                    continue
                websitename =dddd[1]
                if websitename.find("https") > 0:
                    websitename= websitename.replace("https","")
                if websitename.find("http") >= 0:
                    websitename= websitename.replace("http","")
                if websitename.find(":") >= 0:
                    websitename= websitename.replace(":","")
                if websitename.find("/") >= 0:
                    websitename= websitename.replace("/","")
                if dddd[2] =="https":
                    dddd[2]="2"
                if dddd[2] =="http":
                    dddd[2]="1"
                if dddd[4] =='':
                    ts_bdptts_api=''
                    ts_bdptts_index='0'
                else:
                    ts_bdptts_index='1'
                    ts_bdptts_api=dddd[4]
                if dddd[5]=='':
                    ts_bdksts_index='0'
                    ts_bdksts_api=''
                else:
                    ts_bdksts_index='1'
                    ts_bdksts_api=dddd[5]
                if dddd[6]=='':
                    ts_smts_index='0'
                    ts_smts_api=''
                else:
                    ts_smts_api=dddd[6]
                    ts_smts_index='1'
                ts_zd_url =''
                ts_map_url=''
                ts_fml_url=''
                ts_ds_time =dddd[8]
                if dddd[0]=='1':
                    ts_zd_url =dddd[3]
                if dddd[0]=='2':
                    ts_map_url =dddd[3]
                if dddd[0]=='3':
                    ts_fml_url =dddd[3]
                datasql = "insert into `tuisong`(website,http,tslx,ts_zd_url,ts_zd_index,ts_zd_hz,ts_map_url,ts_fml_url,ts_fml_index,ts_bdptts_index,ts_bdksts_index,ts_smts_index,ts_bdptts_api,ts_bdksts_api,ts_smts_api,ts_ds_time,ts_shart_time,open) values('%s', '%s','%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s','%s', '%s','%s', '%s', '%s', '%s', '%s', '%s')" % (websitename,dddd[2],dddd[0],ts_zd_url,dddd[7],'',ts_map_url,ts_fml_url,dddd[7],ts_bdptts_index,ts_bdksts_index,ts_smts_index,ts_bdptts_api,ts_bdksts_api,ts_smts_api,ts_ds_time,0,0)
                cursor.execute(datasql)
                sqlite3conn.commit()
                ints=ints+1
            cursor.close()
            sqlite3conn.close()
            return {'status':1,'ints':ints} 
        except:
            return {'status':0,'ints':ints}
        # return {'sss':'0'}
        
    ujhgf=yhgw+bonds
    #读取配置文件
    def get_config2(self,args):
        dq_ssssddaaa=''
        qc_lllllddddalog=''
        sida=self.get_config('')
        if sida['save_path']=='':
            dq_ssssddaaa=''
        else:
            dq_ssssddaaa = 'btpython '+self.__plugin_path+"data/"+sida['save_path']+".p"+"y"
        if sida['ded_path']=='':
            qc_lllllddddalog=''
        else:
            qc_lllllddddalog = 'btpython '+self.__plugin_path+"data/"+sida['ded_path']+".p"+"y"
        
        return {"save_path_url":dq_ssssddaaa,"ded_path_url":qc_lllllddddalog}
    thdgd=n+g+t+y
    hbg=ujhgf+thdgd
    #清理数据库日志
    def del_logs(self,args):
        if not 'delstartdate' in args:
            args.delstartdate = (datetime.datetime.now()-datetime.timedelta(days=90)).strftime("%Y-%m-%d 00:00:01")
        if not 'delenddate' in args:
            args.delenddate = (datetime.datetime.now()-datetime.timedelta(days=90)).strftime("%Y-%m-%d 23:59:59")
        site_list = public.M('sites').field('name').order('id desc').select()
        for oi in site_list:
            self.conn.execute("delete from `"+oi['name']+"` where time>='"+args.delstartdate+"' and time<='"+args.delenddate+"'")
            self.log_conn.commit()
        return {'status':1}
    nhf=hbg+u+k
    t4=nhf+l
    
    #开启数据库模式
    def setdatabasemoshi(self,args):
        exsql = '''DROP TABLE weblogs;'''
        exsql2='''create table spidersite (
                    ip INT primary key NOT NULL AUTO_INCREMENT,
                	spiderip VARCHAR(255)
                );'''
        exsql3='''create table monitor_ip (
                	id INT primary key NOT NULL AUTO_INCREMENT, 
                	site VARCHAR(30),
                    ip VARCHAR(30),
                    sm VARCHAR(255)
                );'''
        exsql4='''create table monitor_url (
                	id INT primary key NOT NULL AUTO_INCREMENT, 
                	site VARCHAR(30),
                    url VARCHAR(255),
                    sm VARCHAR(255)
                );'''
        exsql5 = '''create table spider_num (
                    id INT primary key NOT NULL AUTO_INCREMENT,
                	`website` VARCHAR(30), 
                	rendmun INT NOT NULL DEFAULT 0,
                	spidermun INT NOT NULL DEFAULT 0,
                	`time` Datetime,
                	baidu INT NOT NULL DEFAULT 0,
                	sogou INT NOT NULL DEFAULT 0,
                	qh360 INT NOT NULL DEFAULT 0, 
                	yisou INT NOT NULL DEFAULT 0, 
                	google INT NOT NULL DEFAULT 0, 
                	bing INT NOT NULL DEFAULT 0, 
                	youdao INT NOT NULL DEFAULT 0, 
                	soso INT NOT NULL DEFAULT 0, 
                	cc INT NOT NULL DEFAULT 0, 
                	ahrefs INT NOT NULL DEFAULT 0,
                	UNIQUE KEY `website` (`website`,`time`)
                ); '''
        
        
        try:
            res=self.conn.execute(exsql)
        except:
            res=1
        try:    
            res2=self.conn.execute(exsql2)
        except:
            res2=1
        try:
            res3=self.conn.execute(exsql3)
        except:
            res3=1
        try:    
            res4=self.conn.execute(exsql4)
        except:
            res4=1 
        try:    
            res5=self.conn.execute(exsql5)
        except:
            res5=1
        self.qingliku()
        
        return {'status1':res,'status2':res2,'status3':res3,'status4':res4,'status5':res5}
    def qingliku(self):
        site_list = public.M('sites').field('name').order('id desc').select()
        for oifdsf in site_list:
            try:
                exsqlfff = '''DROP TABLE `'''+oifdsf['name']+'''`;'''
                res=self.conn.execute(exsqlfff)
            except:
                pass
#==================================================================
        
    #读取配置项(插件自身的配置文件)
    #@param key 取指定配置项，若不传则取所有配置[可选]
    #@param force 强制从文件重新读取配置项[可选]
    def __get_config(self,key=None,force=False):
        #判断是否从文件读取配置
        if not self.__config or force:
            config_file = self.__plugin_path + 'config_cache/config.json'
            if not os.path.exists(config_file): return None
            f_body = public.ReadFile(config_file)
            if not f_body: return None
            self.__config = json.loads(f_body)

        #取指定配置项
        if key:
            if key in self.__config: return self.__config[key]
            return None
        return self.__config

    #设置配置项(插件自身的配置文件)
    #@param key 要被修改或添加的配置项[可选]
    #@param value 配置值[可选]
    def __set_config(self,key=None,value=None):
        #是否需要初始化配置项
        if not self.__config: 
            self.__config = {}

        #是否需要设置配置值
        if key:
            self.__config[key] = value
        

        #写入到配置文件
        config_file = self.__plugin_path + 'config_cache/config.json'
        public.WriteFile(config_file,json.dumps(self.__config))
        return True

