#!/usr/bin/python
# coding: utf-8
# +-------------------------------------------------------------------
#   土拨鼠网站日记分析管理
# | 定期清理数据库日志记录脚本
#	自动清理设定天数以前的日志记录
# +-------------------------------------------------------------------
# | Copyright (c) 2019-2099 土拨鼠 All rights reserved.
# +-------------------------------------------------------------------
# | Author: 圣仔
# +-------------------------------------------------------------------

import sys,os,json,datetime,time

# 设置运行目录
# os.chdir("/www/server/panel")
basedir = os.path.abspath(os.path.dirname(__file__))
try:
    os.chdir("/www/server/panel")
except :
    os.chdir(os.path.join(basedir, '..', '..', '..'))
# 添加包引用位置并引用公共包
sys.path.append("class/")
import public
if 'win' in sys.platform:
    try:
        import pymysql
    except:
        os.system('pip install pymysql')
        import pymysql
else:
    import pymysql
if 'win' in sys.platform:
    config_file = os.path.abspath(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))+'/tuboshufenxi/config_cache/config.json'
else:
    config_file = '/www/server/panel/plugin/tuboshufenxi/config_cache/config.json'

# 清除
def main():
    # config_file = '/www/server/panel/plugin/tuboshufenxi/config_cache/config.json'
    # 读取配置项
    if not os.path.exists(config_file):
        dellogdays = 7
    else:
        f_body = public.ReadFile(config_file)
        if not f_body:
            dellogdays = 7
        else:
            __config = json.loads(f_body)
            if not 'dellogdays' in __config:
                dellogdays = 7
            else:
                dellogdays = int(__config['dellogdays'])

    if not 'mysql_port' in __config:
        __config['mysql_port'] = 3306
    log_conn = pymysql.connect(host=__config['mysql_host'], user=__config['mysql_username'],
                               passwd=__config['mysql_psd'], db=__config['mysql_db'], port=int(__config['mysql_port']),
                               charset='utf8')
    conn = log_conn.cursor()
    startdate = "2021-01-01 00:00:01"
    site_list = public.M('sites').field('name').order('id desc').select()
    for oi in site_list:
        enddate = (datetime.datetime.now() - datetime.timedelta(days=dellogdays)).strftime("%Y-%m-%d 23:59:59")
        conn.execute("delete from `" + oi['name'] + "` where time>='" + startdate + "' and time<='" + enddate + "'")
        log_conn.commit()
    conn.close()
    log_conn.close()
    print((datetime.datetime.now()).strftime("%Y-%m-%d %H:%M:%S") + ' 自动清理了 ' + enddate + ' 之前的日志记录')
    
# 清除
def delete_spider():
    dellogdays2 = 30
    # config_file = '/www/server/panel/plugin/tuboshufenxi/config_cache/config.json'
    # 读取配置项
    if not os.path.exists(config_file):
        dellogdays = 7
    else:
        f_body = public.ReadFile(config_file)
        if not f_body:
            dellogdays = 7
        else:
            __config = json.loads(f_body)
            if not 'dellogdays' in __config:
                dellogdays = 7
            else:
                dellogdays = int(__config['dellogdays'])

    if not 'mysql_port' in __config:
        __config['mysql_port'] = 3306
    log_conn = pymysql.connect(host=__config['mysql_host'], user=__config['mysql_username'],
                               passwd=__config['mysql_psd'], db=__config['mysql_db'], port=int(__config['mysql_port']),
                               charset='utf8')
    conn = log_conn.cursor()
    enddate = (datetime.datetime.now() - datetime.timedelta(days=dellogdays2)).strftime("%Y-%m-%d 00:00:01")
    conn.execute("delete from `spider_num` where time<='" + enddate + "'")
    log_conn.commit()
    conn.close()
    log_conn.close()
    print('记录自动清理完成')
    
    
if __name__ == "__main__":
    main()
    delete_spider()