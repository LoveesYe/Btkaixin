//定义窗口尺寸
$('.layui-layer-page').css({ 'width': '1000px','height':'730px'});
//左测菜单切换效果
$(".bt-w-menu p").click(function () {
    $(this).addClass('bgw').siblings().removeClass('bgw')
});
var load_msg = '处理大量请求中，请耐心等待...';
var load;
//第一次打开窗口时调用
get_index();
function  get_index() {
    var index =  layer.msg('加载最新列表',{icon:16});
    $('.plugin_body').html('此插件依赖PHP7.1');
    get_info();
    request_plugin('get_web_list',{},function (res) {
        if(res.code == 0){
            layer.msg(res.msg,{icon:2});
        }
        layer.close(index);
        var list = res.data;
        var content = "";
        // for(var i in list){
        //     content +=    "<tr>  " +
        //         "<td>"+list[i]['host']+"</td>  " +
        //         // "<td>"+list[i]['type']+"</td>  " +
        //         "<td>"+list[i]['status']+"</td>  " +
        //         "<td>"+list[i]['path']+"</td>  " +
        //         "<td> <a class='btn btn-success btn-xs' target='_blank' href='http://"+list[i]['host']+"/sitemap.xml'>sitemap</a>  <a class='btn btn-success btn-xs' target='_blank' href='http://"+list[i]['host']+"/robots.txt'>robots</a>  <button onclick='show_edit(this)'  data-path = '"+list[i]['path']+"'   data-sm = '"+list[i]['sm_api']+"'  data-baidu = '"+list[i]['baidu_api']+"'  data-index='"+list[i]['id']+"'  data-host = '"+list[i]['host']+"' class='btn btn-primary btn-xs'>完善信息</button> &nbsp; <button  data-index='"+list[i]['id']+"'  onclick='del_web(this)' class='btn btn-xs'>删除</button></td></tr>";
        // }
        list.forEach(function (item,index,arr) {
            content +=    "<tr>  " +
                "<td>"+item.host+"</td>" +
                // "<td>"+item.type+"</td>  " +
                "<td>"+item.status+"</td>" +
                "<td>"+item.path+"</td>" +
                "<td>"+item.priority+"</td>" +
                "<td><span style=\"cursor:pointer;\"  onclick=sw_cron("+item.id+",'get_index')>"+item.is_cron+"</span></td>" +
                "<td>" +
                // " <a class='btn btn-success btn-xs' target='_blank' href='http://"+item.host+"/sitemap.xml'>详情</a> " +
                "<button class='btn btn-success btn-xs' data-host = '"+item.host+"' onclick='show_info(this)'>详情</button> &nbsp;"+
                // " <a class='btn btn-success btn-xs' target='_blank' href='http://"+item.host+"/robots.txt'>robots</a>  " +
                "<button onclick='show_edit(this)' data-priority = '"+item.priority+"'  data-changefreq = '"+item.changefreq+"' data-page-rule = '"+item.page_rule+"'   data-path = '"+item.path+"'   data-sm = '"+item.sm_api+"'  data-baidu = '"+item.baidu_api+"'  data-index='"+item.id+"'  data-host = '"+item.host+"'   data-rep-str = '"+item.rep_str+"' data-rm-str = '"+item.rm_str+"'   class='btn btn-primary btn-xs'>完善信息</button> " +
                "&nbsp; <button  data-index='"+item.id+"'  onclick='del_web(this)' class='btn btn-xs'>删除</button></td></tr>";
        })
        var html  =  "<div class='u_main'>" +
            "<p><button class='btn btn-success btn-sm' onclick='sync_data()' >   <i class='fa fa-refresh'></i>   同步宝塔网站 </button> &nbsp;" +
            "<a class='btn btn-success btn-sm' onclick='backup()' >   <i class='fa fa-download'></i>   备份配置 </a> &nbsp;" +
            "<a class='btn btn-success btn-sm' onclick='recover()' >   <i class='fa fa-coffee'></i>   恢复配置 </a> &nbsp;" +
            "<a class='btn btn-info btn-sm' onclick='add_cron()' >   <i class='fa fa-clock-o'></i>   开启批量定时任务 </a> &nbsp;" +
            "<a class='btn btn-danger btn-sm' onclick='rm_config()' >   <i class='fa fa-remove '></i>   清空配置 </a> &nbsp;</p>" +
            "<p>此插件依赖PHP7.1，开启批量定时任务后，批量任务才能生效</p>"+
            "<table style='margin-top: 15px' class='table table-hover table-bordered '>" +
            "<thead><th>网站</th>   <th style='width: 70px'>状态</th>    <th>路径</th>  <th style='width: 70px'>优先级</th> <th style='width: 70px'>批量任务</th>   <th width='250'>操作栏[完善API信息的域名才能推送]</th></thead>" +
            "<tbody>" +
            content+
            "</tbody>"+
            "</table>" +
            "</div>";
        $('.plugin_body').html(html);
    });
}
function add_cron() {
    request_plugin("add_cron",{},function (res) {
        tip(res);
        if(res.code === 0){
            return false;
        }
        var php_path = res.php_path;
        var path = res.path;
        //存储域名
        var args = {
            "name":res.cron_name,
            "type":"day",
            "where1":"",
            "hour":1,
            "minute": 30,
            "week":"",
            "sType": "toShell",
            "sBody": php_path+" "+path,
            "sName":"",
            "save":"",
            "backupTo": "localhost",
            "urladdress":""
        };
        $.ajax({
            type:'POST',
            url: '/crontab?action=AddCrontab',
            data: args,
            success: function(rdata) {
                layer.close(load);
                layer.alert('计划任务添加成功，请前往【<a class="btlink" target="_blank" href="crontab">计划任务</a>】查看', { icon: rdata.status ? 1 : 2 });
            },
            error: function(ex) {
                layer.msg('请求过程发现错误!', { icon: 2 });
            }
        });
    });
}
function rm_config()
{
    layer.confirm('<span class="red">清除插件内站点配置?</span>', {
        title:'操作提示',
        btn: ['确定','取消'], //按钮
    }, function(){
        var index = layer.load(0, {shade: false});
        request_plugin('rm_config',{},function (res) {
            layer.close(index);
            tip(res,function () {
                get_index();
            });
        })
    });
}

/**
 * 备份配置
 */
function backup() {
    request_plugin('backup',{},function (res) {
        tip(res);
    })
}
function recover() {
    layer.confirm('<span class="red">当前配置将会被备份配置覆盖，是否要恢复？</span>', {
        title:'操作提示',
        btn: ['确定','取消'], //按钮
    }, function(){
        var index = layer.load(0, {shade: false});
        request_plugin('recover',{},function (res) {
            layer.close(index);
            tip(res,function () {
                get_index();
            });

        })
    });
}
function sync_data() {
    var index =  layer.msg('正在同步',{icon:16});
    request_plugin('sync_data',{},function (res) {
        layer.close(index);
        layer.msg('同步完成!',{icon:1},function () {
            get_index();
        });
    })
}
function show_info(obj)
{
    var host =  $(obj).attr('data-host');
    var load = layer.load();
    request_plugin('web_info',{host:host},function (res) {
        var info = res.data.info;
        layer.close(load);
        if(!info.filename){
            layer.alert('还未设置生成【文件名】');
            return false;
        }
        var sitemap = "http://"+info.host+"/"+info.filename+".xml";
        var rob = "http://"+info.host+"/robots.txt";
        layer.open({
            title:'详情',
            type: 1,
            area: ['520px', '300px'], //宽高
            skin: 'layui-layer-dialog',
            closeBtn: 2,
            content: '<div style="margin-top: 15px;margin-left: 15px" class="u_main layer-modal">' +
                "<p> sitemap地址: <a class='btlink' target='_blank' href='"+sitemap+"'>"+sitemap+" </a>  </p>"+
                "<p> robots.txt : <a class='btlink' target='_blank' href='"+rob+"'>"+rob+" </a></p>"+
                '</div>'
        });
    })
}
function show_edit(obj) {
    var host =  $(obj).attr('data-host');
    var id =  $(obj).attr('data-index');
    var baidu_api = $(obj).attr('data-baidu');
    var sm_api = $(obj).attr('data-sm');
    var path = $(obj).attr('data-path');
    var rep_str = $(obj).attr('data-rep-str');
    var rm_str = $(obj).attr('data-rm-str');
    var page_rule = $(obj).attr('data-page-rule');
    var load = layer.load();
    request_plugin('web_info',{host:host},function (res) {
        var info = res.data.info;
        layer.close(load);
        var priority_op = '';
        res.data.priority.forEach(function (item) {
            priority_op += "<option>"+item+"</option>";
        })
        var changefreq_op = '';
        res.data.changefreq.forEach(function (item) {
            changefreq_op += "<option>"+item+"</option>";
        })
        var rule_op = '<option value="1">通用抓取</option><option value="2">分页抓取</option>';
        var protocol_op = '<option>http://</option><option >https://</option>';
        layer.open({
            title:'完善信息页面',
            type: 1,
            area: ['auto', 'auto'], //宽高
            skin: 'layui-layer-dialog',
            closeBtn: 2,
            content: '<div  class="u_main layer-modal">' +
                '<input type="hidden" name="id" value="'+id+' ">'+

                '<p><label>*域名</label><input name="host"   value="'+host+'" class="bt-input-text"></p>' +

                '<p><label>*路径</label><input placeholder="请输入网站路径" value="'+path+'"  name="path" class="bt-input-text"></p>' +
                '<p><label></label>说明:此路径是sitemap.xml保存的路径,一般是网站的运行目录.</p>' +

                '<p><label>*文件名</label><input placeholder="生成的地图文件名" value="'+info.filename+'"  name="filename" class="bt-input-text"></p>' +
                '<p><label></label>说明:地图文件的命名，如填sitemap那么插件会生成sitemap.xml</p>' +
                '<p><label></label>子域名地图应设置不同的文件名，避免覆盖，单域名站点无需设置</p>' +
                // '<p><label>生成规则</label><select name="rule" style="width: 150px" class="bt-input-text"><option>通用</option> <option>wordpress</option> <option>zblog</option> </select>  </p>' +


                '<p><label>*百度普通api</label><input placeholder="请输入百度普通收录api" value="'+baidu_api+'" name="baidu_api" class="bt-input-text"></p>' +
                '<p><label>神马推送</label><input placeholder="请输入神马推送API" value="'+sm_api+'"  name="sm_api" class="bt-input-text"></p>' +

                '<p><label>字符串替换</label> <input class="bt-input-text" value="'+rep_str+'" name="rep_str" placeholder="例如 origin_str=new_str 那么origin_str会被替换成new_str,多个#号隔开 "> </p>' +
                '<p><label></label>网址中的字符串替换</p>' +

                '<p><label>字符串排除</label> <input class="bt-input-text" value="'+rm_str+'" name="rm_str" placeholder="例如 aaa 多个#号隔开, 如 aaa#bbb#ccc "> </p>' +
                '<p><label></label>不希望出现在地图中的网址字符串进行排除,任何包含字符的网址被排除</p>' +

                '<p><label>分页规则</label> <input class="bt-input-text" value="'+page_rule+'" name="page_rule" placeholder="例如 /p/数字/ 需要与你站点的分页规则保持一致，分页码用【数字】代替"> </p>' +
                '<p><label>priority</label><select name="priority" style="width: 150px" class="bt-input-text"> '+priority_op+'  </select>  </p>' +
                // '<p><label></label>优先级，不了解的直接用默认即可</p>' +
                '<p><label>changefreq</label><select name="changefreq" style="width: 150px" class="bt-input-text"> '+changefreq_op+'  </select>  </p>' +
                // '<p><label></label>建议引擎抓取频率，不了解的直接用默认即可</p>' +
                '<p><label>定时任务抓取</label><select name="mode" style="width: 150px" class="bt-input-text"> '+rule_op+'  </select>  </p>' +
                '<p><label>协议</label><select name="protocol" style="width: 150px" class="bt-input-text"> '+protocol_op+'  </select>  </p>' +
                '<p><label>批量定时任务</label><select name="is_cron" style="width: 150px" class="bt-input-text"> <option value="1">关闭</option> <option value="2">开启</option> </select>  </p>' +
                // '<p><label></label>抓取方式，定时任务抓取方式</p>' +
                '<p><label></label><a class="btlink" target="_blank" href="https://www.waytomilky.com/archives/1950.html">如何获取API?</a></p>' +
                '<p><div style="text-align: center"><button class="btn btn-success "   onclick="edit_web()">提交</button></div></p>' +
                '</div>'
        });
        $('select[name=priority]').val(info.priority);
        $('select[name=changefreq]').val(info.changefreq);
        $('select[name=mode]').val(info.mode);
        $('select[name=is_cron]').val(info.is_cron);
    })

}
function edit_web() {
    var id   =  $("input[name = id]").val();
    var host =  $("input[name = host]").val();
    var baidu_api =  $("input[name = baidu_api]").val();
    var sm_api = $("input[name = sm_api]").val();
    var path = $("input[name = path]").val();
    var filename = $("input[name=filename]").val();
    var rep_str = $("input[name = rep_str]").val();
    var rm_str = $("input[name = rm_str]").val();
    var page_rule = $("input[name=page_rule]").val();
    var priority = $("select[name = priority]").val();
    var changefreq = $("select[name = changefreq]").val();
    var mode = $("select[name = mode]").val();
    var protocol = $("select[name = protocol]").val();
    var is_cron = $("select[name = is_cron]").val();

    request_plugin('edit_web',
        {id:id,host:host,path:path,baidu_api:baidu_api,sm_api:sm_api,
            filename:filename
            ,rep_str:rep_str
            ,rm_str:rm_str
            ,page_rule:page_rule
            ,priority:priority
            ,changefreq:changefreq
            ,mode:mode
            ,protocol:protocol
            ,is_cron:is_cron
        },
        function (res) {
            if(res.code == 1){
                layer.close(layer.index);
                get_index();
            }
            tip(res);
        });
}
function del_web(obj) {
    layer.confirm('<span class="red">确定要删除么？</span>', {
        title:'操作提示',
        btn: ['确定','取消'], //按钮
    }, function(){
        var index = layer.load(0, {shade: false});
        var id =  $(obj).attr('data-index');
        request_plugin('del_web',
            {id:id},
            function (res) {
                tip(res,function () {
                    layer.close(index);
                    get_index();
                });
            });
    });
}
function get_act() {
    var index = layer.msg('加载数据中',{icon:16});
    request_plugin('get_wc',{},function (res) {
        if(res.code == 0){
            layer.msg(res.msg,{icon:2});
        }
        layer.close(index);
        var op = '';
        var data = res.data;
        data.forEach(function (item) {
            op+="<option>"+item.host+"</option>";
        })
        var html = '<div class="u_main">' +
            '<p> <label>协议</label> <select name="protocol" class="bt-input-text"> <option value="http://">http://</option> <option value="https://">https://</option> </select> </p>' +
            '<p> <label>网站</label> <select onchange="remember(this)"  name="host" class="bt-input-text"> '+op+' </select> </p>' +
            '<p> <label>抓取方式</label> <select   name="way" class="bt-input-text"> ' +
            ' <option value="1"> 首页抓取 </option>  ' +
            ' <option value="2">多层抓取(手动抓取最长时间10分钟，建议添加为[定时任务]</option>  ' +
            // ' <option value="3">三级抓取(手动抓取时间漫长,建议添加为[定时任务]执行)</option>  ' +
            '</select> </p>' +
            '<p><label></label> <button onclick="man_push()" class="btn btn-success">一键生成</button>  </p>' +
            '<div class="u_output">' +
            '<p>注意事项</p>' +
            '<p>1.插件依赖PHP7.1,不影响其他网站设置</p>' +
            '<p>2.生成sitemap.xml文件将直接保存至网站根目录</p>' +
            '</div>' +
            '<p id="sitemap_url_p"   style="margin-top: 5px"><label></label> ' +
            '<a id="sitemap_url"   onclick="check_href(this)" target="_blank" class="btn btn-primary btn-sm">访问已生成sitemap.xml</a>&nbsp;' +
            '<button onclick="active_push()"  class="btn btn-primary btn-sm">主动推送[根据对应网站配置]</button>&nbsp;' +
            '<button onclick="create_ds()" class="btn btn-success btn-sm">添加定时任务[自动生成sitemap并主动推送]</button> ' +
            '</p>' +
            '<p><label></label><a class="btlink" target="_blank" href="/crontab">查看定时任务</a></p>' +
            '</div>';
        $('.plugin_body').html(html);
        var record_host = localStorage.getItem("host");
        $("select[name=host]").val(record_host);
    })
}
function remember() {
    var host  =  $("select[name = host]").val();
    localStorage.setItem("host",host);
}

function man_push() {
    $('.u_output').html('');
    var protocol = $("select[name = protocol]").val();
    var host  =  $("select[name = host]").val();
    var way   =  $("select[name = way]").val();
    var str = "生成数据中,请耐心等待";
    if ( way ==3) {
        str = "生成数据中,手动执行多级抓取比较慢,容易超时,建议【添加定时任务】";
    }
    // if (way ==3) {
    //     str = "生成数据中,手动执行三级抓取极其缓慢,且会超时,建议直接【添加定时任务】,凌晨执行";
    // }
    var index =  layer.msg(str,{
        icon:16,
        time:0,
        shade:0.3
    });
    request_plugin('man_push',{protocol:protocol,host:host,way:way},function (res) {
        layer.close(index);
        if(res.code == 1){
            $('.u_output').html(res.data.content);
            $("#sitemap_url").attr('href',res.data.sitemap_url);
            //layer.alert('sitemap.xml已经保存至网站根目录,访问地址:<br><a class="btlink" target="_blank" href='+res.data.sitemap_url+'>'+res.data.sitemap_url+'</a>',{icon:1,time:5000});
        }else{
            layer.msg(res.msg,{icon:res.code == 1?1:2,time:res.code == 1?500:6000});
        }
    },600*1000)
}
function active_push() {
    var index =  layer.msg('加载数据中',{icon:16,time:0});
    var protocol = $("select[name = protocol]").val();
    var host  =  $("select[name = host]").val();
    var way   =  $("select[name = way]").val();
    request_plugin('active_push',{protocol:protocol,host:host,way:way},function (res) {
        layer.close(index);
        //layer.alert(res.msg,{icon:res.code == 1?1:2  })
        //页面层
        layer.open({
            title:'推送结果',
            type: 1,
            skin: 'layui-layer-dialog',
            closeBtn: 2,
            area: ['650px', '540px'], //宽高
            content: "<div class='tan'>"+ res.msg +"</div>"
        });
    })
}

//定时推送
function create_ds() {
    var protocol = $("select[name = protocol]").val();
    var host  =  $("select[name = host]").val();
    var sitemap =  protocol+host+"/sitemap.xml";
    var way = $("select[name = way]").val();
    var load = layer.load();
    request_plugin('check_os',{},function (resData) {
        if(resData.data.os == 'linux'){
            request_plugin("getPath",{},function (res) {
                var path = res.path;
                var dir = res.dir;
                var php_path = res.php_path;
                //存储域名
                var args = {
                    "name":"【sitemap插件定时任务】 为域名  "+host+"  生成网站地图并推送",
                    "type":"day",
                    "where1":"",
                    "hour":1,
                    "minute": 30,
                    "week":"",
                    "sType": "toShell",
                    "sBody": php_path+" "+path+" -a "+host+" -b "+sitemap+" -c "+dir+" -d "+protocol+" -e "+way,
                    "sName":"",
                    "save":"",
                    "backupTo": "localhost",
                    "urladdress":""
                };
                $.ajax({
                    type:'POST',
                    url: '/crontab?action=AddCrontab',
                    data: args,
                    success: function(rdata) {
                        layer.close(load);
                        layer.alert('计划任务添加成功，请前往【<a class="btlink" target="_blank" href="crontab">计划任务</a>】查看', { icon: rdata.status ? 1 : 2 });
                        return;
                    },
                    error: function(ex) {
                        layer.msg('请求过程发现错误!', { icon: 2 });
                        return;
                    }
                });
            });
        }

        if(resData.data.os == 'windows'){
            request_plugin("getPath",{},function (res) {
                var path = res.path;
                var dir = res.dir;
                var php_path = res.php_path;
                //存储域名
                var args = {
                    "name":"【sitemap插件定时任务】 为域名 "+host+" 生成网站地图并推送",
                    "type":"day",
                    // "where1":"",
                    "hour":1,
                    "minute": 30,
                    // "week":"",
                    "sType": "toShell",
                    "sBody": php_path+" "+path+" -a "+host+" -b "+sitemap+" -c "+dir+" -d "+protocol+" -e "+way,
                    "sName":"",
                    "save":"",
                    "backupTo": "localhost",
                    // "urladdress":""
                };

                $.ajax({
                    type:'POST',
                    url: '/crontab?action=AddCrontab',
                    data: args,
                    success: function(rdata) {
                        layer.close(load);
                        layer.alert('计划任务添加成功，请前往【<a class="btlink" target="_blank" href="crontab">计划任务</a>】查看', { icon: rdata.status ? 1 : 2 });
                        return;
                    },
                    error: function(ex) {
                        layer.msg('请求过程发现错误!', { icon: 2 });
                        return;
                    }
                });
            });
        }
    })
}

function get_robots() {
    var index = layer.msg('加载数据中',{icon:16});
    request_plugin('get_wc',{},function (res) {
        layer.close(index);
        var op = '';
        var data = res.data;
        data.forEach(function (item) {
            op+="<option>"+item.host+"</option>";
        })
        var html = '<div class="u_main" >' +
            '<p> <label>网站</label> <select onchange="remember(this)"  name="host" class="bt-input-text"> '+op+' </select> &nbsp; <button onclick="read_r()" class="btn btn-success btn-sm">加载当前</button>   </p>' +
            '<p> <label>限制目录</label> <input name="dir" class="bt-input-text mr5"  placeholder="限制目录如 /bin 多个限制目录用#分割，如/upload#/bin"></p>' +
            '<p> <label>检索间隔</label> <input name="delay"  type="number" class="bt-input-text mr5"  placeholder="为空则不限,限值数字 1-120">秒</p>' +
            '<p> <label>屏蔽搜索引擎</label>    <input type="checkbox" name="Sogou" title="搜狗"> 搜狗 <input type="checkbox" name="Googlebot" title="Googlebot"> Googlebot <input type="checkbox" name="bingbot" title="bingbot"> bingbot <input type="checkbox" name="YandexBot" title="YandexBot"> YandexBot <input type="checkbox" name="SemrushBot" title="SemrushBot"> SemrushBot  <input type="checkbox" name="PetalBot" title="PetalBot"> PetalBot</p>' +
            '<p><label></label> <button onclick="gen_r()" class="btn btn-success">生成配置</button>  </p>' +
            '<p ><label></label> <textarea  name="robots"  cols="68" rows="15"></textarea>  </p>' +
            '<p><label></label>  <button onclick="wr_robots()" class="btn btn-success btn-sm">写入网站目录</button>  </p>' +
            '<p><label></label>谨慎设置，此功能是生成搜索引擎爬虫robots.txt协议，可以用来保护站点隐私和限制一些遵守协议但是不需要的引擎爬虫</p>' +
            '</div>';
        $('.plugin_body').html(html);
        var record_host = localStorage.getItem("host");
        $("select[name=host]").val(record_host);
        // var host = $("select[name=host]").val();
        // request_plugin('get_r',{host,host},function (res) {
        //     if(res.code == 1 ){
        //         $('textarea[name=robots]').val(res.data.text);
        //     }
        // })
    })
}
function read_r()
{
    var host =  $("select[name=host]").val();
    request_plugin('get_r',{host,host},function (res) {
        if(res.code == 0){
            layer.msg(res.msg);
        }
        $('textarea[name=robots]').val(res.data.text);
    })
}
function is_empty(str) {
    if(str=='' || str == null || str == undefined){
        return true;
    }
    return false;
}

function gen_r() {
    var host = $("select[name=host]").val();
    var dir =  $("input[name=dir]").val();
    var delay =  $("input[name=delay]").val();
    // var baidu =  $("input[name=baidu]:checked").val();
    var Sogou =  $("input[name=Sogou]:checked").val();
    var Googlebot =  $("input[name=Googlebot]:checked").val();
    var bingbot =  $("input[name=bingbot]:checked").val();
    var YandexBot  =  $("input[name=YandexBot]:checked").val();
    var SemrushBot  =  $("input[name=SemrushBot]:checked").val();
    var PetalBot  =  $("input[name=PetalBot]:checked").val();


    var old =  $('textarea[name=robots]').val();
    // if(old !== '' || old !== null ){
    //     old = old+"\n";
    // }
    // var str = old +"# generate by sitemap生成器,追加内容如下 \n";
    var str = '';
    var reg  = /\//;
    var reg2 = /#/;
    if(!is_empty(dir)){
        if(!reg2.test(dir)  ){
            if(!reg.test(dir)){
                var text = "限值目录中有目录不含有斜杠 /  请更正！";
                layer.msg(text,{icon:2});
                return false;
            }
            str += "Disallow: "+dir+"\n";
        }else{
            var arr = dir.split('#');
            arr.forEach(function (item) {
                if(!reg.test(item)){
                    var text = "限值目录中有目录不含有斜杠 /  请更正！";
                    layer.msg(text,{icon:2});
                    return false;
                }
                str += "Disallow: "+item+"\n";
            })
        }
    }
    if(!is_empty(delay)){
        str += "Crawl-delay:"+delay+"\n";
        if(delay <1 || delay >120){
            var text = "检索间隔单位过大或过小，<span class='red'>限值1-120 秒</span> ";
            layer.msg(text,{icon:2});
            return false;
        }
    }
    // if(!is_empty(baidu)){
    //     str += "User-agent: Baiduspider\nDisallow: /  \n";
    // }
    if(!is_empty(Sogou)){
        str += "User-agent: Sogou\nDisallow: /  \n";
    }
    if(!is_empty(Googlebot)){
        str += "User-agent: Googlebot\nDisallow: /  \n";
    }
    if(!is_empty(bingbot)){
        str += "User-agent: bingbot\nDisallow: /  \n";
    }
    if(!is_empty(YandexBot)){
        str += "User-agent: YandexBot\nDisallow: /  \n";
    }
    if(!is_empty(SemrushBot)){
        str += "User-agent: SemrushBot\nDisallow: /  \n";
    }
    if(!is_empty(PetalBot)){
        str += "User-agent: PetalBot\nDisallow: /  \n";
    }
    //str += "Sitemap: http://"+host+"/sitemap.xml";
    $('textarea[name=robots]').val(replaceBlank(str));


}
function replaceBlank(oldStr){
    var reg = /\n(\n)*( )*(\n)*\n/g;
    return oldStr.replace(reg,"\n");
}
function  wr_robots() {
    var index = layer.load(0, {shade: false});
    var text =  $("textarea[name=robots]").val();
    var host =  $("select[name=host]").val();
    request_plugin('wr_robots',{host:host,text:text},function (res) {
        layer.close(index);
        layer.msg(res.msg,{icon:res.code,time:1000},function () {
            if(res.code == 1){
                layer.alert('生成地址:<a class="btlink" target="_blank" href="'+res.data.url+'">'+res.data.url+'</a>');
            }
        });
    })
}
function check_href(obj) {
    var protocol =  $("select[name= protocol]").val();
    var host =  $("select[name= host]").val();
    request_plugin('web_info',{host,host},function (res) {
        layer.msg('正在跳转至网站地图,如果内容为空,请先生成哦!',{icon:16},function () {
            window.open(protocol+host+"/"+res.data.info.filename+".xml");
        });
    })
}
function  get_log() {
    var index = layer.load(0, {shade: false});
    request_plugin('get_log',{},function (res) {
        layer.close(index);
        var content  = "";
        var em =  res.data.content;
        em.forEach(function (item) {
            content +=  "<p>---------------------------------------------------------------------------------</p>";
            content +=  "<p>"+"推送域名:"+item.host+"</p>";
            content +=  "<p>推送时间:"+item.create_time+"</p>";
            content +=  "<p>"+"推送类型:"+item.type+"</p>";
            content +=  "<p>"+"网址数量:"+item.num+"</p>";
            content +=  item.msg;
            content +=  "<p>推送地址:<a  class='btlink' target='_blank' href='"+item.pro+item.host+"/sitemap.xml' >"+item.pro+item.host+"/sitemap.xml</a></p>";
        })
        if(is_empty(content)){
            content =  "<p style='color: white'>没有日志记录</p>";
        }
        var html = '<div class="u_main">' +
            '<div class="u_output" style="height: 530px;margin-left: 14px;width: 709px">' +
            content +
            '</div>' +
            '</div>' +
            '<button onclick="rmlog()" style="margin-top: 5px;margin-bottom: 10px;margin-left: 14px" class="btn btn-success btn-sm">清空日志</button>';
        $('.plugin_body').html(html);
    })
}
function rmlog() {
    layer.confirm('<span class="red">确定要删除么？</span>', {
        title:'操作提示',
        btn: ['确定','取消'], //按钮
    }, function(){
        var index = layer.load(0, {shade: false});
        request_plugin('rmlog',{},function (res) {
            tip(res,function () {
                layer.close(index);
                get_log();
            });
        })
    });
}
function page_get()
{
    var index = layer.msg('加载数据中',{icon:16});
    request_plugin('get_wc',{},function (res) {
        if(res.code == 0){
            layer.msg(res.msg,{icon:2});
        }
        layer.close(index);
        var op = '';
        var data = res.data;
        data.forEach(function (item) {
            op+="<option>"+item.host+"</option>";
        })
        var html = '<div class="u_main">' +
            '<p> <label>协议</label> <select name="protocol" class="bt-input-text"> <option value="http://">http://</option> <option value="https://">https://</option> </select> </p>' +
            '<p> <label>网站</label> <select onchange="fetch_host_config(this)"  name="host" class="bt-input-text"> '+op+' </select> </p>' +
            '<p><label>分页规则</label> <input name="page_rule" placeholder="例如 /p/数字/ 需要与你站点的分页规则保持一致，分页码用【数字】代替" class="bt-input-text" value="/p/数字/"> <button onclick="save_page_rule()" class="btn btn-sm btn-success">保存至站点配置</button>  </p>' +
            '<p><label></label>  <button onclick="page_push()" class="btn btn-success scbtn">一键生成</button>  </p>' +
            '<div class="u_output1">' +
            '<p>注意事项</p>' +
            '<p>1、插件依赖PHP7.1,不影响其他网站设置</p>' +
            '<p>2、生成sitemap.xml文件将直接保存至网站根目录</p>' +
            '<p>3、对于分页超过100页的站点，手动生成可能会超时，可以利用定时任务抓取，避免超时</p>' +
            '<p>4、此功能为beta阶段，有问题可以随时反馈</p>' +
            '<p>5、例子 比如我的博客站点 分页链接 https://www.waytomilky.com/page/2/  那么分页规则为 /page/数字/ </p>' +
            '</div>' +
            '</p>' +
            '</div>';
        $('.plugin_body').html(html);
        var record_host = localStorage.getItem("host");
        $("select[name=host]").val(record_host);
        fetch_host_config();
    })
}
function page_push()
{
    var param = {
        protocol:$('select[name=protocol]').val(),
        host:$('select[name=host]').val(),
        page_rule:$('input[name=page_rule]').val()
    }
    loading_msg();
    request_plugin('page_push',param,function (rdata) {
        loading_close();
        showtip(rdata,function () {
            $('.u_output1').html(rdata.data.content);
        })
    })
}
function save_page_rule()
{
    var param = {
        host:$('select[name=host]').val(),
        page_rule:$('input[name=page_rule]').val()
    }
    request_plugin('save_page_rule',param,function (rdata) {
        showtip(rdata)
    })
}
function  fetch_host_config(obj = null)
{
    if(obj !== null){
        remember(obj);
    }
    var param = {
        host:$('select[name=host]').val()
    }
    request_plugin('fetch_host_config',param,function (rdata) {
        $("input[name=page_rule]").val(rdata.data.page_rule);
    })
}
function url_manage()
{
    var html = '<div class="u_main"> <input type="hidden" name="page">' +
        '<p> <label style="width: 30px" >网站</label> <select style="width: 100px" onchange="get_table_log()"  name="host" class="bt-select">  </select> ' +
        '链接 <input placeholder="支持模糊搜索" name="url" class="bt-input-sm">&nbsp;' +
        '<button onclick="get_table_log()" class="btn btn-sm btn-success"><i class="fa fa-search"></i> 搜索</button>&nbsp;' +
        '<button onclick="refresh_sitemap()" class="btn btn-sm btn-success"><i class="fa fa-refresh"></i> 刷新地图</button>' +
        '</p>' +
        '<div><table class="table">  <thead><th>链接</th> <th>生成时间</th> <th style="width: 45px">状态</th> <th style="width: 70px">操作栏</th>  </thead> ' +
        '<tbody id="url_body"></tbody> ' +
        '</table> <div id="table_tfoot" class="page pull-right"> </div> </div>' +
        '</div>';
    $('.plugin_body').html(html);
    get_web();
}
function refresh_sitemap()
{
    var param = {
        host:$('select[name=host]').val()
    }
    request_plugin('refresh_sitemap',param,function (rdata) {
        tip(rdata);
    })
}
function get_table_log(page = 1){
    var param = {
        host:$('select[name=host]').val(),
        url:$('input[name=url]').val(),
        page:page
    }
    request_plugin('get_table_log',param,function (rdata) {
        var table_body = '';
        rdata.data.page_data.forEach(function (item) {
            table_body += "<tr>" +
                "<td>"+item.url+"</td>" +
                "<td>"+item.create_time+"</td>" +
                "<td>"+item.status+"</td>" +
                "<td><button onclick=sw_status("+item.id+",'get_table_log') class='btn btn-xs btn-success'>切换</button> </td>" +
                "</tr>"
        })
        $('input[name=page]').val(page);
        $('#url_body').html(table_body);
        $('#table_tfoot').html(rdata.data.paginate);
    })
}
function sw_status(id,func = '')
{
    var param = {
        id:id
    }
    request_plugin('sw_status',param,function (rdata) {
        tip(rdata,function () {
            //get_table_log();
            eval(func+"()");
        });
    })
}
function sw_cron(id,func = '')
{
    var param = {
        id:id
    }
    request_plugin('sw_cron',param,function (rdata) {
        tip(rdata,function () {
            //get_table_log();
            eval(func+"()");
        });
    })
}
function get_web()
{
    var index = layer.msg('加载数据中',{icon:16});
    request_plugin('get_wc',{},function (res) {
        if(res.code === 0){
            layer.msg(res.msg,{icon:2});
        }
        layer.close(index);
        var op = '';
        var data = res.data;
        data.forEach(function (item) {
            op+="<option>"+item.host+"</option>";
        })
        $('select[name=host]').html(op);
        var record_host = localStorage.getItem("host");
        $("select[name=host]").val(record_host);
        get_table_log();
    })
}
function node_push()
{
    var param = {
        protocol:$('select[name=protocol]').val(),
        host:$('select[name=host]').val()
    }
    loading_msg();
    request_plugin('node_push',param,function (rdata) {
        loading_close();
        showtip(rdata,function () {
            $('.u_output1').html(rdata.data.content);
        })
    })
}


