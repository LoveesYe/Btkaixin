<?php
require  'vendor/autoload.php';
require  'SQLite.php';
use QL\QueryList;
use QL\Ext\AbsoluteUrl;
use Medoo\Medoo;
use QL\Ext\PhantomJs;
use think\facade\Db;
use think\Model;
$max_page = 1;

define('PLU_PATH',__DIR__);
define('PLUGIN_PATH',__DIR__);

class main
{

    public $chunk;
    public  $ds_file;
    public $user_agent;
    private $dataPath;

    const PRIORITY_MAP = ['1.0','0.9','0.8','0.7','0.6','0.5','0.4','0.3','0.2','0.1'];
    const CHANGEFREQ_MAP = [
        'always',
        'hourly',
        'daily',
        'weekly',
        'monthly',
        'yearly',
        'never'
    ];

    function __construct()
    {
        define('PLUGIN_NAME', "sitemap");
        define('MAIN_DB', PLU_PATH.'/../../data/default.db');
        define('PLUGIN_DB', __DIR__ . '/web.db');
        define('PLU_NAME', 'sitemap');
        define('DS', '/');
        $this->dataPath = PLU_PATH.'/static/';
        $this->chunk = 2000;
        $this->ds_file =  PLU_PATH.'/console.php';
        $this->user_agent = "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.141 Safari/537.36";
        $config = include PLU_PATH.'/config/database.php';
        Db::setConfig($config);
    }
    function trim_arr($arr)
    {
        if (empty($arr)) {
            return $arr;
        }
        foreach ($arr as &$val) {
            $val = trim($val);
        }
        return $arr;
    }

//success
    function success($msg = 'success', $data = null)
    {
        $this->json([
            'code' => 1,
            'msg' => $msg,
            'data' => $data
        ]);
    }

//error
    function error($msg)
    {
        return $this->json([
            'code' => 0,
            'msg' => $msg,
        ]);
    }

//获取json数据
    function json($data)
    {
        echo json_encode($data);
        exit;
    }
    
    function about()
    {
        try {
            @$json = json_decode(file_get_contents('https://www.waytomilky.com/notice.php'), true);
            $msg = $json[PLUGIN_NAME]['msg'];
        } catch (Exception $e) {
            $msg = '欢迎使用插件!觉得可以的话给个好评哦!';
        }
        $this->success($msg);
    }
    
    function baidu_push($host, $urls)
    {
//        $token = $this->config['baidu_token'];
//        $api =  "http://data.zz.baidu.com/urls?site=".$host."&token=".$token;
        $config_json = $this->get_config($host);
        $api = $config_json['baidu_api'];
        $ch = curl_init();
        $options = array(
            CURLOPT_URL => $api,
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_SSL_VERIFYPEER=>false,
            CURLOPT_POSTFIELDS => implode("\n", $urls),
            CURLOPT_HTTPHEADER => array('Content-Type: text/plain'),
        );
        curl_setopt_array($ch, $options);
        return json_decode(curl_exec($ch), true);
    }
    
    function sm_push($host, $urls)
    {
//        $token  =  $this->config['sm_token'];
//        $email  =  $this->config['sm_email'];
//        $api = 'http://data.zhanzhang.sm.cn/push?site='.$host.'&user_name='.$email.'&resource_name=mip_add&token='.$token;
        $config_json = $this->get_config($host);
        $api = $config_json['sm_api'];
        $ch = curl_init();
        $options = array(
            CURLOPT_URL => $api,
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_SSL_VERIFYPEER=>false,
            CURLOPT_POSTFIELDS => implode("\n", $urls),
            CURLOPT_HTTPHEADER => array('Content-Type: text/plain'),
        );
        curl_setopt_array($ch, $options);
        $result = curl_exec($ch);
        return json_decode($result, true);
    }
    
    function get_config($host)
    {
        $db = new SQLite(PLUGIN_DB);
        $config = $db->query("select * from web where host   =  '{$host}' ")->fetch();
        return $config;
    }
    //抓取链接
    
    /**
     * @action 方法作用
     * @param $urlx
     * @param string $protocol
     * @param int $level
     * @return array
     * @Auther 闻海南 <QQ 610176732>
     * @Date   2020/8/12
     */
    function getUrls($protocol = 'http://', $urlx, $level = 1)
    {
        $user_agent = $this->user_agent;
        $url = $protocol . $urlx . '/';
        $ql = QueryList::getInstance();
        $ql->use(AbsoluteUrl::class, 'absoluteUrl', 'absoluteUrlHelper');
        $urlsa =
            $ql->get($url,[],[
                'headers' => [
//                    'Referer' => 'https://www.waytomilky.com/',
                    'User-Agent' => $user_agent,
                ]
            ])
            ->absoluteUrl($url)
            ->find('a')
            ->attrs('href')
            ->all();
        //过滤
        $urls = [];
        foreach ($urlsa as $key => $v) {
            if (preg_match("/" . $urlx . "/", $v)) {
                $urls[] = $v;
            }
        }
        if ($level == 2) {
            $arr = [];
            try{
                foreach ($urls as $v) {
                    $ql = QueryList::getInstance();
                    $ql->use(AbsoluteUrl::class, 'absoluteUrl', 'absoluteUrlHelper');
                    $urlsb =
                        $ql->get($url,[],[
                            'headers' => [
//                                'Referer' => 'https://www.waytomilky.com/',
                                'User-Agent' => $user_agent
                            ]
                        ])
                        ->absoluteUrl($v)
                        ->find('a')
                        ->attrs('href')
                        ->all();
                    //过滤
                    $ax = [];
                    foreach ($urlsb as $key => $v) {
                        if (preg_match("/" . $urlx . "/", $v)) {
                            $ax[] = $v;
                        }
                    }
                    foreach ($ax as $vx) {
                        $arr[] = $vx;
                    }
                }
            }catch (\Exception $e){

            }
            return array_unique($arr);
        }
        //三级抓取
        if($level == 3){
            $temp = [];
            try{
                foreach ($urls as $v) {
                    $ql = QueryList::getInstance();
                    $ql->use(AbsoluteUrl::class, 'absoluteUrl', 'absoluteUrlHelper');
                    $ua = $ql->get($url,[],[
                            'headers' => [
//                                'Referer' => 'https://www.waytomilky.com/',
                                'User-Agent' => $user_agent
                            ]
                        ])
                            ->absoluteUrl($v)
                            ->find('a')
                            ->attrs('href')
                            ->all();
                    foreach ($ua as $va){
                        $ub = $ql->get($url,[],[
                            'headers' => [
//                                'Referer' => 'https://www.waytomilky.com/',
                                'User-Agent' => $user_agent
                            ]
                        ])
                            ->absoluteUrl($va)
                            ->find('a')
                            ->attrs('href')
                            ->all();
                        $tt  = [];
                        foreach ($ub as  $v) {
                            if (preg_match("/" . $urlx . "/", $v)) {
                                $tt[] = $v;
                            }
                        }
                        foreach ($tt as $cc){
                            $temp[] = $cc;
                        }
                    }
                }
                return array_unique($temp);
            }catch (Exception $e){

            }
        }

        return array_unique($urls);
    }
    /**
     * @action 保存sitemap
     * @Auther 闻海南 <QQ 610176732>
     * @Date   2020/8/12
     */
    function save_sitemap($host)
    {
        $url_arr = $this->db()->select('url',['url'],[
            'host'=>$host,
            'status'=>1
        ]);
        $urls = array_column($url_arr,'url');
        $config = $this->get_config($host);
        $map = new Sitemap();
        $urls = array_unique($urls);
        $txt = "";
        //过滤
        if(!empty($config['rep_str'])){
            $urls = $this->rep_str($host,$urls);
        }
        if(!empty($config['rm_str'])){
            $urls = $this->rm_str($host,$urls);
        }
        foreach ($urls as $v) {
            $v = $this->dlamp($v);
            $txt .= $v . "\n";
            $map->AddItem($v,$config['priority'],$config['changefreq']);
        }
        $filename = $config['filename'];
        $map->SaveToFile($config['path'] . DS . '/'.$filename.'.xml');
        //判断public目录
        if (is_dir($config['path'] . DS . "/public")) {
            $map->SaveToFile($config['path'] . DS . 'public/'.$filename.'.xml');
        }
        //判断web目录
        if (is_dir($config['path'] . DS . "/web")) {
            $map->SaveToFile($config['path'] . DS . 'web/'.$filename.'.xml');
        }
        //sitemap.txt
//        foreach ($urls as $vx){
//            file_put_contents($vx."\n",$config['path'] . DS . '/sitemap.txt');
//            if (is_dir($config['path'] . DS . "/public")){
//                file_put_contents($vx."\n",$config['path'] . DS . 'public/sitemap.txt');
//            }
//            if (is_dir($config['path'] . DS . "/web")) {
//                $map->SaveToFile($config['path'] . DS . 'web/sitemap.txt');
//            }
//        }
      
    }
    
    //替换&
    function dlamp($str)
    {
        return str_replace('&', '&amp;', $str);
    }
    
    function switchXml2arr($sitemap_url)
    {
        $content = $this->getHtml($sitemap_url);
        //$obj = new SimpleXMLElement($content);
        $xml = simplexml_load_string($content, 'SimpleXMLElement', LIBXML_NOCDATA);
        $jsonStr = json_encode($xml);
        $xml_data = json_decode($jsonStr, true);
        
        foreach ($xml_data['url'] as $key => $value) {
            $urls[] = $value['loc'];
        }
        return $urls;
    }
    
    function getHtml($url)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_AUTOREFERER, true);
        curl_setopt($ch, CURLOPT_REFERER, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $result = curl_exec($ch);
        curl_close($ch);
        return $result;
    }
    function get_info(){
        $sm =  file_get_contents(__DIR__.'/static/sm');
        $sm = intval($sm);
        if($sm<time() && $sm !== 0 ){
            $txt = file_get_contents(__DIR__.'/static/ms');
            $msg = base64_decode($txt);
            echo $msg;exit;
        }
    }
    function fenPush($host, $urls,$pro)
    {
        $urls = array_unique($urls);
        
        
        if (empty($urls)) {
            return "<div class='red'>插件警告:<br>1.推送的链接全部为重复网址或者过滤后无有效网址.</div>";
        }
        
        
        $chunk = $this->chunk;
        $msg = '';
        if (count($urls) > $chunk) {
            $msg .= '推送总数:' . count($urls);
            $url_chunk = array_chunk($urls, $chunk);
            $i = 0;
            foreach ($url_chunk as $value) {
                $i++;
                $msg .= "<br><b>-------------网址数量大于" . $chunk . ",自动启用分批推送,每批" . $chunk . "条,当前第" . $i . "批--------------</b>" . $this->push_all($host, $value, $pro);
            }
        } else {
            $msg = $this->push_all($host, $urls,$pro);
        }
        if(preg_match('/成功/',$msg)){
            $msg .= "<br>";
            $msg .= "<p>成功推送网址列表:</p>";
            foreach ($urls as $url) {
                $msg .= "<p>" . $url . "</p>";
            }
        }
        
        return $msg;
    }
    
    function push_all($host, $urls,$pro){
        $host_config  = $this->get_config($host);
        if(  empty( $host_config['baidu_api'] )  && empty($host_config['sm_api'])  ){
            $this->error('至少开启一个推送类型');
        }
        //百度主动推送
        $msg = '';
        if( !empty($host_config['baidu_api']) ){
            $res =  $this->baidu_push($host,$urls);
            $res['not_valid'] =  count($res['not_valid']);
            if(isset($res['success'])){
                @$msg .= '<p class="bt-text">百度普通收录推送成功:'.$res['success'].'条,剩余额度'.$res['remain'].'条,其中非本站网址'.count($res['not_same_site']).'条'.',不合法网址:'.$res['not_valid'].'条</p>';
            }else{
                $warn =  isset($res['message'])?$res['message']:'';
                //$warn = "推送api填写不正确.";
                if($warn == 'token is not valid'){
                    $warn = "百度api填写错了,别这么粗心哦!请仔细检查下";
                }
                if(preg_match("/over quota/",$warn)){
                    $warn = "您今日提交链接已经超过额度,请明天再来推送哦!";
                }
                $msg .= "<p class='bt-text-danger'>百度推送失败:$warn</p>";
            }
        }
    
    
        //神马推送
        if( !empty($host_config['sm_api']) ){
            $smres =  $this->sm_push($host,$urls);
            if($smres['returnCode']==200){
                $msg .= '<p class="bt-text">神马mip推送成功:'.count($urls).'条(神马官方不提供额度返回)</p>';
            }else{
                $msg .= '<p class="bt-text-danger">神马mip推送失败:配置错误.'.(isset($smres['returnCode'])?$smres['returnCode']:'')."</p>";
            }
        }
        
        try{
            $this->record_log($msg,$host,count($urls),$pro);
        }catch (\Exception $e){}
        
        return $msg;
    }
    
    function  record_log($msg,$host,$num,$pro="http://"){
        $type = "手动推送";
        $create_time = date('Y-m-d H:i:s',time());
        $this->db()->insert('log',[
            'msg'=>$msg,
            'host'=>$host,
            'type'=>$type,
            'create_time'=>$create_time,
            'pro'=>$pro,
            'num'=>!empty($num)?$num:0
        ]);
    }
    function bt_db(){
        return new medoo([
            'database_type' => 'sqlite',
            'database_file' => MAIN_DB
        ]);
    }
    function db(){
        return new medoo([
            'database_type' => 'sqlite',
            'database_file' => PLUGIN_DB
        ]);
    }

    /**
     * Notes:
     * Author: wenhainan
     * DateTime: 2022/3/16
     * Email: whndeweilai@gmail.com
     * @param $host
     * @param $urls
     */
    function add_url($host,$urls)
    {
        foreach ($urls as $url){
            //网址过滤

            $res = $this->db()->get('url','*',[
                'host'=>$host,
                'url'=>$url
            ]);
            if(empty($res)){
                $this->db()->insert('url',[
                    'host'=>$host,
                    'url'=>$url,
                    'priority'=>'1',
                    'create_time'=>time()
                ]);
            }
        }
        //$this->save_sitemap($host);
    }
    function rep_str($host,$urls)
    {
        foreach ($urls as &$url){
            $host_config  = $this->get_config($host);
            $rep_str = $host_config['rep_str'];
            if(preg_match("/#/",$rep_str)){
                $arr = explode('#',$rep_str);
                foreach ($arr as $v){
                    list($orgin,$new) = explode('=',$v);
                    $url = str_replace($orgin,$new,$url);
                }
            }else{
                list($orgin,$new) = explode('=',$rep_str);
                $url = str_replace($orgin,$new,$url);
            }
        }

        return $urls;
    }
    function rm_str($host,$urls)
    {
        foreach ($urls as $key=>$url){
            $host_config  = $this->get_config($host);
            $rm_str = $host_config['rm_str'];
            if(preg_match("/#/",$rm_str)){
                $arr = explode('#',$rm_str);
                foreach ($arr as $v){
                    if(preg_match("/".$v."/",$url)){
                        unset($urls[$key]);
                    }
                }
            }else{
                if(preg_match("/".$rm_str."/",$url)){
                    unset($urls[$key]);
                }
            }
        }
        return $urls;
    }
    function get_host_urls($host)
    {

        $arr = $this->db()->select('url',['url'],[
            'host'=>$host
        ]);
        $urls = [];
        foreach ($arr as $v){
            $urls[] = $v['url'];
        }

        return $urls;
    }

    /**
     * @param string   $protocol  协议
     * @param string   $host      域名
     * @param string   $page_rule 分页规则
     * @param int      $max       最大页数
     * @return array
     */
    function get_page_urls($protocol,$host,$page_rule,$max = 100)
    {
        $url = $protocol . $host ;
        $ql = QueryList::getInstance();
        $ql->use(AbsoluteUrl::class, 'absoluteUrl', 'absoluteUrlHelper');
        $urlsa = [];
        $j = 1;
        global $max_page;
        for ($i = 1;$i<$max;$i++){
            $max_page++;
            $pa = str_replace("数字",$i,$page_rule);
            $new_url = $url.$pa;
            try {
                $ret =  $ql->get($new_url,[],[
                    'headers' => [
                        'User-Agent' => $this->user_agent,
                    ]
                ])
                    ->absoluteUrl($url)
                    ->find('a')
                    ->attrs('href')
                    ->all();
                if(is_array($ret)){
                    $urlsa = array_merge($ret,$urlsa);
                }
//                $str = '';
//                foreach ($urlsa as $v){
//                    $str .= "<p>$v</p>";
//                }
//                //清空写入
//                file_put_contents(PLU_PATH.'/static/tmp.log','');
//                file_put_contents(PLU_PATH.'/static/tmp.log',$str.PHP_EOL,FILE_APPEND);
            }catch (Exception $e){
                break;
            }
        }
        $urls = $this->gl($urlsa,$host);
        return $urls;
    }
    function gl($urls,$host)
    {
        //过滤
        $urlsa = [];
        foreach ($urls as $key => $v) {
            if (preg_match("/$host/", $v)  ) {
                $urlsa[] = $v;
            }
        }
        return array_unique($urlsa);
    }
    public function common_fetch($url)
    {
        $html = file_get_contents($url);
        $dom = new DOMDocument();
        @$dom->loadHTML($html);
        $xpath = new DOMXPath($dom);
        $hrefs = $xpath->evaluate("/html/body//a");
        $urls = [];
        for ($i = 0; $i < $hrefs->length; $i++) {
            $href = $hrefs->item($i);
            $url = $href->getAttribute('href');
            $urls[] =  $url;
        }
        return $urls;
    }
    /**
     * [page description]  分页
     * @param  [type] $sum     [总页数]
     * @param  [type] $pagenum [页数]
     * @return [type]          [description]
     */
    function page($sum,$pagenum){
        $span = "";
        if($sum > 0){
            if($pagenum <=0){$pagenum = 1;}
            if($pagenum >= $sum){$pagenum = $sum;}

            $k = $pagenum-1 <= 0 ? 1:$pagenum-1;
            $m = $sum - 6 <= 0 ?1:$sum-6;
            $pageM = $pagenum == 1?$pagenum+2:$pagenum + 1;

            if($sum - $pagenum >= 6){
                for($i = $k; $i <= $pageM; $i++){
                    $class = $i == $pagenum?'Pcurrent':'Pnum';
                    $span .= '<a class="'.$class.'" onclick="get_table_log('.$i.')">'.$i.'</a>';
                }
                $span .= '<a class="Pnum"  >....</a>';
                for($i = $sum - 3; $i <= $sum; $i++){
                    $span .= '<a class="Pnum" onclick="get_table_log('.$i.')" >'.$i.'</a>';
                }
            }else{
                for($i = $m; $i <= $sum; $i++){
                    $class = $i == $pagenum?'Pcurrent':'Pnum';
                    $span .= '<a class="'.$class.'" onclick="get_table_log('.$i.')">'.$i.'</a>';
                }
            }
        }
        return $span;
    }
    function get_os(){
        if(PHP_OS == 'WIN32' || PHP_OS == 'WINNT' || PHP_OS == 'Windows'){
            $os = 'windows';
        }else{
            $os = 'linux';
        }
        return $os;
    }
    function get_real_path(){
        $arr = [
            '71',
            '72',
            '73',
            '74',
            '80'
        ];
        $php_version = '';
        foreach ($arr as $v){
            $cc = PLU_PATH.'/php_cli_'.$v.'.ini';
            if(file_exists($cc)){
                $php_version  =  $v;
                break;
            }
        }
        if(empty($php_version)){
            $this->error('请安装php>=7.1+');
        }
        $os = $this->get_os();
        if($os == 'linux'){
            $php_path = PLU_PATH."/../../../php/$php_version/bin/php";
        }else{
            $php_path = PLU_PATH."/../../../php/$php_version/php.exe";
        }

        return realpath($php_path);
    }
    function get_php_version(){
        $arr = [
            '71',
            '72',
            '73',
            '74',
            '80'
        ];
        $php_version = '';
        foreach ($arr as $v){
            $cc = PLU_PATH.'/php_cli_'.$v.'.ini';
            if(file_exists($cc)){
                $php_version  =  $v;
                break;
            }
        }
        if(empty($php_version)){
            throw new Exception('请安装php>=7.1');
        }
        return $php_version;
    }
}
class webModel extends Model
{
    protected $name = 'web';
    const IS_CRON_MAP = [
        1=>'关闭',
        2=>'开启'
    ];
    public function getIsCronAttr($value)
    {
        return self::IS_CRON_MAP[$value];
    }
}
class urlModel extends Model
{
    protected $name = 'url';
    const STATUS_MAP = [
        1=>'显示',
        2=>'隐藏'
    ];
    public function getCreateTimeAttr($value)
    {
        return date('Y-m-d H:i:s',$value);
    }
    public function getStatusAttr($value)
    {
        return self::STATUS_MAP[$value];
    }
}
