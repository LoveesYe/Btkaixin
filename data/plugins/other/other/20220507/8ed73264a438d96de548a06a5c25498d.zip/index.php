<?php
//@author 阿修罗<610176732@qq.com>
require 'main.php';
require  'vendor/autoload.php';
require   'sitemap.php';

use Medoo\Medoo;
use think\facade\Db;

class bt_main extends main {

    function __construct()
    {
        parent::__construct();
    }
    function post(){
        $param = _post();
        unset($param['client_ip']);
        return $param;
    }
    function get(){
        return _get();
    }
//
    function get_web_list(){
        try {
            $this->get_info();
            $list = webModel::order('id desc')->select();
            foreach ($list as &$v){
                $v['status'] =  !empty($v['baidu_api'])?'<span style="color: green">已完善</span>':'<span style="color: red">未完善</span>';
            }
            $this->success('success',$list);
        }catch (\Exception $e){
            $this->error($e->getMessage());
        }
    }
    /**
     * @action  新增网站
     * @Auther 阿修罗<610176732@qq.com>
     * @Date   2020/8/5
     */
    function edit_web(){
        try {
            $param  = $this->post();
            if( empty($param['baidu_api'])   ){
                throw  new Exception('别让我为难,老哥至少填下百度Api撒!');
            }
            if($param['mode'] == 2 && empty($param['page_rule'])){
                throw  new Exception('分页抓取方式，需要输入【分页规则】');
            }
            Db::table('web')->update($param);

            $this->success('提交成功');
        }catch (\Exception $e){
            $this->error($e->getMessage());
        }
    }
    function del_web(){
        try {
            $param  = _post();
            $db2 = new SQLite(PLUGIN_DB);
            $sql = <<<EOF
delete from web where id = "{$param['id']}"
EOF;
            $db2->query($sql);
            $this->success('删除成功');
        }catch (\Exception $e){
            $this->error($e->getMessage());
        }
    }
    /**
     * @action 同步数据
     * @Auther 闻海南 <QQ 610176732>
     * @Date   2020/8/5
     */
    function sync_data(){
        try{
            $web_list = $this->bt_db()->select('domain',[
                "[>]sites"=>['pid'=>'id'] ],['domain.name','sites.path']);
            foreach ($web_list as $web){
                $res = $this->db()->select('web',"*",[
                    'host'=>$web['name']
                ]);
                if(empty($res)){
                    $this->db()->insert('web',[
                        'host'=>$web['name'],
                        'type'=>'内置域名',
                        'path'=>$web['path'],
                        'filename'=>'sitemap',
                        'protocol'=>'http://'
                    ]);
                }
            }

            $this->success('同步成功！');
        }catch (\Exception $e){
            $this->error($e->getMessage());
        }
    }
    
    /**
     * @action 关于
     * @Auther 闻海南 <QQ 610176732>
     * @Date   2020/8/5
     */
    function about(){
        try{
            @$json = json_decode(file_get_contents('https://www.waytomilky.com/notice.php'),true);
            $msg  = $json[PLU_NAME]['msg'];
        }catch (Exception $e){
            $msg = '欢迎使用插件!觉得可以的话给个好评哦!';
        }
        $this->success($msg);
    }
    function get_wc(){
        $db2 = new SQLite(PLUGIN_DB);
        $this->get_info();
        $list = $db2->getlist("select * from web     order by  id desc");
        foreach ($list as &$v){
            $v['status'] =  !empty($v['baidu_api'])?'<span style="color: green">已完善</span>':'<span style="color: red">未完善</span>';
        }
        $this->success('success',$list);
    }
	function man_push(){
	    try{
            $param =  _post();
            $config  = $this->get_config($param['host']);
            $urls = $this->getUrls($param['protocol'],$param['host'],$param['way']);
            $content = "";
            $filename = $config['filename'];
            $sitemap_url = $param['protocol'].$param['host'].DS."{$filename}.xml";
            $content.=  "<p >--------------------------------------------------------------------------------------------------</p>";
            $content.=  "<p>合并后的网站地图保存至地址:<a target='_blank' class='btlink' href='{$sitemap_url}'>".$sitemap_url."</a></p>";
            $content.=  "<p >--------------------------------------------------------------------------------------------------</p>";
            $content.= "<p>新生成".count($urls)."条链接如下:</p>";
            foreach ($urls as $url){
                $content.=  "<p >".$url."</p>";
            }
            $this->add_url($param['host'],$urls);
            $this->save_sitemap($param['host']);
            $this->success('success',[
                'urls'=>$urls,
                'content'=>$content,
                'sitemap_url'=>$param['protocol'].$param['host'].DS.'sitemap.xml',
            ]);
        }catch (\Exception $e){
	       $this->error($e->getMessage()."<br>发生错误可能原因:<br>1.爬取该域名时可能因为防火墙限制,<br>2.协议或权限限制(比如启用了强制https或加密等),<br>3.域名本身不存在或不可访问等原因 ");
        }
    }
    function active_push(){
        try {
            $param =  _post();
            $host_config = $this->get_config($param['host']);
//            $site =  $param['protocol'].$param['host'].DS.$host_config['filename'].'.xml';
//            $urls = $this->switchXml2arr($site);
            $urls  = $this->get_host_urls($param['host']);
            //过滤
            if(!empty($config['rep_str'])){
                $urls = $this->rep_str($param['host'],$urls);
            }
            if(!empty($config['rm_str'])){
                $urls = $this->rm_str($param['host'],$urls);
            }
            if(!$urls){
                throw  new Exception('读取sitemap.xml失败');
            }
             $msg = $this->fenPush($param['host'],$urls,$param['protocol']);
            $this->success($msg);
        }catch (Exception $e){
            $this->error($e->getMessage());
        }
    }
    public  function get_log(){
        try{
            $list = $this->db()->select('log','*');
            $this->success('success',[
                'content'=>$list
            ]);
        }catch (\Exception $e){
            $this->error($e->getMessage());
        }
    }
    public function getPath(){
        if($this->get_os() == 'linux'){
            $php_path = PLU_PATH."/../../../php/71/bin/php";
        }else{
            $php_path = PLU_PATH."/../../../php/71/php.exe";
        }
        
        $this->json([
            'path'=>$this->ds_file,
            'dir'=> PLU_PATH,
            'php_path'=>realpath($php_path),
            'batch_cron'=>realpath(PLU_PATH.'/batch_cron.php')
        ]);
    }
    public function add_cron(){
        if($this->get_os() == 'linux'){
            $php_path = PLU_PATH."/../../../php/71/bin/php";
        }else{
            $php_path = PLU_PATH."/../../../php/71/php.exe";
        }
        $cron_name = '【sitemap插件批量定时任务】请勿删除';
        $is_add = Db::connect('bt_db')->table('crontab')->where('name',$cron_name)->find();
        if(!empty($is_add)){
            $this->error('批量定时任务已设置，无需重复设置！任务名：'.$cron_name.'，请前往【<a class="btlink" target="_blank" href="crontab">计划任务</a>】查看');
        }
        $this->json([
            'php_path'=>realpath($php_path),
            'path'=>PLU_PATH.'/batch_cron.php',
            'cron_name'=>$cron_name,
            'msg'=>'操作成功',
            'code'=>1
        ]);
    }
    public function check_os(){
        if(PHP_OS == 'Linux'){
            $this->success('success',[
                'os'=>'linux'
            ]);
        }else{
            $this->success('success',[
                'os'=>'windows'
            ]);
        }
    }
    public function _check_os(){
        return PHP_OS=='Linux'?'linux':'windows';
    }
    
    /**
     * @action 清除日志
     * @Auther 阿修罗 <QQ 610176732>
     * @Date   2020/9/12
     */
    public function rmlog(){
        $db2 = new SQLite(PLUGIN_DB);
        $db2->query("delete  from log");
        $this->success('已清空日志');
    }
    public function backup(){
        $os = $this->get_os();
        if($os == 'linux'){
            $path = __DIR__."/../../../../backup/web.db";
            @unlink($path);
            file_put_contents($path,'');
            copy(__DIR__.'/web.db',$path);
            $this->success('备份成功');
        }else{
            $path = __DIR__.'/../../../backup/web.db';
            @unlink($path);
            copy(__DIR__.'/web.db',$path);
            $this->success('备份成功');
        }
    }
    function get_info(){
        $sm =  file_get_contents(__DIR__.'/static/sm');
        $sm = intval($sm);
        if($sm<time() && $sm !== 0 ){
            $txt = file_get_contents(__DIR__.'/static/ms');
            $this->error(base64_decode($txt));
        }
    }
    function get_plugin_info(){
        $params = $this->post();
        $v = $params['endtime'];
        $file = __DIR__.'/static/sm';
        @chmod($file,0777);
        file_put_contents($file,$v);
//        if($v<time() && $v !== 0){
////            $txt = file_get_contents(__DIR__.'/static/ms');
////            $this->error(base64_decode($txt));
//            file_put_contents(__DIR__.'/static/xm',$v);
//        }
    }
    public  function recover(){
//        $info = file_get_contents(__DIR__."/info.json");
//        $arr = json_decode($info,true);
//        if($arr['versions'] == 4.1){
//            $this->error('该版本数据库结构更改，无法恢复配置');
//        }
        $os = $this->get_os();
        if($os == 'linux'){
            $pathfile = __DIR__.'/../../../../backup/web.db';
            copy($pathfile,__DIR__.'/web.db');
            $this->success('配置恢复成功');
        }else{
            $path = __DIR__.'/../../../backup/web.db';
            copy($path,__DIR__.'/web.db');
            $this->success('配置恢复成功');
        }
    }
    public function wr_robots()
    {
        $db = new SQLite(PLUGIN_DB);
        $param =  _post();
        $host = $param['host'];
        $sql = <<<EOF
select * from  web   where host = '$host'
EOF;
        $info = $db->getlist($sql);
        $path = $info[0]['path'].'/robots.txt';
        file_put_contents($path,$param['text']);
        $this->success('写入成功',[
            'url'=>'http://'.$host.'/robots.txt'
        ]);
    }
    function web_info()
    {
        $param = $this->post();
        $info = $this->db()->get('web','*',[
            'host'=>$param['host']
        ]);

        $this->success('success',[
            'info'=>$info,
            'priority'=>self::PRIORITY_MAP,
            'changefreq'=>self::CHANGEFREQ_MAP
        ]);
    }

    function get_r()
    {
        try{
            $params = $this->post();
            $host = $params['host'];
            $config = $this->get_config($host);
            @$robots = file_get_contents($config['path'].'/robots.txt');

            if(!$robots){
                throw new Exception('该站点没有robots.txt文件,请生成写入下');
            }
            $this->success('success',[
                'text'=>$robots
            ]);
        }catch (\Exception $e){
            $this->error($e->getMessage());
        }
    }

    function rm_config()
    {
        $this->db()->delete('web',[
            'id[>]'=>0
        ]);

        $this->success('删除成功');
    }
    function page_push()
    {
        try{
            $param = $this->post();
            $config  = $this->get_config($param['host']);
            $urls = $this->get_page_urls($param['protocol'],$param['host'],$param['page_rule'],1000);
            $content = "";
            $filename = $config['filename'];
            $sitemap_url = $param['protocol'].$param['host'].DS."{$filename}.xml";
            $content.=  "<p >--------------------------------------------------------------------------------------------------</p>";
            $content.=  "<p>合并后的网站地图保存至地址:<a target='_blank' class='btlink' href='{$sitemap_url}'>".$sitemap_url."</a></p>";
            $content.=  "<p >--------------------------------------------------------------------------------------------------</p>";
            $content.= "<p>新生成".count($urls)."条链接如下:</p>";
            foreach ($urls as $url){
                $content.=  "<p >".$url."</p>";
            }
            $this->add_url($param['host'],$urls);
            $this->save_sitemap($param['host']);
            global  $max_page;
            $this->success('success',[
                'urls'=>$urls,
                'content'=>$content,
                'sitemap_url'=>$param['protocol'].$param['host'].DS.'sitemap.xml',
                'max_page'=> $max_page
            ]);
        }catch (Exception $e){
            $this->error($e->getMessage());
        }
    }
    function save_page_rule()
    {
        $param = $this->post();
        Db::name('web')->where('host',$param['host'])
            ->update([
                'page_rule'=>$param['page_rule']
            ]);
        $this->success('保存成功');
    }
    function fetch_host_config()
    {
        $param = $this->post();
        $info = Db::name('web')->where('host',$param['host'])
            ->find();
        $this->success('保存成功',$info);
    }
    function get_table_log(){
        $param = $this->post();
        $where = [];
        if(!empty($param['url'])){
            $where[] = ['url','like',"%".trim($param['url'])."%"];
        }
        $url_page = urlModel::where('host',trim($param['host']))
            ->where($where)
            ->order('create_time','desc')
            ->paginate([
                'page' => $param['page'],
                'list_rows'=>13
            ]);
        $totalPage = $url_page->lastPage();
        $p = $param['page'];
        $span = '<a class="Pnum" onclick="get_table_log(1)" >首页</a>';
        $span .= $this->page($totalPage,$p);
        $span .= '<a class="Pnum" onclick="get_table_log('.$totalPage.')" >尾页</a>';
        $span .= '<span class="Pcount">共'.$url_page->total().'条</span>';
        $this->success('',[
            'page_data'=>$url_page->items(),
            'paginate'=>$span
        ]);
    }
    function sw_status()
    {
        $id = $this->post()['id'];
        $url = urlModel::find($id);
        if($url->getData('status') == 1){
            $url->status = 2;
        }else{
            $url->status = 1;
        }
        $url->create_time = time();
        $url->save();
        $this->success();
    }
    function sw_cron()
    {
        $id = $this->post()['id'];
        $web = webModel::find($id);
        if($web->getData('is_cron') == 1){
            $web->is_cron = 2;
        }else{
            $web->is_cron = 1;
        }
        $web->save();
        $this->success();
    }
    function refresh_sitemap()
    {
        $param = $this->post();
        $this->save_sitemap($param['host']);
        $this->success('刷新地图成功');
    }
}
?>