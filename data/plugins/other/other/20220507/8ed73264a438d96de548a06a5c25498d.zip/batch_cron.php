<?php
//@author 阿修罗<610176732@qq.com>
require 'vendor/autoload.php';
require 'sitemap.php';
require 'main.php';

use QL\QueryList;
use QL\Ext\AbsoluteUrl;
use think\facade\Db;

class batch_cron extends  main {

    public $chunk;
    public function  __construct(){
        parent::__construct();
        define("PLUGIN_DB",__DIR__."/web.db");
        define('PLU_NAME', 'sitemap');
        define('DS', '/');
        $this->chunk = 2000;
        $this->get_info();
        $webs = Db::table('web')->where([
            'is_cron'=>2,
        ])->select();
        foreach ($webs as $web){
            echo '网站'.$web['host']."生成sitemap并推送搜索引擎\n";
            if($web['mode'] ==1){
                $this->push($web['host'],$web['protocol']);
            }
            if($web['mode'] ==2){
                $this->push_page($web['host'],$web['protocol'],$web['page_rule']);
            }
        }
    }
    function push($host,$protocol,$level = 2){
        //获取链接保存
        $urls =  $this->getUrls($protocol,$host,$level);
        $this->add_url($host,$urls);
        $this->save_sitemap($host);
        $this->fenPush($host,$urls,$protocol);
    }
    function push_page($host,$protocol,$page_rule)
    {
        //获取链接保存
        $urls =  $this->get_page_urls($protocol,$host,$page_rule);
        $this->add_url($host,$urls);
        $this->save_sitemap($host);
        $this->fenPush($host,$urls,$protocol);
    }
    /**
     * @action 保存sitemap
     * @Auther 闻海南 <QQ 610176732>
     * @Date   2020/8/12
     */
    function save_sitemap($host)
    {
        $config = $this->get_config($host);
        $map = new Sitemap();
        $url_arr = $this->db()->select('url',['url'],[
            'host'=>$host,
            'status'=>1
        ]);
        $urls = array_column($url_arr,'url');
        $urls = array_unique($urls);
        $txt = "";
        //过滤
        if(!empty($config['rep_str'])){
            $urls = $this->rep_str($host,$urls);
        }
        if(!empty($config['rm_str'])){
            $urls = $this->rm_str($host,$urls);
        }

        foreach ($urls as $v) {
            $v = $this->dlamp($v);
            $txt .= $v . "\n";
            $map->AddItem($v,$config['priority'],$config['changefreq']);
        }
        $filename = $config['filename'];
        $map->SaveToFile($config['path'] .  '/'.$filename.'.xml');
        //判断public目录
        if (is_dir($config['path'] . DS . "/public")) {
            $map->SaveToFile($config['path'] . DS . 'public/'.$filename.'.xml');
        }
        //判断web目录
        if (is_dir($config['path'] . DS . "/web")) {
            $map->SaveToFile($config['path'] . DS . 'web/'.$filename.'.xml');
        }
        echo  "\n-------------------------------------";
        echo "\n sitemap.xml保存地址:".$config['path'] . DS . "{$filename}.xml ";
    }
    function get_config($host)
    {
        $db = new SQLite(PLUGIN_DB);
        $config = $db->query("select * from web where host   =  '{$host}' ")->fetch();
        return $config;
    }
    function baidu_push($host, $urls)
    {
        $config_json = $this->get_config($host);
        $api = $config_json['baidu_api'];
        $ch = curl_init();
        $options = array(
            CURLOPT_URL => $api,
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POSTFIELDS => implode("\n", $urls),
            CURLOPT_SSL_VERIFYPEER=>false,
            CURLOPT_HTTPHEADER => array('Content-Type: text/plain'),
        );
        curl_setopt_array($ch, $options);
        return json_decode(curl_exec($ch), true);
    }

    function sm_push($host, $urls)
    {
        $config_json = $this->get_config($host);
        $api = $config_json['sm_api'];
        $ch = curl_init();
        $options = array(
            CURLOPT_URL => $api,
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_SSL_VERIFYPEER=>false,
            CURLOPT_POSTFIELDS => implode("\n", $urls),
            CURLOPT_HTTPHEADER => array('Content-Type: text/plain'),
        );
        curl_setopt_array($ch, $options);
        $result = curl_exec($ch);
        return json_decode($result, true);
    }
    function fenPush($host, $urls,$protocol)
    {
        $urls = array_unique($urls);
        if (empty($urls)) {
            echo "\n插件警告:1.推送的链接全部为重复网址或者过滤后无有效网址\n";
        }
        $chunk = $this->chunk;
        $msg = '';
        if (count($urls) > $chunk) {
            $msg .= '推送总数:' . count($urls);
            $url_chunk = array_chunk($urls, $chunk);
            $i = 0;
            foreach ($url_chunk as $value) {
                $i++;
                $msg .= "\n-------------网址数量大于" . $chunk . ",自动启用分批推送,每批" . $chunk . "条,当前第" . $i . "批--------------" . $this->push_all($host, $value, $protocol);
            }
        } else {
            $msg = $this->push_all($host, $urls,$protocol);
        }
        if(preg_match('/成功/',$msg)){
            $msg .= "\n--------------------------------------";
            $msg .= "\n成功推送网址列表:";
            foreach ($urls as $url) {
                $msg .= "\n" . $url;
            }
        }
        echo "\n--------------------------------------";
        echo $msg;
        echo "\n--------------------------------------";
    }

    function push_all($host, $urls,$pro){
        $host_config  = $this->get_config($host);
        if(  empty( $host_config['baidu_api'] )  && empty($host_config['sm_api'])  ){
            echo '至少开启一个推送类型';exit;
        }
        //百度主动推送
        $msg = '';
        $str = '';
        if( !empty($host_config['baidu_api']) ){
            $res =  $this->baidu_push($host,$urls);
            $res['not_valid'] =  count($res['not_valid']);
            if(isset($res['success'])){
                @$msg .= "\n".'百度普通收录推送成功:'.$res['success'].'条,剩余额度'.$res['remain'].'条,其中非本站网址'.count($res['not_same_site']).'条'.',不合法网址:'.$res['not_valid'].'条';
                @$str .= '<p class="bt-text">百度普通收录推送成功:'.$res['success'].'条,剩余额度'.$res['remain'].'条,其中非本站网址'.count($res['not_same_site']).'条'.',不合法网址:'.$res['not_valid'].'条</p>';
            }else{
                $warn =  isset($res['message'])?$res['message']:'';
                if($warn == 'token is not valid'){
                    $warn = "百度API填写错了,别这么粗心哦!请仔细检查下";
                }
                $msg .= "\n".'百度普通收录推送失败:'.$warn;
                $str .= '<br><p class="bt-text-danger">百度普通收录推送失败:'.$warn.'</p>';
            }
        }


        //神马推送
        if( !empty($host_config['sm_api']) ){
            $smres =  $this->sm_push($host,$urls);
            if($smres['returnCode']==200){
                $msg .= "\n神马mip推送成功:".count($urls)."条(神马官方不提供额度返回)";
                $str .= '<p class="bt-text">神马mip推送成功:'.count($urls).'条(神马官方不提供额度返回)</p>';
            }else{
                $msg .= "神马mip推送失败:配置错误,".(isset($smres['returnCode'])?$smres['returnCode']:'');
                $str .= '<p class="bt-text-danger">神马mip推送失败:配置错误,'.(isset($smres['returnCode'])?$smres['returnCode']:'')."</p>";
            }
        }

        $this->_record_log($str,$host,$pro,count($urls),'定时推送');


        return $msg;
    }
    function  _record_log($msg,$host,$pro,$num,$type = "定时推送")
    {
        $create_time = date('Y-m-d H:i:s',time());
        $this->db()->insert('log',[
            'msg'=>$msg,
            'host'=>$host,
            'type'=>$type,
            'create_time'=>$create_time,
            'pro'=>$pro,
            'num'=>$num
        ]);
//        $this->db->query("insert into `log` (msg,host,type,create_time,pro,num) values('{$msg}','{$host}','{$type}','{$create_time}','{$pro}','{$num}')  ");
    }
    /**
     * @action 方法作用
     * @param $urlx   域名
     * @param string $protocol 协议
     * @param int $level 层级
     * @return array
     * @Auther 闻海南 <QQ 610176732>
     * @Date   2020/8/12
     */
    function getUrls($protocol = 'http://', $urlx, $level = 1)
    {
        $url = $protocol . $urlx . '/';
        $ql = QueryList::getInstance();
        $ql->use(AbsoluteUrl::class, 'absoluteUrl', 'absoluteUrlHelper');
        $urlsa =
            $ql->get($url,[],[
                'headers' => [
                    'Referer' => 'https://www.waytomilky.com/',
                    'User-Agent' =>$this->user_agent
                ]
            ])
                ->absoluteUrl($url)
                ->find('a')
                ->attrs('href')
                ->all();
        //过滤
        $urls = [];
        foreach ($urlsa as $key => $v) {
            if (preg_match("/" . $urlx . "/", $v)) {
                $urls[] = $v;
            }
        }
        if ($level == 2) {
            $arr = [];
            try{
                foreach ($urls as $v) {
                    $ql = QueryList::getInstance();
                    $ql->use(AbsoluteUrl::class, 'absoluteUrl', 'absoluteUrlHelper');
                    $urlsb = $ql->get($v,[],[
                        'headers' => [
                            'Referer' => 'https://www.waytomilky.com/',
                            'User-Agent' =>$this->user_agent
                        ]
                    ])
                        ->absoluteUrl($v)
                        ->find('a')
                        ->attrs('href')
                        ->all();
                    //过滤
                    $ax = [];
                    foreach ($urlsb as $key => $v) {
                        if (preg_match("/" . $urlx . "/", $v)) {
                            $ax[] = $v;
                        }
                    }
                    foreach ($ax as $vx) {
                        $arr[] = $vx;
                    }
                }
            }catch (\Exception $e){

            }
            return array_unique($arr);
        }
        //三级抓取
        if($level == 3){
            $temp = [];
            try{
                foreach ($urls as $v) {
                    $ql = QueryList::getInstance();
                    $ql->use(AbsoluteUrl::class, 'absoluteUrl', 'absoluteUrlHelper');
                    $ua = $ql->get($url,[],[
                        'headers' => [
                            'Referer' => 'https://www.waytomilky.com/',
                            'User-Agent' =>$this->user_agent
                        ]
                    ])
                        ->absoluteUrl($v)
                        ->find('a')
                        ->attrs('href')
                        ->all();
                    foreach ($ua as $va){
                        $ub = $ql->get($url,[],[
                            'headers' => [
                                'Referer' => 'https://www.waytomilky.com/',
                                'User-Agent' =>$this->user_agent
                            ]
                        ])
                            ->absoluteUrl($va)
                            ->find('a')
                            ->attrs('href')
                            ->all();
                        $tt  = [];
                        foreach ($ub as  $v) {
                            if (preg_match("/" . $urlx . "/", $v)) {
                                $tt[] = $v;
                            }
                        }
                        foreach ($tt as $cc){
                            $temp[] = $cc;
                        }
                    }
                }
                return array_unique($temp);
            }catch (Exception $e){

            }
        }

        //过滤
        $config = $this->get_config($urlx);
        if(!empty($config['rep_str'])){
            $urls = $this->rep_str($urlx,$urls);
        }
        if(!empty($config['rm_str'])){
            $urls = $this->rm_str($urlx,$urls);
        }

        return array_unique($urls);
    }




}

//初始化类
echo "开始执行批量定时任务:\n";
$console = new batch_cron();