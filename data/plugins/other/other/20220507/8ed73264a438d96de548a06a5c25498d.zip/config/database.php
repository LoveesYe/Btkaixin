<?php
return [
    // 默认数据连接标识
    'default'     => 'plugin_db',
    // 数据库连接信息
    'connections' => [
        'plugin_db' => [
            'type'     => 'sqlite',
            'database' => realpath(PLUGIN_PATH.'/web.db'),
            'auto_timestamp'=>true,
            'break_reconnect'=>true,
            'fields_cache'=>true
        ],
        'bt_db' => [
            'type'     => 'sqlite',
            'database' => realpath(PLUGIN_PATH.'/../../data/default.db')
        ],
    ],
];
