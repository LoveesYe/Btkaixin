<?php

/*
站长好工具宝塔管理员必备站长好工具


20191224更新
1. 解决空间不存在情况下报错不显示结果（不存在就不判断）；
2. 解决临时文件不存在情况下报错不显示结果；
3. 解决泛绑定域名查状态及解析IP出错；

*/

class bt_main{
 //不允许被面板访问的方法请不要设置为公有方法
//推荐linux平台php5.4-5.6 windows下ngnix apache也正常

public function getsite(){
   $db = new SQLite3('../../data/default.db'); //要不要判断文件是否存在呢 /www/server/panel/data/default.db
   if(!$db){
         return "<option value =\"chafenba.com\">读取失败</option>"; //读取不到就默认域名
   }
 $ret = $db->query("SELECT * from sites");
   $domas = "";  $ib = 0;    
 while($row = $ret->fetchArray(SQLITE3_ASSOC)){
  $sitename =	$row['name'];   $siteid =	$row['id'];
  $domas .= "<option value =\"{$siteid}\">查站点 $sitename 状态</option>";    $ib++;
 }
  $db->close();
 if($ib<1)  return "<option value =\"chafenba.com\">暂无站点</option>";
    return $domas;
 }
 

public function chafenba(){
$CACHE = "抱歉:查询不到信息"; //初始提示
$doma = _get('ip'); //获取域名
if(!$doma){ $doma = _post('ip'); }
if(!preg_match("/^[0-9]{1,8}$/i", $doma)) {
    return ['state'=>'1001','table'=>$doma];
}
$db = new SQLite3('../../data/default.db'); //要不要判断文件是否存在呢
   if(!$db){
   return ['state'=>'1001','table'=>$doma];
   }
   
  $numa = $db->querySingle("SELECT path from sites where id = {$doma}", true);
  $sitedirs = $numa["path"];
  $userdirs = $sitedirs."/.user.ini";
  $domafile = "/chafenba.cache.txt"; //临时文件.txt看目录等信息
  $daydan = date('YmdHis');
  $domxtxts = "@{$sitedirs}@{$daydan}@"; //零食文件写入内容 时间参数用于更精准判断
   $myip = "<table cellspacing=\"0\" class=\"table\" cellpadding=\"0\">\r\n";
  if (!is_dir($sitedirs)){
  	$isdirs = "<br><b>注意：</b>网站目录不存在";
  	$myip .= "<tr><td class=\"r\">空间存在检查</td><td>{$sitedirs}{$isdirs}</td></tr>";
  	}else{
  	 file_put_contents($sitedirs.$domafile,$domxtxts);
  $isdirs = "<br><span class=\"text-success\">正常：</span>网站目录存在";
  $myip .= "<tr><td class=\"r\">空间存在检查</td><td>{$sitedirs}{$isdirs}</td></tr>";
  if (!file_exists($userdirs)){
  	$isuser = "<br><b>注意：</b>user.ini文件不存在";
  	}else{
    $initxt = file_get_contents($userdirs); //当前仅判断是否包含 是不是得等于判断?
    if(!stristr($initxt,$sitedirs)){
    	$isuser = "<br><b>注意：</b>配置未包含目录信息";
    }else{
    	$quanx = substr(sprintf('%o',fileperms($userdirs)), -3);
        $isuser = "<br><span class=\"text-success\">正常：</span>配置包含目录信息 "; 
    }
   }
    $myip .= "<tr><td class=\"r\">user.ini检查</td><td>{$userdirs}{$isuser} <b>权限</b>{$quanx}</td></tr>";
  	}
   $myip .= "</table>\r\n";
   
   $ret = $db->query("SELECT * from domain where pid = {$doma}");   $ib = 0;
   $myip .= "<table cellspacing=\"0\" class=\"table\" cellpadding=\"0\">\r\n";
   $myip .= "<tr class=\"tt\"><td>序号</td><td>绑定域名</td><td>域名解析IP</td><td>域名空间对应</td></tr>";
 while($row = $ret->fetchArray(SQLITE3_ASSOC)){
  $sitename = $row['name'];  $ib++;
  $siteport = $row['port'];
  if(stristr($sitename,"*")){
  	$sitenamex = str_replace('*',$daydan,$sitename); //解决域名泛绑定情况
  }else{
  	$sitenamex = $sitename; 
  }
  if($siteport=="443"){
  	$urls = "https://{$sitenamex}{$domafile}";
  }elseif(!is_numeric($siteport)){
  	$urls = "http://{$sitenamex}{$domafile}";
  }else{
    $urls = "http://{$sitenamex}:{$siteport}{$domafile}";	
  }
if (!file_exists($sitedirs.$domafile)){
  $urltxt = $daydan;	
}else{
$ch = curl_init(); 
curl_setopt ($ch, CURLOPT_URL, $urls); 
curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1); 
curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT,10); 
$urltxt = Trim(curl_exec($ch)); 
}
   // if(!stristr($urltxt,$sitedirs)){ //$domxtxts
   if($urltxt == $domxtxts){ //$domxtxts
    $ishttp = "<span class=\"text-success\">正常</span>"; 
   }elseif($urltxt == $daydan){ //$domxtxts
    $ishttp = "<b>注意：</b>网站目录不存在或权限不足";
   }else{
  	$ishttp = "<b>注意：</b>可能域名、空间不对应";
  }
 //如果可以获取本机IP，cookie未发现IP,如果有可以对解析IP对比识别
 //action=get_soft_list 有IP，各页面左上角有html含IP
  $sitename = strtolower($sitename); //类型转大写
  $tipa = gethostbyname($sitenamex); //域名转小写
if($tipa == $sitename){ $tipa = "未解析或未生效";}
$myip .= "<tr><td>{$ib}</td><td>{$sitename}</td><td>".$tipa."</td><td>{$ishttp}</td></tr>";
}
 if($ib<1)  $myip .= "<tr><td colspan=\"4\">未发现绑定的域名</td></tr>";
  $myip .= "</table>\r\n";
  if (file_exists($sitedirs.$domafile)) unlink($sitedirs.$domafile); //删除缓存
  $db->close();
return ['ip' => $doma, 'dk' => "gethostbyname", 'state'=>'1000','table'=>$myip];
}

}