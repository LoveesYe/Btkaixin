#!/usr/bin/python
# coding: utf-8

#+--------------------------------------------------------------------
#|   百度网盘
#|   Author: 技术雨 <forxiaoyu@qq.com>
#+--------------------------------------------------------------------

import sys,os,json,time
if sys.version_info[0] == 2:
    reload(sys)
    sys.setdefaultencoding('utf-8')
elif sys.version_info[0] == 3:
    from importlib import reload
    reload(sys)

#设置运行目录
plugin_path = os.path.dirname(os.path.abspath(__file__))
panel_path = os.path.dirname(os.path.dirname(plugin_path))
os.chdir(panel_path)

#添加包引用位置并引用公共包
sys.path.append("class/")
import public,db#,config

#添加包引用位置
plugin_libs_path = "%s/libs/" % (plugin_path)
sys.path.append(plugin_libs_path)
# 引入扩展包
import utils
import baidu_netdisk

#在非命令行模式下引用面板缓存和session对象
if __name__ != '__main__':
    pass
    # from BTPanel import cache,session,redirect

class baidu_netdisk_main:
    __config = None
    __exclude = ""
    __plugin_path = "%s/" % (plugin_path)
    __basePath = '/apps/宝塔面板网盘助手/'
    __db_path = "%s/data/baidu_netdisk.db" % (panel_path)
    __task_name = "baidu_netdisk_task_main"
    __logs_path = "%s/logs" % (plugin_path)
    __tmp_path = "%s/tmp" % (plugin_path)
    __tail_path = "tail"
    __start_task_lock = "%s/start_task.lock" % (plugin_path)
    __backup_path = ""

    #构造方法
    def  __init__(self):
        reload(utils)
        reload(baidu_netdisk)
        self.utils = utils.Utils()
        self.baiduNetdisk = baidu_netdisk.BaiduNetdisk()
        self.__get_exclode()
        if self.utils.is_win():
            import panelBackup
            self._backupObj = panelBackup.panelBackup()
            # tail路径
            self.__tail_path = "%s/script/tail.exe" % (panel_path)

        # 初始化数据库
        if not os.path.exists(self.__db_path) or os.path.getsize(self.__db_path) == 0:
            # 初始化数据库
            import db
            sql = db.Sql().dbfile('baidu_netdisk')
            # self.utils.logs(sql)
            result = sql.fofile(self.__plugin_path+'default.sql')
            # self.utils.logs(result)
        
        # 初始化日志目录
        if not os.path.exists(self.__logs_path):
            os.makedirs(self.__logs_path)

        # 初始化临时目录
        if not os.path.exists(self.__tmp_path):
            os.makedirs(self.__tmp_path)
        
        # 初始化计划任务临时目录
        import db
        sql = db.Sql()
        backup_path = sql.table('config').where("id=?",(1,)).getField('backup_path') + '/baidu_netdisk'
        self.__backup_path = backup_path
        if not os.path.exists(self.__backup_path):
            os.makedirs(self.__backup_path)

    # 获取排除目录
    def __get_exclode(self):
        tmp_exclude = os.getenv('BT_EXCLUDE')
        if not tmp_exclude: return ""
        for ex in tmp_exclude.split(','):
            self.__exclude += " --exclude=\"" + ex + "\""
        self.__exclude += " "
        return self.__exclude

    # 获取备份根目录
    def __get_base_path(self):
        if self.utils.get_config('base_path') == None or self.utils.get_config('base_path') == "" :
            return self.__basePath
        else:
            return self.utils.get_config('base_path')

    # 获取数据库指定table实例
    def __table(self,table):
        import db
        return db.Sql().dbfile('baidu_netdisk').table(table)

    #访问/index.html时调用的默认方法，需要在templates中有index.html，否则无法正确响应模板
    def index(self,args):
        return None

    # 修复插件
    def get_fix(self,args):
        # public.ExecShell('pip install pyOpenSSL -I')
        # public.ExecShell('pip install requests -I')
        os.system('pip install cryptography==3.2')
        os.system('pip install pyOpenSSL -I')
        os.system('pip install requests -I')
        self.install()
        return {"code":1,"msg":"修复完成"}

    # 解绑账号
    def unbind_user(self,args):
        config_file = self.__plugin_path + 'config.json'
        self.utils.remove(config_file)
        return {"code":1,"msg":"解绑完成"}

    # 请求授权信息
    def get_auth(self,args):
        return self.baiduNetdisk.get_auth()

    # 获取授权信息
    def get_access(self,args):
        if not 'state' in args:
            return {"code":0,"msg":"参数错误"}
        return self.baiduNetdisk.get_access(args.state)

    # 获取文件列表
    def get_list(self,args):
        # 获取面板配置信息
        # panel_config = config.config()
        # return panel_config.get_config(args)
        if not 'path' in args: args.path = '/'
        return self.baiduNetdisk.get_list(args.path)

    # 获取账号信息
    def get_userinfo(self,args):
        return self.baiduNetdisk.get_userinfo()

    # 设置网盘根目录
    def set_base_path(self,args):
        if not 'base_path' in args : args.base_path = ''

        if args.base_path[-1] != "/" :
            args.base_path += "/"

        self.utils.set_config('base_path',args.base_path)

        return {
            "code":1,
            "msg":"操作成功",
        }

    # 创建文件夹
    def get_create_dir(self,args):
        if not 'path' in args : args.path = ''
        if not 'dir' in args : args.dir = ''
        if args.path == '' or args.dir == '':
            return {"code":0,"msg":"参数错误"}

        result = self.baiduNetdisk.create_dir(args.path+'/'+args.dir)
        if result['errno'] != 0:
            return {"code":0,"msg":"创建失败"}

        return {"code":1,"msg":"操作成功"}

    # 上传本地文件
    def get_upload(self,args):
        if not 'path' in args : args.path = ''
        if not 'remote_path' in args : args.remote_path = ''
        if args.path == '' or args.remote_path == '':
            return {"code":0,"msg":"参数错误"}

        if args.remote_path[-1] != '/' :
            args.remote_path = args.remote_path + '/'

        # 判断是否使用管道刷新组件
        if self.utils.is_win():
            python_path = 'python'
        else:
            python_path = '/usr/bin/unbuffer python'

        # 创建定时任务
        self.__table('tasks').add('name,type,shell,other,add_time,status',(os.path.basename(args.path),1,'%s %sbaidu_netdisk_main.py upload "%s" "%s"' % (python_path,self.__plugin_path,args.path,args.remote_path),'',int(time.time()),0))

        # 开始执行定时任务
        task = public.M('task_list').where('name=? and status=?',(self.__task_name,0)).find()
        if not task and not os.path.exists(self.__start_task_lock):
            import panelTask
            t = panelTask.bt_task()
            t.create_task(self.__task_name,0,'python %sbaidu_netdisk_main.py startTask' % (self.__plugin_path))

        return {"code":1,"msg":"操作成功"}


    # 下载文件
    def download_file(self,args):
        if not 'fs_id' in args:
            return {"code":0,"msg":"参数错误"}
        return self.baiduNetdisk.download_file(args.fs_id)

    # 下载文件到服务器
    def download_file_server(self,args):
        if not 'path' in args : args.path = ''
        if not 'server_filename' in args : args.server_filename = ''
        if not 'fs_id' in args : args.fs_id = ''
        if args.path == '' or args.server_filename == '' or args.fs_id == '':
            return {"code":0,"msg":"参数错误"}

        # 判断文件是否存在
        if os.path.exists("%s/%s" % (args.path,args.server_filename)):
            return {"code":0,"msg":"服务器已存在同名文件"}

        # 判断是否使用管道刷新组件
        if self.utils.is_win():
            python_path = 'python'
        else:
            python_path = '/usr/bin/unbuffer python'

        # 创建定时任务
        self.__table('tasks').add('name,type,shell,other,add_time,status',(os.path.basename(args.server_filename),2,'%s %sbaidu_netdisk_main.py download "%s" "%s"' % (python_path,self.__plugin_path,args.path,args.fs_id),'',int(time.time()),0))

        # 开始执行定时任务
        task = public.M('task_list').where('name=? and status=?',(self.__task_name,0)).find()
        if not task and not os.path.exists(self.__start_task_lock):
            import panelTask
            t = panelTask.bt_task()
            t.create_task(self.__task_name,0,'python %sbaidu_netdisk_main.py startTask' % (self.__plugin_path))

        return {"code":1,"msg":"操作成功"}


    # 删除文件
    def delete_file(self,args):
        if not 'path' in args:
            return {"code":0,"msg":"参数错误"}
        result = self.baiduNetdisk.delete_file(args.path,1,False)
        if result:
            return {"code":1,"msg":"操作成功"}
        else:
            return {"code":0,"msg":"操作失败"}

    # 获取后台任务记录
    def get_tasks(self,args):

        tasks_list = self.__table('tasks').field('id,name,type,shell,other,add_time,status').select()
        return {
            "code":1,
            "msg":"操作完成",
            "data":{
                "list":tasks_list
            }
        }

    # 清除后台任务记录
    def clear_tasks(self,args):

        tasks_list = self.__table('tasks').field('id,name,type,shell,other,add_time,status').select()

        for task in tasks_list:
            log_file = '%s/%s.log' % (self.__logs_path,task['id'])
            self.utils.remove(log_file)
        self.__table('tasks').delete()

        # 删除task锁定文件
        self.utils.remove(self.__start_task_lock)

        return {
            "code":1,
            "msg":"操作完成",
        }

    # 获取后台任务列表
    def get_tasks_list(self,status):
        tasks_list = self.__table('tasks').where('status=?',(status,)).field('id,name,type,shell,other,add_time,status').select()
        return tasks_list

    # 获取一个后台任务
    def get_task_find(self,status):
        task = self.__table('tasks').where('status=?',(status,)).order('id asc').field('id,name,type,shell,other,add_time,status').find()
        return task

    # 获取后台任务数量
    def get_tasks_count(self,status):
        tasks_count = self.__table('tasks').where('status=?',(status,)).count()
        return tasks_count

    # 删除后台任务
    def delete_task(self,args):
        if not 'id' in args:
            return {"code":0,"msg":"参数错误"}

        self.__table('tasks').where('id=?',(args.id,)).delete()

        log_file = '%s/%s.log' % (self.__logs_path,args.id)
        self.utils.remove(log_file)

        return {"code":1,"msg":"操作成功"}

    # 获取后台任务日志
    def get_task_logs(self,args):
        if not 'id' in args:
            return {"code":0,"msg":"参数错误"}
        log_file = '%s/%s.log' % (self.__logs_path,args.id)
        temp_log_file = '%s/%s_temp.log' % (self.__logs_path,args.id)
        if not os.path.exists(log_file):
            logs = ''
        else:
            if self.utils.is_win():
                line_number_limit = '-1000'
                if os.path.exists(temp_log_file):
                    log_file = temp_log_file
            else:
                line_number_limit = '-n1000'

            logs = self.utils.run_shell('%s %s %s' % (self.__tail_path,line_number_limit,log_file))
            # result = public.ExecShell('%s %s %s' % (self.__tail_path,line_number_limit,log_file))
            # logs = result[0]

        return {
            "code":1,
            "msg":"操作成功",
            "data":{
                "logs":logs
            }
        }

    # 清楚后台任务日志
    def clear_task_logs(self,args):
        if not 'id' in args:
            return {"code":0,"msg":"参数错误"}

        try:
            log_file = '%s/%s.log' % (self.__logs_path,args.id)
            self.utils.remove(log_file)
        except Exception as e:
            return {
                "code":0,
                "msg":"操作失败："+str(e),
            }

        return {
            "code":1,
            "msg":"操作成功",
        }

    # 获取后台进程
    def get_process(self,args):

        # 判断是否使用管道刷新组件
        if self.utils.is_win():
            python_path = 'python'
        else:
            python_path = '/usr/bin/unbuffer python'
        # return 'ps -auxf|grep -v grep|grep /baidu_netdisk/baidu_netdisk_main.py|grep "%s"|grep -v " &> "' % (python_path)

        # 获取后台进程
        # return self.utils.get_proc_by_cmd('baidu_netdisk/baidu_netdisk_main.py upload')

        process_list = []

        if self.utils.is_win():
            tasks_list_upload = self.utils.get_proc_by_cmd('script/wget.exe --header=User-Agent: pan.baidu.com ')
            tasks_list_down = self.utils.get_proc_by_cmd('baidu_netdisk/baidu_netdisk_main.py upload ')
            tasks_list = tasks_list_upload + tasks_list_down
            if len(tasks_list) != 0:
                for task in tasks_list:
                    pid = task[0]
                    info = task[1].replace("宝塔面板网?助手", "宝塔面板网盘助手")
                    if 'cmd.exe /c' in info:
                        continue
                    process_list.append({
                        'type':1,
                        'pid':pid,
                        'info':info,
                        })

            backups_list_site = self.utils.get_proc_by_cmd('baidu_netdisk/baidu_netdisk_main.py site')
            backups_list_database = self.utils.get_proc_by_cmd('baidu_netdisk/baidu_netdisk_main.py database ')
            backups_list_path = self.utils.get_proc_by_cmd('baidu_netdisk/baidu_netdisk_main.py path ')
            backups_list = backups_list_site + backups_list_database + backups_list_path
            if len(backups_list) != 0:
                for backup in backups_list:
                    pid = backup[0]
                    info = backup[1].replace("宝塔面板网?助手", "宝塔面板网盘助手")
                    if 'cmd.exe /c' in info:
                        continue
                    process_list.append({
                        'type':0,
                        'pid':pid,
                        'info':info,
                        })

        else:
            # 获取插件任务
            tasks_list = public.ExecShell('ps -auxf|grep -v grep|grep /baidu_netdisk/baidu_netdisk_main.py|grep "%s"|grep -v " &> "' % (python_path))
            tasks_list = tasks_list[0].split("\n")
            tasks_list = filter(None, tasks_list)
            tasks_list = list(tasks_list)

            if len(tasks_list) != 0:
                for task in tasks_list:
                    pid = list(filter(None, task.split(' ')))[1:2][0]
                    info = task.split('python %s/' % (plugin_path))[-1].replace("宝塔面板网?助手", "宝塔面板网盘助手")
                    process_list.append({
                        'type':1,
                        'pid':pid,
                        'info':info,
                        })
            # return process_list

            # 获取计划任务
            backups_list = public.ExecShell('ps -auxf|grep -v grep|grep -E "/baidu_netdisk/baidu_netdisk_main.py site|/baidu_netdisk/baidu_netdisk_main.py database|/baidu_netdisk/baidu_netdisk_main.py path"')
            backups_list = backups_list[0].split("\n")
            backups_list = filter(None, backups_list)
            backups_list = list(backups_list)
            # return backups_list

            if len(backups_list) != 0:
                for backup in backups_list:
                    pid = list(filter(None, backup.split(' ')))[1:2][0]
                    info = backup.split('python %s/' % (plugin_path))[-1]
                    process_list.append({
                        'type':0,
                        'pid':pid,
                        'info':info,
                        })
            # return process_list

        return {
            "code":1,
            "msg":"操作成功",
            "data":{
                "process_list":process_list
            }
        }

    # 杀死后台进程
    def kill_task(self,args):
        if not 'pid' in args : args.pid = ''

        if args.pid != '':
            if self.utils.is_win():
                public.ExecShell('taskkill /pid %s /f' % (args.pid))
            else:
                public.ExecShell('kill %s' % (args.pid))

        return {
            "code":1,
            "msg":"操作完成",
        }

    # 获取高级配置
    def get_system(self,args):

        if self.utils.is_win():
            is_win = 1
        else:
            is_win = 0

        # sql = db.Sql()
        # backup_path = sql.table('config').where("id=?",(1,)).getField('backup_path') + '/baidu_netdisk'

        return {
            "code":1,
            "msg":"操作成功",
            "data":{
                "file_size":self.utils.get_config('file_size'),
                "block_size":self.utils.get_config('block_size'),
                "base_path":self.__get_base_path(),
                "retry_times":self.utils.get_config('retry_times'),
                "standalone_directory":self.utils.get_config('standalone_directory'),
                "download_concurrent":self.utils.get_config('download_concurrent'),
                "bandwidth_optimization":self.utils.get_config('bandwidth_optimization'),
                "is_win":is_win,
                "backup_path":self.__backup_path,
                "tmp_path":self.__tmp_path
            }
        }

    # 更新高级配置
    def get_system_act(self,args):
        if not 'file_size' in args : args.file_size = 0
        if not 'block_size' in args : args.block_size = 4
        if not 'base_path' in args : args.base_path = ""
        if not 'retry_times' in args : args.retry_times = 3
        if not 'standalone_directory' in args : args.standalone_directory = 0
        if not 'download_concurrent' in args : args.download_concurrent = 5
        if not 'bandwidth_optimization' in args : args.bandwidth_optimization = 0
        args.file_size = args.file_size.upper()

        if args.base_path[-1] != "/" :
            args.base_path += "/"

        type = args.file_size[-1]
        if type == 'M':
            args.file_size = args.file_size[:-1]
        elif type == 'G':
            args.file_size = int(args.file_size[:-1])*1024
        else:
            args.file_size = 0

        bandwidth_optimization = self.utils.get_config('bandwidth_optimization')
        if bandwidth_optimization == None :
            bandwidth_optimization = 0

        if int(bandwidth_optimization) != int(args.bandwidth_optimization):
            if int(args.bandwidth_optimization) == 1:
                public.ExecShell('/bin/bash %sbandwidth_optimization.sh disable' % (plugin_libs_path))
            else:
                public.ExecShell('/bin/bash %sbandwidth_optimization.sh enable' % (plugin_libs_path))

        self.utils.set_config('file_size',args.file_size)
        self.utils.set_config('block_size',args.block_size)
        self.utils.set_config('base_path',args.base_path)
        self.utils.set_config('retry_times',args.retry_times)
        self.utils.set_config('standalone_directory',args.standalone_directory)
        self.utils.set_config('download_concurrent',args.download_concurrent)
        self.utils.set_config('bandwidth_optimization',args.bandwidth_optimization)

        return {
            "code":1,
            "msg":"操作成功",
        }

    # 【命令行】 - 启动任务执行
    def startTask(self):
        if os.path.exists(self.__start_task_lock): return False
        public.writeFile(self.__start_task_lock,'')
        while self.get_tasks_count(0):
            task = self.get_task_find(0)
            self.__table('tasks').where('id=?',(task['id'],)).setField('status',1)
            # self.utils.logs(task)
            if self.utils.is_win():
                pipeline = '>'
            else:
                pipeline = '&>'
            log_file = '%s/%s.log' % (self.__logs_path,task['id'])
            if task['type'] == '1':
                public.ExecShell('%s %s %s %s' % (task['shell'],task['id'],pipeline,log_file))
            elif task['type'] == '2':
                public.ExecShell('%s %s %s %s' % (task['shell'],task['id'],pipeline,log_file))

            self.__table('tasks').where('id=?',(task['id'],)).setField('status',2)
        self.utils.remove(self.__start_task_lock)
        self.utils.logs('任务执行完成')

    # 【命令行】 - 上传文件
    def uploadFile(self,path,remote_path):
        source_path = path
        # 如果是文件夹就先压缩
        if os.path.isdir(path):
            if self.utils.is_win():
                tmp_file = '%s/%s.zip' % (self.__tmp_path,os.path.basename(path))
                self.utils.zip(path,tmp_file)
                path = tmp_file
            else:
                tmp_file = '%s/%s.tar.gz' % (self.__tmp_path,os.path.basename(path))
                public.ExecShell('cd %s && tar -czf "%s" "%s"' % (os.path.dirname(path),tmp_file,os.path.basename(path)))
            path = tmp_file

        max_file_size = self.utils.get_config('file_size')
        if max_file_size != 0:
            local_file_size = os.path.getsize(path)
            if local_file_size > int(max_file_size)*1024*1024:
                self.utils.logs("进行分包上传")
                packs_count = (local_file_size + int(max_file_size)*1024*1024 - 1)/(int(max_file_size)*1024*1024)
                if self.utils.get_config('file_size') == 0:
                    packs_size = 0
                else:
                    packs_size = '%sM' % (self.utils.get_config('file_size'))
                import math
                self.utils.logs("预计分包数量：%s 分包大小：%s" % (math.ceil(packs_count),packs_size))


                # 开始分包上传
                tmp_path = '%s/%s.tmp' % (self.__tmp_path,os.path.basename(path))
                if self.utils.is_win():
                    tmp_file = '%s/%s.zip' % (self.__tmp_path,os.path.basename(path))
                    tmp_path = self.utils.zip_by_volume(path,tmp_file,int(max_file_size)*1024*1024)
                else:
                    if path[-7:0].lower() == '.tar.gz':
                        public.ExecShell('mkdir -p %s && cd %s && split -b %sm -d %s %s/%s.' % (
                            tmp_path,
                            self.__tmp_path,
                            self.utils.get_config('file_size'),
                            path,
                            tmp_path,
                            os.path.basename(path)
                            ))
                    else:
                        # 进行文件分包
                        public.ExecShell('mkdir -p %s && cd %s && tar -czp %s | split -b %sm -d - %s/%s.tar.gz.' % (
                            tmp_path,
                            self.__tmp_path,
                            path,
                            self.utils.get_config('file_size'),
                            tmp_path,
                            os.path.basename(path)
                            ))

                if os.path.isdir(tmp_path):
                    file_list = os.listdir(tmp_path)
                    for file in file_list:
                        self.utils.logs("----------------------------------------------------------------------------")
                        self.baiduNetdisk.upload_file(tmp_path+'/'+file,remote_path)
                    if source_path != tmp_path:
                        self.utils.rmtree(tmp_path)
                elif os.path.isfile(tmp_path):
                    self.baiduNetdisk.upload_file(tmp_path,remote_path)
                    if source_path != tmp_path:
                        self.utils.remove(tmp_path)

            else:
                self.baiduNetdisk.upload_file(path,remote_path)
        else:
            self.baiduNetdisk.upload_file(path,remote_path)
        
        self.utils.logs("完成上传文件")
        self.utils.logs("----------------------------------------------------------------------------")

    # 【命令行】 - 下载文件
    def downloadFile(self,path,fs_id,task_id):
        self.baiduNetdisk.download_file_server(path,fs_id,task_id)
        self.utils.logs("完成下载文件")
        self.utils.logs("----------------------------------------------------------------------------")

    # 【命令行】 - 备份全部网站
    def backupSiteAll(self,save):
        sites = public.M('sites').field('name').select()
        for site in sites:
            self.backupSite(site['name'],save)

    # 【命令行】 - 备份网站
    def backupSite(self,name,count):
        self.echo_start()
        startTime = time.time()
        self.echo_info('备份网站：{}'.format(name))

        sql = db.Sql()
        path = sql.table('sites').where('name=?',(name,)).getField('path')
        startTime = time.time()
        if not path:
            endDate = time.strftime('%Y/%m/%d %X',time.localtime())
            log = "网站["+name+"]不存在!"
            self.utils.logs("★["+endDate+"] "+log)
            self.utils.logs("----------------------------------------------------------------------------")
            self.echo_end()
            return
        
        # 生成本地备份文件
        if self.utils.is_win():
            filename = self._backupObj.backupSite(name)
        else:
            backup_path = self.__backup_path + '/site'
            if not os.path.exists(backup_path): public.ExecShell("mkdir -p " + backup_path)
            filename= backup_path + "/web_" + name + "_" + time.strftime('%Y%m%d_%H%M%S',time.localtime()) + '.tar.gz'
            public.ExecShell("cd " + os.path.dirname(path) + " && tar zcvf '" + filename + "' '" + os.path.basename(path) + "'" + self.__exclude + " > /dev/null")
        
        if not os.path.exists(filename):
            endDate = time.strftime('%Y/%m/%d %X',time.localtime())
            log = "网站["+name+"]备份失败!"
            self.utils.logs("★["+endDate+"] "+log)
            self.utils.logs("----------------------------------------------------------------------------")
            self.echo_end()
            return
        
        if int(self.utils.get_config('standalone_directory')):
            remote_path = "%s%s/" % (self.__get_base_path(),name)
        else:
            remote_path = self.__get_base_path()

        #上传到百度网盘
        upload_status = self.baiduNetdisk.upload_file(filename,remote_path,False)
        if upload_status == False:
            self.utils.logs("网站["+name+"]备份失败,请重新备份")
            #清理本地文件
            self.utils.remove(filename)
            self.echo_end()
            return None

        endDate = time.strftime('%Y/%m/%d %X',time.localtime())
        outTime = time.time() - startTime
        pid = sql.table('sites').where('name=?',(name,)).getField('id')
        sql.table('backup').add('type,name,pid,filename,addtime,size',('0',os.path.basename(filename),pid,'baidu_netdisk',endDate,os.path.getsize(filename)))
        log = "网站["+name+"]已成功备份到百度网盘,用时["+str(round(outTime,2))+"]秒"
        public.WriteLog('计划任务',log)
        self.utils.logs("★["+endDate+"] " + log)
        self.utils.logs("|---保留最新的["+count+"]份备份")
        self.utils.logs("|---文件名:"+os.path.basename(filename))
        self.utils.logs(u"|---文件大小:"+public.to_size(os.path.getsize(filename)))
        if self.__exclude: self.utils.logs(u"|---排除规则: " + self.__exclude)
        
        #清理本地文件
        self.utils.remove(filename)
        
        #清理多余备份     
        backups = sql.table('backup').where('type=? and pid=? and filename=?',('0',pid,'baidu_netdisk')).field('id,name,filename').select()
        
        num = len(backups) - int(count)
        if  num > 0:
            for backup in backups:
                delete_file_status = self.baiduNetdisk.delete_file(remote_path + backup['name'],1,False)
                if delete_file_status:
                    sql.table('backup').where('id=?',(backup['id'],)).delete()
                    self.utils.logs(u"|---已清理过期备份文件：" + backup['name'])
                else:
                    self.utils.logs(u"|---清理过期备份文件：" + backup['name'] + "失败")
                num -= 1
                if num < 1: break
        self.echo_end()
        return None

    # 【命令行】 - 备份全部数据库
    def backupDatabaseAll(self,save):
        databases = public.M('databases').field('name').select()
        for database in databases:
            self.backupDatabase(database['name'],save)

    # 【命令行】 - 备份数据库
    def backupDatabase(self,name,count):
        self.echo_start()
        startTime = time.time()
        self.echo_info('备份数据库：{}'.format(name))

        sql = db.Sql()
        path = sql.table('databases').where('name=?',(name,)).getField('id')
        startTime = time.time()
        if not path:
            endDate = time.strftime('%Y/%m/%d %X',time.localtime())
            log = "数据库["+name+"]不存在!"
            self.utils.logs("★["+endDate+"] "+log)
            self.utils.logs("----------------------------------------------------------------------------")
            self.echo_end()
            return
        
        # 生成本地备份文件
        if self.utils.is_win():
            filename = self._backupObj.backupDatabase(name)
        else:
            backup_path = self.__backup_path + '/database'
            if not os.path.exists(backup_path): public.ExecShell("mkdir -p " + backup_path)
            filename = backup_path + "/db_" + name + "_" + time.strftime('%Y%m%d_%H%M%S',time.localtime())+".sql.gz"
            import re
            mysql_root = sql.table('config').where("id=?",(1,)).getField('mysql_root')
            mycnf = public.readFile('/etc/my.cnf')
            rep = "\[mysqldump\]\nuser=root"
            sea = "[mysqldump]\n"
            subStr = sea + "user=root\npassword=" + mysql_root+"\n"
            mycnf = mycnf.replace(sea,subStr)
            if len(mycnf) > 100:
                public.writeFile('/etc/my.cnf',mycnf)
            public.ExecShell(os.path.dirname(panel_path)+"/mysql/bin/mysqldump --default-character-set="+ self.__get_database_character(name) +" --force --opt -R " + name + " | gzip > " + filename)

            mycnf = public.readFile('/etc/my.cnf')
            mycnf = mycnf.replace(subStr,sea)
            if len(mycnf) > 100:
                public.writeFile('/etc/my.cnf',mycnf)

        if not os.path.exists(filename):
            endDate = time.strftime('%Y/%m/%d %X',time.localtime())
            log = "数据库["+name+"]备份失败!"
            self.utils.logs("★["+endDate+"] "+log)
            self.utils.logs("----------------------------------------------------------------------------")
            self.echo_end()
            return

        if int(self.utils.get_config('standalone_directory')):
            remote_path = "%s%s/" % (self.__get_base_path(),name)
        else:
            remote_path = self.__get_base_path()

        #上传到百度网盘
        upload_status = self.baiduNetdisk.upload_file(filename,remote_path,False)
        if upload_status == False:
            self.utils.logs("数据库["+name+"]备份失败,请重新备份")
            #清理本地文件
            self.utils.remove(filename)
            self.echo_end()
            return None
        
        endDate = time.strftime('%Y/%m/%d %X',time.localtime())
        outTime = time.time() - startTime
        pid = sql.table('databases').where('name=?',(name,)).getField('id')
        
        sql.table('backup').add('type,name,pid,filename,addtime,size',(1,os.path.basename(filename),pid,'baidu_netdisk',endDate,os.path.getsize(filename)))
        log = "数据库["+name+"]已成功备份到百度网盘,用时["+str(round(outTime,2))+"]秒"
        public.WriteLog('计划任务',log)
        self.utils.logs("★["+endDate+"] " + log)
        self.utils.logs("|---保留最新的["+count+"]份备份")
        self.utils.logs("|---文件名:"+os.path.basename(filename))
        self.utils.logs(u"|---文件大小:"+public.to_size(os.path.getsize(filename)))
        
        #清理本地文件
        self.utils.remove(filename)
        
        #清理多余备份     
        backups = sql.table('backup').where('type=? and pid=? and filename=?',('1',pid,'baidu_netdisk')).field('id,name,filename').select()
        
        num = len(backups) - int(count)
        if  num > 0:
            for backup in backups:
                delete_file_status = self.baiduNetdisk.delete_file(remote_path + backup['name'],1,False)
                if delete_file_status:
                    sql.table('backup').where('id=?',(backup['id'],)).delete()
                    self.utils.logs(u"|---已清理过期备份文件：" + backup['name'])
                else:
                    self.utils.logs(u"|---清理过期备份文件：" + backup['name'] + "失败")
                num -= 1
                if num < 1: break
        self.echo_end()
        return None

    # 【命令行】 - 取数据库字符集
    def __get_database_character(self,db_name):
        try:
            import panelMysql
            tmp = panelMysql.panelMysql().query("show create database `%s`" % db_name.strip())
            c_type = str(re.findall("SET\s+([\w\d-]+)\s",tmp[0][1])[0])
            c_types = ['utf8','utf-8','gbk','big5','utf8mb4']
            if not c_type.lower() in c_types: return 'utf8'
            return c_type
        except:
            return 'utf8'

    # 【命令行】 - 备份指定目录
    def backupPath(self,path,count):
        sql = db.Sql()
        startTime = time.time()
        if path[-1:] == '/': path = path[:-1]

        # 生成本地备份文件
        if self.utils.is_win():
            filename = self._backupObj.backupPath(path)
        else:
            name = os.path.basename(path)
            backup_path = self.__backup_path + '/path'
            if not os.path.exists(backup_path): os.makedirs(backup_path)
            filename= backup_path + "/path_" + name + "_" + time.strftime('%Y%m%d_%H%M%S',time.localtime()) + '.tar.gz'
            os.system("cd " + os.path.dirname(path) + " && tar zcvf '" + filename + "' '" + os.path.basename(path) + "'" + self.__exclude + " > /dev/null")
        
        if not os.path.exists(filename):
            endDate = time.strftime('%Y/%m/%d %X',time.localtime())
            log = u"目录["+path+"]备份失败"
            self.utils.logs(u"★["+endDate+"] "+log)
            self.utils.logs(u"----------------------------------------------------------------------------")
            return
        
        #上传到百度网盘
        upload_status = self.baiduNetdisk.upload_file(filename,"",False)
        if upload_status == False:
            self.utils.logs("目录["+path+"]备份失败,请重新备份")
            #清理本地文件
            self.utils.remove(filename)
            return None

        endDate = time.strftime('%Y/%m/%d %X',time.localtime())

        # self.utils.logs(os.path.basename(filename))
        outTime = time.time() - startTime
        sql.table('backup').add('type,name,pid,filename,addtime,size',('2',os.path.basename(filename),'0','baidu_netdisk',endDate,os.path.getsize(filename)))
        log = u"目录["+path+"]已成功备份到百度网盘,用时["+str(round(outTime,2))+"]秒"
        public.WriteLog(u'计划任务',log)
        self.utils.logs(u"★["+endDate+"] " + log)
        self.utils.logs(u"|---保留最新的["+count+u"]份备份")
        self.utils.logs(u"|---文件名:"+os.path.basename(filename))
        self.utils.logs(u"|---文件大小:"+public.to_size(os.path.getsize(filename)))
        if self.__exclude: self.utils.logs(u"|---排除规则: " + self.__exclude)
        
        #清理多余备份     
        backups = sql.table('backup').where('type=? and pid=? and filename=?',('2',0,'baidu_netdisk')).field('id,name,filename').select()
        
        #清理本地文件
        self.utils.remove(filename)

        num = len(backups) - int(count)
        if  num > 0:
            for backup in backups:
                delete_file_status = self.baiduNetdisk.delete_file(self.__get_base_path() + backup['name'],1,False)
                if delete_file_status:
                    sql.table('backup').where('id=?',(backup['id'],)).delete()
                    self.utils.logs(u"|---已清理过期备份文件：" + backup['name'])
                else:
                    self.utils.logs(u"|---清理过期备份文件：" + backup['name'] + "失败")
                num -= 1
                if num < 1: break

    def echo_start(self):
        print("=" * 90)
        print("★开始备份[{}]".format(self.format_date()))
        print("=" * 90)

    def echo_end(self):
        print("=" * 90)
        print("☆备份完成[{}]".format(self.format_date()))
        print("=" * 90)
        print("\n")

    def echo_info(self, msg):
        print("|-{}".format(msg))

    def echo_error(self, msg):
        print("=" * 90)
        print("|-错误：{}".format(msg))

    # 格式化指定时间戳
    def format_date(self, format="%Y-%m-%d %H:%M:%S", times=None):
        if not times: times = int(time.time())
        time_local = time.localtime(times)
        return time.strftime(format, time_local)

    # 【命令行】 - 安装插件
    def install(self):
        filename = '%s/data/libList.conf' % (panel_path)
        tmp = public.ReadFile(filename)
        libs = json.loads(tmp)
        
        install = False
        for lib in libs:
            if lib['opt'] == 'baidu_netdisk':
                install = True

        if install != True:
            baidu_netdisk = {
                "name":"百度网盘",
                "type":"计划任务",
                "ps":"备份你的数据到百度网盘",
                "status":False,
                "opt":"baidu_netdisk",
                "module":"os",
                "script":"baidu_netdisk",
                "help":"http://www.bt.cn/bbs/thread-839-1-1.html",
                "key":"access_key|请输入AccessKey|百度网盘秘钥中的AK",
                "secret":"secret_key|请输入SecretKey|百度网盘秘钥中的SK",
                "bucket":"存储空间|请输入对象存储空间名称|百度网盘中您创建的空间名称",
                "domain":"外链域名|请输入绑定域名或测试域名|绑定的百度网盘域名，若没有则填测试域名",
                "check":["%s/baidu_netdisk_main.py" % (plugin_path)]
            }

            libs.append(baidu_netdisk)

        # 安装试试管道刷新组件
        platform = self.utils.get_platform()
        # self.utils.logs(platform)
        if platform == 'CentOS':
            public.ExecShell('yum install expect-devel -y')
            public.ExecShell('yum install expect -y')
            public.ExecShell('yum install aria2 -y')
        elif platform == 'Windows':
            pass
        else:
            public.ExecShell('apt install expect -y')
            public.ExecShell('apt install aria2 -y')

        return public.WriteFile(filename,json.dumps(libs,indent=4,ensure_ascii=False))

    # 【命令行】 - 卸载插件
    def uninstall(self):
        filename = '%s/data/libList.conf' % (panel_path)
        tmp = public.ReadFile(filename)
        libs = json.loads(tmp)
        for lib in libs:
            if lib['opt'] == 'baidu_netdisk':
                libs.remove(lib)

        self.utils.remove(self.__db_path)
        self.utils.rmtree(self.__logs_path)

        return public.WriteFile(filename,json.dumps(libs,indent=4,ensure_ascii=False))



#在命令行模式下执行
if __name__ == "__main__":
    # import json
    # data = None
    b = baidu_netdisk_main()
    type = sys.argv[1]

    if type == 'site': # 备份网站
        if sys.argv[2] == 'ALL' or sys.argv[2] == 'all':
            b.backupSiteAll( sys.argv[3])
        else:
            b.backupSite(sys.argv[2], sys.argv[3])
        exit()
    elif type == 'database': # 备份数据库
        if sys.argv[2] == 'ALL' or sys.argv[2] == 'all':
            b.backupDatabaseAll(sys.argv[3])
        else:
            b.backupDatabase(sys.argv[2], sys.argv[3])
        exit()
    elif type == 'path': # 备份目录
        b.backupPath(sys.argv[2],sys.argv[3])
        exit()
    elif type == 'upload': # 上传文件
        b.uploadFile(sys.argv[2],sys.argv[3])
        exit()
    elif type == 'download': # 下载文件
        b.downloadFile(sys.argv[2],sys.argv[3],sys.argv[4])
        exit()
    elif type == 'startTask': # 启动任务执行
        b.startTask()
        exit()
    elif type == 'install': # 安装插件
        b.install()
        exit()
    elif type == 'uninstall': # 卸载插件
        b.uninstall()
        exit()
