CREATE TABLE "tasks" (
	"id" INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
	"name" TEXT,
	"type" TEXT,
	"status" INTEGER DEFAULT 0,
	"shell" TEXT,
	"other" TEXT,
	"exectime" INTEGER DEFAULT 0,
	"add_time" INTEGER DEFAULT 0,
	"update_time" INTEGER DEFAULT 0
);