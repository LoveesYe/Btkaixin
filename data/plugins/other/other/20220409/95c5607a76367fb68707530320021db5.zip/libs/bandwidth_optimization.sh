#!/bin/bash

function Enable(){
    tcp_window_scaling=$(sysctl -p|grep '^net.ipv4.tcp_window_scaling = 0')
    if [[ $tcp_window_scaling != *'tcp_window_scaling'* ]]; then
        tcp_window_scaling=$(cat /etc/sysctl.conf|grep '^#net.ipv4.tcp_window_scaling = 0')
        if [[ $tcp_window_scaling == *'tcp_window_scaling'* ]]; then
            sed -i "s/#net.ipv4.tcp_window_scaling = 0/net.ipv4.tcp_window_scaling = 0/g" /etc/sysctl.conf
        else
            echo >> /etc/sysctl.conf
            echo 'net.ipv4.tcp_window_scaling = 0' >> /etc/sysctl.conf
        fi
        sysctl -p
    fi
}

function Disable()
{
    tcp_window_scaling=$(sysctl -p|grep '^net.ipv4.tcp_window_scaling = 0')
    if [[ $tcp_window_scaling == *'tcp_window_scaling'* ]]; then
        sed -i "s/net.ipv4.tcp_window_scaling = 0/#net.ipv4.tcp_window_scaling = 0/g" /etc/sysctl.conf
        sysctl -p
    fi
}

function Status()
{
    tcp_window_scaling=$(sysctl -p|grep '^net.ipv4.tcp_window_scaling = 0')
    if [[ $tcp_window_scaling == *'tcp_window_scaling'* ]]; then
        echo '=== Is Enable ==='
    else
        echo '=== Is Disable ==='
    fi
}

case "$1" in
    "enable")
        echo '=== Enable ==='
        Enable
        ;;
    "disable")
        echo '=== Disable ==='
        Disable
        ;;
    *)
        echo '=== Status ==='
        Status
        ;;
esac