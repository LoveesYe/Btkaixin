#!/bin/bash
PATH=/www/server/panel/pyenv/bin:/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH

#配置插件安装目录
install_path=/www/server/panel/plugin/baidu_netdisk

#安装
Install()
{
	
	echo '正在安装...'
	#==================================================================
	#依赖安装开始

	pip install cryptography==3.2
	pip install pyOpenSSL

	python ${install_path}'/baidu_netdisk_main.py' install

	# tcp_window_scaling = $(sysctl -a|grep '^net.ipv4.tcp_window_scaling = 0')

	tcp_window_scaling=$(sysctl -p|grep '^net.ipv4.tcp_window_scaling = 0')
	if [[ $tcp_window_scaling != *'tcp_window_scaling'* ]]
	then
		echo >> /etc/sysctl.conf
		echo 'net.ipv4.tcp_window_scaling = 0' >> /etc/sysctl.conf
		sysctl -p
	fi

	#依赖安装结束
	#==================================================================

	echo '================================================'
	echo '安装完成'
}

#卸载
Uninstall()
{
	python ${install_path}'/baidu_netdisk_main.py' uninstall
	rm -rf $install_path
}

#操作判断
if [ "${1}" == 'install' ];then
	Install
elif [ "${1}" == 'uninstall' ];then
	Uninstall
else
	echo 'Error!';
fi
