#!/usr/bin/python
# coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# editor: mufei(ypdh@qq.com tel:15712150708)
'''
牧飞 _ __ ___   ___   ___  / _| ___(_)
| '_ ` _ \ / _ \ / _ \| |_ / _ \ |
| | | | | | (_) | (_) |  _|  __/ |
|_| |_| |_|\___/ \___/|_|  \___|_|
'''
#+--------------------------------------------------------------------
#|   宝塔第三方应用开发 mflogview
#+--------------------------------------------------------------------

__all__ = ['mflogview_main']

import sys,os,json,re,time,math

try:
    from urllib.parse import unquote
except:
    from urllib import unquote

#设置运行目录
basedir = os.path.abspath(os.path.dirname(__file__))
plugin_path = basedir

try:
    from accesslog import AccessLog as NgxLog
except ImportError:
    pass
    

if __name__ != '__main__':
    #添加包引用位置并引用公共包
    sys.path.append("class/")
    import public
    from BTPanel import cache,session

    #设置缓存(超时10秒) cache.set('key',value,10)
    #获取缓存 cache.get('key')
    #删除缓存 cache.delete('key')

    #设置session:  session['key'] = value
    #获取session:  value = session['key']
    #删除session:  del(session['key'])
    


import codecs
 
def is_binary_file(ff):
    
    if ff.endswith(('.log','.html','.php','.js','.css','.html','.txt','.sh')):
        return 
    TEXT_BOMS = (
        codecs.BOM_UTF16_BE,
        codecs.BOM_UTF16_LE,
        codecs.BOM_UTF32_BE,
        codecs.BOM_UTF32_LE,
        codecs.BOM_UTF8,
    )
    with open(ff, 'rb') as file:
        CHUNKSIZE = 8192
        initial_bytes = file.read(CHUNKSIZE)
        file.close()
    return not any(initial_bytes.startswith(bom) for bom in TEXT_BOMS) and b'\0' in initial_bytes


rules = {
    'SQLinject': {
        'UNION注入': r'union.*select.*from',
        'MSSQL报错注入': r'(and|or).*(in.*select|=convert|=concat)',
        'MySQL报错注入': r'(and|or).*(extractvalue|updatexml|floor)',
        'Oracle报错注入': r'(and|or).*(UPPER.*XMLType|utl_inaddr|CTXSYS.DRITHSX.SN|dbms_utility)',
        'MySQL盲注': r'(and|or).*(rlike|make_set|elt|sleep)',
        'Oracle盲注': r'select.*case[\s\S]when.*=.*then.*dual',
        'Oracle时间盲注': r'(and|or|begin|select).*(dbms_pipe|select.*from.*all_users|dbms_lock)',
        'MSSQL盲注': r'select.*case[\s\S]when.*=.*then',
        'MSSQL时间盲注': r'(and|or|select).*(from.*sysusers|waitfor[\s\S]delay)',
        },
    'ArbitraryFileOperation':{
        '任意文件读取/包含(linux)': r'[.]+/',
        '任意文件读取/包含(windows)': r'[.]+\\',
    },
    'dirtraversal':{
        'windows路径穿越': r'(win.ini|system.ini|boot.ini|cmd.exe|global.asa)',
        'linux路径穿越': r'(etc.*passwd|etc.*shadow|etc.*hosts|.htaccess|.bash_history)',
    },
    'ArbitraryCodeExcute':{
        '任意代码执行': r'(=.*phpinfo|=.*php://|=.*\$_post\[|=.*\$_get\[|=.*\$_server\[|=.*exec\(|=.*system\(|=.*call_user_func|=.*passthru\(|=.*eval\(|=.*execute\(|=.*shell_exec\(|=.*file_get_contents\(|=.*xp_cmdshell|=.*array_map\(|=.*create_function\|=.*unserialize\(|=.*echo\()',
    },
    'struts2vuln':{
        'struts005~009': r'xwork.MethodAccessor.denyMethodExecution',
        'struts013': r'_memberAccess.*ServletActionContext',
        'struts016': r'redirect:.*context.get',
        'struts019': r'xwork2.dispatcher.HttpServletRequest',
        'struts032~057': r'@ognl.OgnlContext@DEFAULT_MEMBER_ACCESS',
    },
    'XSS':{
        '一般型': r'(<script|<img|<object|<style|<div|<table|<iframe|<meta|<body|<svg|<embed|<a|<input|<marquee|<link|<xml|<image|<html).*(alert|prompt|confirm)',
        'flashxss': r'javascript:alert',
    },
    'SSTI':{
        '一般型': r'{{.*}}',
        'Ruby模板注入': r'<%.*%>',
        'Java模板注入': r'\${.*}',
    },
    'LDAP':{
        '一般型': r'\*[\(\)|]+',
    },
    'XXE':{
        '外部实体注入': r'(<\?xml.*\?>|<!.*>|<xsl.*>)',
    },
    'DangerRequests':{
        '不安全http方法': r'("put.*http/1.|"options.*http/1.|"delete.*http/1.|"move.*http/1.|"trace.*http/1.|"copy.*http/1.|"connect.*http/1.|"propfind.*http/1.)',
        '爬虫UA': r'(python-requests|python-urllib|"curl/)',
    }
}



    



class mflogview_main:
    __plugin_path = plugin_path
    __config = None

    #构造方法
    def  __init__(self):
        ""
        self.__config = self.__get_config()
        


    #def _check(self,args):
    #    return True
    
    def check(self, args):
        logpath = args.logpath.strip() if "logpath" in args else ""
        try:
            logpath = logpath.decode('utf-8')
        except:
            pass
        if not logpath or not os.path.isfile(logpath):
            return {"error":"文件路径有误"}
        return {}
        
    def view(self, args):
        logpath = args.logpath.strip() if "logpath" in args else ""
        
        try:
            logpath = logpath.decode('utf-8')
        except:
            pass
        if not logpath or not os.path.isfile(logpath):
            #return {"error":"文件路径有误", 'logpath':logpath, 'data':{}}
            error = 1
            txt = "文件路径有误"
            mtype = ''
        else:
            error = 0
            

        curpage = int(args.curpage.strip()) if "curpage" in args else 1
        if curpage<1: curpage=1

        dpagesize = 100
        pagesize = int(args.pagesize.strip()) if "pagesize" in args else dpagesize
        
        if pagesize<1: pagesize=dpagesize
        _pagesize = pagesize*1024
        
        if error:
            totalsize = 1
        else:
            totalsize = os.path.getsize(logpath)
        cursize = (curpage-1)*_pagesize
        totalpage =  int(totalsize/_pagesize)
        tmp = totalsize%_pagesize
        if tmp: totalpage+=1

        if cursize>=totalsize: 
            curpage = totalpage
            cursize = totalsize - _pagesize
            
        if cursize<0:
            cursize=0
            curpage = 1
        
        
        sort = args.sort.strip() if "sort" in args else ""
        
        aparse = "aparse" in args
        ngxlog = "ngxlog" in args
        if error:
            if ngxlog: txt = []
            pass
        elif ngxlog:
            mtype = 'r'
            txts = []
            n = 0
            with open(logpath,'r') as f:
                if cursize: f.seek(cursize)
                for line in f:
                    n += len(line)
                    txts.append(line)
                    if n>=_pagesize: break
                    
                #txt = f.read(_pagesize)
            Log = NgxLog(file=txts)
            Log.ngx()
            txt = Log.sort(sort, isMsg=1)
            #txt = Log.records
        
        elif aparse:
            mtype = 'r'
            txts = ["以下为攻击行为分析：\n\n"]
            n = 0
            with open(logpath,'r') as f:
                if cursize: f.seek(cursize)
                for line in f:
                    n += len(line)
                    
                    L = []
                    for key, value in rules.items():
                        for key2, value2 in value.items():
                            try:
                                match = re.search(value2, line, re.IGNORECASE)
                                if match:
                                    res = '[!]漏洞类型: {0}\t漏洞细节: {1}\t匹配规则: {2}'.format(key, key2, value2)
                                    L.append('\t{0}\n'.format(res))
                                    #L.append(res)
                            except:
                                pass
                    if L:
                        txts.append('[*]日志: {0}\n'.format(line.strip()))
                        for e in L: txts.append(e)
                        txts.append("\n")
                        
                    if n>=_pagesize: break
            if len(txts)==1: 
                    txts.append("\t(此页没有发现URL攻击行为)")
            txt = "".join(txts)
        else:
            mtype = 'rb' if is_binary_file(logpath) else 'r'
            
            with open(logpath,mtype) as f:
                if cursize: f.seek(cursize)
                txt = f.read(_pagesize)
                
            self.__set_config(logpath)
            if not isinstance(txt, str):
                try:
                    txt = txt.decode('utf-8')
                except:
                    print("error isinstance str")
                    
            if mtype=='rb':
                try:
                    if sys.version_info < (3, 0):
                        txt = repr(txt).replace('\\n', '\\n\n')
                    else:
                        txt = str(txt).replace('\\n', '\\n\n')
                except:
                    print("error mtype str")
                
            
                

        
        rs = {'data':{
            'pagesize':pagesize,
            'totalsize':totalsize,
            'pagesize':pagesize,
            'curpage':curpage,
            'totalpage':totalpage,
            'txt':txt,
            "sort":sort,
            'mtype':mtype,
            "logpath":logpath,
            "aparse": aparse
            }}
        if error:
            rs['error'] = "文件路径有误"
        #print type(txt),txt.decode('utf-8')
        #import jinja2; print jinja2.Template('{{txt|e}}').render(txt=txt)
        #import jinja2; print jinja2.Template(open('./templates/view.html','r').read()).render(data={'data':rs})
        #
        return rs

    def ngx_log(self, args):
        return self.view(args)

    def getIpInfo(self, args):
        import requests
        ip = args.ip.strip()
        
        r = requests.get('http://ip.taobao.com/service/getIpInfo.php?ip='+ip,
                         timeout=2)
        return r.text
        


    def get_search(self, args):
        folder = args.folder.strip() if "folder" in args else ""
        if not folder or folder=="/" or not os.path.isdir(folder):
            return {"error":"文件夹路径有误且不能为/"}
        utime = args.utime.strip() if "utime" in args else ""
        if utime:
            utime = time.strptime(utime, '%Y-%m-%d %H:%M:%S')
            utime = time.mktime(utime)-8*3600
        M = 1024*1024
        fsize = (int(args.fsize.strip() or '1024') )*1024
        
        data = []
        
        if 'subfold' not in  args:
            for f in os.listdir(folder):
                fpath = os.path.join(folder,f)
                if not os.path.isfile(fpath):continue
                size = os.path.getsize(fpath)
                if size<=fsize: continue
                if utime and os.path.getmtime(fpath)<=utime: continue
                if is_binary_file(fpath): continue
                fpath = fpath.replace('\\','/')
                
                try:
                    data.append([fpath.decode('GBK'), int(size/M)])
                except:
                    data.append([fpath, int(size/M)])
                
                
        else:
            for root, dirs, files in os.walk(folder, True, None, False): 
                for f in files:
                    fpath = os.path.join(root,f)
                    size = os.path.getsize(fpath)
                    if size<=fsize: continue
                    if utime and os.path.getmtime(fpath)<=utime: continue
                    if is_binary_file(fpath): continue
                    fpath = fpath.replace('\\','/')
                    try:
                        data.append([fpath.decode('GBK'), int(size/M)])
                    except:
                        data.append([fpath, int(size/M)])
        
        return {'data':data, 'total':len(data)} 

    def __get_config(self,key=None,force=False):
        if not self.__config or force:
            config_file = self.__plugin_path + '/'+ 'config.json'
            if not os.path.exists(config_file): return None
            f_body = public.ReadFile(config_file)
            if not f_body: return None
            self.__config = json.loads(f_body)
            
        if key:
            if key in self.__config: return self.__config[key]
            return None
        return self.__config


    def __set_config(self,key=None,value=None):
        if not self.__config: self.__config = {"loglist":{}} #path,time
        d = self.__config["loglist"]

        t = time.strftime('%Y-%m-%d %H:%M:%S',time.localtime())
        
        d[key] = t
        if len(d)>20:
            L = sorted(d.items(), key=lambda d: d[1])
            d.pop(L[0][0])
        
        config_file = self.__plugin_path +'/'+ 'config.json'

        try:
            public.WriteFile(config_file,json.dumps(self.__config))
        except UnicodeDecodeError:
            d2 = {}
            for k in d:
                d2[k.decode('GBK')]=d[k]
            self.__config["loglist"] = d2
            public.WriteFile(config_file,json.dumps(self.__config))
            #public.WriteFile(config_file,json.dumps(self.__config, ensure_ascii=Falses))
        return True

    def get_loglist(self, args):
        d = self.__config or {"loglist":{}}
        L = sorted(d["loglist"].items(), key=lambda d: d[1], reverse=True)
        return {'data':L}


if __name__ == "__main__":
    """ 
    class args(dict):
        logpath = '/home/pytiger.web.20180811我.log'
        folder = '/home'
        fsize = '1024'
        pagesize = '1'
    print mflogview_main().get_search(args(logpath='',pagesize='', folder=""))
    print mflogview_main().view(args(logpath='',pagesize=''))
    """
        
        
    
    
        
    

