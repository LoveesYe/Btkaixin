#!/usr/bin/python
# -*- coding: UTF-8 -*-
# editor: moofei


import os
import re
import time
from collections import Counter
import math
import sys
import json
from datetime import datetime, timedelta
try:
    from IPy import IP
except:
    print(os.popen('pip install IPy').read())

date_regex = r"?P<date>\d+"
month_regex = r"?P<month>\w+"
year_regex = r"?P<year>\d+"
day_time_regex = r"?P<day_time>\S+"

ip_regex = r"?P<ip>[\d.]*"
time_regex = r"?P<time>.+"
method_regex = r"?P<method>\S+"
request_regex = r"?P<request>\S+"
status_regex = r"?P<status>\d+"
body_bytes_regex = r"?P<body_bytes>\d+"
refer_regex = r"?P<refer>\S+"
agent_regex = r"?P<agent>.+"

def parse_time(date, month, year, log_time):
    time_str = '%s%s%s %s' %(year, month, date, log_time)
    t = time.strptime(time_str, '%Y%b%d %H:%M:%S')
    return time.strftime("%Y-%m-%d %H:%M:%S",t)

#转换字节单位
def convertBytes(bytes, lst=['B','KB','MB','GB','TB','PB']):
    if not bytes: return "0B"
    i = int(math.floor(math.log(bytes, 1024)))
    if i >= len(lst):
        i = len(lst) - 1
    return ('%.2f ' + lst[i]) % (bytes/math.pow(1024, i))


class AccessLog:
    def __init__(self, path="", file=None):
        """
        log_fmt = r"(%s)\s+-\s+-\s+\[(%s)/(%s)/(%s)\:(%s)\ [\S]+\]\ \"(%s)?[\s]?(%s)?.*?\"\ (%s)\ (%s)\s"
        p = re.compile(log_fmt %(ip_regex, date_regex, month_regex, year_regex, day_time_regex, method_regex, request_regex, status_regex),re.VERBOSE)
        """
        self.path = path
        self.file = file if file else open(path)
        self.records  = {}
        
        log_fmt = r'(%s)\s+-\s+-\s+\[(%s)/(%s)/(%s)\:(%s)\ [\S]+\]\ \"(%s)?[\s]?(%s)?.*?\"\ (%s)\ (%s)\s\"(%s)\"\s\"(%s)\"'
        self.p = re.compile(log_fmt %(ip_regex, date_regex, month_regex, year_regex, day_time_regex,
                                      method_regex, request_regex, status_regex,body_bytes_regex, refer_regex, agent_regex)
                            ,re.VERBOSE)

        #log_fmt = r'(%s)\s+-\s+-\s+\[(%s)]\ \"(%s)?[\s]?(%s)?.*?\"\ (%s)\ (%s)\s\"(%s)\"\s\"(%s)\"'
        #self.p = re.compile(log_fmt %(ip_regex, time_regex,
        #                              method_regex, request_regex, status_regex,body_bytes_regex, refer_regex, agent_regex)
        #                    ,re.VERBOSE)
        
    def ngx(self):
        for line in self.file:
            if not line: continue
            d = self.p.search(line)
            if not d: continue
            
            d = d.groupdict()
            #print d
            date = d["date"]
            month = d["month"]
            year = d["year"]
            day_time = d["day_time"]
            ip = d['ip']
            status = int(d['status'] or 0)
            body_bytes = int(d['body_bytes'] or 0)
            refer = d['refer']
            agent = d['agent']
            method = d['method']
            request = d['request']
            
            IP = self.records.setdefault(ip, {
                '3xx':0,
                '4xx':0,
                '5xx':0,
                'qts':0,
                'post':0,
                'body_bytes':0,
                'ua':"",
                "lasttime":"",
                })
            ctime = parse_time(date, month, year, day_time)
            IP['body_bytes'] += body_bytes
            IP['qts'] += 1
            if status>=500:
                IP['5xx'] +=1
            elif status>=400:
                IP['4xx'] +=1
            elif status>=300:
                IP['3xx'] +=1
            
            if method=='POST': IP['post']+=1
            if agent and agent!='-': IP['ua'] = agent
            IP['lasttime'] = ctime
            
            #print ctime
            #break
        return self.records
    
    def sort(self, key=None, isMsg=0):
        if not key: key = "qts"
        if isMsg:
            ipwhites = readIpTxt('/www/server/nginx/mfwaf/conf/ipwhites.txt')
            ipzhizhu = readIpTxt('/www/server/nginx/mfwaf/conf/ipzhizhu.txt')
            ipblacks = readIpTxt('/www/server/nginx/mfwaf/conf/ipblacks.txt')
            btwhites = btwafJson('/www/server/btwaf/rule/ip_white.json')
            btblacks = btwafJson('/www/server/btwaf/rule/ip_black.json')
            #btwhites = btwafJson('/www/server/btwaf/rule/cn.json')
        
        if key in ('lasttime',  'qts','body_bytes','3xx','4xx','5xx', 'post') :
            
            try:
                L = sorted(self.records.items(), lambda x, y: cmp(x[1][key], y[1][key]), reverse=True)
            except:
                L = sorted(self.records.items(), key = lambda x: x[1][key], reverse=True)
            for e in L:
                e[1]['body_bytes2'] = convertBytes(e[1]['body_bytes'])
                if isMsg:
                    if e[0] in  ipwhites:
                        e[1]['msg'] = 'white'
                    elif e[0] in  ipblacks:
                        e[1]['msg'] = 'black'
                    elif e[0] in  ipzhizhu:
                        e[1]['msg'] = 'zhizhu'
                    else:
                        ip2 = [int(i) for i in e[0].split('.')]
                        if isInBtJson(ip2,btblacks):
                            e[1]['msg'] = 'black'
                        elif isInBtJson(ip2,btwhites):
                            e[1]['msg'] = 'white'
        return L


def readTxt(path):
    if not os.path.isfile(path):
        return []
    with open(path,'r') as f:
        txt = f.read()
    txt = re.sub(r'<!--[\s\S]*?-->', ' ', txt)
    L = []
    for line in txt.split('\n'):
        s = line.split('#')[0].strip()
        if s: L.append(s)
    return L

int_ip = lambda x: '.'.join([str(x/(256**i)%256) for i in range(3,-1,-1)])
ip_int = lambda x:sum([256**j*int(i) for j,i in enumerate(x.split('.')[::-1])])
def readIpTxt(path, d=None):
    L = readTxt(path)
    if not L: return {}
    if d is None: d = {}
    for s in L:
        if s[0]=='(': s=s[1:-1]
        if '|' in s:
            ss = s.split('|')
        else:
            ss = [s]
        for e in ss:
            if '-' in e:
                ip1,ip2 = e.split('-', 1)
                try:
                    ip1_num = ip_int(ip1.strip())
                    ip2_num = ip_int(ip2.strip())
                    for i in range(ip1_num,ip2_num+1): d[int_ip(i)]= 1
                except:
                    pass
                    
            else:
                try:
                    for ip in IP(e): d[str(ip)] = 1
                except:
                    pass
    return d


def btwafJson(path):
    #/www/server/btwaf/rule/
    if not os.path.isfile(path):
        return []
    with open(path,'r') as f:
        txt = f.read()
    rs = json.loads(txt)
    return rs
def isInBtJson(ip2, L):
    for e in L:
        if e[0] <= ip2 <= e[1]:
            return 1
    

if __name__ == "__main__":
    o = AccessLog(r'C:\Users\liuyouhua\Documents\Tencent Files\53133259\FileRecv\uwv5.com (15).log')
    o.ngx()
    o.sort('body_bytes')
    
