#!/bin/bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH
install_tmp='/tmp/bt_install.pl'
public_file='/www/server/panel/install/public.sh'
download_Url='http://bt.02988.com'
pluginPath='/www/server/panel/plugin/bdbos'
pluginfile='bosfs-1.0.0.10.tar.gz'


Install()
{
	
	echo '正在安装...'
	#==================================================================
	#依赖安装开始
    if [ -f "/usr/local/bin/bosfs" ] || [ -f "/usr/bin/bosfs" ];then
       echo '环境已经安装...' > $install_tmp
    else
       echo '正在安装脚本文件...' > $install_tmp
	   mkdir -p ${pluginPath}
   	   egrep -i "debian" /etc/issue /proc/version >/dev/null && SysName='Debian';
	   egrep -i "ubuntu" /etc/issue /proc/version >/dev/null && SysName='Ubuntu';
	   whereis -b yum | grep -q '/yum' && SysName='CentOS';
           wget -O fuse-2.9.4.tar.gz ${download_Url}/download/fuse-2.9.4.tar.gz
           tar -xzvf fuse-2.9.4.tar.gz 
           cd fuse-2.9.4
           ./configure
           sudo make && sudo make install 
           cd ..
           rm -fr fuse-2.9.4
           rm -fr fuse-2.9.4.tar.gz
		  if [ "$SysName" == 'CentOS' ]; then
              sudo yum -y install gcc-c++ autoconf automake libuuid-devel  openssl-devel libcurl-devel
	      else
		      sudo apt-get install -y autoconf uuid-dev libssl-dev libcurl4-openssl-dev
	      fi;
           wget -O ${pluginfile} ${download_Url}/download/${pluginfile}
           tar -xzvf ${pluginfile} 
           cd bosfs-1.0.0
           chmod +x build.sh
           ./build.sh
           cd ..
           rm -fr bosfs-1.0.0
           rm -fr ${pluginfile}
           echo '/usr/local/lib' > /etc/ld.so.conf.d/fuse.conf
           chmod 644 /etc/ld.so.conf.d/fuse.conf
           ldconfig
   
   fi
	  #依赖安装结束
	  #==================================================================
	     wget -O ${pluginPath}/index.html $download_Url/bdbos/index.html -T 5
	     wget -O ${pluginPath}/info.json $download_Url/bdbos/info.json -T 5
	     wget -O ${pluginPath}/bdbos_main.py $download_Url/bdbos/bdbos_main.py -T 5
	     wget -O ${pluginPath}/icon.png $download_Url/bdbos/icon.png -T 5
 	     wget -O ${pluginPath}/install.sh $download_Url/bdbos/install.sh -T 5
	     \cp -a -r ${pluginPath}/icon.png /www/server/panel/BTPanel/static/img/soft_ico/ico-bdbos.png
	  echo '================================================'
      echo '安装完成' > $install_tmp
}

Uninstall()
{
	rm -rf $pluginPath
}

#操作判断
if [ "${1}" == 'install' ];then
	Install
elif [ "${1}" == 'uninstall' ];then
	Uninstall
else
	echo 'Error!';
fi
