#!/usr/bin/python
# coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: xxx <xxxx@qq.com>
# +-------------------------------------------------------------------

#+--------------------------------------------------------------------
#|   宝塔第三方应用开发docker_bbb
#+--------------------------------------------------------------------
import sys,os,json
os.chdir("/www/server/panel")
sys.path.append("class/")
import public
import panelTask
import socket
import random

if __name__ != '__main__':
    from BTPanel import cache,session,redirect

class docker_bbb_main:
    __plugin_path = "/www/server/panel/plugin/docker_bbb/"
    __config = None

    def  __init__(self):
        pass

    def startDockerService(self):
        if("active" in os.popen("systemctl status docker").read()):
            os.popen("systemctl start docker").read()

    def isPortUsed(self, port):
        s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
        try:
            s.connect(('127.0.0.1',port))
            s.shutdown(2)
            return True
        except Exception as e:
            print(e)
            return False

    def getDockerVer(self, args):
        self.startDockerService()
        dockerVer = os.popen("docker --version").read()
        return {"msg":"查询成功","data":dockerVer,"status":1}

    def doesTheMirrorExist(self, args):
        self.startDockerService()
        if("fastos/fastosdocker" in os.popen("docker image ls").read()):
            return {"msg":"镜像存在","status":1}
        else:
            t = panelTask.bt_task()
            t.create_task("拉取Docker镜像中",0,"docker image pull registry.cn-qingdao.aliyuncs.com/fastos/fastosdocker:latest")
            return {"msg":"找不到镜像，正在下载","status":0}
    
    def getContainerStatus(self, args):
        self.startDockerService()
        containerStatus = False
        port = -1
        if("fastos/fastosdocker" in os.popen("docker ps").read() and os.path.exists("/www/server/panel/plugin/docker_bbb/main.json")):
            configFile = open('/www/server/panel/plugin/docker_bbb/main.json', 'r')
            configDict = json.loads(configFile.read())
            containerStatus = os.popen("docker inspect " + configDict['containerId'] + "  --format '{{.State.Status}}'").read().split("\n")[0]=='running'
            port = configDict['port']
        return {"msg":"查询成功","containerStatus":containerStatus,"port":port,"status":1}

    def stopContainer(self, args):
        self.startDockerService()
        configFile = open('/www/server/panel/plugin/docker_bbb/main.json', 'r')
        configDict = json.loads(configFile.read())
        os.popen("docker stop "+configDict['containerId'])
        return {"msg":"操作成功","status":1}

    def startContainer(self, args):
        self.startDockerService()
        port = 8081
        if(self.isPortUsed(port)):
            port = random.randint(1024,60000)
            if(self.isPortUsed(port)):
                return {"msg":"启动镜像时出现了一个问题，请重试！","status":0}
        if(os.path.exists("/www/server/panel/plugin/docker_bbb/main.json")):
            configFile = open('/www/server/panel/plugin/docker_bbb/main.json', 'r')
            configDict = json.loads(configFile.read())
            dockerStatus = os.popen("docker inspect " + configDict['containerId'] + "  --format '{{.State.Status}}'").read()
            if(not dockerStatus.split("\n")[0] =="running"):
                if("Error" in dockerStatus or dockerStatus == "\n"):
                    os.remove('/www/server/panel/plugin/docker_bbb/main.json') 
                    return {"msg":"启动失败，请重试！","port":-1,"status":0}
                else:
                    if(self.isPortUsed(configDict['port'])):
                        return {"msg":"抱歉！当前启动端口[" + str(configDict['port']) + "]被占用，无法启动！","status":0}
                    os.popen("docker start "+configDict['containerId']).read()
            return {"msg":"启动成功！","port":configDict['port'],"status":1}
        else:
            containerId = os.popen("docker run --restart always -p " + str(port) + ":8081 -d -v /var/run/docker.sock:/var/run/docker.sock -v /etc/docker/:/etc/docker/ registry.cn-qingdao.aliyuncs.com/fastos/fastosdocker:latest").read()
            configDict = {
                'containerId': containerId.split("\n")[0],
                'port': port,
            }
            with open('/www/server/panel/plugin/docker_bbb/main.json', "w") as f:
                json.dump(configDict, f, indent=2,sort_keys=True, ensure_ascii=False)
        return {"msg":"启动成功！","port":port,"status":1}