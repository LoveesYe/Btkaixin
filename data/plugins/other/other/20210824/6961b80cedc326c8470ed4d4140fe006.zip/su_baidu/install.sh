#!/bin/bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH

#配置目录和网址
pluginPath=/www/server/panel/plugin
download_Url='https://www.66web.com/download/bt/su_baidu/su_baidu.zip'

#检查系统
check_sys() {
  if [[ -f /etc/redhat-release ]]; then
    release="centos"
  elif cat /etc/issue | grep -q -E -i "debian"; then
    release="debian"
  elif cat /etc/issue | grep -q -E -i "ubuntu"; then
    release="ubuntu"
  elif cat /etc/issue | grep -q -E -i "centos|red hat|redhat"; then
    release="centos"
  elif cat /proc/version | grep -q -E -i "debian"; then
    release="debian"
  elif cat /proc/version | grep -q -E -i "ubuntu"; then
    release="ubuntu"
  elif cat /proc/version | grep -q -E -i "centos|red hat|redhat"; then
    release="centos"
  fi
  bit=`uname -m`
}

#安装
Install()
{
	check_sys
	if [[ ${release} == "centos" ]]; then
	cmd="yum"
	else
	cmd="apt"
	fi
   	mkdir -p $pluginPath
	cd $pluginPath
	${cmd} -y install wget unzip
	echo '正在安装脚本文件...'
	wget --no-check-certificate -O su_baidu.zip $download_Url
	unzip -o su_baidu.zip
	\cp -a -r /www/server/panel/plugin/su_baidu/icon.png /www/server/panel/BTPanel/static/img/soft_ico/ico-su_baidu.png
	rm -rf su_baidu.zip
	echo '安装完成'
}

#卸载
Uninstall()
{
	rm -rf $pluginPath/su_baidu
}

#操作判断
if [ "${1}" == 'install' ];then
	Install
elif  [ "${1}" == 'update' ];then
	Install
elif [ "${1}" == 'uninstall' ];then
	Uninstall
else
    echo 'Error!';
fi
