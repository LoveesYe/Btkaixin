#!/bin/bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH

#配置插件安装目录
install_path=/www/server/panel/plugin/myhaproxy

#安装
Install()
{
  yum -y install make gcc gcc-c++ openssl-devel epel-release haproxy
	echo '正在安装...'
	alias cp=cp
	cp -rf $install_path/icon.png  /www/server/panel/BTPanel/static/img/soft_ico/ico-myhaproxy.png
	cp -rf $install_path/haproxy.cfg /etc/haproxy/
	cp -rf $install_path/haproxy.conf /etc/rsyslog.d/
	sed -i "s#SYSLOGD_OPTIONS=.*#SYSLOGD_OPTIONS=\"-c 2 -r -m 0\"#" /etc/sysconfig/rsyslog
	cat /etc/sysconfig/rsyslog |grep "使用兼容模式"
	if [ $? != 0 ];then
	cat >> /etc/sysconfig/rsyslog << EOF
#-c 2 使用兼容模式，默认是 -c 5
#-r 开启远程日志
#-m 0 标记时间戳。单位是分钟，为0时，表示禁用该功能
EOF
  fi
  systemctl restart rsyslog
  systemctl restart haproxy
	#==================================================================
	#依赖安装开始


	#依赖安装结束
	#==================================================================

	echo '================================================'
	echo '安装完成'
}

#卸载
Uninstall()
{
	rm -rf $install_path
}

#操作判断
if [ "${1}" == 'install' ];then
	Install
elif [ "${1}" == 'uninstall' ];then
	Uninstall
else
	echo 'Error!';
fi
