#!/usr/bin/python
# coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: xxx <xxxx@qq.com>
# +-------------------------------------------------------------------

# +--------------------------------------------------------------------
# |   宝塔第三方应用开发haproxy
# +--------------------------------------------------------------------
import sys, os, json , re

# 设置运行目录
os.chdir("/www/server/panel")

# 添加包引用位置并引用公共包
sys.path.append("class/")
import public

# from common import dict_obj
# get = dict_obj();


# 在非命令行模式下引用面板缓存和session对象
if __name__ != '__main__':
    from BTPanel import cache, session, redirect

    # 设置缓存(超时10秒) cache.set('key',value,10)
    # 获取缓存 cache.get('key')
    # 删除缓存 cache.delete('key')

    # 设置session:  session['key'] = value
    # 获取session:  value = session['key']
    # 删除session:  del(session['key'])


class myhaproxy_main:
    __plugin_path = "/www/server/panel/plugin/myhaproxy/"
    __config = None
    __haproxy_config = '/etc/haproxy/haproxy.cfg'
    __algorithm =['roundrobin','static-rr','leastconn','source','uri','url_param','hdr','rdp-cookie']
    # 构造方法
    def __init__(self):
        self.__tmp={}

    # 访问/haproxy/index.html时调用的默认方法，需要在templates中有index.html，否则无法正确响应模板
    def index(self, args):
        return self.get_logs(args)

    def del_log(self,args):
        ret=public.M('logs').where('type=?', (u'haproxy',)).delete()
        return public.returnMsg(True, '清理成功')

    #批量删除
    def del_proxy_multiple(self,args):
        if not os.path.exists(self.__haproxy_config):
            return {"status":False,'msg':"配置文件不存在,无法删除！！"}
        file= open(self.__haproxy_config)
        data = file.readlines()
        all_data = "".join(data)
        every_txt = self.handle_txt(data)
        proxynames = args.f_name.split(',')
        del_successfully = []
        for proxyname in proxynames:
            if not proxyname:
                continue
            for item in every_txt:
                if re.search(r'(\bfrontend\b\s+%s.*)'%proxyname,item):
                    all_data = all_data.replace(item,"")
                    del_successfully.append(proxyname)
                    port = re.search(':(\d+)', item).group(1)
                    self.handle_port(port, type=False)
        public.WriteFile(self.__haproxy_config, all_data)
        self.write_logs("用户批量删除代理%s" %proxynames)
        return {"status":True,'msg':"删除反向代理成功",'success': del_successfully,'error':""}

    #删除代理
    def delete_proxy(self,args):
        name = args.f_name
        default_backend = args.default_backend
        if not os.path.exists(self.__haproxy_config):
            return {"status":False,'msg':"配置文件不存在,无法删除！！"}
        file= open(self.__haproxy_config)
        data = file.readlines()
        all_data = "".join(data)
        every_txt = self.handle_txt(data)
        for item in every_txt:
            pat = re.search(r'(\bfrontend\b\s+%s.*)'%name,item)
            if pat:
                all_data = all_data.replace(item,"")
                port = re.search(':(\d+)', item).group(1)
                self.handle_port(port,type=False)
        public.WriteFile(self.__haproxy_config,all_data)

        self.write_logs("用户删除代理%s ,保留对应目标集群%s"%(name,default_backend))
        return {"status":True,'msg':"删除成功"}

    def get_monitor(self,args):
        f= open(self.__haproxy_config)
        data = f.readlines()
        every_txt = self.handle_txt(data)
        ret = {}
        for item in every_txt:
            pat = re.search('listen\s+admin_stats',item)
            if pat:
                ret['mode'] = re.search('mode\s+(\w+)',item).group(1)
                pat = re.search("bind\s+(?P<ip>(\d+\.\d+\.\d+\.\d+)|(\*)|(\s)|((\w+\.){1,4}\w+)):(?P<port>\d+)",item)
                ret['ip'] = pat.group('ip')
                ret['port'] = pat.group('port')
                if ret['mode']=='http':
                    self.handle_port(ret['port'])
                pat2 = re.search("stats\s+auth\s+(?P<username>\w+):(?P<passwd>\w+)",item)
                ret['username']=pat2.group('username')
                ret['passwd']=pat2.group('passwd')
                pat3 = re.search("stats\s+uri\s+(.*)",item)
                ret['uri'] = pat3.group(1)

        return {"status":True,'data':ret,'msg':"请求成功"}
    #获取haproxt默认default配置
    def get_haproxy_value(self,args):
        c_list = [{"mode":"工作模式"},
                  {"retries":"check检查次数"},
                  {"timeout http-request":"秒,http请求超时时间"},
                  {"timeout queue":"分钟,队列超时时间"},
                  {"timeout connect":"秒,连接超时时间"},
                  {"timeout client":"分钟,客户端连接超时时间"},
                  {"timeout server":"分钟,服务器端连接超时时间"},
                  {"timeout http-keep-alive":"秒,持久连接超时时间"},
                  {"timeout check":"秒,设置心跳检查超时时间"},
                  {"maxconn":"最大连接数"}]
        config_data = public.ReadFile(self.__haproxy_config)
        conflist = []
        for item in c_list:
            i = list(item.keys())[0]
            rep = r"(%s)\s+((\d+)|(\w+))" % i
            k = re.search(rep,config_data)
            if not k:
                return public.returnMsg(False,"获取 key {} 失败{}".format(k,i))
            k = k.group(1)
            v = re.search(rep,config_data)
            if not v:
                return public.returnMsg(False, "获取 value {} 失败".format(v))
            v = v.group(2)
            u = ""
            psstr = item[i]
            kv = {"name": k, "value": v, "unit": u, "ps": psstr}
            conflist.append(kv)
        return conflist
    def get_status(self,args):
        ret = {"status":True,'data':[]}
        status = os.system('ps -aux|grep haproxy|grep -v grep')
        if status != 0:
            ret['status']=False
        return ret
    def check_config_valid(self):
        status = os.system("haproxy -c -f %s" % self.__haproxy_config)
        if status==0:
            return True
        else:return False

    def check_port(self,port):
        try:
            port = int(port)
        except Exception as e:
            return False
        if port<1 or port>65535:
            return False
        else:
            return True

    def check_host(self,name):
        if not name:
            return False
        pat = re.search(r'((\d+\.\d+\.\d+\.\d+)|((\w+\.){1,4}\w+)|(\*))',name)
        if pat:
            return True
        else:
            return False

    def set_monitor_val(self,args):
        username=args.username
        passwd=args.passwd
        mode = args.mode
        f = open(self.__haproxy_config)
        data = f.readlines()
        all_data = "".join(data)
        every_txt = self.handle_txt(data)
        for item in every_txt:
            pat = re.search('listen\s+admin_stats',item)
            if pat:
                pat2 = re.search('(stats\s+auth\s+.*)',item)
                old = pat2.group(1)
                new = "stats auth %s:%s"%(username,passwd)
                all_data = all_data.replace(old,new)
                pat3 = re.search('(mode\s\w+)',item)
                old2 = pat3.group(1)
                new2 = "mode %s"%mode
                all_data = all_data.replace(old2, new2)
        public.WriteFile(self.__haproxy_config,all_data)
        public.ExecShell("systemctl restart haproxy")
        return {"status":True,'msg':"设置成功"}
    def set_ha_config(self,args):
        ret = {"status": True, 'msg': "设置成功"}
        frontend_name = args.frontend_name
        frontend_ip = args.frontend_ip
        try:
            mode = args.mode
        except:
            mode = None
        try:
            frontend_port = int(args.frontend_port)
        except Exception as e:
            frontend_port = -999
        backend_name = args.backend_name
        balance = args.balance
        backend_obj = json.loads(args.backend_obj)
        if not self.check_port(frontend_port):
            ret['status']=False
            ret['msg']="端口超出范围(1-65535)!!"
        if not frontend_name or not frontend_ip or not backend_name or not balance:
            ret['status']=False
            ret['msg']="参数为空，保存失败！"
        if not self.check_host(frontend_ip):
            ret['status']=False
            ret['msg']="监听地址错误！"
        if ret['status']:
            for index,server in enumerate(backend_obj):
                if not server['backend_server'] or not server['backend_addr'] or not server['backend_port']:
                    return {"status":False,"msg":'后端参数为空'}
                if not self.check_port(server['backend_port']):
                    return {"status": False, "msg": '%s端口超出范围(1-65535)!!'%server['backend_port']}
                if not self.check_host(server['backend_addr']):
                    return {"status": False, "msg": '%s 格式错误，请填写ip或域名'%server['backend_port']}
                if server['backend_check']:
                    backend_obj[index]['backend_check']="check"
                else:
                    backend_obj[index]['backend_check'] = ""
                if server['backend_backup']:
                    backend_obj[index]['backend_backup']="backup"
                else:
                    backend_obj[index]['backend_backup'] =""
            #所有参数检测完成后判断是更新还是插入
            file= open(self.__haproxy_config)
            data = file.readlines()
            all_data = "".join(data)
            every_txt = self.handle_txt(data)
            frontend_add = True
            backend_add =True
            for item in every_txt:
                #每一个原始frontend段落,找到符合修改的段落
                pat = re.search(r'(\bfrontend\b\s+%s.*)'%frontend_name,item)
                pat2 = re.search(r'(\bbackend\b\s+%s.*)'%backend_name,item)
                if pat:#代表是修改frontend
                    frontend_add = False
                    old = pat.group(1)
                    new = "frontend %s  %s:%s" % (frontend_name, frontend_ip, frontend_port)
                    new_frontend_txt = item.replace(old,new)
                    pat2 = re.search('(bind\s+.*)',new_frontend_txt)
                    if pat2:
                        #过滤bind语法
                        new_frontend_txt = new_frontend_txt.replace(pat2.group(1),'')
                    pat3 = re.search('(default_backend\s+.*)',new_frontend_txt)
                    if pat3:
                        new_frontend_txt = new_frontend_txt.replace(pat3.group(1), 'default_backend %s'%backend_name)
                    pat4 = re.search('(mode\s+\w+)', new_frontend_txt)
                    #给了mode说明是新增或者修改
                    if mode:
                        #修改
                        if pat4:
                            new_frontend_txt = new_frontend_txt.replace(pat4.group(1), 'mode %s' % mode)
                        #xinzeng
                        else:
                            new_frontend_txt += '''    mode  %s\n''' % mode
                    elif pat4:
                            new_frontend_txt = new_frontend_txt.replace(pat4.group(1), "")

                    all_data = all_data.replace(item,new_frontend_txt)
                if pat2:#修改backend
                    backend_add = False
                    new_backend_txt = item
                    b1 = re.search('(balance\s+.*)',item)
                    if b1:
                        #替换算法
                        old_balance = b1.group(1)
                        new_balance = "balance %s"%balance
                        new_backend_txt = item.replace(old_balance,new_balance)
                    b2 = re.findall('(server\s+.*)',item)
                    for s in b2:
                        new_backend_txt = new_backend_txt.replace(s,'')
                    #去除多余空行
                    new_backend_txt = new_backend_txt.strip()
                    server_str="\n"
                    for s in backend_obj:
                        weight = "weight %s"%s['backend_weight'] if s['backend_weight'] else ""
                        is_backup =  "backup" if s['backend_backup'] else ""
                        server_str+="    server %s %s:%s %s %s %s\n"%(s['backend_server'],s['backend_addr'],s['backend_port'],s['backend_check'],weight,is_backup)
                    new_backend_txt+=server_str
                    all_data = all_data.replace(item,new_backend_txt)
            #新增frontend
            if frontend_add:
                new_txt = '''
frontend %s %s:%s
    default_backend %s\n'''%(frontend_name,frontend_ip,frontend_port,backend_name)
                all_data += new_txt
                if mode:
                    all_data += '''    mode  %s        '''%mode
                self.write_logs("用户添加代理%s 对应后端集群%s" % (frontend_name, backend_name))
            if backend_add:
                new_txt ='''
backend %s
    balance %s'''%(backend_name,balance)
                for s in backend_obj:
                    weight = "weight %s" % s['backend_weight'] if s['backend_weight'] else ""
                    is_backup = "backup" if s['backend_backup'] else ""
                    new_txt += '''
    server %s %s:%s %s %s %s''' % (
                    s['backend_server'], s['backend_addr'], s['backend_port'], s['backend_check'], weight, is_backup)
                all_data += "\n" + new_txt
            public.WriteFile(self.__haproxy_config,all_data)

            self.handle_port(frontend_port)
        return ret

    def set_ha_default(self,args):
        config_data = public.ReadFile(self.__haproxy_config)
        g_list=['mode','retries','timeout http-request','timeout queue','timeout connect','timeout client','timeout server','timeout http-keep-alive','timeout check','maxconn']
        for name in g_list:
            i = eval("args['" + name + "']")
            if not i:
                return {"status":False,'msg':"%s 参数错误！"%name}
            rep = r"(%s\s+((\d+)|(\w+)))"%name
            pat =re.search(rep,config_data)
            if pat:
                old = pat.group(1)
                new = "%s    %s"%(name,i)
                config_data = config_data.replace(old,new)
        public.WriteFile(self.__haproxy_config,config_data)
        public.ExecShell("systemctl restart haproxy")
        return {"status":True,'msg':"设置成功"}

    def set_status(self,args):
        data = {"status":True,'msg':'设置成功'}
        shell = args.status
        #检查配置文件是否错误
        if not self.check_config_valid():
            a,e = public.ExecShell("haproxy -c -f %s"%self.__haproxy_config)
        else:e=None
        if e:
            data['msg']= e
            data['status']=False
            return data
        ret = os.system('systemctl %s haproxy'%shell)
        self.write_logs('用户 %s 服务'%shell)
        if ret !=0:
            data['status']=False
            data['msg']='设置失败'
        return data

    def parser_config(self):
        f= open(self.__haproxy_config)
        data = f.readlines()
        frontend = []
        backend = []
        every_txt = self.handle_txt(data)
        for txt in every_txt:
            if txt.startswith('frontend'):
                frontend.append(self.handle_frontend(txt))
            if txt.startswith('backend'):
                backend.append(self.handle_backend(txt))
        return frontend,backend

    def get_config(self,args):
        if not os.path.exists(self.__haproxy_config):
            return {"status":False,'msg':"配置文件不存在"}
        f,b = self.parser_config()
        #缓存一下
        self.__tmp={"f":f,"b":b}
        return {"status":True,'msg':"ok",'f':f,'b':b}
    def handle_port(self,port,type=True):
        import firewalls,common
        fw = firewalls.firewalls()
        get = common.dict_obj()
        get.ps='haproxy 代理端口'
        get.port = str(port)
        if type:#添加
            fw.AddAcceptPort(get)
        else:#删除
            get.id = public.M('firewall').where('port=?', (port,)).getField('id')
            fw.DelAcceptPort(get)
    def handle_txt(self,lines):
        tmp = ""
        every_txt = []
        for i in lines:
            #空格也要
            if i.startswith('#'):
                continue
            if tmp:  # 已经找到过头
                if i.startswith('defaults') or i.startswith('global') or i.startswith('frontend') or i.startswith(
                        'backend'):
                    every_txt.append(tmp)
                    tmp = ""
                else:
                    tmp += i
            if i.startswith('frontend') or i.startswith('backend') or i.startswith('listen'):
                if tmp:
                    every_txt.append(tmp)
                    tmp = ""
                else:
                    tmp += i
        if tmp:
            every_txt.append(tmp)
        return every_txt
    def handle_frontend(self,txt):

        item = {"f_name": "", 'ip': "", "port": ""}
        lines = txt.split('\n')
        for line in lines:
            if line.startswith('frontend'):
                name = re.search('frontend\s+(\w+)', line).group(1)
                item['f_name'] = name
                try:
                    pat = re.search("(?P<ip>(\d+\.\d+\.\d+\.\d+)|(\*)|(\s)|((\w+\.){1,4}\w+)):(?P<port>\d+)",line)
                    ip = pat.group('ip')
                    port = pat.group('port')
                    item['ip'] = ip
                    item['port'] = port
                except Exception as e:
                    continue
            if line.find("bind") != -1:
                ip = re.search('((\d+\.\d+\.\d+\.\d+)|(\*)|(\s)|((\w+\.){1,4}\w+)):', line).group(1)
                port = re.search(':(\d+)', line).group(1)
                item['ip'] = ip
                item['port'] = port
            if line.find('default_backend') != -1:
                back_name = line.split(' ')[-1]
                item['default_backend'] = back_name
            if line.find("mode") != -1:
                mode = line.split(' ')[-1]
                item['mode'] = mode
            if item['ip'] == " " or item['ip'] == "*":
                item['ip'] = '0.0.0.0'

        return item
    def handle_backend(self,txt):
        item = {'b_name': "", 'balance': "", 'backend_server': []}
        lines = txt.split('\n')
        for line in lines:
            if line.startswith('backend'):
                name = re.search('backend\s+(\w+)', line).group(1)
                item['b_name'] = name
            if line.find('balance') != -1:
                balance = re.search('balance\s+(.*)', line).group(1)
                item['balance'] = balance
            if line.find("server") != -1:
                server_name = re.search('server\s+(\w+)', line).group(1)
                # server_ip = re.search('(\d+\.\d+\.\d+\.\d+):',line).group(1)
                server_ip = re.search('((\d+\.\d+\.\d+\.\d+)|((\w+\.){1,4}\w+)):',line).group(1)
                server_port = re.search(':(\d+)', line).group(1)
                if line.find('check')!=-1:
                    server_check = True
                else:
                    server_check = False
                if line.find("backup")!=-1:
                    server_backup = True
                else:
                    server_backup = False
                if line.find('weight')!=-1:
                    weight = re.search('weight\s+(\d+)',line).group(1)
                else:
                    weight = ""
                item['backend_server'].append({
                    'server_name': server_name,
                    'server_ip': server_ip,
                    'server_port': server_port,
                    'server_backup': server_backup,
                    'server_check': server_check,
                    'server_weight':weight
                })
        return item
    def get_version(self,args):
        import platform
        data = json.loads(public.ReadFile(self.__plugin_path + "info.json"))
        data['pyversion'] = platform.python_version()
        return data

    def write_logs(self,logstr):
        public.WriteLog('haproxy',logstr)

    # 获取面板日志列表
    # 传统方式访问get_logs方法：/plugin?action=a&name=haproxy&s=get_logs
    # 使用动态路由模板输出： /haproxy/get_logs.html
    # 使用动态路由输出JSON： /haproxy/get_logs.json
    def get_logs(self, args):
        # 处理前端传过来的参数
        if not 'p' in args: args.p = 1
        if not 'rows' in args: args.rows = 12
        if not 'callback' in args: args.callback = ''
        args.p = int(args.p)
        args.rows = int(args.rows)

        # 取日志总行数
        count = public.M('logs').where('type=?',(u'haproxy',)).count()

        # 获取分页数据
        page_data = public.get_page(count, args.p, args.rows, args.callback)

        # 获取当前页的数据列表
        log_list = public.M('logs').where('type=?',(u'haproxy',)).order('id desc').limit(page_data['shift'] + ',' + page_data['row']).field(
            'id,type,log,addtime').select()

        # 返回数据到前端
        return {'data': log_list, 'page': page_data['page']}

    # 读取配置项(插件自身的配置文件)
    # @param key 取指定配置项，若不传则取所有配置[可选]
    # @param force 强制从文件重新读取配置项[可选]
    def __get_config(self, key=None, force=False):
        # 判断是否从文件读取配置
        if not self.__config or force:
            config_file = self.__plugin_path + 'config.json'
            if not os.path.exists(config_file): return None
            f_body = public.ReadFile(config_file)
            if not f_body: return None
            self.__config = json.loads(f_body)

        # 取指定配置项
        if key:
            if key in self.__config: return self.__config[key]
            return None
        return self.__config

    # 设置配置项(插件自身的配置文件)
    # @param key 要被修改或添加的配置项[可选]
    # @param value 配置值[可选]
    def __set_config(self, key=None, value=None):
        # 是否需要初始化配置项
        if not self.__config: self.__config = {}

        # 是否需要设置配置值
        if key:
            self.__config[key] = value

        # 写入到配置文件
        config_file = self.__plugin_path + 'config.json'
        public.WriteFile(config_file, json.dumps(self.__config))
        return True
