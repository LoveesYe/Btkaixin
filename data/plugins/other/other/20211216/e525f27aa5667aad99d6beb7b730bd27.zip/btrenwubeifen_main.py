#!/usr/bin/python3
# coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: xxx <xxxx@qq.com>
# +-------------------------------------------------------------------

# +--------------------------------------------------------------------
# |   宝塔第三方应用开发DEMO
# +--------------------------------------------------------------------
import sys
import os
import os.path
import json
import time
import datetime
import panelTask
import platform
import string
import zipfile

#t.create_task(‘压缩 test’,3,’/www’,{“sfile”:”test”,”dfile”:”/www/test.zip”,”z_type”:”rar”}) 压缩文件
t = panelTask.bt_task()

if sys.version[0:1] == '2':
    import ConfigParser

    # 解决ConfigParser小写问题
    class real_conf(ConfigParser.ConfigParser):
        def __init__(self, defaults=None):
            ConfigParser.ConfigParser.__init__(self, defaults=None)

        def optionxform(self, optionstr):
            return optionstr


if sys.version[0:1] == '3':
    import configparser

    # 解决ConfigParser小写问题


    class real_conf(configparser.ConfigParser):
        def __init__(self, defaults=None):
            configparser.ConfigParser.__init__(self, defaults=None)

        def optionxform(self, optionstr):
            return optionstr


# 设置运行目录
panelPath = os.getenv('BT_PANEL')
panelPath = panelPath if panelPath else "/www/server/panel"
os.chdir(panelPath)
# os.chdir("/www/server/panel")

# 添加包引用位置并引用公共包
sys.path.append("class/")

import public

#from common import dict_obj
#get = dict_obj();

# 在非命令行模式下引用面板缓存和session对象
if __name__ != '__main__':
    from BTPanel import cache, session, redirect

    # 设置缓存(超时10秒) cache.set('key',value,10)
    # 获取缓存 cache.get('key')
    # 删除缓存 cache.delete('key')

    # 设置session:  session['key'] = value
    # 获取session:  value = session['key']
    # 删除session:  del(session['key'])


class btrenwubeifen_main:
    __config = ""
    __increase_config = ""
    __plugin_path = panelPath + "/plugin/btrenwubeifen/"
    __run_log = __plugin_path + "log/gitea_service.log"

    # 构造方法

    def __init__(self):
        os.system('mkdir -p ' + self.__plugin_path + "tmp/reduction_zip")
        pass
        #备份必要文件

    field = 'id,name,type,where1,where_hour,where_minute,echo,addtime,status,save,backupTo,sName,sBody,sType,urladdress'

    #取计划任务列表
    def GetCrontab(self, get):
        if not 'page' in get:
            get.page = "0"
        if not 'limit' in get:
            get.limit = "20"

        get.page = int(get.page)
        get.limit = int(get.limit)
        crontab_obj = public.M('crontab')
        # if get.page>0:
        #     crontab_obj=crontab_obj.where('id=?',(id,)).
        count = crontab_obj.count()
        if get.page > 0:
            crontab_obj = crontab_obj.limit(
                '%d,%d' % (((get.page - 1) * get.limit), get.limit))
        data = crontab_obj.field(self.field).order("id desc").select()

        # data = public.M('crontab').order("id desc").field(self.field).select()
        return data, count

    def get_list(self, args):
        data, count = self.GetCrontab(args)
        return public.returnMsg('1', {"data": data, "count": count})

    def put_backups(self, args):
        data, count = self.GetCrontab(args)

        #系统类型
        os_type = self.UsePlatform(args)
        if os_type == 3:
            return public.returnMsg('-1', '仅支持linux和windows操作系统')
        self.__save_json(args, 'os_type', os_type)

        #系统位数
        digit = self.UsePlaceform(args)
        self.__save_json(args, 'digit', digit)

        self.__save_json(args, 'data', data)

        logintime = time.time()
        fileName = str(os_type) + "_" + str(digit) + "_" + str(
            time.strftime('%Y_%m_%d_%H_%M_%S', time.localtime(int(logintime))))

        #打包
        # t.create_task("备份文件打包",3,self.__plugin_path + 'tmp/',{"sfile":"reduction_zip","dfile":self.__plugin_path + "tmp/reduction_zip/test.zip","z_type":"rar"})

        z = zipfile.ZipFile(
            self.__plugin_path + "tmp/reduction_zip/" + fileName + ".zip", 'w',
            zipfile.ZIP_DEFLATED)
        z.write(self.__plugin_path + 'tmp/data.json', arcname="data.json")
        z.close()

        return public.returnMsg(
            '1', self.__plugin_path + "tmp/reduction_zip/test.zip")

    # 对象转换成dict
    def obj2dict(obj):

        if (isinstance(obj, user)):
            return {'name': obj.name, 'pwd': obj.pwd}
        else:
            return obj

    def put_increase_backups(self, args):
        data, count = self.GetCrontab(args)

        #系统类型
        os_type = self.UsePlatform(args)
        if os_type == 3:
            return public.returnMsg('-1', '仅支持linux和windows操作系统')

        confData = self.__get_increase_json(args, 'data')
        confData = json.dumps(confData, default=self.obj2dict)
        self.__save_increase_json(args, 'os_type', os_type)
        return public.returnMsg('1', confData)
        #系统位数
        digit = self.UsePlaceform(args)
        self.__save_increase_json(args, 'digit', digit)
        newData = {}

        for dt in data:
            for olddt in confData:
                if dt.echo == olddt.echo and dt is olddt:
                    data.remove(dt)

        data.extend(confData)

        self.__save_increase_json(args, 'data', data)

        logintime = time.time()
        fileName = str(os_type) + "_" + str(digit) + "_" + str(
            time.strftime('%Y_%m_%d_%H_%M_%S', time.localtime(int(logintime))))

        #打包
        # t.create_task("备份文件打包",3,self.__plugin_path + 'tmp/',{"sfile":"reduction_zip","dfile":self.__plugin_path + "tmp/reduction_zip/test.zip","z_type":"rar"})

        z = zipfile.ZipFile(
            self.__plugin_path + "tmp/reduction_zip/" + fileName + ".zip", 'w',
            zipfile.ZIP_DEFLATED)
        z.write(self.__plugin_path + 'tmp/increase_data.json',
                arcname="increase_data.json")
        z.close()

        return public.returnMsg(
            '1', self.__plugin_path + "tmp/reduction_zip/test.zip")

    # 保存为json文件
    # @param key 要被修改或添加的配置项[可选]
    # @param value 配置值[可选]
    def __save_increase_json(self, args, key=None, value=None):
        # 是否需要初始化配置项
        if not self.__increase_config:
            self.__increase_config = {}

        # 是否需要设置配置值
        if key:
            self.__increase_config[key] = value

        # 写入到配置文件
        config_file = self.__plugin_path + 'tmp/increase_data.json'
        public.WriteFile(config_file, json.dumps(self.__increase_config))
        return True

    # 读取json文件
    # @param key 取指定配置项，若不传则取所有配置[可选]
    # @param force 强制从文件重新读取配置项[可选]
    def __get_increase_json(self, args, key=None, force=False):

        # 是否需要初始化配置项
        if not self.__increase_config or force:
            config_file = self.__plugin_path + 'tmp/increase_data.json'
            if not os.path.exists(config_file):
                return None
            f_body = public.ReadFile(config_file)
            if not f_body:
                return None
            self.__increase_config = json.loads(f_body)
        # 取指定配置项
        if key:
            if key in self.__increase_config:
                return self.__increase_config[key]
            return None
        return self.__increase_config

    # 获取备份文件列表
    def get_bakfiles(self, args):
        file_list = []
        for root, dirs, files in os.walk(self.__plugin_path +
                                         "tmp/reduction_zip/"):
            for file in files:
                file_path = os.path.join(root, file)
                file_date = datetime.datetime.fromtimestamp(
                    os.path.getmtime(file_path)).strftime('%Y-%m-%d %H:%M:%S')
                hard_path = self.__plugin_path + "tmp/reduction_zip/" + file

                file_obj = {
                    'hard_path':
                    hard_path,
                    'file':
                    file,
                    'date':
                    file_date,
                    'time':
                    int(
                        time.mktime(
                            time.strptime(file_date, "%Y-%m-%d %H:%M:%S")))
                }
                file_list.append(file_obj)
        file_list = sorted(file_list, key=lambda k: k['time'])
        file_list.reverse()
        return public.returnMsg('1', file_list)

    def delete_backup(self, args):
        if not 'delete_file' in args:
            args.delete_file = ''
        if args.delete_file == '':
            return public.returnMsg('0', '文件不存在，刷新页面重试！')

        path = self.__plugin_path + "tmp/reduction_zip/" + args.delete_file

        if os.path.exists(path):  # 如果文件存在
            # 删除文件，可使用以下两种方法。
            os.remove(path)
            return public.returnMsg('1', '删除成功！')
        else:
            return public.returnMsg('0', '文件不存在，刷新页面重试！')

    # def import_restore(self, args):

    #   return public.returnMsg('1','删除成功！')
    #还原操作
    # def suc_reduction(self, args):
    #     if not 'multipleSelection' in args:
    #         args.multipleSelection = ''
    #     multipleSelection = json.loads(args.multipleSelection)
    #     if not os.path.exists(self.__plugin_path + 'tmp/import/data.json'):
    #         return {'status': 0, 'msg': '未找到导入的文件，请重新导入!'}
    #     import_arr= self.__get_import_json( args)
    #     # return {'status': 0, 'msg': '未找到导入的文件，请重新导入!','imp':import_arr['data']}
    #     for mlt in multipleSelection:
    #         for imp in import_arr['data']:
    #             # return {'status': 0, 'msg': '未找到导入的文件，请重新导入!','imp':imp['where_minute']}
    #             if mlt['id']==imp['id']:
    #                 pdata = {
    #                     'name':imp['name']!='null' and imp['name'] or "",
    #                     'type':imp['type']!='null' and imp['type'] or "",
    #                     'where1':imp['where1']!='null' and imp['where1'] or "",
    #                     'where_hour':imp['where_hour']!='null' and imp['where_hour'] or "",
    #                     'where_minute':imp['where_minute']!='null' and imp['where_minute'] or "",
    #                     # 'echo':imp['echo']!='null' and imp['echo'] or "",
    #                     'save':imp['save']!='null' and imp['save'] or "",
    #                     'addtime':imp['addtime']!='null' and imp['addtime'] or "",
    #                     'status':imp['status']!='null' and imp['status'] or "",
    #                     'backupTo':imp['backupTo']!='null' and imp['backupTo'] or "",
    #                     'sName':imp['sName']!='null' and imp['sName'] or "",
    #                     'sBody':imp['sBody']!='null' and imp['sBody'] or "",
    #                     'sType':imp['sType']!='null' and imp['sType'] or "",
    #                     'urladdress':imp['urladdress']!='null' and imp['urladdress'] or ""
    #                 }
    #                 # http://127.0.0.1:9088/crontab?action=AddCrontab
    #                 add_url=public.GetHost()+":"+public.GetHost(True)+"/crontab?action=AddCrontab"

    #                 #  request_token = request.cookies.get('request_token')
    #                 #     if session['request_token'] != request_token: return False
    #                 #     http_token = request.headers.get('x-http-token')
    #                 #     if not http_token: return False
    #                 #     if http_token != session['request_token_head']: return False
    #                 #     cookie_token = request.headers.get('x-cookie-token')
    #                 #     if cookie_token != session['request_token']: return Fa
    #                 request_token = request.cookies.get('request_token')
    #                 http_token = request.headers.get('x-http-token')
    #                 cookie_token = request.headers.get('x-cookie-token')
    #                 headers = {
    #                         # "Content-Type":"text/html",
    #                         "Content-Type":"application/x-www-form-urlencoded; charset=UTF-8",
    #                         "request_token":request_token,
    #                         "x-http-token":http_token,
    #                         "x-cookie-token":cookie_token
    #                     }
    #                 http_body=public.HttpPost(add_url,pdata,60,headers)
    #                 return {'status': 0, 'msg': '此文件不是一个有效的备份文件!','m':http_body}

    #                 # crontab.AddCrontab(pdata)
    #                 # return {'status': 0, 'msg': '此文件不是一个有效的备份文件!','m':pdata}
    #                 # public.M('crontab').insert(pdata)

    #     return {'status': 0, 'msg': '此文件不是一个有效的备份文件!','m':multipleSelection}
    def local_reduction(self, args):
        pathname = self.__plugin_path + '/tmp/reduction_zip/'

        if not 'reduction_file' in args:
            args.reduction_file = ''
        try:

            filename = pathname + args.reduction_file
            #解压

            #y原生解压
            z = zipfile.ZipFile(filename, 'r')

            for file in z.namelist():
                z.extract(file, self.__plugin_path + 'tmp/import')

            z.close()
            if not os.path.exists(self.__plugin_path + 'tmp/import/data.json'):
                return {'status': 0, 'msg': '此文件不是一个有效的备份文件!'}

            #系统类型
            os_type = self.UsePlatform(args)

            #系统位数
            digit = self.UsePlaceform(args)

            import_os_type = self.__get_import_json(args, 'os_type')
            if import_os_type != os_type:
                return {'status': 0, 'msg': '此备份文件适配的操作系统类型与当前服务器操作系统类型不符!'}
            import_digit = self.__get_import_json(args, 'digit')
            if import_digit != digit:
                return {'status': 0, 'msg': '此备份文件适配的系统位数与当前服务器操作系统位数不符！'}

            import_arr = self.__get_import_json(args)

            return {'status': 1, 'msg': '请选择要导入的任务!', 'import_arr': import_arr}

        except IOError:
            return {'status': 0, 'msg': '无效文件!'}
        return {'status': 0, 'msg': '无效文件!'}

    def import_restore(self, args):
        filename = self.__plugin_path + '/tmp/import/'

        logintime = time.time()
        importName = time.strftime('%Y_%m_%d_%H_%M_%S',
                                   time.localtime(int(logintime)))
        try:
            from flask import request
            file = request.files['import']

            if file.filename[-7:] == '.tar.gz':
                filename = filename + importName + file.filename[-7:]
            elif file.filename[-4:] == '.zip':
                filename = filename + importName + file.filename[-4:]

            os.system('rm -rf ' + self.__plugin_path + 'tmp/import')
            os.system('mkdir -p ' + self.__plugin_path + 'tmp/import')

            file.save(filename)

            # if file.filename[-7:] == '.tar.gz' or file.filename[-4:] == '.zip':
            if file.filename[-4:] == '.zip':
                filename = self.__plugin_path + 'tmp/import/' + importName + '.zip'
                # import panelTask
                #解压
                # panelTask.bt_task()._unzip(filename, self.__plugin_path +
                #  '/tmp/import', '', '/dev/null')

                #y原生解压
                z = zipfile.ZipFile(filename, 'r')
                # for item in z.namelist():
                #     print(item)
                # z.extractall()
                for file in z.namelist():
                    z.extract(file, self.__plugin_path + 'tmp/import')
                # z.extract('data.json',self.__plugin_path + 'tmp/import')
                z.close()
                if not os.path.exists(self.__plugin_path +
                                      'tmp/import/data.json'):
                    return {'status': 0, 'msg': '此文件不是一个有效的备份文件!'}

                # success, failed = public.ExecShell(
                #     'find %s/tmp/import -name data' % self.__plugin_path)

                # if success.strip() != '':
                #   #移动文件并修改所属者
                #     os.system('mv -f %s %s' % (success.strip(),
                #                                self.__plugin_path+self.__exe_name))
                #     os.system('chown root:root ' +
                #               self.__plugin_path+self.__exe_name)
                #     # os.system('chmod +x ' + self.__plugin_path+self.__exe_name)
                #     # os.system('rm -rf ' + self.__plugin_path + '/tmp/import')
                #     # os.system('rm -rf ' + filename)
                #     if os.path.isfile(self.__plugin_path+self.__exe_name):
                #         public.ExecShell("%soperation.sh service %s" %
                #                          (self.__plugin_path, 'start'))
                #         return {'status': 1, 'msg': '安装成功！'}
                #读取文件

                #系统类型
                os_type = self.UsePlatform(args)

                #系统位数
                digit = self.UsePlaceform(args)

                import_os_type = self.__get_import_json(args, 'os_type')
                if import_os_type != os_type:
                    return {
                        'status': 0,
                        'msg': '此备份文件适配的操作系统类型与当前服务器操作系统类型不符!'
                    }

                import_digit = self.__get_import_json(args, 'digit')
                if import_digit != digit:
                    return {'status': 0, 'msg': '此备份文件适配的系统位数与当前服务器操作系统位数不符！'}

                import_arr = self.__get_import_json(args)
                # return {'status': 0, 'msg': json.dumps(import_arr)}

                return {
                    'status': 1,
                    'msg': '请选择要导入的任务!',
                    'import_arr': import_arr
                }

            else:
                return {'status': 0, 'msg': '无效文件!', 'aa': file.filename}

        except IOError:
            return {'status': 0, 'msg': '无效文件!'}
        return {'status': 0, 'msg': '无效文件!'}

    ##下面的读取方法比较冗余，抽空优化一下，本来只要写一遍的读取方法却写了2遍

    # 读取json文件
    # @param key 取指定配置项，若不传则取所有配置[可选]
    # @param force 强制从文件重新读取配置项[可选]
    def __get_import_json(self, args, key=None, force=False):
        # 是否需要初始化配置项
        if not self.__config or force:
            config_file = self.__plugin_path + 'tmp/import/data.json'
            if not os.path.exists(config_file):
                return None
            f_body = public.ReadFile(config_file)
            if not f_body:
                return None
            self.__config = json.loads(f_body)
        # 取指定配置项
        if key:
            if key in self.__config:
                return self.__config[key]
            return None
        return self.__config

    # 保存为json文件
    # @param key 要被修改或添加的配置项[可选]
    # @param value 配置值[可选]
    def __save_json(self, args, key=None, value=None):
        # 是否需要初始化配置项
        if not self.__config:
            self.__config = {}

        # 是否需要设置配置值
        if key:
            self.__config[key] = value

        # 写入到配置文件
        config_file = self.__plugin_path + 'tmp/data.json'
        public.WriteFile(config_file, json.dumps(self.__config))
        return True

    # 读取json文件
    # @param key 取指定配置项，若不传则取所有配置[可选]
    # @param force 强制从文件重新读取配置项[可选]
    def __get_json(self, args, key=None, force=False):

        # 是否需要初始化配置项
        if not self.__config or force:
            config_file = self.__plugin_path + 'tmp/data.json'
            if not os.path.exists(config_file):
                return None
            f_body = public.ReadFile(config_file)
            if not f_body:
                return None
            self.__config = json.loads(f_body)
        # 取指定配置项
        if key:
            if key in self.__config:
                return self.__config[key]
            return None
        return self.__config

    # 自定义访问权限检查
    # 一但声明此方法，这意味着可以不登录面板的情况下，直接访问此插件，由_check方法来检测是否有访问权限
    # 如果您的插件必需登录后才能访问的话，请不要声明此方法，这可能导致严重的安全漏洞
    # 如果权限验证通过，请返回True,否则返回 False 或 public.returnMsg(False,'失败原因')
    # 示例未登录面板的情况下访问get_logs方法： /demo/get_logs.json  或 /demo/get_logs.html (使用模板)
    # 可通过args.fun获取被请求的方法名称
    # 可通过args.client_ip获取客户IP
    # def _check(self,args):
    #token = '123456'
    #limit_addr = ['192.168.1.2','192.168.1.3']
    # if args.token != token: return public.returnMsg(False,'Token验证失败!')
    # if not args.client_ip in limit_addr: return public.returnMsg(False,'IP访问受限!')
    # return redirect('/login')
    # return True
    # 判断系统是linux还是windows
    def UsePlatform(self, args):
        sysstr = platform.system()
        if sysstr == "Windows":
            return 'windows'
        elif sysstr == "Linux":
            return 'linux'
        else:
            return 3

    # 判断操作系统位数
    def UsePlaceform(self, args):
        import struct

        return struct.calcsize("P") * 8

    # 清理运行日志
    def clear_runlog(self, args):
        public.ExecShell('cat /dev/null > %s' % self.__run_log)
        return public.returnMsg(True, '清理成功')

    # 获取面板日志列表
    # 传统方式访问get_logs方法：/plugin?action=a&name=demo&s=get_logs
    # 使用动态路由模板输出： /demo/get_logs.html
    # 使用动态路由输出JSON： /demo/get_logs.json

    def get_logs(self, args):
        filename = self.__run_log
        if os.path.isfile(filename):
            # 宝塔封装的 public.ReadFile 不适合读取大文件
            success, failed = public.ExecShell('tail -n 1000 %s' % filename)
            if success.strip() != '':
                return public.returnMsg(True, success.strip())
            return public.returnMsg(True, '暂无运行日志')

    # 读取配置项(插件自身的配置文件)
    # @param key 取指定配置项，若不传则取所有配置[可选]
    # @param force 强制从文件重新读取配置项[可选]
    def __get_config(self, args, key=None, force=False):
        # 判断是否从文件读取配置

        if not self.__config or force:
            config_file = self.__plugin_path + 'config.json'
            if not os.path.exists(config_file):
                return None
            f_body = public.ReadFile(config_file)
            if not f_body:
                return None
            self.__config = json.loads(f_body)
        # 取指定配置项
        if key:
            if key in self.__config:
                return self.__config[key]
            return None
        return self.__config

    # 设置配置项(插件自身的配置文件)
    # @param key 要被修改或添加的配置项[可选]
    # @param value 配置值[可选]
    def __set_config(self, args, key=None, value=None):
        # 是否需要初始化配置项
        if not self.__config:
            self.__config = {}

        # 是否需要设置配置值
        if key:
            self.__config[key] = value

        # 写入到配置文件
        config_file = self.__plugin_path + 'config.json'
        public.WriteFile(config_file, json.dumps(self.__config))
        return True
