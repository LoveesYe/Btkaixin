import sys,os,shutil
panelPath = os.getenv('BT_PANEL')
os.chdir(panelPath)
sys.path.append("class/")
import public,json

__name = 'btrenwubeifen'
__path = panelPath + '/plugin/' + __name

def install():  

    if not os.path.exists(__path+'/tmp'): os.makedirs(__path+'/tmp')
    if not os.path.exists(__path+'/tmp/import'): os.makedirs(__path+'/tmp/import')
    if not os.path.exists(__path+'/tmp/reduction_zip'): os.makedirs(__path+'/tmp/reduction_zip')


def update():
    install()

def uninstall():
    shutil.rmtree(__path)


if __name__ == "__main__":
    opt = sys.argv[1]
    if opt == 'update':
        update()
    elif opt == 'uninstall':
        uninstall()
    else:
        install()
