#!/bin/bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH

#配置插件安装目录
install_path=/www/server/panel/plugin/btrenwubeifen
install_path_tmp=$install_path'/tmp'

#安装
Install() {
  echo '正在安装...' 
  #==================================================================
  Is_64bit=$(getconf LONG_BIT)
  #获取操作系统是否64位
  mkdir -p ${install_path}
  #设置权限
  


  #==================================================================
  #service giteaser start
  

  echo '================================================'
  echo '安装完成'


}

#卸载
Uninstall() {
 
  if [ "${PM}" == "yum" ] || [ "${PM}" == "dnf" ]; then
    su - root <<EOF
rm -rf $install_path
EOF
  elif [ "${PM}" == "apt" ]; then
    sudo rm -rf $install_path
  fi

}

#判断系统发行版本
Get_Dist_Name() {
  if grep -Eqii "CentOS" /etc/issue || grep -Eq "CentOS" /etc/*-release; then
    DISTRO='CentOS'
    PM='yum'
  elif grep -Eqi "Red Hat Enterprise Linux Server" /etc/issue || grep -Eq "Red Hat Enterprise Linux Server" /etc/*-release; then
    DISTRO='RHEL'
    PM='yum'
  elif grep -Eqi "Aliyun" /etc/issue || grep -Eq "Aliyun" /etc/*-release; then
    DISTRO='Aliyun'
    PM='yum'
  elif grep -Eqi "Fedora" /etc/issue || grep -Eq "Fedora" /etc/*-release; then
    DISTRO='Fedora'
    PM='yum'
  elif grep -Eqi "Debian" /etc/issue || grep -Eq "Debian" /etc/*-release; then
    DISTRO='Debian'
    PM='apt'
  elif grep -Eqi "Ubuntu" /etc/issue || grep -Eq "Ubuntu" /etc/*-release; then
    DISTRO='Ubuntu'
    PM='apt'
  elif grep -Eqi "Raspbian" /etc/issue || grep -Eq "Raspbian" /etc/*-release; then
    DISTRO='Raspbian'
    PM='apt'
  else
    DISTRO='unknow'
  fi
  echo $DISTRO
  echo $PM
}


Get_Dist_Name
#操作判断
if [ "${1}" == 'install' ]; then
  Install
elif [ "${1}" == 'uninstall' ]; then
  Uninstall
else
  echo 'Error!'
fi
