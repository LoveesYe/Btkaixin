// $("#aemail").change(function(e){
//     console.log('gaibian')
//     console.log(e)
// });
 $("#aemail").on('input',function(){
     console.log($("#aemail").val())
     
    var ischecked = $("input[name='aache']").is(':checked');
    if(ischecked === true){
        $("#copyemail").val($("#aemail").val()) 
    }else{
        console.log('无需与发件邮箱相同')
    }
    
     
    })

// $("#aemail").bind('input propertychange',function () {
//     console.log('gaibian')
//     console.log(e)
// 		var summary=$(this).val();
// 		$(".textarea-length").html(summary.length);
// });

// $("#aemail").keydown(function(){
//      console.log('gaibian')
// });
// $("#aemail").mouseup(function(){
//      console.log('gaibian')
// });
// $("#aemail").blur(function(){
//      console.log('gaibian')
// });
// $("input").blur(function(){
//   $("input").css("background-color","#D6D6FF");
// });




        
        layui.use(['layer', 'jquery', 'form'], function () {
			var layer = layui.layer,
					$ = layui.jquery,
					form = layui.form;
 
			form.on('select(email)', function(data){
			    console.log(data.value)
			    if(data.value == 1){
			        
			        $("#aserver").val('smtp.qq.com')
                    $("#aport").val('465')
                    
                     $("#aserver").css({"background":"#f1f1f1"});
                     $("#aport").css({"background":"#f1f1f1"});
                    
			    }
			    else  if(data.value == 2){
			         $("#aserver").val('smtp.163.com')
                    $("#aport").val('465')
                    
                    $("#aserver").css({"background":"#f1f1f1"});
                     $("#aport").css({"background":"#f1f1f1"});
			    }
			    
			    else  if(data.value == 3){
			         $("#aserver").val('smtp.126.com')
                    $("#aport").val('465')
                    
                    $("#aserver").css({"background":"#f1f1f1"});
                     $("#aport").css({"background":"#f1f1f1"});
			    }
			    else  if(data.value == 4){
			         $("#aserver").val('smtp.qq.com')
                    $("#aport").val('465')
                    
                    $("#aserver").css({"background":"#f1f1f1"});
                     $("#aport").css({"background":"#f1f1f1"});
			    }
			    else  if(data.value == 5){
			         $("#aserver").val('smtp.139.com')
                    $("#aport").val('465')
                    
                    $("#aserver").css({"background":"#f1f1f1"});
                     $("#aport").css({"background":"#f1f1f1"});
			    }
			     else  if(data.value == 6){
			         $("#aserver").val('')
                    $("#aport").val('')
                    
                     $("#aserver").css({"background":"#fff"});
                     $("#aport").css({"background":"#fff"});
			    }
			   
			});
			form.on('checkbox(ischeck)', function(data){
			    console.log(data)
			})
			
		});
        
        $("#ischeck").on("click",function (data) {
             var emailtext = $("#aemail").val()
            var aachecked = $("input[name='aache']").is(':checked');
            
            console.log('是否勾选：'+aachecked)
            if(aachecked){
                $('#copyemail').val(emailtext)
                
                $('#copyemailid').css({"height":"0px","overflow":"hidden"})
            }else{
                $('#copyemailid').css({"height":"auto","overflow":"visible"})
            }
        })
        
       $('form').submit(function (event) {
            let aadata =  $('form').serialize();  
            // console.log(JSON.parse('aadata') )
            // 终止默认事件的传递
            // event.preventDefault()
            
            console.log($('#aport').val())
            
            if($('#aport').val() >0 &&  $('#aport').val() < 65536){
                $(document).ready(function(){
                    parent.$.post("/plugin?action=a&s=mailconfig&name=baktomail",aadata,function(result){
                        layer.msg('提交成功')
                    })
                })
            }else{
                layer.msg("发送端口错误");
            }
            
            
           
          
            return false;
        })