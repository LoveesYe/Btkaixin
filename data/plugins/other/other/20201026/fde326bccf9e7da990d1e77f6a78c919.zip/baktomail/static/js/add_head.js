layui.use([ 'layer', 'form', 'element' ], function() {
		var $ = layui.jquery, 
		layer = layui.layer, 
		form = layui.form, 
		element = layui.element;
		/* 自适应页面 */
// 		resizeTheWindow();
		/* 视窗变化监听 */
// 		window.onresize = function() {
// 			resizeTheWindow();
// 		}
		$(document).ready(function(){
		 parent.$.post("/plugin?action=a&s=readmailcfg&name=baktomail",{},function(result){
		     if(result.data == ''){
		         layer.msg('请先完整填写邮件配置并保存')
		        $("#ischeckinput").prop("checked",true);  
                form.render();
                $('#copyemailid').css({"height":"0px","overflow":"hidden"})
                $("#aserver").val('smtp.qq.com')
                $("#aport").val('465')
                
		     }else{
                        let adata = JSON.parse(result.data)
                        var select = 'dd[value=' + adata.smtp + ']';
                        $('#smtp').siblings("div.layui-form-select").find('dl').find(select).click();
                        
                        setTimeout(function() {
                                $(".layui-input").eq(1).text(adata.smtp);
                                $('#smtp').find("option[value='" + adata.smtp + "']").attr('selected','selected');
                                $(".layui-input").eq(0).val($('#smtp').find("option[value='" + adata.smtp + "']")[0].text);
                                
                                $("#aserver").val(adata.server)
                                $("#aemail").val(adata.email)
                                $("#apassword").val(adata.password)
                                $("#aport").val(adata.port)
                                
                                if(adata.bakmail == adata.email || adata.bakmail==''){
                                    $("#copyemail").val(adata.bakmail)
                                    $("#ischeckinput").prop("checked",true);  
                                    form.render();
                                    
                                    $('#copyemailid').css({"height":"0px","overflow":"hidden"})
                                    
                                    
                                       
                                }else{
                                    $('#copyemailid').show();
                                    $("#copyemail").val(adata.bakmail)
                                    $("#ischeckinput").prop("checked",false); 
                                    $(".layui-form-checkbox").removeClass("layui-form-checked");
                                    
                                     $('#copyemailid').css({"height":"auto","overflow":"visible"})
                                }
                               
                                
                        },100)
                        
                      
		     }            
        })
		});
	});
    function del(id){
        console.log('wwwwwwwwwwwwww')
    }
     $('form').submit(function (event) {
        console.log($('form').serialize())
        let aadata =  $('form').serialize();  
        // 终止默认事件的传递
        event.preventDefault()
                    
  })
    function getQueryVariable(variable)
        {
               var query = window.location.search.substring(1);
               var vars = query.split("&");
               for (var i=0;i<vars.length;i++) {
                       var pair = vars[i].split("=");
                       if(pair[0] == variable){return pair[1];}
               }
               return(false);
        }
    
    var headertext = parent.$.ajaxSettings.headers
    
    layui.use('table', function(){
      var table = layui.table;
      table.render({
        elem: '#test'
        ,width:'360'
        ,height:'600'
        ,url:'/plugin?action=a&s=dirlist&name=baktomail'
    ,method: 'post' //如果无需自定义HTTP类型，可不加该参数
//   ,request: {
//       'x-cookie-token':getQueryVariable("x-cookie-token"),
//                 'x-http-token':getQueryVariable("x-http-token")
//   } //如果无需自定义请求参数，可不加该参数
//   ,response: {
//       'x-cookie-token':getQueryVariable("x-cookie-token"),
//                 'x-http-token':getQueryVariable("x-http-token")
//   } //如果无需自定义数据响应名称，可不加该参数
    ,headers:{
        'x-cookie-token':headertext[Object.keys(headertext)[1]],
                'x-http-token':headertext[Object.keys(headertext)[0]]
    }
        // ,url:'/login.php?m=admin&c=Points&a=query&actid='+getQueryVariable("actid")
        ,cellMinWidth: 80 //全局定义常规单元格的最小宽度，layui 2.2.1 新增
        ,cols: [[
            {type:'checkbox',toolbar:'11111',style:'border-right:#000000 0px solid;'}
        //   ,{field:'id', width:80, title: 'ID', sort: true,style:'border-right:#000000 0px solid;'}
        //   ,{field:'icon', width:60, title: '类型',style:'border-right:#000000 0px solid;'}
          ,{field:'title', width:310, title: '请选择要备份的文件夹或者文件',event:'eventee' }
        ]]
         ,page: false
         ,limit:20
          ,id: 'testReload'
      });
      
var $ = layui.$, active = {
    getCheckData: function(){ //获取选中数据
    console.log('aaa4544444')
      var checkStatus = table.checkStatus('testReload')
      ,data = checkStatus.data;
    //   layer.alert(JSON.stringify(data));
      console.log(data)
      
      var dirslist = []
      $.each(data, function (k, v) {  // 这里的函数参数是键值对的形式，k代表键名，v代表值
console.log(v.dirname)
if(v.dirname){
    dirslist.push(v.dirname)
}
          
      });
console.log(dirslist)
//       parent.request_plugin('baktomail', 'recdir',dirs:data,  { p: 1, callback: 'demo.recdir' },function (rdata){
// console.log(rdata)
//       });
    if(dirslist.length >0){
        
        
        parent.$.post("/plugin?action=a&s=readmailcfg&name=baktomail",{},function(result){
           
            if(result.data == ''){
                layer.msg('请先完整填写邮件配置并保存')
            }else{
                 let adata = JSON.parse(result.data)
                parent.request_plugin('baktomail', 'addtask', { p: 1, callback: 'tomail.addtask' ,dirs:JSON.stringify(dirslist)}, function (rdata) {
                    $("#restext").html(rdata.data.task );
                });
            }
        })
        
            
    }else{
        console.log('暂无选择')
        layer.msg('请从左边至少选择1个文件夹或者文件')
    }
      
    }
    ,getCheckDatacopy: function(){ //获取选中数目
       
                         var copytext =$("#restext").html(); 
             console.log(copytext)
                     $("#hide").val(copytext);//这里可以获取动态数据赋值给$("#hide").val()
                      $("#hide").select();
                      try {var state = document.execCommand("copy");}
                      catch(err){var state = false;}
                      if(state){
                       layer.msg("复制成功")
                      }else{
                        layer.msg("复制失败")
                      }
                                
        
    }
    ,isAll: function(){ //验证是否全选
      var checkStatus = table.checkStatus('idTest');
      layer.msg(checkStatus.isAll ? '全选': '未全选')
    }
  };
  
  $('.demoTable .layui-btn').on('click', function(){
    var type = $(this).data('type');
    active[type] ? active[type].call(this) : '';
  });
  
        $('#tofile').on('click', function(){
              console.log('sendoneclick')
             let titletexttwo = $("#blinput").val();
            console.log(titletexttwo)
            
            
            
                                table.reload('testReload', {
                                        // page: {
                                        //   curr: 1 //重新从第 1 页开始
                                        // }
                                        // ,
                                        where: {
                                            dir:titletexttwo
                                        //   keyword: demoReload.val(),
                                        //   type:$("#points_exchange").find("option:selected").val()
                                        }
                                      }, 'data');
          });
      
      table.on("checkbox(test)",function(data){
          console.log('radio')
          console.log(data)
      })
      
      
        table.on("tool(test)",function(obj){
          console.log('eeeeeeeeeee')
          console.log(obj)
          console.log(obj.event)
          if(obj.event == 'eventee'){
                                $("#blinput").val(obj.data.dirname);
                                let titletext
                                if(obj.data.title.indexOf('上级目录')>-1){
                                    titletext = obj.data.dirname
                                }else{
                                    titletext = obj.data.dirname
                                }
                                
                                if(obj.data.isfile == 0){
                                    table.reload('testReload', {
                                        // page: {
                                        //   curr: 1 //重新从第 1 页开始
                                        // }
                                        // ,
                                        where: {
                                            dir:titletext
                                        //   keyword: demoReload.val(),
                                        //   type:$("#points_exchange").find("option:selected").val()
                                        }
                                      }, 'data');
                             }
          }
      })
      
      table.on('row(test)', function (obj) {
            console.log(obj.data.title.indexOf('上级目录')>-1)
        
        //头工具栏事件
  table.on('toolbar(test)', function(obj){
      console.log(obj)
    var checkStatus = table.checkStatus(obj.config.id);
    
    
    
      //   标注选中行样式
        
      obj.tr.addClass("layui-table-click").siblings().removeClass("layui-table-click");

      //选中行，勾选复选框

      obj.tr.find("div.layui-unselect.layui-form-checkbox")[1].click();
    
    
    switch(obj.event){
      case 'getCheckData':
        var data = checkStatus.data;
        layer.alert(JSON.stringify(data));
      break;
      case 'getCheckLength':
        var data = checkStatus.data;
        layer.msg('选中了：'+ data.length + ' 个');
      break;
      case 'isAll':
        layer.msg(checkStatus.isAll ? '全选': '未全选');
      break;
      
      //自定义头工具栏右侧图标 - 提示
      case 'LAYTABLE_TIPS':
        layer.alert('这是工具栏右侧自定义的一个图标按钮');
      break;
    };
  });

   });
      
      
    });
    
    $('#addgift').on('click', function(){
       layer.open({
                type: 2,
                title: "增减积分",
                area: ['100%', '100%'],
                content: '/login.php?m=admin&c=points&a=add',
                success: function (layero, index) {
                    var body = layer.getChildFrame('body', index);
                    var iframeWin = window[layero.find('iframe')[0]['name']]; //得到iframe页的窗口对象，执行iframe页的方法：iframeWin.method();比如iframeWin.alert11();
                    body.find('.btn').hide();//隐藏class为btn的元素
                    // window.location.reload() 
                }
        });
    });
  
    // 下拉选择框
    $(document).on('change', '#points_exchange', function(){
        // 获取value值赋值给type便于传递给后台
        var type = $("#points_exchange").find("option:selected").val();
        
         $("#searchclick").trigger("click");
        console.log(type)
    });
    
    // 搜索按钮的点击事件
    
    
     $('#tofile').on('click', function(){
            console.log('toto')
            let titletexttwo = $("#blinput").val();
            console.log(titletexttwo)
            table.reload('testReload', {
                    // page: {
                    //   curr: 1 //重新从第 1 页开始
                    // }
                    // ,
                    where: {
                        dir:titletexttwo
                    }
                  }, 'data');
            })