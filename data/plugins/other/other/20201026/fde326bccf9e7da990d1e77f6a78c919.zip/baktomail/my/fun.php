<?php
/*
　　 * 分割文件 
　　 * 默认大小 2M=10485760/5
　　 */
function filesplit($fname)
{
    $i  = 0;                 //分割的块编号
    $fp  = fopen($fname,"rb");      //要分割的文件
    ////$file = fopen("split_hash.txt","a");    //记录分割的信息的文本文件，实际生产环境存在redis更合适
    while(!feof($fp)){
        $handle = fopen($fname.".{$i}","wb");
        fwrite($handle,fread($fp,49*10485760/10));//切割的块大小 2m
        ////fwrite($file,"hadoop.{$i}.sql\r\n");
        fclose($handle);
        unset($handle);
        $i++;
    }
    fclose ($fp);
    ////fclose ($file);
    ////echo "ok";
}

function getmcfg()
{
    $mailconfig=file_get_contents(dirname(__FILE__).'/config/mail.json.php');
    $mailconfig=str_replace('<?php /*','',$mailconfig);
    $mailconfig=str_replace('*/ ?>','',$mailconfig);
    return json_decode($mailconfig);
}

function getdirs($param_arr)
{
    $json=file_get_contents(dirname(__FILE__).'/task/'.$param_arr[t].'.json.php');
      
    $json=str_replace('<?php /*','',$json);$json=str_replace('*/ ?>','',$json);
    
    $jsonobj=json_decode($json);
    
    return json_decode($jsonobj->dirs);
}

function zipfile($bakname,$varr,$v)
{
    $archive = new PclZip($bakname);
	        
	        unset($varr[count($varr)-1]);
	        $rpath=implode('/',$varr);
	        
	        //echo $rpath;
	        
            $v_list = $archive->create($v,
            PCLZIP_OPT_REMOVE_PATH,$rpath,
            PCLZIP_OPT_ADD_PATH,'');
            if($v_list==0){
                die("Error:".$archive->errorInfo(true));
            }
}

?>