<?php
function filecombine($dir)
{
    $fzero=glob($dir."/*.0")[0];
    $fcname=substr($fzero, 0, strrpos($fzero, "."));
    $list=glob("$fcname.*");
    foreach($list as $k=>$v){
        $list[$k]=$fcname.".$k";
    }
    //$fcname=str_replace(strrchr($filename, "."),"",$fzero); 
    
    ////var_dump($list);die;

    ////$hash = file_get_contents("split_hash.txt"); //读取分割文件的信息
    ////$list = explode("\r\n",$hash);
    $fp = fopen("$fcname","ab");    //合并后的文件名
    foreach($list as $value){
      if(!empty($value)) {
        $handle = fopen($value,"rb");
        fwrite($fp,fread($handle,filesize($value)));
        fclose($handle);
        unset($handle);
      }
    }
    fclose($fp);

}


filecombine(dirname(__FILE__).'/combine');

?>