<?php
//压给备份到邮箱
//@author 芯湖<329818918@qq.com>

//必需面向对象编程，类名必需为bt_main
//允许面板访问的方法必需是public方法
//通过_get函数获取get参数,通过_post函数获取post参数
//可在public方法中直接return来返回数据到前端，也可以任意地方使用echo输出数据后exit();
//可在./php_version.json中指定兼容的PHP版本，如：["56","71","72","73"]，没有./php_version.json文件时则默认兼容所有PHP版本，面板将选择 已安装的最新版本执行插件
//允许使用模板，请在./templates目录中放入对应方法名的模板，如：test.html，请参考插件开发文档中的【使用模板】章节
//支持直接响应静态文件，请在./static目录中放入静态文件，请参考插件开发文档中的【插件静态文件】章节

class bt_main{
	//不允许被面板访问的方法请不要设置为公有方法

	public function test(){
		//_post()会返回所有POST参数，要获取POST参数中的username参数，请使用 _post('username')
		//可通过_version()函数获取面板版本
		//可通过_post('client_ip') 来获取访客IP

		//常量说明：
		//PLU_PATH 插件所在目录
		//PLU_NAME 插件名称
		//PLU_FUN  当前被访问的方法名称
		return array(
			_get(),
			_post(),
			_version(),
			PLU_FUN,
			PLU_NAME,
			PLU_PATH
		);
	}


	//获取phpinfo
	public function phpinfo(){
	    
		return phpinfo();
	}
	
	//邮箱配置
	public function mailconfig()
	{
	    $data=_post();
	    $fpc=file_put_contents(PLU_PATH.'/my/config/mail.json.php','<?php /*'.json_encode($data).'*/ ?>');
	    if($fpc)
	    {
	        return ['code'=>0,'msg'=>'成功','data'=>$data];
	    }
	    else
	    {
	        return ['code'=>1,'msg'=>'失败','data'=>$fpc];
	    }
	}
	
	//读取邮箱配置
	public function readmailcfg()
	{
	    @$json=file_get_contents(PLU_PATH.'/my/config/mail.json.php');
	    $json=str_replace('<?php /*','',$json);$json=str_replace('*/ ?>','',$json);
	    if($json)
	    {
	        return ['code'=>0,'msg'=>'成功','data'=>$json];
	    }
	    else
	    {
	        return ['code'=>1,'msg'=>'失败','data'=>$json];
	    }
	}
	
	
	public function combine()
	{
	    $comdir=PLU_PATH.'/my/combine';
	    $runcode="php ".PLU_PATH."/my/combine.php";
	    return ['code'=>0,'msg'=>'成功','data'=>['comdir'=>$comdir,'runcode'=>$runcode]];
	}
	
	//接收选择的目录数组
	public function addtask()
	{
        $json=json_encode(_post());
        $now=date('Ymd_His');
        file_put_contents(PLU_PATH.'/my/task/'.$now.'.json.php','<?php /*'.$json.'*/ ?>');
        $task="php ".PLU_PATH."/my/run.php -t $now";
        $data['task']=$task;
        return ['code'=>0,'msg'=>'成功','data'=>$data];
        die;
	}
	
	//任务列表
	public function tasklist()
	{
	   $files=glob("my/task/*.json.php");
	   usort( $files, function( $b, $a ) { return filemtime($a) - filemtime($b); } );
	   
	   $data=array();
	   foreach($files as $k=>$v)
	   {
	       $varr=explode('/',$v);
	       $taskname=$varr[count($varr)-1];
	       $taskname=str_replace('.json.php','',$taskname);
	       $data[$k]['taskname']=$taskname;
	       $json=file_get_contents(PLU_PATH.'/'.$v);
           $json=str_replace('<?php /*','',$json);$json=str_replace('*/ ?>','',$json);
           $obj=json_decode($json);
           $data[$k]['content']='';
           $dirs=json_decode($obj->dirs);
	       $data[$k]['content']=implode(',',$dirs);
	       $task="php ".PLU_PATH."/my/run.php -t $taskname";
	       $data[$k]['task']=$task;
	   }
	   
	   return ['code'=>0,'msg'=>'成功','count'=>count($data),'data'=>$data];
	}
	
	//删除任务
	public function deltask()
	{
	    $taskname=_get('taskname');
	    unlink(PLU_PATH.'/my/task/'.$taskname.'.json.php');
	    return ['code'=>0,'msg'=>'成功','data'=>$taskname];
	}

    //目录列表
    public function dirlist() {
        $dir=_post('dir');
        if(null==$dir) 
        {
            if(is_dir(dirname(dirname(dirname(PLU_PATH)))))
            {
                $dir=dirname(dirname(dirname(dirname(PLU_PATH))));
            }
            else
            {
                $dir=dirname(dirname(dirname(PLU_PATH)));
            }
        }
        //if('/'==$dir) $dir='';
        $dir=str_replace('\\','/',$dir);
        $dirfiles=glob($dir."/*");//获取/tmp/目录下的所有目录和文件
        ////usort( $dirfiles, function( $b, $a ) { return filemtime($a) - filemtime($b); } );
        
        $data=array();
        
            $darr=explode('/',$dir);
            $endir='/'.$darr[count($darr)-1];
            $pdir=substr($dir,0,mb_strlen($dir)-mb_strlen($endir));
            
            $data[0]['id']=0;
            $data[0]['title']='⬆上级目录';
            $data[0]['dirname']=$pdir;
            $data[0]['field']='dir';
            $data[0]['checked']=false;
            $data[0]['spread']=true;
            $data[0]['children']=[];
            $data[0]['isfile']=0;
            $data[0]['icon']='⬆';

        foreach($dirfiles as $k=>$v)
        {
            $data[$k+1]['id']=$k+1;
            $titarr=explode('/',$v);
            $title=$titarr[count($titarr)-1];
            
            $data[$k+1]['title']=$title;
            $data[$k+1]['dirname']=$v;
            $data[$k+1]['field']='dir';
            $data[$k+1]['checked']=false;
            $data[$k+1]['spread']=true;
            $data[$k+1]['children']=[];
            
            if(is_file(iconv('UTF-8','GB2312',$v)))
            {
                $data[$k+1]['isfile']=1;
                $data[$k+1]['icon']='📄';
            }
            else
            {
                $data[$k+1]['isfile']=0;
                $data[$k+1]['icon']='📁';
            }
            $data[$k+1]['title']=$data[$k+1]['icon'].$title;
            
            $dirfiles[$k]=mb_convert_encoding($v,'UTF-8','GBK');
            
        }
        return ['code'=>0,'msg'=>'成功','count'=>count($data),'data'=>$data];
    }
    	
    }


?>