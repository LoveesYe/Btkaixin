var plugin_name = 'sitemap';
var title_name  = 'sitemap生成器';
/**
 * 发送请求到插件
 * 注意：除非你知道如何自己构造正确访问插件的ajax，否则建议您使用此方法与后端进行通信
 * @param plugin_name    插件名称 如：colscript
 * @param function_name  要访问的方法名，如：get_logs
 * @param args           传到插件方法中的参数 请传入数组，示例：{p:1,rows:10,callback:"colscript.get_logs"}
 * @param callback       请传入处理函数，响应内容将传入到第一个参数中
 */
function request_plugin(function_name, args, callback, timeout, method) {
    if (!timeout) timeout = 90*1000;
    if (!method)  method = 'POST';
    $.ajax({
        type:method,
        url: '/plugin?action=a&s=' + function_name + '&name=' + plugin_name,
        data: args,
        timeout:timeout,
        dataType:'json',
        success: function(rdata) {
            if (!callback) {
                layer.msg(rdata.msg, { icon: rdata.status ? 1 : 2 });
                return;
            }
            return callback(rdata);
        },
        error: function(ex) {
            if (!callback) {
                layer.msg('请求过程发现错误!', { icon: 2 });
                return;
            }
            return callback(ex);
        }
    });
}
function get_info()
{
      bt.soft.get_soft_list(1,10,title_name,function (rdata) {
         var info = rdata.list.data[0];
          //console.log(info);
         request_plugin('get_plugin_info',info,function (res) {

         })
     })
    // var args = {query:plugin_name,tojs:'soft.get_list',p:1,type:-1,force:0};
    // $.ajax({
    //     type:'POST',
    //     url: '/plugin?action=get_soft_list',
    //     data: args,
    //     timeout:30,
    //     // dataType:'json',
    //     success: function(rdata) {
    //         console.log(rdata);
    //     },
    //     error: function(ex) {
    //
    //     }
    // });
}
function sub_form(elem,data,function_name,callback) {
    if(!data) data = {};
    var options = {
        url: '/plugin?action=a&s=' + function_name + '&name=' + plugin_name,
        type: 'post',
        dataType: "json",
        data: data,
        clearForm: false,
        resetForm: false,
        cache: false,
        async: false,
        success: function (data) {
            if (!callback) {
                layer.msg(data.msg, { icon: data.status ? 1 : 2 });
                return;
            }
            return callback(data);
        },
        error: function (ex) {
            if (!callback) {
                layer.msg('请求过程发现错误!', { icon: 2 });
                return;
            }
            return callback(ex);
        }
    };
    // bind form using 'ajaxForm'
    $(elem).ajaxForm(options).submit(function (data) {
    });
}

function  tip(res,callback,type = 1) {
    if(type === 2){
        layer.alert(res.msg,{icon:res.code===1?1:2},callback);
        return;
    }
    layer.msg(res.msg,{icon:res.code===1?1:2,time:res.code === 1?1000:3000},callback);
}

function about() {

    var html =
        "  <div id=\"404_logo\" align=\"center\"><a target='_blank' href='https://www.waytomilky.com/'><img src='https://www.waytomilky.com/usr/uploads/2019/04/2930328315.png'></a></div><br/>\n" +
        "                <div id=\"404_dev\" >\n" +
        "                    <table align=\"left\"  style=\"position:absolute; left:10%\" border=\"0\">\n" +


        "                        <tr ><td>&nbsp;</td></tr>\n" +
        "                        <tr ><td><b>开发者公告:</b></td></tr>\n" +
        "                        <tr ><td>&nbsp;</td></tr>\n" +
        "                        <tr ><td id='msg'>欢迎使用插件,觉得好的话给个好评哦!</td></tr>\n" +

        "                        <tr ><td>&nbsp;</td></tr>\n" +
        "                        <tr ><td><b>使用说明,务必查看:</b></td></tr>\n" +

        "                        <tr ><td>&nbsp;</td></tr>\n" +
        "                        <tr ><td>1.插件依赖PHP 7.1,不影响网站设置</td></tr>\n" +




        // "                        <tr ><td>&nbsp;</td></tr>\n" +
        // "                        <tr ><td>2.插件依赖PHP-CLI>=5.4 此项在宝塔面板 【网站】->【PHP命令行版本】中修改</td></tr>\n" +

        // "<p>1.此插件依赖PHP>=7.0,未安装的请安装下其中任意版本,不影响其他网站设置.其次设置定时推送前,建议手动测试下 </p>" +
        // "<p>2.请输入域名(不是网址),和对应至少一个完整的API信息,<a class='btlink' target='_blank' href='https://www.waytomilky.com/archives/1950.html'>如何获取百度和神马API参考地址?</a></p>" +
        // "<p>3.  [网址去重] 为全局配置,手动和定时均生效</p>" +
        // "<p>4.  [网址过滤] 为空无限制,填入过滤信息,譬如有效网址包含archives关键词为有效网址,就填入article,多个用#号隔开</p>" +



        "                        <tr ><td>&nbsp;</td></tr>\n" +
        "                        <tr ><td><b>关于插件:</b></td></tr>\n" +
        "                        <tr ><td>&nbsp;</td></tr>\n" +
        "                        <tr ><td><a target='_blank' href='https://www.waytomilky.com/'>开发人员： 阿修罗</a></td></tr>\n" +
        "                        <tr ><td>&nbsp;</td></tr>\n" +
        "                        <tr ><td>官方网站： <a target='_blank' class='green' href='https://www.waytomilky.com/'>https://www.waytomilky.com/</a></td></tr>\n" +
        "                        <tr ><td>&nbsp;</td></tr>\n" +
        "                        <tr ><td>QQ群支持：<a target=\"_blank\" href=\"//shang.qq.com/wpa/qunwpa?idkey=289eaf4dfef0cc9220256b90ff502bef467767f6f790b817ce1cbe7658b5b3b3\"><img border=\"0\" src=\"//pub.idqqimg.com/wpa/images/group.png\" alt=\"PHP-LotusAdmin&amp;宝塔插件反\" title=\"PHP-LotusAdmin&amp;宝塔插件反\"></a></td></tr>\n" +
        "                        <tr ><td>&nbsp;</td></tr>\n" +
        "                        <tr ><td>别点我：<a style='color:green' target='_blank' href='https://www.bt.cn/?invite_code=MV9heHlhemM='>领取宝塔优惠券</a> </td></tr>\n" +



        "                    </table>\n" +
        "                </div>\n" +
        "                </div>";
    $('.plugin_body').html(html);
    request_plugin('about',{},function (res) {
        console.log(res);
        var msg = res.msg;
        if(msg == null){
            msg = "欢迎使用插件,觉得好的话给个好评哦!";
        }
        $("#msg").html(msg);
    },5000)


}

function get_icon($code){
    return parseInt($code);
}
function close_modal()
{
    layer.close(layer.index);
    layer.close(layer.index - 1);
    layer.close(modal);
}
function loading()
{
    loading_close();
    load = layer.load();
}
function loading_msg()
{
    loading_close();
    load = layer.msg(load_msg,{icon:16,time:0});
}
function loading_close()
{
    layer.close(load);
}
function  showtip(rdata,callback = null,error_callback = null)
{
    var icon = get_icon(rdata.code);
    layer.msg(rdata.msg,{icon:icon,time:800},function () {
        if(icon === 1 && callback !== null){
            return callback(rdata);
        }
        if(icon === 2 && error_callback !== null){
            return error_callback(rdata);
        }
    });
}