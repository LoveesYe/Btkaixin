return {
    ["baidu"] ="Baiduspider",
    ["bytes"] ="Bytespider",
    ["qh360"] ="360Spider",
    ["sogou"] ="Sogou",
    ["soso"] ="Soso",
    ["google"] ="Google",
    ["bing"] ="bingbot",
    ["youdao"] ="YoudaoBot",
    ["yandex"] ="YandexBot",
    ["dnspod"] ="DNSPod-Monitor",
    ["yisou"] ="YisouSpider",
    ["yahoo"] ="Yahoo"
}