pluginPath=/www/server/panel/plugin/total
sh $pluginPath/install.sh update