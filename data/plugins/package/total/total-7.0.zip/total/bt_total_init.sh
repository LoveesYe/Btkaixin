#!/bin/bash
# chkconfig: 2345 55 25
# description: 宝塔面板监控报表后台统计服务

### BEGIN INIT INFO
# Provides:          BT
# Required-Start:    $all
# Required-Stop:     $all
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
# Short-Description: starts BT TOTAL SERVER
# Description:       starts BT TOTAL SERVER
### END INIT INFO
target_dir=/www/server/panel/plugin/total
panel_path=/www/server/panel
cd $target_dir
env_path=$panel_path/pyenv/bin/activate
if [ -f $env_path ];then
        source $env_path
fi


tcpserver_start()
{     
        isStart=$(ps aux |grep 'bt_total_server'|grep -v grep|awk '{print $2}')
        if [ "$isStart" == '' ];then
                echo -e "Starting TOTAL SERVER... \c"
                nohup $target_dir/bt_total_server >> $log_file 2>&1 &
                sleep 0.2
                isStart=$(ps aux |grep 'bt_total_server'|grep -v grep|awk '{print $2}')
                if [ "$isStart" == '' ];then
                        echo -e "\033[31mfailed\033[0m"
                        echo '------------------------------------------------------'
                        tail -n 5 $log_file
                        echo '------------------------------------------------------'
                        echo -e "\033[31mError: BT TOTAL SERVER service startup failed.\033[0m"
                        return;
                fi
                echo -e "	\033[32mdone\033[0m"
        else
                echo "Starting BT TOTAL SERVER... BT TOTAL SERVER (pid $isStart) already running"
        fi
}

total_init(){
        pidfile=$target_dir/server.pid
        cd $target_dir
        env_path=$panel_path/pyenv/bin/python3
        if [ -f $env_path ];then
                pythonV=$panel_path/pyenv/bin/python3
                chmod -R 700 $panel_path/pyenv/bin
        else
                pythonV=/usr/bin/python
        fi
        reg="^#\!$pythonV\$"
        is_sed=$(cat $target_dir/bt_total_server|head -n 1|grep -E $reg)
        if [ "${is_sed}" = "" ];then
                sed -i "s@^#!.*@#!$pythonV@" $target_dir/bt_total_server
        fi
        chmod 700 $target_dir/bt_total_server
        log_file=$target_dir/server.log
        port=$(cat $target_dir/server_port.pl)
}
total_init

server_start()
{
        tcpserver_start
}

tcpservice_stop()
{
    echo -e "Stopping BT TOTAL SERVER...\c";
    pids=$(ps aux |grep 'bt_total_server'|grep -v grep|awk '{print $2}')
    arr=($pids)

    for p in ${arr[@]}
    do
            kill -9 $p
    done
    echo -e "	\033[32mdone\033[0m"
}

service_stop()
{
        tcpservice_stop
}

tcpservice_status()
{
        isStart=$(lsof -i:$port|grep LISTEN|grep -v grep|awk '{print $2}'|xargs)
        if [ "$isStart" != '' ];then
                echo -e "\033[32mBT TOTAL SERVER (pid $(echo $isStart)) already running\033[0m"
        else
                echo -e "\033[31mBT TOTAL SERVER not running\033[0m"
        fi
}

service_status()
{
        tcpservice_status
}

case "$1" in
        'start')
                server_start
                ;;
        'stop')
                service_stop
                ;;
        'restart')
                service_stop
                sleep 1
                server_start
                ;;
        'status')
                service_status
                echo "Port:${port}"
                start_time=$(cat $target_dir/startime)
                echo "Start time: " $start_time
                ;;
esac


