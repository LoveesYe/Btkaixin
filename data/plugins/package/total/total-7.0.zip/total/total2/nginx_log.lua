log_by_lua_block {
	local ngx_log                     = ngx.log
	local ERR                         = ngx.ERR

	local cpath = "/www/server/total/"
	if not package.path:find(cpath) then
		package.path = cpath .. "?.lua;" .. package.path
	end

	local logger = require "total_logger"

	local inited = logger.initted()
	-- ngx.log(ngx.ERR, "------ ("..tostring(worker_id)..")inited:"..tostring(inited))
	-- ngx.log(ngx.ERR, tostring(err))
	
	if not inited then
        local ok, err = logger.init{
			host = "127.0.0.1",
			sock_type = "tcp",
			port = 9876,
			-- port = 20001,
            flush_limit = 20, -- 存储阈值,已存储日志数量
			drop_limit = 99999, -- 丢弃阈值,已存储的日志数量
			periodic_flush = 20 -- 开启自动刷新，并设置间隔时间(s)
        }
		-- ngx.log(ngx.ERR, "init ok?"..tostring(ok), err)
        if not ok then
            ngx.log(ERR, "failed to initialize the logger: ", err)
            return
        end
    end

    local bytes, err = logger.log()
    if err then
        ngx.log(ERR, "failed to log message: ", err)
        return
    end
}