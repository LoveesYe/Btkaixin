#!/bin/bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH


Install_dns()
{
	mkdir -p /www/server/panel/plugin/dns
	nohup pip install python-whois > /dev/null 2>&1 &
	echo 'Successify'
}

Uninstall_dns()
{
	rm -rf /www/server/panel/plugin/dns
	echo 'Successify'
}


action=$1
host=$2;
if [ "${1}" == 'install' ];then
	Install_dns
else
	Uninstall_dns
fi
