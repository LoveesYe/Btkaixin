#!/bin/bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH
install_tmp='/tmp/bt_install.pl'
pluginPath=/www/server/panel/plugin/backup

Install_Backup()
{
	mkdir -p $pluginPath
	echo '正在安装脚本文件...' > $install_tmp
	\cp -a -r /www/server/panel/plugin/backup/icon.png /www/server/panel/BTPanel/static/img/soft_ico/ico-backup.png
	echo '安装完成'
}

Uninstall_Backup()
{
	rm -rf $pluginPath
	echo '卸载成功'
}

if [ "${1}" == 'install' ];then
	Install_Backup
elif  [ "${1}" == 'update' ];then
	Install_Backup
elif [ "${1}" == 'uninstall' ];then
	Uninstall_Backup
fi


