#!/bin/bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH

Install_task_manager()
{

	echo 'Successify'
}

Uninstall_task_manager()
{
	rm -rf /www/server/panel/plugin/task_manager
	echo 'Successify'
}

action=$1
if [ "${1}" == 'install' ];then
	Install_task_manager
else
	Uninstall_task_manager
fi