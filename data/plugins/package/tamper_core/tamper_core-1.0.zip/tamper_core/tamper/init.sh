#!/bin/bash
# chkconfig: 2345 55 25
# description: bt-tamper Service

### BEGIN INIT INFO
# Provides:          bt-tamper
# Required-Start:    $all
# Required-Stop:     $all
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
# Short-Description: starts bt-tamper
# Description:       starts the bt-tamper
### END INIT INFO

install_path=/www/server/tamper
tamperuser_bin=/www/server/tamper/tamperuser
tamper_cli_bin=/www/server/tamper/tamper-cli
tamper_config_file=/www/server/tamper/tamper.conf
kernel_version=$(uname -r|cut -f 1 -d "-")
cd $install_path

# 复制内核模块相关文件
copy_kernel_modules_files(){
    # 复制tampercore.ko
    rm -f $install_path/tampercore.ko
    if [ -f $install_path/kernel/$kernel_version/tampercore.ko ];then
        \cp -f $install_path/kernel/$kernel_version/tampercore.ko $install_path/tampercore.ko
        if [ $? -ne 0 ];then
            echo -e "\033[31mError: copying tempercore.ko failed!\033[0m"
            exit 1
        fi
    else
        echo -e "\033[31mError: tempercore.ko not found!\033[0m"
        exit 1
    fi

    # 复制tamperuser
    if [ -f $install_path/kernel/$kernel_version/tamperuser ];then
        \cp -f $install_path/kernel/$kernel_version/tamperuser $install_path/tamperuser
        if [ $? -ne 0 ];then
            echo -e "\033[31mError: copying temperuser failed!\033[0m"
            exit 1
        fi
    fi

    # 复制tamper_cli
    if [ -f $install_path/kernel/$kernel_version/tamper-cli ];then
        \cp -f $install_path/kernel/$kernel_version/tamper-cli $install_path/tamper-cli
        if [ $? -ne 0 ];then
            echo -e "\033[31mError: copying temper-cli failed!\033[0m"
            exit 1
        fi
    fi

    chmod 700 $install_path/tamper-cli
    chmod 700 $install_path/tamperuser

    # 创建软链接
    if [ ! -f /usr/bin/tamper ];then
        ln -sf $install_path/tamper-cli /usr/bin/tamper
    fi

    if [ ! -f /usr/bin/tamper-cli ];then
        ln -sf $install_path/tamper-cli /usr/bin/tamper-cli
    fi
}


tamper_start()
{
    is_ins=$(lsmod | grep tampercore)
    if [ "$is_ins" == "" ]; then
        echo -e "Loading Bt-Tampercore...\c"
        copy_kernel_modules_files
        sys_call_table_addr_str=$(cat /proc/kallsyms|grep ' sys_call_table'|head -n 1|awk '{printf $1}')
        insmod tampercore.ko sys_call_table_addr=$sys_call_table_addr_str >/dev/null 2>&1
        if [ $? -ne 0 ];then
            insmod -f tampercore.ko sys_call_table_addr=$sys_call_table_addr_str
            if [ $? -ne 0 ];then
                echo -e "   \033[31mfailed\033[0m"
                exit 1
            fi
        fi

        tamperuser_pid=$(pidof tamperuser)
        if [ "$tamperuser_pid" != "" ]; then
            kill -9 $tamperuser_pid
            pkill -9 tamperuser
        fi

        echo -e "	\033[32mdone\033[0m"
    else
        echo "Loading Bt-Tampercore... Bt-Tampercore Kernel module loaded"
    fi
    
    tamperuser_pid=$(pidof tamperuser)
    if [ "$tamperuser_pid" != "" ]; then
        echo -e "Starting Bt-Tamperuser... Bt-Tamperuser (pid $tamperuser_pid) already running"
    else
        echo -e "Starting Bt-Tamper...\c"
        nohup $tamperuser_bin  &> $install_path/tamperuser.log &
        sleep 1
        tamperuser_pid=$(pidof tamperuser)
        if [ "$tamperuser_pid" == "" ]; then
            echo -e "   \033[31mfailed\033[0m"
        else
            echo -e "	\033[32mdone\033[0m"
        fi
    fi
}



tamper_stop()
{
        echo -e "Stopping Bt-Tamperuser...\c";
        tamperuser_pid=$(pidof tamperuser)
        if [ "$tamperuser_pid" != "" ]; then
            kill -9 $tamperuser_pid
            pkill -9 tamperuser
        fi
        echo -e "	\033[32mdone\033[0m"

        echo -e "Uninstall Bt-Tampercore...\c";
        is_ins=$(lsmod | grep tampercore)
        if [ "$is_ins" != "" ]; then
            rmmod tampercore
        fi
        echo -e "	\033[32mdone\033[0m"
}

tamper_status()
{
    tamperuser_pid=$(pidof tamperuser)
    is_ins=$(lsmod | grep tampercore)
    if [ "$is_ins" != "" ]; then
        echo -e "\033[32mBt-Tamperuser (pid $tamperuser_pid) is running\033[0m"
    else
        echo -e "\033[31mBt-Tamperuser is not running\033[0m"
    fi

    if [ "$is_ins" != "" ]; then
        echo -e "\033[32mBt-Tampercore Kernel module loaded\033[0m"
    else
        echo -e "\033[31mBt-Tampercore Kernel module not loaded\033[0m"
    fi
}

tamper_reload()
{
    tamper_stop
    tamper_start
}


case "$1" in
    start)
        tamper_start
        ;;
    stop)
        tamper_stop
        ;;
    restart)
        tamper_stop
        tamper_start
        ;;
    status)
        tamper_status
        ;;
    reload)
        tamper_reload
        ;;
    *)
        echo "Usage: $0 {start|stop|restart|status|reload}"
        exit 1
        ;;
esac
