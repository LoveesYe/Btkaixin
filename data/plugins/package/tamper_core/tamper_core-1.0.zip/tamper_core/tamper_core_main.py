#coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: hwliang<hwl@bt.cn>
# +-------------------------------------------------------------------

# +--------------------------------------------------------------------
# |   宝塔防篡改程序(驱动层) - 重构版
# +--------------------------------------------------------------------


import os,sys,json,time,public


class tamper_core_main:

    __plugin_path = public.get_plugin_path('tamper_core')
    __tamper_path = "{}/tamper".format(public.get_setup_path())
    __tamper_user_bin = "{}/tamperuser".format(__tamper_path)
    __tamper_cli_bin = "{}/tamper-cli".format(__tamper_path)
    __tamper_cli_bash = "{}/cli.sh".format(__tamper_path)
    __init_file = "{}/init.sh".format(__plugin_path)
    __config_file = "{}/tamper.conf".format(__tamper_path)
    __tips_file = "{}/tips.pl".format(__tamper_path)
    __logs_path = "{}/logs".format(__tamper_path)
    __total_path = "{}/total".format(__tamper_path)


    def rep_config(self):
        '''
            @name 修复配置文件
            @author hwliang
            @return void
        '''

        default_config = {
            "status":1,
            "ltd":1,
            "min_pid":10,
            "is_create":1,
            "is_modify":1,
            "is_unlink":1,
            "is_mkdir":1,
            "is_rmdir":1,
            "is_rename":1,
            "is_chmod":1,
            "is_chown":1,
            "is_link":1,
            "process_names":["mysqld","systemctl"],
            "uids":[],
            "gids":[],
            "default_black_exts":[".java",".php",".html",".tpl",".js",".css",".jsp",".do",".shtml",".htm"],
            "default_white_files":[],
            "default_white_dirs":[],
            "paths":[]
        }

        public.writeFile(self.__config_file,json.dumps(default_config,ensure_ascii=False,indent=4))



    def read_config(self):
        '''
            @name 获取配置信息
            @author hwliang
            @return dict
        '''
        # 配置文件不存在？
        if not os.path.exists(self.__config_file):
            self.rep_config()

        config = public.readFile(self.__config_file)
        if not config: # 配置文件为空？
            self.rep_config()
            config = public.readFile(self.__config_file)

        try:
            config_dict = json.loads(config)
        except:
            # 配置文件损坏？
            self.rep_config()
            config_dict = json.loads(public.readFile(self.__config_file))

        return config_dict

    def save_config(self,config):
        '''
            @name 保存配置信息
            @author hwliang
            @param dict config
            @return void
        '''
        public.writeFile(self.__config_file,json.dumps(config,ensure_ascii=False,indent=4))
        public.writeFile(self.__tips_file,'1')



    def get_tamper_paths(self,args = None):
        '''
            @name 获取受保护的目录列表
            @author hwliang
            @return list
        '''
        config = self.read_config()
        if not config.get("paths"):
            return []

        result = []
        for path_info in config["paths"]:
            path_info['total'] = self.get_path_total(path_id=path_info['pid'])
            result.append(path_info)
        return config["paths"]


    def get_tamper_global_config(self,args = None):
        '''
            @name 获取全局配置
            @author hwliang
            @return dict
        '''
        config = self.read_config()
        return config


    def get_tamper_path_find(self,args=None,path_id=None,path=None):
        '''
            @name 获取指定目录配置
            @author hwliang
            @param args<dict_obj> 外部参数，可以为空
            @param path_id<int> 目录ID [选填]
            @param path<string> 目录路径 [选填]
            @return dict or None
        '''
        if args: # 参数传递
            if 'path_id' in args:
                path_id = int(args.get("path_id"))
            if 'path' in args:
                path = args.get("path")

        # 参数错误
        if not path_id and not path:
            return None

        # 获取目录配置列表
        path_list = self.get_tamper_paths()

        # 查找目录配置
        for path_info in path_list:
            if path_id and path_info["pid"] == path_id:
                return path_info
            if path and path_info["path"] == path:
                return path_info

        # 没找到？
        return None


    def get_path_id(self,path_list):
        '''
            @name 获取目标ID
            @author hwliang
            @param path_list<list> 目录列表
            @return int
        '''
        if not path_list:
            return 1

        # 获取最大ID
        max_id = 0
        for path_info in path_list:
            if max_id < path_info["pid"]:
                max_id = path_info["pid"]

        # 返回ID
        return max_id + 1


    def create_path_config(self,args=None,path=None,ps=None):
        '''
            @name 创建目录配置
            @author hwliang
            @param args<dict_obj> 外部参数，可以为空
            @param path<string> 目录路径
            @param ps<dict_obj> 备注
            @return dict
        '''
        if args: # 参数传递
            if 'path' in args:
                path = args.get("path")
            if 'ps' in args:
                ps = args.get("ps")

        # 路径标准化处理
        if path[-1] != "/": path += "/"
        path = path.replace('//','/')

        # 参数过滤
        if not path: return public.returnMsg(False,"目录路径不能为空")
        if not os.path.exists(path) or os.path.isfile(path): return public.returnMsg(False,"无效的目录: {}".format(path))
        if self.get_tamper_path_find(path=path): return public.returnMsg(False,"指定目录已经添加过了: {}".format(path))

        # 关键路径过滤
        if path in ['/','/root/','/boot/','/www/','/www/server/','/www/server/panel/','/www/server/panel/class/','/usr/','/etc/','/usr/bin/','/usr/sbin/']:
            return public.returnMsg(False,"不能添加系统关键目录: {}".format(path))

        config = self.read_config()
        path_info = {
            "pid":self.get_path_id(config["paths"]),
            "path":path,
            "status":1,
            "mode":0,
            "is_create":1,
            "is_modify":1,
            "is_unlink":1,
            "is_mkdir":1,
            "is_rmdir":1,
            "is_rename":1,
            "is_chmod":1,
            "is_chown":1,
            "is_link":1,
            "black_exts": config["default_black_exts"],
            "white_files": config["default_white_files"],
            "white_dirs": config["default_white_dirs"],
            "ps":ps
        }

        # 添加到配置列表
        config["paths"].append(path_info)
        self.save_config(config)
        public.WriteLog("防篡改","添加目录配置: {}".format(path))
        return public.returnMsg(True,"添加成功")

    def modify_path_config(self,args=None,path_id=None,path=None,key=None,value=None):
        '''
            @name 修改目录配置
            @author hwliang
            @param args<dict_obj> 外部参数，可以为空
            @param path_id<int> 目录ID
            @param path<string> 目录路径
            @param key<string> 配置项
            @param value<string> 配置值
            @return dict
        '''

        if args:
            if 'path_id' in args:
                path_id = int(args.get("path_id"))
            if 'path' in args:
                path = args.get("path")
            if 'key' in args:
                key = args.get("key")
            if 'value' in args:
                value = args.get("value")
                if not key in ['ps']: value = int(value)
        if not path_id and not path: return public.returnMsg(False,"参数错误")
        if not key: return public.returnMsg(False,"参数错误")
        keys = ["status","mode","is_create","is_modify","is_unlink","is_mkdir","is_rmdir","is_rename","is_chmod","is_chown","is_link","ps"]
        if key not in keys: return public.returnMsg(False,"指定配置项不存在")
        if not self.get_tamper_path_find(path_id=path_id,path=path): return public.returnMsg(False,"指定目标配置不存在")

        # 获取目录配置
        config = self.read_config()
        for path_info in config["paths"]:
            if path_id and path_info["pid"] == path_id:
                path = path_info["path"]
                path_info[key] = value
                break
            if path and path_info["path"] == path:
                path_info[key] = value
                break
        self.save_config(config)

        key_status = {
            "is_modify":"修改",
            "is_unlink":"删除文件",
            "is_rename":"重命名",
            "is_create":"创建文件",
            "is_mkdir":"创建目录",
            "is_chmod":"修改权限",
            "is_chown":"修改所有者",
            "is_rmdir":"删除目录",
            "is_link":"创建软链接",
        }
        value_status = ["允许","禁止"]
        open_status = ['关闭','开启']
        if key in ['status','ps']:
            if key == 'status':
                public.WriteLog("防篡改","修改目录[{}]配置: [{}]防篡改".format(path,open_status[value]))
            else:
                public.WriteLog("防篡改","修改目录[{}]配置: 备注={}".format(path,value))
        else:
            public.WriteLog("防篡改","修改目录[{}]配置:[{}]{}".format(path,value_status[value],key_status[key]))
        return public.returnMsg(True,"修改成功")

    def remove_path_config(self,args=None,path_id=None,path=None):
        '''
            @name 删除目录配置
            @author hwliang
            @param args<dict_obj> 外部参数，可以为空
            @param path_id<int> 目录ID
            @param path<string> 目录路径
            @return dict
        '''
        if args:
            if 'path_id' in args:
                path_id = int(args.get("path_id"))
            if 'path' in args:
                path = args.get("path")
        if not path_id and not path: return public.returnMsg(False,"参数错误")
        if not self.get_tamper_path_find(path_id=path_id,path=path): return public.returnMsg(False,"指定目标配置不存在")

        # 获取目录配置
        config = self.read_config()
        for path_info in config["paths"]:
            if path_id and path_info["pid"] == path_id:
                path = path_info["path"]
                config["paths"].remove(path_info)
                break
            if path and path_info["path"] == path:
                path_id = path_info["pid"]
                config["paths"].remove(path_info)
                break
        self.save_config(config)
        # 清理日志和统计文件
        log_file = "{}/{}.log".format(self.__logs_path,path_id)
        if os.path.exists(log_file): os.remove(log_file)
        total_path = "{}/{}".format(self.__total_path,path_id)
        if os.path.exists(total_path): public.ExecShell("rm -rf {}".format(total_path))

        public.WriteLog("防篡改","删除目录配置: {}".format(path))
        return public.returnMsg(True,"删除成功")


    def add_black_exts(self,args=None,path_id=None,path=None,exts=None):
        '''
            @name 添加黑名单扩展名
            @author hwliang
            @param args<dict_obj> 外部参数，可以为空
            @param path_id<int> 目录ID
            @param path<string> 目录路径
            @param exts<string> 扩展名
            @return dict
        '''
        if args:
            if 'path_id' in args:
                path_id = int(args.get("path_id"))
            if 'path' in args:
                path = args.get("path")
            if 'exts' in args:
                exts = args.get("exts")
        if not path_id and not path: return public.returnMsg(False,"参数错误")
        if not exts: return public.returnMsg(False,"参数错误")
        if not self.get_tamper_path_find(path_id=path_id,path=path): return public.returnMsg(False,"指定目标配置不存在")

        # 获取目录配置
        config = self.read_config()
        for path_info in config["paths"]:
            if path_id and path_info["pid"] == path_id:
                if exts in path_info["black_exts"]: return public.returnMsg(False,"指定后缀名已存在")
                path_info["black_exts"].append(exts)
                path = path_info["path"]
                break
            if path and path_info["path"] == path:
                if exts in path_info["black_exts"]: return public.returnMsg(False,"指定后缀名已存在")
                path_info["black_exts"].append(exts)
                break

        self.save_config(config)
        public.WriteLog("防篡改","添加指定目录:{},的受保护的后缀名: {}".format(path,exts))
        return public.returnMsg(True,"添加成功")


    def remove_black_exts(self,args=None,path_id=None,path=None,exts=None):
        '''
            @name 删除黑名单扩展名
            @author hwliang
            @param args<dict_obj> 外部参数，可以为空
            @param path_id<int> 目录ID
            @param path<string> 目录路径
            @param exts<string> 扩展名
            @return dict
        '''
        if args:
            if 'path_id' in args:
                path_id = int(args.get("path_id"))
            if 'path' in args:
                path = args.get("path")
            if 'exts' in args:
                exts = args.get("exts")
        if not path_id and not path: return public.returnMsg(False,"参数错误")
        if not exts: return public.returnMsg(False,"参数错误")
        if not self.get_tamper_path_find(path_id=path_id,path=path): return public.returnMsg(False,"指定目标配置不存在")


        # 获取目录配置
        config = self.read_config()
        for path_info in config["paths"]:
            if path_id and path_info["pid"] == path_id:
                if exts not in path_info["black_exts"]: return public.returnMsg(False,"指定后缀名不存在")
                path_info["black_exts"].remove(exts)
                path = path_info["path"]
                break
            if path and path_info["path"] == path:
                if exts not in path_info["black_exts"]: return public.returnMsg(False,"指定后缀名不存在")
                path_info["black_exts"].remove(exts)
                break

        self.save_config(config)
        public.WriteLog("防篡改","删除目录配置：{},的受保护的后缀名: {}".format(path,exts))
        return public.returnMsg(True,"删除成功")


    def add_white_files(self,args=None,path_id=None,path=None,filename=None):
        '''
            @name 添加文件白名单
            @author hwliang
            @param args<dict_obj> 外部参数，可以为空
            @param path_id<int> 目录ID
            @param path<string> 目录路径
            @param filename<string> 文件名
            @return dict
        '''

        if args:
            if 'path_id' in args:
                path_id = int(args.get("path_id"))
            if 'path' in args:
                path = args.get("path")
            if 'filename' in args:
                filename = args.get("filename")
        if not path_id and not path: return public.returnMsg(False,"参数错误")
        if not filename: return public.returnMsg(False,"参数错误")
        if not self.get_tamper_path_find(path_id=path_id,path=path): return public.returnMsg(False,"指定目标配置不存在")

        # 获取目录配置
        config = self.read_config()
        for path_info in config["paths"]:
            if path_id and path_info["pid"] == path_id:
                if filename in path_info["white_files"]: return public.returnMsg(False,"指定文件已经添加过了")
                path_info["white_files"].append(filename)
                path = path_info["path"]
                break
            if path and path_info["path"] == path:
                if filename in path_info["white_files"]: return public.returnMsg(False,"指定文件已经添加过了")
                path_info["white_files"].append(filename)
                break

        self.save_config(config)
        public.WriteLog("防篡改","添加指定目录:{},的文件白名单: {}".format(path,filename))
        return public.returnMsg(True,"添加成功")


    def remove_white_files(self,args=None,path_id=None,path=None,filename=None):
        '''
            @name 删除文件白名单
            @author hwliang
            @param args<dict_obj> 外部参数，可以为空
            @param path_id<int> 目录ID
            @param path<string> 目录路径
            @param filename<string> 文件名
            @return dict
        '''
        if args:
            if 'path_id' in args:
                path_id = int(args.get("path_id"))
            if 'path' in args:
                path = args.get("path")
            if 'filename' in args:
                filename = args.get("filename")
        if not path_id and not path: return public.returnMsg(False,"参数错误")
        if not filename: return public.returnMsg(False,"参数错误")
        if not self.get_tamper_path_find(path_id=path_id,path=path): return public.returnMsg(False,"指定目标配置不存在")

        # 获取目录配置
        config = self.read_config()
        for path_info in config["paths"]:
            if path_id and path_info["pid"] == path_id:
                if filename not in path_info["white_files"]: return public.returnMsg(False,"指定文件不存在")
                path_info["white_files"].remove(filename)
                path = path_info["path"]
                break
            if path and path_info["path"] == path:
                if filename not in path_info["white_files"]: return public.returnMsg(False,"指定文件不存在")
                path_info["white_files"].remove(filename)
                break

        self.save_config(config)
        public.WriteLog("防篡改","删除指定目录:{},的文件白名单: {}".format(path,filename))
        return public.returnMsg(True,"删除成功")


    def add_white_dirs(self,args=None,path_id=None,path=None,dirname=None):
        '''
            @name 添加目录白名单
            @author hwliang
            @param args<dict_obj> 外部参数，可以为空
            @param path_id<int> 目录ID
            @param path<string> 目录路径
            @param dirname<string> 目录名
            @return dict
        '''
        if args:
            if 'path_id' in args:
                path_id = int(args.get("path_id"))
            if 'path' in args:
                path = args.get("path")
            if 'dirname' in args:
                dirname = args.get("dirname")
        if not path_id and not path: return public.returnMsg(False,"参数错误")
        if not dirname: return public.returnMsg(False,"参数错误")
        if not self.get_tamper_path_find(path_id=path_id,path=path): return public.returnMsg(False,"指定目标配置不存在")

        # 获取目录配置
        config = self.read_config()
        for path_info in config["paths"]:
            if path_id and path_info["pid"] == path_id:
                if dirname in path_info["white_dirs"]: return public.returnMsg(False,"指定目录已经添加过了")
                path_info["white_dirs"].append(dirname)
                path = path_info["path"]
                break
            if path and path_info["path"] == path:
                if dirname in path_info["white_dirs"]: return public.returnMsg(False,"指定目录已经添加过了")
                path_info["white_dirs"].append(dirname)
                break

        self.save_config(config)
        public.WriteLog("防篡改","添加指定目录:{},的目录白名单: {}".format(path,dirname))
        return public.returnMsg(True,"添加成功")

    def remove_white_dirs(self,args=None,path_id=None,path=None,dirname=None):
        '''
            @name 删除目录白名单
            @author hwliang
            @param args<dict_obj> 外部参数，可以为空
            @param path_id<int> 目录ID
            @param path<string> 目录路径
            @param dirname<string> 目录名
            @return dict
        '''
        if args:
            if 'path_id' in args:
                path_id = int(args.get("path_id"))
            if 'path' in args:
                path = args.get("path")
            if 'dirname' in args:
                dirname = args.get("dirname")
        if not path_id and not path: return public.returnMsg(False,"参数错误")
        if not dirname: return public.returnMsg(False,"参数错误")
        if not self.get_tamper_path_find(path_id=path_id,path=path): return public.returnMsg(False,"指定目标配置不存在")

        # 获取目录配置
        config = self.read_config()
        for path_info in config["paths"]:
            if path_id and path_info["pid"] == path_id:
                if dirname not in path_info["white_dirs"]: return public.returnMsg(False,"指定目录不存在")
                path_info["white_dirs"].remove(dirname)
                path = path_info["path"]
                break
            if path and path_info["path"] == path:
                if dirname not in path_info["white_dirs"]: return public.returnMsg(False,"指定目录不存在")
                path_info["white_dirs"].remove(dirname)
                break

        self.save_config(config)
        public.WriteLog("防篡改","删除指定目录:{},的目录白名单: {}".format(path,dirname))
        return public.returnMsg(True,"删除成功")


    def modify_global_config(self,args=None,key=None,value=None):
        '''
            @name 修改全局配置
            @author hwliang<2020-07-01>
            @param args<dict_obj> 外部参数，可以为空
            @param key<string> 全局配置键名
            @param value<string> 全局配置键值
            @return dict
        '''
        if args:
            if 'key' in args: key = args.get("key")
            if 'value' in args: value = int(args.get("value"))

        if not key: return public.returnMsg(False,"参数错误")
        if key in ['process_names','uids','gids','paths']: return public.returnMsg(False,'不允许修改的配置项')
        config = self.read_config()

        if key not in config: return public.returnMsg(False,"指定全局配置不存在")
        config[key] = value
        self.save_config(config)

        key_status = {
            "is_modify":"修改",
            "is_unlink":"删除文件",
            "is_rename":"重命名",
            "is_create":"创建文件",
            "is_mkdir":"创建目录",
            "is_chmod":"修改权限",
            "is_chown":"修改所有者",
            "is_rmdir":"删除目录",
            "is_link":"创建软链接",
        }
        value_status = ["允许","禁止"]
        open_status = ['关闭','开启']
        if key in ['status','min_pid']:
            if key == 'status':
                public.WriteLog("防篡改","修改全局配置: [{}]防篡改".format(open_status[value]))
            else:
                public.WriteLog("防篡改","修改全局配置: 最小受保护PID={}".format(value))
        else:
            public.WriteLog("防篡改","修改全局配置:[{}]{}".format(value_status[value],key_status[key]))
        return public.returnMsg(True,"修改成功")

    def add_process_names(self,args=None,pname=None):
        '''
            @name 添加进程名
            @author hwliang<2020-07-01>
            @param args<dict_obj> 外部参数，可以为空
            @param name<string> 进程名
            @return dict
        '''
        if args:
            if 'pname' in args: pname = args.get("pname")
        if not pname: return public.returnMsg(False,"参数错误")
        config = self.read_config()
        if pname in config["process_names"]: return public.returnMsg(False,"指定进程名已经添加过了")
        config["process_names"].append(pname)
        self.save_config(config)
        public.WriteLog("防篡改","添加到进程名白名单: {}".format(pname))
        return public.returnMsg(True,"添加成功")


    def remove_process_names(self,args=None,pname=None):
        '''
            @name 删除进程名
            @author hwliang<2020-07-01>
            @param args<dict_obj> 外部参数，可以为空
            @param pname<string> 进程名
            @return dict
        '''
        if args:
            if 'pname' in args: pname = args.get("pname")
        if not pname: return public.returnMsg(False,"参数错误")
        config = self.read_config()
        if pname not in config["process_names"]: return public.returnMsg(False,"指定进程名不存在")
        config["process_names"].remove(pname)
        self.save_config(config)
        public.WriteLog("防篡改","删除进程名白名单: {}".format(pname))
        return public.returnMsg(True,"删除成功")


    def add_uids(self,args=None,uid=None):
        '''
            @name 添加UID
            @author hwliang<2020-07-01>
            @param args<dict_obj> 外部参数，可以为空
            @param uid<int> UID
            @return dict
        '''
        if args:
            if 'uid' in args: uid = int(args.get("uid"))
        if uid == None: return public.returnMsg(False,"参数错误")
        config = self.read_config()
        if uid in config["uids"]: return public.returnMsg(False,"指定UID已经添加过了")
        config["uids"].append(uid)
        self.save_config(config)
        public.WriteLog("防篡改","添加到用户白名单: {}".format(self.get_user_byuid(uid)))
        return public.returnMsg(True,"添加成功")

    def remove_uids(self,args=None,uid=None):
        '''
            @name 删除UID
            @author hwliang<2020-07-01>
            @param args<dict_obj> 外部参数，可以为空
            @param uid<int> UID
            @return dict
        '''
        if args:
            if 'uid' in args: uid = int(args.get("uid"))
        if uid == None: return public.returnMsg(False,"参数错误")
        config = self.read_config()
        if uid not in config["uids"]: return public.returnMsg(False,"指定UID不存在")
        config["uids"].remove(uid)
        self.save_config(config)
        public.WriteLog("防篡改","删除用户白名单: {}".format(self.get_user_byuid(uid)))
        return public.returnMsg(True,"删除成功")

    def get_group_bygid(self,gid):
        '''
            @name 获取组名
            @author hwliang
            @param gid<int> 组ID
            @return string
        '''
        gid = str(gid)
        gids = self.get_linux_gids()
        for g in gids:
            if gid == g['gid']:
                return g['group']
        return gid

    def get_user_byuid(self,uid):
        '''
            @name 获取用户名
            @author hwliang
            @param uid<int> 用户ID
            @return string
        '''
        uid = str(uid)
        uids = self.get_linux_uids()
        for u in uids:
            if uid == u['uid']:
                return u['user']
        return uid

    def add_gids(self,args=None,gid=None):
        '''
            @name 添加GID
            @author hwliang<2020-07-01>
            @param args<dict_obj> 外部参数，可以为空
            @param gid<int> GID
            @return dict
        '''
        if args:
            if 'gid' in args: gid = int(args.get("gid"))
        if gid == None: return public.returnMsg(False,"参数错误")
        config = self.read_config()
        if gid in config["gids"]: return public.returnMsg(False,"指定GID已经添加过了")
        config["gids"].append(gid)
        self.save_config(config)


        public.WriteLog("防篡改","添加到用户组白名单: {}".format(self.get_group_bygid(gid)))
        return public.returnMsg(True,"添加成功")

    def remove_gids(self,args=None,gid=None):
        '''
            @name 删除GID
            @author hwliang<2020-07-01>
            @param args<dict_obj> 外部参数，可以为空
            @param gid<int> GID
            @return dict
        '''
        if args:
            if 'gid' in args: gid = int(args.get("gid"))
        if gid == None: return public.returnMsg(False,"参数错误")
        config = self.read_config()
        if gid not in config["gids"]: return public.returnMsg(False,"指定GID不存在")
        config["gids"].remove(gid)
        self.save_config(config)
        public.WriteLog("防篡改","删除GID白名单: {}".format(self.get_group_bygid(gid)))
        return public.returnMsg(True,"删除成功")


    def get_user_ps(self,user):
        '''
            @name 获取用户描述
            @author hwliang
            @param user<string> 用户名
            @return string
        '''
        user = str(user)
        user_ps = {
            "root": "超级管理员用户",
            "www": "用于运行网站的用户，包括php-fpm、nginx、apache、pure-ftpd等网站相关进程都使用此用户",
            "mysql": "用于运行MySQL数据库的用户",
            "mongo": "用于运行MongoDB数据库的用户",
            "memcached": "用于运行Memcached的用户",
            "redis": "用于运行Redis的用户",
            "ftp": "用于运行FTP的用户",
            "postfix": "用于运行Postfix(邮件)的用户",
            "sshd": "用于运行SSH的用户",
            "springboot": "用于运行Java-SpringBoot的用户",
            "tomcat": "用于运行Tomcat的用户",
            "postgres": "用于运行PostgreSQL数据库的用户",
            "named": "用于运行DNS的用户",
            "httpd": "用于运行Apache的用户",
            "nginx": "用于运行Nginx的用户",
            "php-fpm": "用于运行PHP-FPM的用户",
            "pure-ftpd": "用于运行Pure-FTP的用户",
            "nobody": "低权限用户",
        }
        if user in user_ps:
            return user_ps[user]
        return user


    def get_linux_uids(self,args=None):
        '''
            @name 获取系统UID
            @author hwliang<2020-07-01>
            @param args<dict_obj> 外部参数，可以为空
            @return list
        '''
        passwd_file = "/etc/passwd"
        if not os.path.exists(passwd_file): return []
        uids = []
        passwd_body = public.readFile(passwd_file)
        for line in passwd_body.split("\n"):
            if not line: continue
            _tmp = line.split(":")
            uid = int(_tmp[2])
            if uid < 1000 and uid > 0: continue
            uid_info = {
                "uid":uid,
                "ps": self.get_user_ps(_tmp[0]),
                "user":_tmp[0]
            }
            uids.append(uid_info)
        return sorted(uids,key=lambda x:x['uid'])

    def get_linux_gids(self,args=None):
        '''
            @name 获取系统GID
            @author hwliang<2020-07-01>
            @param args<dict_obj> 外部参数，可以为空
            @return list
        '''
        group_file = "/etc/group"
        if not os.path.exists(group_file): return []
        gids = []
        group_body = public.readFile(group_file)
        for line in group_body.split("\n"):
            if not line: continue
            _tmp = line.split(":")
            gid = int(_tmp[2])
            if gid < 1000 and gid > 0: continue
            gid_info = {
                "gid":gid,
                "ps": self.get_user_ps(_tmp[0]),
                "group":_tmp[0]
            }
            gids.append(gid_info)
        return sorted(gids,key=lambda x:x['gid'])

    def get_linux_users_or_groups(self,args=None):
        '''
            @name 获取系统用户和组
            @author hwliang<2020-07-01>
            @param args<dict_obj> 外部参数，可以为空
            @return list
        '''

        result = {
            "users":self.get_linux_uids(args),
            "groups":self.get_linux_gids(args)
        }
        return result

    def get_logs(self,args = None,path_id = None):
        '''
            @name 获取日志
            @author hwliang<2020-07-01>
            @param path_id<int> 日志路径ID
            @return list
        '''
        rows = 10
        p = 1
        if args:
            if 'path_id' in args: path_id = int(args.get("path_id"))
            if 'p' in args: p = int(args.get("p"))
            if 'rows' in args: rows = int(args.get("rows"))
        if path_id == None: return public.returnMsg(False,"参数错误")

        log_file = "{}/{}.log".format(self.__logs_path,path_id)
        if not os.path.exists(log_file):
            return []

        result = []

        f_size = os.path.getsize(log_file)

        if f_size > 1024 * 1024 * 30:
            page = public.get_page(100,p,rows)
            tmp_lines = public.GetNumLines(log_file,rows,p)
        else:
            fp = open(log_file,"r")
            all_lines = fp.readlines()
            fp.close()
            page = public.get_page(len(all_lines),p,rows)
            start = int(page['shift'])
            tmp_lines = []
            all_sort_lines = []
            for line in all_lines:
                all_sort_lines.insert(0,line)
            tmp_lines = all_sort_lines[start:start+rows]

        for _line in tmp_lines:
            _tmp = _line.split("] [")
            if len(_tmp) < 2: continue
            _info = {
                "date": _tmp[0].strip().strip("["),
                "type": _tmp[1],
                "content": _tmp[2],
                "user": _tmp[3],
                "process": _tmp[4].strip().strip("]")
            }
            result.append(_info)
        page['data'] = result
        return page


    def get_action_logs(self,args=None):
        '''
            @name 获取操作日志
            @author hwliang
            @param p<int> 分页
            @param rows<int> 每页行数
        '''

        num = public.M("logs").where("type=?","防篡改").count()
        p = 1
        rows = 10
        if args:
            if 'p' in args: p = int(args.get("p"))
            if 'rows' in args: rows = int(args.get("rows"))

        page = public.get_page(num,p,rows)
        limit = "{},{}".format(page["shift"],page['row'])
        page['data'] = public.M("logs").where("type=?","防篡改").order("id desc").limit(limit).field("addtime,type,log").select()
        return page

    def get_path_total(self,args=None,path_id=None):
        '''
            @name 获取目录统计
            @author hwliang
            @param path_id<int> 目录ID
            @return dict
        '''
        if args:
            if 'path_id' in args: path_id = int(args.get("path_id"))

        if path_id == None: return public.returnMsg(False,"参数错误")
        total_all_file = "{}/{}/total.json".format(self.__total_path,path_id)
        total = {}
        default_total = {
                "create":       0,
                "modify":       0,
                "unlink":       0,
                "rename":       0,
                "mkdir":        0,
                "rmdir":        0,
                "chmod":        0,
                "chown":        0,
                "link": 0
        }

        total['all'] = default_total

        _all = public.readFile(total_all_file)
        if _all: total['all'] = json.loads(_all)
        total['today'] = default_total
        total_today_file = "{}/{}/{}.json".format(self.__total_path,path_id,public.format_date("%Y-%m-%d"))
        _today = public.readFile(total_today_file)
        if _today:
            _today = json.loads(_today)
            for k in _today.keys():
                total['today']['create'] += _today[k]['create']
                total['today']['modify'] += _today[k]['modify']
                total['today']['unlink'] += _today[k]['unlink']
                total['today']['rename'] += _today[k]['rename']
                total['today']['mkdir'] += _today[k]['mkdir']
                total['today']['rmdir'] += _today[k]['rmdir']
                total['today']['chmod'] += _today[k]['chmod']
                total['today']['chown'] += _today[k]['chown']
                total['today']['link'] += _today[k]['link']
        return total


    def get_path_total_list(self,args=None,path_id=None):
        '''
            @name 获取所有目录统计
            @author hwliang
            @param path_id<int> 目录ID
            @return list
        '''
        if args:
            if 'path_id' in args: path_id = int(args.get("path_id"))
        total_path = "{}/{}".format(self.__total_path,path_id)
        if not os.path.exists(total_path): return []
        total_all = []
        day_files = []
        for day_name in os.listdir(total_path):
            if day_name in ['total.json']: continue
            day_file = "{}/{}".format(total_path,day_name)
            if not os.path.exists(day_file): continue
            day_files.append(day_name.strip('.json'))

        for day_name in sorted(day_files,reverse=False):
            day_file = "{}/{}.json".format(total_path,day_name)
            _day = json.loads(public.readFile(day_file))
            for k in sorted(_day.keys()):
                _tmp = _day[k]
                _tmp['date_hour'] = "{}_{}".format(day_name,k)
                total_all.append(_tmp)

        return total_all

    def get_glabal_total(self,args=None):
        '''
            @name 获取全局统计
            @author hwliang
            @return dict
        '''
        total_all_file = "{}/total.json".format(self.__total_path)
        total = {}
        default_total = {
                "create":       0,
                "modify":       0,
                "unlink":       0,
                "rename":       0,
                "mkdir":        0,
                "rmdir":        0,
                "chmod":        0,
                "chown":        0,
                "link": 0
        }

        total = default_total
        _all = public.readFile(total_all_file)
        if _all: total = json.loads(_all)
        return total


    def get_service_status(self,args=None):
        '''
            @name 获取服务状态
            @author hwliang
            @return dict  kernel_module_status=内核驱动加载状态，controller_status=控制器状态
        '''
        result = {}
        result['kernel_module_status'] = not public.ExecShell("lsmod|grep tampercore")[0].strip() == ""
        result['controller_status'] = not public.ExecShell("pidof tamperuser")[0].strip() == ""
        return result

    def service_admin(self,args = None,action = None):
        '''
            @name 服务管理
            @author hwliang
            @param action<str> 动作 start|stop|restart|reload
        '''

        if args:
            if 'action' in args: action = args.get("action")
        if not action in ['stop','reload','start','restart']:
            return public.returnMsg(False,'不支持的操作参数')

        public.ExecShell("/etc/init.d/bt-tamper {}".format(action))

        msg_status = {"stop":"停止","reload":"重载","start":"启动","restart":"重启"}
        public.WriteLog('防篡改','防篡改服务已{}'.format(msg_status[action]))
        return public.returnMsg(True,'防篡改服务已{}'.format(msg_status[action]))


















