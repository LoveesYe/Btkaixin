#!/bin/bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH
install_tmp='/tmp/bt_install.pl'
pluginPath=/www/server/panel/plugin/jumpserver

pyVersion=$(python -c 'import sys;print(sys.version_info[0]);')
py_zi=$(python -c 'import sys;print(sys.version_info[1]);')

Install_jumpserver()
{

  echo '安装完成' > $install_tmp
}

Uninstall_jumpserver()
{
  rm -rf $pluginPath
}

if [ "${1}" == 'install' ];then
  Install_jumpserver
elif  [ "${1}" == 'update' ];then
  Install_jumpserver
elif [ "${1}" == 'uninstall' ];then
  Uninstall_jumpserver
fi
