# coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: 王张杰 <750755014@qq.com>
# +-------------------------------------------------------------------

# +--------------------------------------------------------------------
# |   堡垒机
# +--------------------------------------------------------------------
import paramiko
import threading
import json
import time, re
from io import StringIO
import sys
import os
import socket

if sys.version_info[0] == 2:
    from aes2 import aescrypt
else:
    from aes3 import aescrypt

os.chdir("/www/server/panel")
sys.path.append("/www/server/panel/class/")
import public
from BTPanel import session

try:
    import socks
except:
    if os.path.exists('/www/server/panel/pyenv'):
        public.ExecShell('/www/server/panel/pyenv/bin/pip install PySocks')
    else:
        public.ExecShell("pip install PySocks")
    import socks

try:
    from views import *
except:
    pass


class jumpserver_main:
    __log_type = '堡垒机'
    _username = None
    _host = None
    _web_socket = None
    _ssh_info = None
    _ssh_socket = None
    __plugin_path = '/www/server/panel/plugin/jumpserver'
    _global_proxy_file = os.path.join(__plugin_path, 'global_proxy.json')
    _video_path = "%s/static/video/" % __plugin_path
    _command = ""
    _command_record = "%s/command.json" % __plugin_path

    def __init__(self):
        self.time = time.time()
        self.tab_key = False
        try:
            if 'username' in session:
                self._username = session['username']
        except:
            pass

        # 创建视频录制目录
        if not os.path.exists(self._video_path):
            os.makedirs(self._video_path)

        if not os.path.exists(self._global_proxy_file):
            ret = {"proxy_addr": "", "proxy_port": 0, "proxy_username": "", "proxy_password": "", }
            public.writeFile(self._global_proxy_file, json.dumps(ret))

        self._global_proxy = json.loads(public.ReadFile(self._global_proxy_file))
        self._global_proxy['proxy_password'] = self._decode(self._global_proxy['proxy_password'])

        self.create_table()

    # 获取全局代理配置
    def get_global_proxy(self, get):
        return self._global_proxy

    # 设置全局代理
    def set_global_proxy(self, get):
        if 'proxy_password' in get: get.proxy_password = self._encode(get.proxy_password)
        ret = {"proxy_addr": get.proxy_addr, "proxy_port": get.proxy_port, "proxy_username": get.proxy_username, "proxy_password": get.proxy_password}
        public.writeFile(self._global_proxy_file, json.dumps(ret))
        return public.returnMsg(True, '设置全局代理成功!')

    # 创建表
    def create_table(self):
        # 创建jp_host表
        if not public.M('sqlite_master').where('type=? AND name=?', ('table', 'jp_host')).count():
            public.M('').execute('''CREATE TABLE "jp_host" (
                "id" INTEGER PRIMARY KEY AUTOINCREMENT,
                "addr" TEXT,
                "port" INTEGER DEFAULT 22,
                "auth_type" INTEGER DEFAULT 0,
                "username" TEXT,
                "password" TEXT DEFAULT '',
                "pkey" TEXT DEFAULT '',
                "need_proxy" INTEGER DEFAULT 0,
                "proxy_addr" TEXT DEFAULT '',
                "proxy_port" INTEGER DEFAULT 0,
                "proxy_username" TEXT DEFAULT '',
                "proxy_password" TEXT DEFAULT '',
                "addtime" INTEGER,
                "ps" TEXT DEFAULT '');''')
            public.M('').execute('CREATE INDEX jp_host_addr ON jp_host (addr);')

        # 创建jp_login_record表记录ssh登录记录
        if not public.M('sqlite_master').where('type=? AND name=?', ('table', 'jp_login_record')).count():
            public.M('').execute('''CREATE TABLE jp_login_record (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT,
                addr TEXT,
                ssh_user TEXT,
                login_time INTEGER DEFAULT 0,
                close_time INTEGER DEFAULT 0,
                video_addr TEXT);''')
            public.M('').execute('CREATE INDEX jp_login_record_addr ON jp_login_record (addr);')
        # 修复之前已经创建的jp_login_record表无video_addr字段的问题
        create_table_str = public.M('sqlite_master').where('type=? AND name=?', ('table', 'jp_login_record')).getField('sql')
        if 'video_addr' not in create_table_str:
            public.M('').execute('ALTER TABLE "jp_login_record" ADD "video_addr" TEXT')

        # 创建jp_command_record表记录ssh命令记录
        if not public.M('sqlite_master').where('type=? AND name=?', ('table', 'jp_command_record')).count():
            public.M('').execute('''CREATE TABLE jp_command_record (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT,
                addr TEXT,
                ssh_user TEXT,
                command TEXT,
                operate_time INTEGER DEFAULT 0);''')
            public.M('').execute('CREATE INDEX jp_command_record_addr ON jp_command_record (addr);')

    def record(self, rtype, data):
        if rtype == 'header':
            with open(self._video_path + jp_terms[self._host]._video_addr, 'w') as fw:
                fw.write(json.dumps(data) + '\n')
                return True
        else:
            with open(self._video_path + jp_terms[self._host]._video_addr, 'r') as fr:
                content = json.loads(fr.read())
                stdout = content["stdout"]
            atime = time.time()
            iodata = [atime - self.time, data]
            stdout.append(iodata)
            content["stdout"] = stdout
            with open(self._video_path + jp_terms[self._host]._video_addr, 'w') as fw:
                fw.write(json.dumps(content) + '\n')
                self.time = atime
                return True
        return True

    def connect(self, ssh_info=None):
        if ssh_info: self._ssh_info = ssh_info
        if not self._host: self._host = self._ssh_info['username'] + '@' + self._ssh_info['addr'] + '@' + self._username
        if self._host in jp_terms:
            if time.time() - jp_terms[self._host].last_time < 86400:
                return True
        try:
            # sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock = socks.socksocket()
            if self._ssh_info['need_proxy']:
                if self._ssh_info['proxy_addr'] and self._ssh_info['proxy_port']:
                    proxy_addr = self._ssh_info['proxy_addr']
                    proxy_port = self._ssh_info['proxy_port']
                    proxy_username = self._ssh_info['proxy_username']
                    proxy_password = self._ssh_info['proxy_password']
                else:
                    proxy_addr = self._global_proxy['proxy_addr']
                    proxy_port = self._global_proxy['proxy_port']
                    proxy_username = self._global_proxy['proxy_username']
                    proxy_password = self._global_proxy['proxy_password']
                sock.set_proxy(socks.SOCKS5, proxy_addr, proxy_port, True, proxy_username, proxy_password)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, 262144)
            sock.connect((self._ssh_info['addr'], int(self._ssh_info['port'])))
        except Exception as e:
            print(public.get_error_info())
            self._web_socket.send("服务器连接失败!")
            return False

        # 使用Transport连接
        p1 = paramiko.Transport(sock)
        p1.start_client()
        if 'pkey' not in self._ssh_info: self._ssh_info['pkey'] = None
        if 'auth_type' not in self._ssh_info: self._ssh_info['auth_type'] = None

        try:
            # 如果有pkey时则使用RSA私钥登录
            if self._ssh_info['pkey'] and self._ssh_info['auth_type']:
                # 将RSA私钥转换为io对象，然后生成rsa_key对象
                p_file = StringIO(self._ssh_info['pkey'])
                pkey = paramiko.RSAKey.from_private_key(p_file)
                p1.auth_publickey(username=self._ssh_info['username'], key=pkey)
            else:
                p1.auth_password(username=self._ssh_info['username'], password=self._ssh_info['password'])
        except Exception as e:
            self._web_socket.send("用户验证失败!")
            p1.close()
            return False

        jp_terms[self._host] = public.dict_obj()
        jp_terms[self._host].last_time = time.time()
        jp_terms[self._host].connect_time = time.time()
        # 打开会话
        jp_terms[self._host].tty = p1.open_session()
        # 获取终端对象
        jp_terms[self._host].tty.get_pty(term='xterm', width=100, height=29)
        jp_terms[self._host].tty.invoke_shell()
        # 记录上下键与左右键
        jp_terms[self._host].up_and_down_key = False
        jp_terms[self._host].left_and_right_key = 0
        # 终端视频录制的名称
        # self._video_addr = os.path.join(os.path.abspath(os.path.dirname(__file__)), "video/%s.cast" % str(int(jp_terms[self._host].connect_time)))
        jp_terms[self._host]._video_addr = '%s.json' % str(int(jp_terms[self._host].connect_time))
        # 记录登陆记录
        jp_terms[self._host].row_id = public.M('jp_login_record').add('username,ssh_user,addr,login_time,video_addr',
                                                                      (self._username, self._ssh_info['username'], self._ssh_info['addr'], int(jp_terms[self._host].connect_time),
                                                                       jp_terms[self._host]._video_addr))
        self.record('header', {
            "version": 1,
            "width": 100,
            "height": 29,
            "timestamp": int(jp_terms[self._host].connect_time),
            "env": {
                "TERM": "xterm",
                "SHELL": "/bin/bash",
            },
            "stdout": []
        })
        return True

    def resize(self, data):
        try:
            data = json.loads(data)
            jp_terms[self._host].tty.resize_pty(width=data['width'], height=data['height'], width_pixels=data['width_px'], height_pixels=data['height_px'])
            return True
        except:
            print(public.get_error_info())
            return False

    def data_in_handle(self, c_data):
        if c_data != '\r':
            if c_data == '\t':
                self.tab_key = True
            elif "[A" in c_data:
                jp_terms[self._host].up_and_down_key = True
                # _sql = "select command from jp_command_record limit %d,%d" % (jp_terms[self._host].count, 1)
                # data = public.M('jp_command_record').query(_sql)
            elif "[B" in c_data:
                jp_terms[self._host].up_and_down_key = True
            elif "[D" in c_data:
                if jp_terms[self._host].left_and_right_key < len(self._command):
                    jp_terms[self._host].left_and_right_key += 1
            elif "[C" in c_data:
                if jp_terms[self._host].left_and_right_key:
                    jp_terms[self._host].left_and_right_key -= 1
            else:
                if not jp_terms[self._host].left_and_right_key:
                    self._command += c_data
                else:
                    self._command = self._command[:-jp_terms[self._host].left_and_right_key] + c_data + self._command[-jp_terms[self._host].left_and_right_key:]
            return True
        else:
            if self._command:
                self.add_command_record(self._host, self._command.strip())
                self._command = ""
                jp_terms[self._host].left_and_right_key = 0
            return True

    def data_out_handle(self, data):
        m_data = data.decode("utf-8")
        if self.tab_key:
            m_data = m_data.replace("\x07", "")
            self._command += m_data
            self.tab_key = False
            return True
        if "\x08\x1b[K" in m_data:
            self._command = self._command[:-2]
            return True
        if jp_terms[self._host].up_and_down_key:
            m_data = re.sub(r'[\x1b[\d+P]', '', m_data)
            num = len(m_data) - len(m_data.replace("\x08", ""))
            if num:
                m_data = m_data.replace("\x08", "")
                self._command = self._command[:-num] + m_data
            else:
                self._command = m_data
            jp_terms[self._host].up_and_down_key = False
            return True
        return True

    def send(self):
        try:
            while not self._web_socket.closed:
                c_data = self._web_socket.receive()
                if not c_data: continue
                if len(c_data) > 10:
                    if c_data.find('resize_pty') != -1:
                        if self.resize(c_data): continue
                    elif c_data.find('"password"') != -1 and c_data.find('"host"') != -1:
                        continue
                if self._host in jp_terms:
                    jp_terms[self._host].last_time = time.time()
                    jp_terms[self._host].tty.send(c_data)
                    self.data_in_handle(c_data)
                else:
                    return
        except:
            print(public.get_error_info())

    def recv(self):
        try:
            n = 0
            while not self._web_socket.closed:
                self.not_send()
                if n == 0: self.last_send()
                data = jp_terms[self._host].tty.recv(1024)
                self.data_out_handle(data)
                self.not_send()
                if not data:
                    self.close()
                    self._web_socket.send('连接已断开,连续按两次回车将尝试重新连接!')
                    return
                try:
                    result = data.decode()
                except:
                    result = str(data)
                if not result: continue
                self.record('iodata', result)
                if self._web_socket.closed:
                    jp_terms[self._host].not_send = result
                    return
                self.set_last_send(result)
                if not n: n = 1
                self._web_socket.send(result)
        except:
            print(public.get_error_info())

    def set_last_send(self, result):
        last_size = 1024
        if 'last_send' not in jp_terms[self._host]:
            jp_terms[self._host].last_send = []

        jp_terms[self._host].last_send.append(result)
        last_len = len(jp_terms[self._host].last_send)
        if last_len > last_size:
            jp_terms[self._host].last_send = jp_terms[self._host].last_send[last_len - last_size:]

    def not_send(self):
        if 'not_send' in jp_terms[self._host]:
            if jp_terms[self._host].not_send:
                self._web_socket.send(jp_terms[self._host].not_send)
                jp_terms[self._host].not_send = ""

    def last_send(self):
        if 'last_send' in jp_terms[self._host]:
            for d in jp_terms[self._host].last_send:
                self._web_socket.send(d)

    def close(self):
        try:
            print(jp_terms[self._host].last_time)
            public.M('jp_login_record').where('id=?', jp_terms[self._host].row_id).update({'close_time': int(jp_terms[self._host].last_time)})
            jp_terms[self._host].tty.close()
        except:
            pass
        if self._host in jp_terms:
            del jp_terms[self._host]

    def close_shell_view(self, data):
        if self._host in jp_terms:
            jp_terms[self._host].last_time = time.time()
            jp_terms[self._host].tty.send(c_data)
        return public.ReturnMsg(True, '已经关闭!')

    def run(self, web_socket, ssh_info=None):
        self._web_socket = web_socket
        if 'id' in ssh_info:
            self._ssh_info = self.get_host_info(ssh_info)
        else:
            self._ssh_info = ssh_info

        if not self._ssh_info:
            return
        result = self.connect()
        time.sleep(0.1)
        if result:
            sendt = threading.Thread(target=self.send)
            recvt = threading.Thread(target=self.recv)
            sendt.start()
            recvt.start()
            sendt.join()
            recvt.join()
            if time.time() - jp_terms[self._host].last_time > 86400:
                self.close()
            self._web_socket = None

    # 编码
    def _encode(self, data):
        aesc = aescrypt('d31e571e9292', 'ECB', '', 'utf8')
        return aesc.aesencrypt(data.strip())

    # 解码
    def _decode(self, data):
        aesc = aescrypt('d31e571e9292', 'ECB', '', 'utf8')
        return aesc.aesdecrypt(data.strip())

    def _check_tls(self, args):
        from panelPlugin import panelPlugin

        gsl = panelPlugin().get_soft_list(args)
        endtime = 0
        try:
            if int(gsl['ltd']) > 0:
                return True
            for i in gsl['list']['data']:
                if 'jumpserver' == i['name']:
                    endtime = i['endtime']
            if int(endtime) > 0:
                return True
            return False
        except:
            return False

    # 取所有目标服务器的信息
    def get_host_list(self, args):
        debug_path = 'data/debug.pl'
        if os.path.exists(debug_path):
            return public.returnMsg(False, '当前处于开发者模式，插件无法运行。</br><a href="javascript:;" class="btlink" onclick="SetDebug()">关闭开发者模式</a>')
        # if not self._check_tls(args):
        #     public.ExecShell('rm -f /www/server/panel/plugin/jumpserver/jumpserver_main.so')
        #     return public.returnMsg(False, "请先购买该插件后再使用")
        if 'p' not in args:
            args.p = 1
        host_list = public.M('jp_host').select()
        if hasattr(args, 'query'):
            if args.query:
                tmpList = []
                for ssh_info in host_list:
                    if ssh_info['addr'].find(args.query) != -1 or ssh_info['ps'].find(args.query) != -1: tmpList.append(ssh_info)
                host_list = tmpList

        for item in host_list:
            if item['password']:
                item['password'] = self._decode(item['password'])
            if item['pkey']:
                item['pkey'] = self._decode(item['pkey'])
            if item['proxy_password']:
                item['proxy_password'] = self._decode(item['proxy_password'])
        return self.get_page(host_list, args)

    # 取分页
    def get_page(self, data, get):
        # 包含分页类
        import page
        # 实例化分页类
        page = page.Page()

        info = {}
        info['count'] = len(data)
        info['row'] = 10
        info['p'] = 1
        if hasattr(get, 'p'):
            info['p'] = int(get['p'])
        info['uri'] = {}
        info['return_js'] = ''
        if hasattr(get, 'tojs'):
            info['return_js'] = get.tojs

        # 获取分页数据
        result = {}
        result['page'] = page.GetPage(info, limit='1,2,3,4,5,8')
        n = 0
        result['data'] = []
        for i in range(info['count']):
            if n >= page.ROW: break
            if i < page.SHIFT: continue
            n += 1
            result['data'].append(data[i])
        return result

    # 取指定服务器的ssh登陆信息
    def get_host_info(self, args):
        id = int(args['id'])
        data = public.M('jp_host').where('id=?', (id,)).field('addr,port,username,auth_type,password,pkey,need_proxy,proxy_addr,proxy_port,proxy_username,proxy_password').find()
        if not data:
            return None
        if data['password']:
            data['password'] = self._decode(data['password'])
        if data['pkey']:
            data['pkey'] = self._decode(data['pkey'])
        if data['proxy_password']:
            data['proxy_password'] = self._decode(data['proxy_password'])
        return data

    def add_host(self, args):
        pdata = {}
        pdata['addr'] = args.addr
        pdata['username'] = args.username
        if 'port' in args: pdata['port'] = int(args.port)
        if 'auth_type' in args: pdata['auth_type'] = int(args.auth_type)
        if 'password' in args: pdata['password'] = self._encode(args.password)
        if 'pkey' in args: pdata['pkey'] = self._encode(args.pkey)
        if 'need_proxy' in args: pdata['need_proxy'] = int(args.need_proxy)
        if 'proxy_addr' in args: pdata['proxy_addr'] = args.proxy_addr
        if 'proxy_port' in args: pdata['proxy_port'] = args.proxy_port
        if 'proxy_username' in args: pdata['proxy_username'] = args.proxy_username
        if 'proxy_password' in args: pdata['proxy_password'] = self._encode(args.proxy_password)
        if 'ps' in args: pdata['ps'] = args.ps
        pdata['addtime'] = int(time.time())

        table = public.M('jp_host')
        if table.where('addr=? AND username=?', (pdata['addr'], pdata['username'])).count():
            return public.returnMsg(False, '已经存在相同ip和账号的记录!')
        table.insert(pdata)
        public.WriteLog(self.__log_type, '新增主机信息%s@%s' % (pdata['username'], pdata['addr']))
        return public.returnMsg(True, '新增成功!')

    def update_host(self, args):
        id = int(args.id)
        table = public.M('jp_host')

        pdata = {}
        pdata['addr'] = args.addr
        pdata['username'] = args.username
        if 'port' in args: pdata['port'] = int(args.port)
        if 'auth_type' in args: pdata['auth_type'] = int(args.auth_type)
        if 'password' in args: pdata['password'] = self._encode(args.password)
        if 'pkey' in args: pdata['pkey'] = self._encode(args.pkey)
        if 'need_proxy' in args: pdata['need_proxy'] = int(args.need_proxy)
        if 'proxy_addr' in args: pdata['proxy_addr'] = args.proxy_addr
        if 'proxy_port' in args: pdata['proxy_port'] = args.proxy_port
        if 'proxy_username' in args: pdata['proxy_username'] = args.proxy_username
        if 'proxy_password' in args: pdata['proxy_password'] = self._encode(args.proxy_password)
        if 'ps' in args: pdata['ps'] = args.ps

        table.where('id=?', (id,)).update(pdata)
        public.WriteLog(self.__log_type, '编辑主机信息%s@%s' % (pdata['username'], pdata['addr']))
        return public.returnMsg(True, '编辑成功!')

    def del_host(self, args):
        id = int(args.id)
        host_info = self.get_host_info(args)
        public.WriteLog(self.__log_type, '删除主机信息%s@%s' % (host_info['username'], host_info['addr']))
        public.M('jp_host').where('id=?', (id,)).delete()
        return public.returnMsg(True, '删除成功!')

    # 获取登录记录列表
    def get_record_list(self, args):
        if 'p' not in args:
            args.p = 1

        if session['uid'] == 1:
            record_list = public.M('jp_login_record').order("id desc").select()
        else:
            record_list = public.M('jp_login_record').where('username=?', self._username).order("id desc").select()
        if hasattr(args, 'query'):
            if args.query:
                tmpList = []
                for record in record_list:
                    if record['addr'].find(args.query) != -1 or record['username'].find(args.query) != -1: tmpList.append(record)
                record_list = tmpList

        return self.get_page(record_list, args)

    # 清空日志功能
    def clear_record(self, args):
        if session['uid'] != 1: return public.returnMsg(False, '非管理员用户不能清空日志!')
        public.M('jp_login_record').delete()
        public.WriteLog(self.__log_type, '清空日志')
        if not os.path.isdir(self._video_path): return
        for root, dirs, files in os.walk(self._video_path):
            for file in files:
                file_name = os.path.join(root, file)
                if file_name: os.remove(file_name)
        return public.returnMsg(True, '清空日志完成!')

    # 获取终端操作命令列表
    def get_command_list(self, args):
        if 'p' not in args:
            args.p = 1

        if session['uid'] == 1:
            record_list = public.M('jp_command_record').order("id desc").select()
        else:
            record_list = public.M('jp_command_record').where('username=?', self._username).order("id desc").select()
        if hasattr(args, 'query'):
            if args.query:
                tmpList = []
                for record in record_list:
                    if record['addr'].find(args.query) != -1 or record['username'].find(args.query) != -1: tmpList.append(record)
                record_list = tmpList

        return self.get_page(record_list, args)

    # 添加终端操作命令列表
    def add_command_record(self, host_info, c_data):
        result = host_info.split("@")
        pdata = {}
        pdata["username"] = result[2]
        pdata["addr"] = result[1]
        pdata["ssh_user"] = result[0]
        pdata["command"] = c_data
        pdata["operate_time"] = time.time()
        public.M('jp_command_record').add('username, ssh_user, addr, command, operate_time', (result[2], result[0], result[1], c_data, time.time()))

    # 清空审计功能
    def clear_command(self, args):
        if session['uid'] != 1: return public.returnMsg(False, '非管理员用户不能清空日志!')
        public.M('jp_command_record').delete()
        public.WriteLog(self.__log_type, '清空审计')
        return public.returnMsg(True, '清空审计完成!')
