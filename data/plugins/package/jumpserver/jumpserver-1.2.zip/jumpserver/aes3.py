# coding: utf-8
# | Python3 AES
# +--------------------------------------------------------------------
from Crypto.Cipher import AES
import base64, sys


class aescrypt():
    def __init__(self, key, model, iv, encode_):
        self.encode_ = encode_
        self.model = {'ECB': AES.MODE_ECB, 'CBC': AES.MODE_CBC}[model]
        self.key = self.add_16(key)
        if model == 'ECB':
            self.aes = AES.new(self.key, self.model)
        elif model == 'CBC':
            self.aes = AES.new(self.key, self.model, iv)

    def add_16(self, par):
        par = par.encode(self.encode_)
        while len(par) % 16 != 0:
            par += b'\x00'
        return par

    def aesencrypt(self, text):
        text = self.add_16(text)
        encrypt_text = self.aes.encrypt(text)
        return base64.encodebytes(encrypt_text).decode().strip()

    def aesdecrypt(self, text):
        text = base64.decodebytes(text.encode(self.encode_))
        decrypt_text = self.aes.decrypt(text)
        return decrypt_text.decode(self.encode_).strip('\0')

    # base64 编码
    def encode_base64(self, data):
        str2 = data.strip()
        if sys.version_info[0] == 2:
            return base64.b64encode(str2)
        else:
            return str(base64.b64encode(str2.encode('utf-8')))

    # base64 解码
    def decode_base64(self, data):
        import base64
        str2 = data.strip()
        if sys.version_info[0] == 2:
            return base64.b64decode(str2)
        else:
            return str(base64.b64decode(str2))


# if __name__ == '__main__':
#     pr = aescrypt('9999999999999999', 'ECB', '', 'gbk')
#     en_text = pr.aesencrypt('123456')
#     print('密文:', en_text)
#     print('明文:', pr.aesdecrypt(en_text))
