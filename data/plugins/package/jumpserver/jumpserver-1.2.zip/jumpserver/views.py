#coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: 王张杰 <750755014@qq.com>
# +-------------------------------------------------------------------

# +--------------------------------------------------------------------
# |   堡垒机
# +--------------------------------------------------------------------
import os
import sys
import json
from flask import request, g
from jinja2 import Environment, FileSystemLoader

os.chdir("/www/server/panel")
from BTPanel import app, session, sockets, check_login, get_input, method_all, method_post, json_header

sys.path.append("/www/server/panel/class/")
import public

basedir = os.path.abspath(os.path.dirname(__file__))
jp_terms = {}


def render_template(template_name_or_list, **context):
    env = Environment(loader=FileSystemLoader(os.path.join(basedir, 'templates')))
    tpl = env.get_template(template_name_or_list)
    context.update({'request': request,
                    'session': session,
                    'g': g
                    })
    html = tpl.render(context)
    return html


@sockets.route('/jp_terminal')
def jp_terminal(ws):
    if not check_login():
        ws.send(public.returnJson(False, "请先登录!"))
        return
    addr = request.args.get('addr', None)
    username = request.args.get('username', None)
    print(session['username'])
    print(addr)
    print(username)
    if not addr: return 'error'
    if not username: return 'error'
    key = 'jp_ssh_' + username + '@' + addr + '@' + session['username']
    if key not in session: return 'error'

    from jumpserver_main import jumpserver_main
    p = jumpserver_main()
    p.run(ws, session[key])


@app.route('/jp_term', methods=method_all)
def jp_term():
    if not check_login(): return public.returnMsg(False, '请先登录!')
    from flask import jsonify
    return jsonify(list(jp_terms.keys()))


@app.route('/jp_term_open', methods=method_all)
def jp_term_open():
    if request.method == method_post[0]:
        args = get_input()
        if 'get_ssh_info' in args:
            key = 'jp_ssh_' + args['username'] + '@' + args['addr'] + '@' + session['username']
            if key in session:
                return public.getJson(session[key]), json_header
            return public.returnMsg(False, '获取失败!')
        session['jp_ssh_info'] = json.loads(args.data)
        key = 'jp_ssh_' + session['jp_ssh_info']['username'] + '@' + session['jp_ssh_info']['addr'] + '@' + session['username']
        session[key] = session['jp_ssh_info']
        return public.returnJson(True, '设置成功!')
    else:
        if 'jp_ssh_info' not in session: return 'jp_ssh_info empty!'
        g.title = 'SSH终端 - %s@%s' % (session['jp_ssh_info']['username'], session['jp_ssh_info']['addr'])
        return render_template('jp_term_open.html', data=session['jp_ssh_info'])
