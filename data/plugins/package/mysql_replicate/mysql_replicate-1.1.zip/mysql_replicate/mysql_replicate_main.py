# coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: zhwen <zhw@bt.com>
# +-------------------------------------------------------------------

# --------------------------------
# Mysql主从复制
# --------------------------------
import sys

sys.path.append("class/")
import os, hashlib, time, json, re
import public
import panelMysql as pm

os.chdir("/www/server/panel")

backup_path = '/www/backup/database'
my_cnf = '/etc/my.cnf'
plugin_dir = "/www/server/panel/plugin/mysql_replicate"
plugin_conf_file = plugin_dir+"/config.json"
logs_file = "/tmp/mysql_replicate.log"

class mysql_replicate_main:

    def __init__(self):
        self.write_log = replicate_tools().write_log
        # 初始化从面板认证信息
        # self.slave_info = replicate_tools().get_slave_replicate_info()

    def param_check(self,get):
        values = {}
        rep_ip = "^(25[0-5]|2[0-4]\d|[0-1]?\d?\d)(\.(25[0-5]|2[0-4]\d|[0-1]?\d?\d)){3}$"
        rep_ipv6 = "^\s*((([0-9A-Fa-f]{1,4}:){7}(([0-9A-Fa-f]{1,4})|:))|(([0-9A-Fa-f]{1,4}:){6}(:|((25[0-5]|2[0-4]\d|[01]?\d{1,2})(\.(25[0-5]|2[0-4]\d|[01]?\d{1,2})){3})|(:[0-9A-Fa-f]{1,4})))|(([0-9A-Fa-f]{1,4}:){5}((:((25[0-5]|2[0-4]\d|[01]?\d{1,2})(\.(25[0-5]|2[0-4]\d|[01]?\d{1,2})){3})?)|((:[0-9A-Fa-f]{1,4}){1,2})))|(([0-9A-Fa-f]{1,4}:){4}(:[0-9A-Fa-f]{1,4}){0,1}((:((25[0-5]|2[0-4]\d|[01]?\d{1,2})(\.(25[0-5]|2[0-4]\d|[01]?\d{1,2})){3})?)|((:[0-9A-Fa-f]{1,4}){1,2})))|(([0-9A-Fa-f]{1,4}:){3}(:[0-9A-Fa-f]{1,4}){0,2}((:((25[0-5]|2[0-4]\d|[01]?\d{1,2})(\.(25[0-5]|2[0-4]\d|[01]?\d{1,2})){3})?)|((:[0-9A-Fa-f]{1,4}){1,2})))|(([0-9A-Fa-f]{1,4}:){2}(:[0-9A-Fa-f]{1,4}){0,3}((:((25[0-5]|2[0-4]\d|[01]?\d{1,2})(\.(25[0-5]|2[0-4]\d|[01]?\d{1,2})){3})?)|((:[0-9A-Fa-f]{1,4}){1,2})))|(([0-9A-Fa-f]{1,4}:)(:[0-9A-Fa-f]{1,4}){0,4}((:((25[0-5]|2[0-4]\d|[01]?\d{1,2})(\.(25[0-5]|2[0-4]\d|[01]?\d{1,2})){3})?)|((:[0-9A-Fa-f]{1,4}){1,2})))|(:(:[0-9A-Fa-f]{1,4}){0,5}((:((25[0-5]|2[0-4]\d|[01]?\d{1,2})(\.(25[0-5]|2[0-4]\d|[01]?\d{1,2})){3})?)|((:[0-9A-Fa-f]{1,4}){1,2})))|(((25[0-5]|2[0-4]\d|[01]?\d{1,2})(\.(25[0-5]|2[0-4]\d|[01]?\d{1,2})){3})))(%.+)?\s*$"
        if hasattr(get,"panel_addr"):
            panel_ipv4 = "https?://(.*):\d+"
            if re.search(panel_ipv4,get.panel_addr):
                values['panel_addr'] = get.panel_addr
            else:
                return public.returnMsg(False,"请输入正确的面板地址！ 如：http://1.1.1.1/8888")
        if hasattr(get,"panel_key"):
            values['panel_key'] = get.panel_key
        if hasattr(get,"master_ip"):
            if re.search(rep_ip,get.master_ip):
                values['master_ip'] = get.master_ip
            elif re.search(rep_ipv6,get.master_ip):
                values['master_ip'] = get.master_ip
            else:
                return public.returnMsg(False,"请输入正确的主库IP地址！ 如：1.1.1.1")

        if hasattr(get,"replicate_dbs"):
            values['replicate_dbs'] = json.loads(get.replicate_dbs)
        if hasattr(get,"add_slave"):
            values['add_slave'] = get.add_slave
        if hasattr(get,"ignore_tbs"):
            values['ignore_tbs'] = json.loads(get.ignore_tbs)
        return values

    def setup_readonly_status(self,get):
        return mysql_slave().set_mysql_readonly_temp()

    def get_all_tables_in_master_db(self,get):
        dbs = self.get_master_dbs(get)
        data = {}
        for db in dbs:
            try:
                data[db] = [i[0] for i in pm.panelMysql().query("show tables from {}".format(db))]
            except:
                continue
        return data

    def remove_slave(self,get):
        """
        get.slave_ip
        :param get:
        :return:
        """
        return mysql_slave().remove_slave(get.slave_ip)

    def check_panel_api(self,panel_addr,panel_key):
        try:
            api_info = {}
            api_info['panel_addr'] = panel_addr
            api_info['panel_key'] = panel_key
            result = json.loads(bt_api(api_info).get_user_info())
            if result['status']:
                return True
            return False
        except:
            return False

    def check_slave_db(self,panel_addr,panel_key):
        api_info = {}
        api_info['panel_addr'] = panel_addr
        api_info['panel_key'] = panel_key
        result = bt_api(api_info).get_data_list("database.get_list","databases")
        return result['data']

    def setup_replicate_info(self,get):
        """
        get.panel_addr      从库面板地址
        get.panel_key       从库面板key
        get.master_ip       主库用于同步的IP
        get.replicate_dbs   需要同步的数据库
        get.add_slave       是否为新增的从库
        slave_user          同步用户
        slave_passwd        同步密码
        :param get:
        :return:
        """
        # 验证传入参数
        values = self.param_check(get)
        if "status" in values.keys():
            return values

        if not self.check_panel_api(values['panel_addr'],values['panel_key']):
            return public.returnMsg(False,"面板地址、KEY不正确或没有将主库IP地址添加到从库面板API白名单，请确认后再试！")
        exist_db = self.check_slave_db(values['panel_addr'], values['panel_key'])
        exist_db = [i['name'] for i in exist_db]
        if hasattr(get, "copy_file") and get.copy_file == "1" and exist_db:
            return public.returnMsg(False, "从库已经存在数据库 [{}]，该同步方式不支持从库已经存在数据库得情况下使用！".format(exist_db))
        # 从面板地址中获取ip地址
        slave_ip_rep = "https?://(.*):"
        match = re.search(slave_ip_rep,values['panel_addr'])
        if not match:
            return public.returnMsg(False, "无法匹配到从库IP地址，从库面板地址为:{}".format(values['panel_addr']))
        slave_ip = match.group(1)
        conf = replicate_tools().get_replicate_info()
        if conf:
            slave_info = conf["slave"]
            for i in slave_info:
                if slave_ip == i['ip']:
                    return public.returnMsg(False, "从库【{}】已经存在！".format(slave_ip))
        slave_ip = match.group(1)
        # 如果是新增的从库
        if values['add_slave'] == "1":
            # conf = replicate_tools().get_replicate_info()
            data = {
                "copy_file": get.copy_file,
                "ignore_tbs":values['ignore_tbs'],
                "replicate_dbs": self.build_replicate_dbs_info(values["replicate_dbs"]),
                "ip": slave_ip,
                "panel_key": values['panel_key'],
                "panel_addr": values['panel_addr']
            }
            conf['slave'].insert(0,data)
        else:
            if values["master_ip"] == slave_ip:
                return public.returnMsg(False,"主库IP【{}】和从库相同！".format(values["master_ip"]))
            conf = {"master":
                {
                    "slave_user":self.gen_user_info()['username'],
                    "password":self.gen_user_info()['password'],
                    "master_ip": values["master_ip"],
                    "master_port": mysql_master().get_master_port()
                },

                    "slave":[
                        {
                            "copy_file":get.copy_file,
                            "ignore_tbs":values['ignore_tbs'],
                            "replicate_dbs": self.build_replicate_dbs_info(values["replicate_dbs"]),
                            "ip":slave_ip,
                            "panel_key": values['panel_key'],
                            "panel_addr": values['panel_addr']
                         }
                    ]
            }
        public.writeFile(plugin_conf_file,json.dumps(conf))
        return public.returnMsg(True,"添加成功！")

    def get_master_dbs(self,get):
        return mysql_master().get_master_dbs()

    def build_replicate_dbs_info(self,replicate_dbs):
        return mysql_master().generate_replicate_dbs(replicate_dbs)

    def gen_user_info(self):
        return {"username":public.GetRandomString(8),"password":public.gen_password(12)}

    def master_replicate_env_check(self,get):
        slave_ip = replicate_tools().get_replicate_info()['slave'][0]['ip']
        # 检查主库同步环境
        return mysql_master().master_env_check(slave_ip)

    def slave_replicate_env_check(self, get):
        # 检测从库同步环境
        data = mysql_slave().check_env_check()
        data['port_released'] = self.master_replicate_env_check(get)['port_released']
        return data
        # 导入数据到从库

    def slave_gtid_setup(self,get):
        # 设置gtid状态
        return mysql_slave().set_slave_gtid()

    def slave_serverid_setup(self,get):
        return mysql_slave().set_slave_id()

    def get_logs(self,get):
        import files
        return files.files().GetLastLine(logs_file, 20)

    def replicate_with_large_db(self,dbs,ignore_tbs,slave_ip):
        """
        该方法只在从库第一次配置同步并且没有存在数据库时才能启用
        :return:
        """
        # 获取从库root密码
        passwd = mysql_slave().get_mysql_root_passwd()
        # 停止从库服务
        mysql_slave().control_slave_mysqld_service(type='stop')
        # 获取主库master信息
        executed_gtid = mysql_master().get_executed_gtid()
        # 备份主库数据到从库
        mysql_master().backup_db_path_to_slave(dbs)
        # 备份从库数据目录
        mysql_slave().backup_slave_db_path()
        # 备份uuid文件
        # mysql_slave().backup_slave_uuid_conf()
        # 解压并覆盖到从库数据库目录
        mysql_slave().unzip_to_mysql_db_path()
        # 还原uuid文件
        mysql_slave().restore_salve_uuid_conf()
        # 添加同步配置到从库配置
        mysql_slave().add_replicate_database_conf(dbs)
        # 添加不需要同步的数据表到从库
        mysql_slave().add_ignore_tables(ignore_tbs)
        # 启动mysqld
        mysql_slave().control_slave_mysqld_service(type='start')
        time.sleep(10)
        # 重置mysql root密码
        mysql_slave().set_slave_root_password(passwd)
        time.sleep(10)
        # 清理主库master，slave配置
        mysql_slave().clear_replicate_info()
        # 将需要排除的gtid写入从库
        mysql_slave().set_executed_gtid(executed_gtid)
        # 执行同步命令
        replicate_tools().exec_shell_sql(mysql_slave().generate_sql_replicate())
        # 重启主从
        mysql_slave().restart_slave()
        # 修复主从错误
        replicate_repair().fix_replicate(slave_ip)
        mysql_slave().sync_db_to_panel()

    def replicate_db(self,dbs,ignore_tbs):
        # self.write_log("创建同步账号成功")
        # 从库创建需要接收数据库
        mysql_slave().add_database(dbs)
        # 数据库备份并传到从库 /www/backup/database/ 目录
        mysql_master().backup_db_to_slave(dbs) #新加的从库都放到第一位
        # 添加同步配置到从库配置
        mysql_slave().add_replicate_database_conf(dbs)
        # 添加不需要同步的数据表到从库
        mysql_slave().add_ignore_tables(ignore_tbs)
        # 数据导入到从库
        mysql_slave().master_backup_import()
        # 执行同步命令
        replicate_tools().exec_shell_sql(mysql_slave().generate_sql_replicate())

    def replicate_main(self,get):
        """
        数据库同步主方法
        :return:
        """
        self.write_log("")
        self.write_log("\n{x}开始执行同步程序{x}".format(x="*"*10))
        conf = replicate_tools().get_replicate_info()
        dbs = conf['slave'][0]['replicate_dbs']
        ignore_tbs = conf['slave'][0]['ignore_tbs']
        # 创建同步需要的账号
        mysql_master().create_replicate_user(conf)
        if conf['slave'][0]['copy_file'] == "1":
            # 使用拷贝全库的方式进行主从同步
            self.replicate_with_large_db(dbs,ignore_tbs,conf['slave'][0]['ip'])
        else:
            # 传统同步方式
            self.replicate_db(dbs,ignore_tbs)
        # 将数据库信息写入从库面板
        # mysql_slave().create_replicate_dbs_in_panel(conf['slave']['replicate_dbs'])
        # 清理同步残留文件
        mysql_slave().clear_replicate_file()
        # 重启主从配置
        mysql_slave().restart_slave()
        time.sleep(5)
        # 获取主从配置
        if not replicate_tools().check_replicate_status()['status']:
            return public.returnMsg(False,"获取同步失败，请检测同步详情！")
        return public.returnMsg(True,"同步设置成功！")

    def add_replicate_db(self, get):
        """
        get.slave_ip    192.168.1.41
        get.databases   ["db","db1"]
        get.ignore_tbs  ["db.tb1","db1.tb"]
        :return:
        """
        slave_ip = get.slave_ip
        ignore_tbs = json.loads(get.ignore_tbs)
        new_dbs = json.loads(get.databases)
        conf = replicate_tools().get_replicate_info()
        new_dbs_format = mysql_master().generate_replicate_dbs(new_dbs)

        for i in range(len(conf['slave'])):
            if slave_ip != conf['slave'][i]['ip']:
                continue
            for x in range(len(new_dbs_format)):
                if new_dbs_format[x] in conf['slave'][i]['replicate_dbs']:
                    del(new_dbs_format[x])
            if not new_dbs_format:
                return public.returnMsg(False, "数据库已经存在主从中")
            conf['slave'][i]['replicate_dbs'] = new_dbs_format + conf['slave'][i]['replicate_dbs']
            conf['slave'][i]['ignore_tbs'] = list(set(conf['slave'][i]['ignore_tbs'] + ignore_tbs))
            break

        # 停止某个从库同步
        replicate_tools(slave_ip).exec_shell_sql("stop slave")
        # mysql_master().backup_add_dbs(dbs)
        # 备份主库数据库传到从库
        # print("开始备份数据库: {}".format(new_dbs_format))
        mysql_master().backup_db_to_slave(new_dbs_format,add_dbs=1)
        # 从库创建数据库
        mysql_slave(slave_ip).add_database(new_dbs_format)
        # 修改从库配置文件设置同步新数据库
        mysql_slave(slave_ip).add_replicate_database_conf(conf['slave'][0]['replicate_dbs'])
        # 添加不需要同步的数据表到从库
        mysql_slave().add_ignore_tables(ignore_tbs)
        # 导入数据到从库并重启
        mysql_slave(slave_ip).master_backup_import(create_replicate=False)
        # 开启某个从库同步
        mysql_slave(slave_ip).restart_slave()
        time.sleep(5)
        if not replicate_tools(slave_ip).check_replicate_status()['status']:
            return public.returnMsg(False,"获取同步失败，请检测同步详情！")
        public.writeFile(plugin_conf_file, json.dumps(conf))
        return public.returnMsg(True,"同步设置成功！")

    def set_master_binlog(self,get):
        # 设置主库gtid
        data = {}
        data['binlog_setup'] = mysql_master().set_master_binlog()
        replicate_tools().restart_mysql()
        return public.returnMsg(True,data)

    def set_master_gtid(self,get):
        # 设置主库gtid
        data = {}
        data['gtid_setup'] = mysql_master().set_master_gtid()
        replicate_tools().restart_mysql()
        return public.returnMsg(True,data)

    def port_release(self,get):
        conf = replicate_tools().get_replicate_info()
        if not conf:
            return public.returnMsg(False,"主从配置文件为空！")
        slave_ip = conf['slave'][0]['ip']
        return mysql_master().port_release(slave_ip)

    def get_slave_list(self,get):
        slave_list = []
        conf = replicate_tools().get_replicate_info()
        if not conf:
            return slave_list
        conf = conf['slave']
        for i in conf:
            data = {}
            slave_ip = i['ip']
            str_slave_info = replicate_tools(slave_ip).get_slave_status(show_str=True)
            if not str_slave_info['status']:
                status = False
            else:
                process_slave_info = replicate_tools(slave_ip).get_slave_status(result=str_slave_info['msg'])
                status = replicate_tools().check_replicate_status(process_slave_info)[
                    'status']  # replicate_tools(slave_ip).check_replicate_status()['status']
            # 主从同步状态
            data['slave_status'] = status
            # 主从同步详情
            data['slave_detail'] = str_slave_info['msg']
            # 从库只读状态
            data['slave_readonly'] = mysql_slave(slave_ip).get_mysql_readonly()
            # 正在同步的数据库
            data['replicate_dbs'] = [d['name'] for d in i['replicate_dbs']]
            # 从库IP
            data['slave_ip'] = slave_ip
            slave_list.append(data)
        return slave_list

    def replicate_repair_check(self,get):
        slave_ip = get.slave_ip
        return replicate_repair().check_replicate_error(slave_ip)

    def replicate_repair(self,get):
        slave_ip = get.slave_ip
        return replicate_repair().fix_replicate(slave_ip)

class mysql_master:
    __is_firewalld = False
    __is_ufw = False
    mysqldump_complete_file = '/tmp/mysqldump.txt'

    def __init__(self):
        if os.path.exists('/usr/sbin/firewalld'): self.__is_firewalld = True
        if os.path.exists('/usr/sbin/ufw'): self.__is_ufw = True
        self.write_log = mysql_replicate_main().write_log

    def get_master_dbs(self):
        """
             @name  获取所有可同步数据库
             @author zhwen<zhw@bt.cn>
             @return dbs list
         """
        # 判断mysql是否启动
        if not self.get_master_port():
            return public.returnMsg(False, '请确定数据库已经开启或尝试重置数据库ROOT密码')
        tmp = None
        for i in ['5.7', '8.']:
            if i in self.get_master_version():
                tmp = True
        if not tmp:
            return public.returnMsg(False, '本插件仅支持Mysql5.7 和 Mysql8')
        ms = pm.panelMysql().query("show databases")
        dbs = []
        for i in ms:
            if i[0] not in ["information_schema","performance_schema","sys","mysql"]:
                dbs.append(i[0])
        return dbs

    def get_db_path(self):
        try:
            res = pm.panelMysql().query("show variables like '%datadir%'")[0][1]
        except:
            res = "/www/server/data/"
        return res

    # def get_exclude_dbs(self,dbs):
    #     all_dbs = mysql_master().get_master_dbs()
    #     select_dbs = [db['name'] for db in dbs]
    #     exclude_dbs = list(set(all_dbs).difference(set(select_dbs)))
    #     return exclude_dbs #list ["a","b"]

    def backup_db_path_to_slave(self,dbs):
        self.write_log("|-开始备份数据库目录！如果数据量大可能需要很长时间！")
        # exclude_db = self.get_exclude_dbs(dbs)
        # ex_shell = ""
        # for i in exclude_db:
        #     ex_shell += " --exclude={}".format(i)
        # data_path = self.get_db_path().split("/")
        # base_path = "/".join(data_path[:-2])
        # data_dir = data_path[-2]
        # execute_file = " --exclude=mysql-bin* --exclude=mysql-slow.log {}".format(ex_shell)
        execute_file = " --exclude=mysql-bin* --exclude=mysql-slow.log"
        backup_shell = "cd {data_path} && tar -zcvf {backup_path}/mysql_replicate_full_data.tar.gz * {ex_file} >> {logfile} && > {cp_file}".format(
            backup_path=backup_path,
            # base_path=base_path,
            # data_dir=data_dir,
            data_path = self.get_db_path(),
            logfile=logs_file,
            cp_file=self.mysqldump_complete_file,
            ex_file=execute_file)
        self.write_log("|-备份命令：{}".format(backup_shell))
        public.ExecShell(backup_shell)
        self.db_backup_complete_check()
        target_path = source_file = backup_path + "/mysql_replicate_full_data.tar.gz"
        return bt_api(replicate_tools().get_slave_replicate_info()).upload_file(source_file, target_path)

    def generate_replicate_dbs(self,replicate_dbs):
        """
            @name  构造需要同步的数据库列表
            @author zhwen<zhw@bt.cn>
        """
        dbmsg = []
        if replicate_dbs[0] == "all":
            dbmsg.append('all')
            for i in self.get_master_dbs():
                if i != "mysql":
                    d = public.M('databases').where('name=?', ('%s' % i,)).find()
                    dbmsg.append(d)
        else:
            for i in replicate_dbs:
                d = public.M('databases').where('name=?', (i,)).find()
                dbmsg.append(d)
        return dbmsg

    def master_db_backup(self,databases,add_dbs=None):
        # databases 需要以列表传入
        # 备份主库的数据库准备传输到从库k
        try:
            self.write_log("开始备份数据库")
            password = public.M('config').where('id=?', (1,)).getField('mysql_root')
            self.write_log("获取数据库Root密码:{}".format(password))
            os.environ["MYSQL_PWD"] = password
            if databases[0] == "all":
                self.write_log("开始备份所有数据库")
                result = self.master_db_backup_all()
            else:
                databases = databases
                self.write_log("开始备份特定数据库")
                result = self.master_db_backup_specify(databases,add_dbs)
        except:
            self.write_log("备份失败：{}".format(str(public.get_error_info())))
            result = False
        finally:
            os.environ["MYSQL_PWD"] = ""
        self.write_log("备份成功！")
        return result

    def backup_specify_tables(self,tables):
        """
            @name  备份指定数据表
            @author zhwen<zhw@bt.cn>
            @param
        """
        # 开始备份数据表
        tables = ' '.join(tables.split('.'))
        password = public.M('config').where('id=?', (1,)).getField('mysql_root')
        try:
            os.environ["MYSQL_PWD"] = password
            public.ExecShell("mysqldump -uroot --set-gtid-purged=off --skip-lock-tables --single-transaction"
                             " -uroot {tb}|gzip > {bp}/mysql_replicate.sql.gz && echo '1'>{cf}".format(
                tb = tables,
                bp = backup_path,
                cf = self.mysqldump_complete_file))
            os.environ["MYSQL_PWD"] = ''
            stauts = self.db_backup_complete_check()
            self.write_log('数据表备份完成状态：()'.format(stauts))
        except:
            stauts = False
            self.write_log('数据库备份错误 %s' % tables)
        finally:
            os.environ["MYSQL_PWD"] = ''
        return stauts

    def db_backup_complete_check(self,command=None):
        while True:
            self.write_log("|-开始检测备份是否完成！")
            if os.path.exists(self.mysqldump_complete_file):
                os.remove(self.mysqldump_complete_file)
                break
            if command:
                res = public.ExecShell(command)[0]
                self.write_log("|-开始检测进程是否结束：{}".format(res))
                if not res:
                    break
            time.sleep(1)
        return True

    def get_executed_gtid(self):
        try:
            execute_gtid = pm.panelMysql().query("show master status")[0][4]
            self.write_log("|—获取主库GTID：{}".format(execute_gtid))
            return execute_gtid
        except:
            self.write_log("|—获取主库GTID失败！")
            return ""

    def backup_db_to_slave(self,dbs,add_dbs=None):
        # 备份数据库到从库
        result = mysql_master().master_db_backup(dbs,add_dbs)
        if not result:
            return False
        target_path = source_file = backup_path+"/mysql_replicate.sql.gz"
        return bt_api(replicate_tools().get_slave_replicate_info()).upload_file(source_file,target_path)

    def master_db_backup_all(self):
        # 备份主库的所有数据库
        public.ExecShell("mysqldump --single-transaction --all-databases --triggers --routines --events "
                         "--skip-lock-tables -uroot |gzip > {}/mysql_replicate.sql.gz && echo '1'>{}".format(
            backup_path, self.mysqldump_complete_file))
        return self.db_backup_complete_check()

    # def backup_add_dbs(self,databases):
    #     """
    #         @name  备份需要添加的数据库
    #         @author zhwen<zhw@bt.cn>
    #         @param
    #     """
    #     # 开始备份数据表
    #     databases = " ".format(databases)
    #     password = public.M('config').where('id=?', (1,)).getField('mysql_root')
    #     try:
    #         os.environ["MYSQL_PWD"] = password
    #         public.ExecShell("mysqldump -uroot --set-gtid-purged=off --skip-lock-tables --single-transaction"
    #                          " -uroot {dbs}|gzip > {bp}/mysql_replicate.sql.gz && echo '1'>{cf}".format(
    #             dbs = databases,
    #             bp = backup_path,
    #             cf = self.mysqldump_complete_file))
    #         os.environ["MYSQL_PWD"] = ''
    #         stauts = self.db_backup_complete_check()
    #         self.write_log('数据库备份完成状态：()'.format(stauts))
    #     except:
    #         stauts = False
    #         self.write_log('数据库备份错误 %s' % databases)
    #     finally:
    #         os.environ["MYSQL_PWD"] = ''
    #     return stauts

    def master_db_backup_specify(self, databases,add_dbs=None):
        # 如果是添加的数据库
        databases = [i['name'] for i in databases]
        dbs = " ".join(databases)
        self.write_log("|-开始备份数据库: {}".format(dbs))
        if add_dbs:
            shell = "mysqldump -uroot --set-gtid-purged=off --skip-lock-tables --single-transaction " \
                    "--triggers --routines --events -uroot --databases {dbs}|gzip > {bp}/mysql_replicate.sql.gz && echo '1'>{cf}".format(
                dbs = dbs,
                bp = backup_path,
                cf = self.mysqldump_complete_file)
        else:
        # 备份主库的特定数据库
            shell = "mysqldump --single-transaction --triggers --routines --events --skip-lock-tables " \
                    "--databases {} -uroot |gzip > {}/mysql_replicate.sql.gz && echo '1'>{}".format(
                dbs, backup_path, self.mysqldump_complete_file)
        public.ExecShell(shell)
        return self.db_backup_complete_check()

    def get_master_gtid(self):
        # 获取主库gtid状态
        gtid_mode = pm.panelMysql().query("show global variables like 'gtid_mode'")[0]
        if 'ON' in gtid_mode:
            return True
        return False

    def set_master_gtid(self):
        # 设置主库的gtid支持
        gtid_conf = """
log-slave-updates=true
enforce-gtid-consistency
gtid-mode=on"""
        conf = public.readFile(my_cnf)
        if not self.get_master_gtid():
            conf = re.sub("\[mysqld\]", "[mysqld]" + gtid_conf, conf)
            public.writeFile(my_cnf,conf)
        return True

    def get_master_binlog(self):
        """
            @name  检查数据库二进制日志是否已经开启
            @author zhwen<zhw@bt.cn>
        """
        binlog_status = pm.panelMysql().query("show variables like 'log_bin'")[0]
        if 'ON' in binlog_status:
            return True
        return False

    def set_master_binlog(self):
        # 设置主库binlog
        conf = public.readFile(my_cnf)
        if not re.search('\n\s*#\s*log-bin\s*=\s*mysql-bin',conf):
            bin_log = """
log-bin=mysql-bin
binlog_format=mixed"""
            conf = re.sub("\[mysqld\]", "[mysqld]" + bin_log, conf)
        else:
            conf = conf.replace('#log-bin=mysql-bin', 'log-bin=mysql-bin')
            conf = conf.replace('#binlog_format=mixed', 'binlog_format=mixed')
        public.writeFile(my_cnf, conf)
        return True

    def delete_port_release(self,slave_ip):
        port = self.get_master_port()
        port = str(port) if isinstance(port,int) else port
        if self.__is_ufw:
            str(public.ExecShell('ufw delete allow proto tcp from ' + slave_ip + ' to any port ' + port + ''))
        else:
            public.ExecShell(
                'firewall-cmd --permanent --remove-rich-rule="rule family=ipv4 source address=\"%s\" port protocol=\"tcp\" port=\"%s\" accept"' % (
                    slave_ip, port))
        self.firewall_reload()
        return public.returnMsg(True, '删除成功！')

    def port_release(self, slave_ip):
        # 放行mysql端口只允许从库访问
        port = self.get_master_port()
        port = str(port) if isinstance(port,int) else port
        if self.__is_ufw:
            public.ExecShell('ufw allow proto tcp from ' + slave_ip + ' to any port ' + port + '')
        else:
            a,e = public.ExecShell(
                'firewall-cmd --permanent --add-rich-rule="rule family=ipv4 source address=\"%s\" port protocol=\"tcp\" port=\"%s\" accept"' % (
                    slave_ip, port))
        self.firewall_reload()
        return public.returnMsg(True, '设置成功！')

    # 重载防火墙配置
    def firewall_reload(self):
        if self.__is_ufw:
            public.ExecShell('/usr/sbin/ufw reload')
            return
        else:
            public.ExecShell('firewall-cmd --reload')


    def get_master_port(self):
        """
            @name  获取数据库端口号
            @author zhwen<zhw@bt.cn>
            @return port int
        """
        try:
            port = pm.panelMysql().query("show global variables like 'port'")[0][1]
        except:
            return False
        if not port:
            return 3306
        else:
            return int(port)

    def get_master_version(self):
        """
            @name 获取数据库版本号
            @author zhwen<zhw@bt.cn>
            @return master_version str
        """
        master_version = pm.panelMysql().query("select version()")[0][0].split(".")
        master_version = master_version[0] + "." + master_version[1]
        return master_version

    def mysql_replicate_version(self):
        status = False
        if "5.7" in self.get_master_version():
            status = True
        if "8." in self.get_master_version():
            status = True
        return status

    def create_replicate_user(self,replicate_info):
        self.write_log("|-正在创建同步所需账号...")
        slave_ip = replicate_info['slave'][0]['ip']
        user = replicate_info['master']['slave_user']
        self.write_log("|-同步用户：{}".format(user))
        passwd = replicate_info['master']['password']
        self.write_log("|-同步密码：{}".format(passwd))
        # 清理从库用户
        delete_old_user = "delete from mysql.user where host='{}'".format(slave_ip)
        # 创建从库同步用户
        flush_sql = "flush privileges"
        if "8." in self.get_master_version():
            create_slave_sql = "create user {}@'{}' identified by '{}'".format(
                user,
                slave_ip,
                passwd)
            grant_slave_sql = "grant replication slave on *.* to {}@'{}'".format(
                user,
                slave_ip)
        else:
            grant_slave_sql = ""
            create_slave_sql = "grant replication slave on *.* to {}@'{}' identified by '{}'".format(
                user,
                slave_ip,
                passwd)
        for i in [delete_old_user,flush_sql,create_slave_sql,grant_slave_sql,flush_sql]:
            self.write_log("执行SQL语句：{}".format(i))
            pm.panelMysql().execute(i)
        self.write_log("|-同步信息创建完成")

    def master_env_check(self, slave_ip):
        # 检查主库同步环境
        data = {}
        # 端口是否已经对从库放行
        data['port_released'] = self.master_port_released_check(slave_ip)
        # 检查gtid配置
        data['gtid_status'] = self.get_master_gtid()
        # 检查binlog配置
        data['bin_log_status'] = self.get_master_binlog()
        # 检查主库版本号是否支持gtid同步
        data['gtid_support'] = self.mysql_replicate_version()
        # 要同步的数据库
        slave_info = replicate_tools().get_replicate_info()['slave'][0]
        data['dbs'] = [i['name'] for i in slave_info['replicate_dbs']]
        return data

    def master_port_released_check(self, slave_ip):
        slave_port = mysql_slave(slave_ip).get_slave_port()
        if self.__is_firewalld:
            a, e = public.ExecShell('firewall-cmd --list-all|grep -E "ports.*{}"'.format(slave_port))
            if a:
                return True
            a, e = public.ExecShell(
                'firewall-cmd --list-all|grep -E "rule\s*family.*address=.?{}.?.*{}.*accept"'.format(slave_ip,slave_port))
            if a:
                return True
            return False
        else:
            a, e = public.ExecShell('ufw status|grep -E "{}/tcp\s*ALLOW\s*Anywhere"'.format(slave_port))
            if a:
                return True
            a, e = public.ExecShell('ufw status|grep -E "{}/tcp\s*ALLOW\s*{}"'.format(slave_port,slave_ip))
            if a:
                return True
            return False


class mysql_slave:

    def __init__(self,slave_ip=None):
        self.slave_info = replicate_tools().get_slave_replicate_info(slave_ip)
        self.write_log = replicate_tools().write_log
        self.exec_shell_sql = replicate_tools().exec_shell_sql
        # 初始化从面板认证信息
        self.request_api = bt_api(self.slave_info)

    def get_mysql_root_passwd(self):
        return self.request_api.get_mysql_root_passwd()

    def set_slave_root_password(self,password):
        password = password.strip('"')
        self.write_log("|-开始重置从库root密码！{}".format(password))
        res = self.request_api.set_slave_root_password(password)
        self.write_log("|-开始重置从库root密码！{}".format(res))
        return res

    def get_slave_gtid_status(self):
        # 获取从库gtid状态
        conf = self.request_api.get_slave_conf()
        if re.search("\n\s*gtid-mode\s*=\s*on", conf):
            return True
        return False

    # def backup_slave_uuid_conf(self):
    #     data_path = self.request_api.get_slave_port_path()['datadir']
    #     conf = self.request_api.get_slave_conf(path="{}/auto.cnf".format(data_path))
    #     self.write_log("|-开始备份UUID文件 {}-->/tmp/auto.cnf".format("{}/auto.cnf".format(data_path)))
    #     if not conf:
    #         return False
    #     self.request_api.save_slave_conf(conf,path="/tmp/auto.cnf")
    #     self.write_log("|-备份成功！")

    def restore_salve_uuid_conf(self):
        data_path = self.request_api.get_slave_port_path()['datadir']
        self.request_api.slave_execute_command('rm -f {data_path}/auto.cnf && cp -rp {data_path_bk}/auto.cnf {data_path}/auto.cnf'.format(
            data_path=data_path,
            data_path_bk = data_path+"_replicate_backup"
        ))
        # data_path = self.request_api.get_slave_port_path()['datadir']
        # if not os.path.exists("/tmp/auto.cnf"):
        #     return False
        # conf = self.request_api.get_slave_conf(path="/tmp/auto.cnf")
        # self.write_log("|-开始还原备份UUID文件 /tmp/auto.cnf-->{}".format(data_path))
        # if not conf:
        #     return False
        # self.request_api.save_slave_conf(conf, path="{}/auto.cnf".format(data_path))
        # self.write_log("|-还原成功！")

    def unzip_to_mysql_db_path(self):
        data_path = self.request_api.get_slave_port_path()['datadir']
        self.write_log("|-开始解压备份到从库数据库目录 {}，如果数据较大可能需要较长时间！！".format(data_path))
        unzip_command = "tar -zxvf {} -C {}".format(backup_path + "/mysql_replicate_full_data.tar.gz",data_path)
        self.write_log("|-解压命令： {}".format(unzip_command))
        self.request_api.slave_execute_command(unzip_command)
        return self.check_process_complete("ps aux|grep -E 'tar -zxvf.*mysql_replicate_full_data.tar.gz'|grep -v grep")

    def backup_slave_db_path(self):
        data_path = self.request_api.get_slave_port_path()['datadir']
        self.write_log("|-开始备份从库数据库目录{}！".format(data_path))
        self.request_api.slave_execute_command("cp -rp {d} {d}_replicate_backup".format(d=data_path))
        return self.check_process_complete("ps aux|grep -E 'cp -rp.*_replicate_backup'|grep -v grep")

    def control_slave_mysqld_service(self,type=None):
        self.write_log("|-开始 {} Mysql服务器！".format(type if type else 'restart'))
        return self.request_api.control_mysqld_service(type)

    def set_executed_gtid(self, gtid):
        sql = 'SET @@GLOBAL.GTID_PURGED="{}"'.format(gtid)
        self.write_log("|-开始设置排除的GTID： {}！".format(sql))
        return self.exec_shell_sql(sql)

    def add_ignore_tables(self,tables):
        """
        :param tables: ["db.tb","db.tb1"]
        :return:
        """
        self.write_log("|-开始添加不同步的表到从配置...")
        conf = self.request_api.get_slave_conf()
        self.write_log("|-获取从库配置成功...")
        # 配置会在下次重启后生效
        ignore_tbs = ''
        for i in tables:
            if i in conf:
                continue
            ignore_tbs += "\nreplicate-ignore-table = {}".format(i)
            self.write_log(ignore_tbs)
        if ignore_tbs == '':
            return True
        conf = re.sub("\[mysqld\]", "[mysqld]" + ignore_tbs, conf)
        self.request_api.save_slave_conf(conf)
        self.write_log("|-完成添加不同步的表到从配置...")

    def add_replicate_database_conf(self,dbs):
        self.write_log("|-开始添加同步数据库到从配置文件...")
        conf = self.request_api.get_slave_conf()
        self.write_log("|-获取从库配置完成...")
        # 配置会在下次重启后生效
        replicate_dbs = ''
        for i in dbs:
            if i['name'] in conf:
                self.write_log("|-数据库已经存在从库配置中跳过:{}...".format(i["name"]))
                continue
            replicate_dbs += "\nreplicate-wild-do-table = {}.{}".format(i['name'], "%")
            self.write_log(replicate_dbs)
        if replicate_dbs == '':
            return True
        conf = re.sub("\[mysqld\]", "[mysqld]" + replicate_dbs, conf)
        self.request_api.save_slave_conf(conf)
        self.write_log("|-完成添加同步数据库到配置...")

    def remove_replicate_conf(self):
        # 配置会在下次重启后生效
        conf = self.request_api.get_slave_conf()
        conf = re.sub("replicate-wild-do-table\s*=\s*.+\n","",conf)
        conf = re.sub("replicate-ignore-table\s*=\s*.+\n", "", conf)
        self.request_api.save_slave_conf(conf)

    def set_slave_gtid(self):
        # 设置从库的gtid支持
        gtid_conf = """
log-slave-updates=true
enforce-gtid-consistency
read-only=on
relay-log = relay-log-server
gtid-mode=on"""
        conf = self.request_api.get_slave_conf()
        if not self.get_slave_gtid_status():
            conf = re.sub("\[mysqld\]", "[mysqld]" + gtid_conf, conf)
            self.request_api.save_slave_conf(conf)
            # self.request_api.restart_service()
        return True

    def get_slave_id_status(self):
        conf = self.request_api.get_slave_conf()
        if not re.search("\n\s*server-id\s*=\s*1", conf):
            return True
        return False

    def set_slave_id(self):
        if self.get_slave_id_status():
            return public.returnMsg(True,"设置成功！")
        conf = self.request_api.get_slave_conf()
        if re.search("\n\s*server-id\s*=\s*\d+", conf):
            conf = re.sub("server-id\s*=\s*\d+", "server-id = " + replicate_tools().generate_number(9), conf)
            self.request_api.save_slave_conf(conf)
            # self.request_api.restart_service()
        return public.returnMsg(True,"设置成功！")

    def get_slave_binlog(self):
        # 获取从库binlog状态
        conf = self.request_api.get_slave_conf()
        if re.search("\n\s*log-bin\s*=\s*mysql-bin", conf):
            return True
        return False

    def get_slave_port(self):
        # 获取从库binlog状态
        conf = self.request_api.get_slave_conf()
        res = re.search("\n\s*port\s*=\s*(\d+)", conf)
        if res:
            return res.group(1)
        return 3306

    def set_slave_binlog(self):
        # 设置从库binlog
        conf = self.request_api.get_slave_conf()
        if not re.search('\n\s*#\s*log-bin\s*=\s*mysql-bin'):
            bin_log = """
log-bin=mysql-bin
binlog_format=mixed"""
            conf = re.sub("\[mysqld\]", "[mysqld]" + bin_log, conf)
        else:
            conf = conf.replace('#log-bin=mysql-bin', 'log-bin=mysql-bin')
            conf = conf.replace('#binlog_format=mixed', 'binlog_format=mixed')
        self.request_api.save_slave_conf(conf)
        # self.request_api.restart_service()
        return True

    def get_slave_version(self):
        # 获取从库版本号
        ver = self.request_api.get_slave_version()
        try:
            if not ver['status']:
                return public.returnMsg(False, "获取数据失败：{}".format(ver))
            ver = ver['data']
            if ver:
                if ver[:3] == mysql_master().get_master_version()[:3]:
                    return public.returnMsg(True,str(ver.strip("\n")))
                else:
                    return public.returnMsg(False,"主从服务器数据库版本不一致,将从库安装为Mysql {}".format(mysql_master().get_master_version()))
            return False
        except:
            return public.returnMsg(False,"获取数据失败：{}".format(ver))

    def connect_master(self):
        pass

    def remove_slave(self,slave_ip):
        self.slave_info = replicate_tools().get_slave_replicate_info(slave_ip)
        # 清理主从状态
        self.clear_replicate_info()
        # 清理配置文件
        self.remove_replicate_conf()
        # 清理配置文件
        self.remove_slave_info_conf(slave_ip)
        # 清理主库放行的端口
        mysql_master().delete_port_release(slave_ip)
        return public.returnMsg(True,"删除成功！")

    def remove_slave_info_conf(self,slave_ip):
        replicate_conf = replicate_tools().get_replicate_info()
        # 清理从库的面板信息
        for i in range(len(replicate_conf['slave'])):
            i = i-1
            if slave_ip == replicate_conf['slave'][i]['ip']:
                del(replicate_conf['slave'][i])
        public.writeFile(plugin_conf_file,json.dumps(replicate_conf))


    def generate_sql_replicate(self):
        replicate_conf = replicate_tools().get_replicate_info()['master']
        create_replicate_sql = 'CHANGE MASTER TO MASTER_HOST="{}",MASTER_PORT={},MASTER_USER="{}",MASTER_PASSWORD="{}",MASTER_AUTO_POSITION = 1'.format(
            replicate_conf['master_ip'],
            replicate_conf['master_port'],
            replicate_conf['slave_user'],
            replicate_conf['password'],
        )
        return create_replicate_sql

    def clear_slave_backup(self):
        self.write_log("|-正在清理从库残留文件...")
        self.request_api.slave_execute_command("rm -rf {}/mysql_replicate*".format(backup_path))
        res = self.request_api.get_execute_msg()
        self.write_log("|-清理结果: {}".format(res))

    def skip_error(self,skip_error):
        """
        :param skip_error: list ["1062"]
        :return:
        """
        sconf = self.request_api.get_slave_conf()
        skip_error = ','.join(skip_error)
        skip_error = '\nslave-skip-errors={}'.format(skip_error)
        if 'slave-skip-errors' in sconf:
            return True
        sconf = re.sub("\[mysqld\]", "[mysqld]" + skip_error, sconf)
        self.request_api.save_slave_conf(sconf)

    def remove_skip_error(self):
        sconf = self.request_api.get_slave_conf()
        sconf = re.sub("\nslave-skip-errors\s*=.*", "", sconf)
        self.request_api.save_slave_conf(sconf)


    def master_backup_import(self,create_replicate=True,db=""):
        self.write_log("|-开始准备导入主库备份到从库...")
        self.write_log("|-开始重启从库...")
        self.request_api.control_mysqld_service()
        result = self.request_api.get_execute_msg()
        self.write_log("|-从库重启完成...{}".format(result))
        if create_replicate:
            self.write_log("|-新建同步，开始清理从库主从配置...")
            self.clear_replicate_info()
        passwd = self.request_api.get_mysql_root_passwd()
        self.write_log("|-开始导入数据到从库...")
        self.write_log("|-正在导入，根据数据库大小所需的时间有所差异...")
        import_shell = "gunzip < {}|mysql -uroot -p{} {}".format(backup_path + "/mysql_replicate.sql.gz",passwd, db)
        self.request_api.slave_execute_command(import_shell)
        # self.request_api.get_execute_msg()
        self.check_process_complete('ps aux|grep "mysql -uroot -px"|grep -v "grep"')

    def check_process_complete(self,command):
        start = time.time()
        self.request_api.slave_execute_command(command,"/tmp")
        process = json.loads(self.request_api.get_execute_msg())['msg']
        self.write_log("|-正在检测导入状态...{}".format(command))
        z = 0
        p = 6
        try:
            while process:
                time.sleep(2)
                self.request_api.slave_execute_command(command,"/tmp")
                process = json.loads(self.request_api.get_execute_msg())['msg']
                if process:
                    p = 6
                if not process and p > 1:
                    p -= 1
                    process = "进程似乎已经结束尝试再获取{}次！".format(p)
                self.write_log("|-正在检测导入状态...{}".format(process))
                if len(process.split()) > 3 and process.split()[2] == '0.0':
                    z += 1
                if z >= 10:
                    self.write_log("|-处理异常进程...")
                    self.request_api.slave_execute_command(
                        'kill -9 {}'.format(process.split()[1]), "/tmp")
        except:
            self.write_log("|-检测时发生错误：{}".format(public.get_error_info()))
        end_time = time.time() - start
        self.write_log("|-导入数据库成功！导入时间:{}".format(end_time))


    def clear_replicate_info(self):
        # 清理从库同步信息
        self.write_log("|-开启旧清理从库同步信息")
        self.exec_shell_sql("stop slave")
        # self.write_log("|-{}".format(self.request_api.get_execute_msg()))
        self.exec_shell_sql("reset master")
        self.exec_shell_sql("reset slave all")
        self.write_log("|-清理完成")

    def restart_slave(self):
        self.write_log("|-开始重启主从")
        self.exec_shell_sql("stop slave")
        self.exec_shell_sql("start slave")
        self.write_log("|-主从重启完成！")

    def sync_db_to_panel(self):
        self.request_api.sync_db_to_panel()

    def add_database(self,db_info):
        # db_info = replicate_tools().get_replicate_info()['slave'][0]['replicate_dbs']
        for i in db_info:
            self.write_log("|-在从库创建数据库：{}".format(i['name']))
            result=self.request_api.add_database(i['name'],
                                          i['username'],
                                          i['password'],
                                            i['accept'],
                                            i['accept'],
                                            i['ps'])
            self.write_log("|-在从库创建数据库：{}".format(result['msg']))

    def clear_replicate_file(self):
        self.write_log("|-开始清理同步残留文件...")
        if os.path.exists(backup_path + "/mysql_replicate.sql.gz"):
            os.remove(backup_path + "/mysql_replicate.sql.gz")
        if os.path.exists(backup_path + "/mysql_replicate"):
            public.ExecShell("rm -rf {}".format(backup_path + "/mysql_replicate"))
        if os.path.exists('/tmp/mysqlpid'):
            os.remove('/tmp/mysqlpid')
        if os.path.exists(backup_path+"/mysql_replicate_full_data.tar.gz"):
            os.remove(backup_path+"/mysql_replicate_full_data.tar.gz")
        self.write_log("|-清理完成...")

    def get_replicate_status(self):
        self.exec_shell_sql("show slave status")

    # 获取远程数据库读写状态
    def get_mysql_readonly(self):
        """
        :param get:
        :return:
        """
        result = self.exec_shell_sql('show global variables like "read_only"')
        if "\tON" in result['msg']:
            return True
        return False

    def set_mysql_readonly_temp(self):
        if self.get_mysql_readonly():
            self.exec_shell_sql('set global read_only=0')
        else:
            self.exec_shell_sql('set global read_only=1')
        return public.returnMsg(True, "设置成功，注意该设置是临时生效的，重启后将恢复！")

    def check_env_check(self):
        # 检查从库同步环境
        # 检查从库mysql是否安装,有安装返回版本
        data = {}
        data["mysql_status"] = self.get_slave_version()
        # 获取从库gtid状态
        data['gtid_status'] = self.get_slave_gtid_status()
        # 获取从库binlog状态
        data['binlog_status'] = self.get_slave_binlog()
        data['slave_ip'] = self.slave_info['ip']
        # 检测从库能否连接主库
        # data['conn_status'] = self.connect_master()
        # 检测serverid是否已经修改
        data['server_id'] = self.get_slave_id_status()
        data['read_only'] = self.get_mysql_readonly()
        return data

class replicate_tools:

    def __init__(self,slave_ip=None):
        self.slave_ip = slave_ip
    #     self.slave_info = self.get_slave_replicate_info(slave_ip)
    #     self.request_api = bt_api(self.slave_info)

    def get_slave_replicate_info(self,slave_ip=None):
        if not slave_ip:
            slave_info = self.get_replicate_info()['slave'][0]
        else:
            for slave_info_tmp in self.get_replicate_info()['slave']:
                print(slave_info_tmp['ip'],slave_ip)
                if slave_ip != slave_info_tmp['ip']:
                    continue
                slave_info = slave_info_tmp
        return slave_info

    def get_replicate_info(self):
        self.write_log("|-正在获同步数据...")
        conf = public.readFile(plugin_conf_file)
        if not conf:
            self.write_log("|-配置为空...")
            conf = {}
        else:
            try:
                conf = json.loads(conf)
            except:
                err_msg = "获取同步配置出错，请检测配置文件是否为Json格式! 文件位置：{}".format(plugin_conf_file)
                self.write_log("|-{}".format(err_msg))
                return public.returnMsg(False, err_msg)
        return conf

    def exec_shell_sql(self,sql):
        """
        :param sql: 需要在从库执行的sql语句，执行对象是列表的第一个
        :return:
        """
        self.write_log("|-开始执行同步命令: {} ...".format(sql))
        request_api = bt_api(self.get_slave_replicate_info(self.slave_ip))
        try:
            password = request_api.get_mysql_root_passwd().strip('"')
            # self.write_log("|-root密码...{}".format(password))
            shell = "export MYSQL_PWD={} &&/usr/bin/mysql -uroot -e '{}' && export MYSQL_PWD=''".format(password,sql)
            request_api.slave_execute_command(
                shell,"/tmp")
            result = json.loads(request_api.get_execute_msg())
            self.write_log("|-执行命令...{}".format(shell))
            self.write_log("|-执行同步命令成功...{}".format(result))
        except:
            self.write_log("|-执行同步命令出错：\n{}".format(public.get_error_info()))
            result = {}
        finally:
            request_api.slave_execute_command(
                "export MYSQL_PWD=''","/tmp")
        return result

    # 获取mysql_pid
    def get_mysql_pid(self,pname, exe=None, cmdline=None):
        try:
            import psutil
            pids = psutil.pids()
            for pid in pids:
                try:
                    p = psutil.Process(pid)
                    if p.name() == pname:
                        if not exe and not cmdline:
                            return pid
                        else:
                            if exe:
                                if p.exe() == exe: return pid
                            if cmdline:
                                if cmdline in p.cmdline(): return pid
                except:
                    pass
            return public.ExecShell("ps aux|grep 'mysql.sock'|awk 'NR==1 {print $2}'")[0].split("\n")[0]
        except:
            return public.ExecShell("ps aux|grep 'mysql.sock'|awk 'NR==1 {print $2}'")[0].split("\n")[0]

    def restart_mysql(self):
        """
            @name  重启数据库，最多尝试重启10次
            @author zhwen<zhw@bt.cn>
        """
        self.write_log("开启重启mysql...")
        pid_old = self.get_mysql_pid('mysqld')
        self.write_log("旧PID %s" % pid_old)
        pid_new = pid_old
        public.writeFile("/tmp/mysqlpid", "")
        n=0
        # 重启数据库，最多尝试10次
        for i in range(50):
            if i == 0:
                public.ExecShell("/etc/init.d/mysqld restart &")
                time.sleep(10)
                pid_new = self.get_mysql_pid('mysqld')
                self.write_log("新PID %s" % pid_new)
            if pid_old == pid_new:
                time.sleep(10)
                pid_new = self.get_mysql_pid('mysqld')
            else:
                public.writeFile("/tmp/mysqlpid", "ok")
                n+=1
                self.write_log("重启成功！")
                break
        return n

    def check_replicate_status(self,result = None):
        self.write_log("|-正在检测主从状态...")
        status = False
        msg = "同步失败"
        if not result:
            status_info = self.get_slave_status()
        else:
            status_info = result
        if 'status' not in status_info:
            self.write_log("|-主从状态为空，配置出错了！")
            return public.returnMsg(status,status_info)
        if not status_info['status'] :
            self.write_log("|-主从状态为空，配置出错了！")
            return public.returnMsg(status,status_info)
        status_info = status_info['msg']
        try:
            if status_info['Slave_IO_Running'] == 'Yes' and status_info['Slave_SQL_Running'] == 'Yes':
                self.write_log("|-主从状态正常！")
                status = True
                msg = "同步成功"
        except:
            return public.returnMsg(status, "无法获取从库状态！请尝试重新同步")
        return public.returnMsg(status,msg)

    # def get_slave_status_source(self):
    #     result = self.exec_shell_sql("show slave status\G")['msg']
    #     if not result:
    #         return public.returnMsg(False,"同步设置失败或未设置完成，请尝试删除该从库后重新进行同步！")
    #     return public.returnMsg(True,result)

    def get_slave_status(self, show_str = None, result = None):
        """
        :param show_str:为真时直接答应原始数据
        :return:
        """
        try:
            if not result:
                result = self.exec_shell_sql("show slave status\G")['msg']
            if not result:
                return public.returnMsg(False,"同步设置失败或未设置完成，请尝试删除该从库后重新进行同步！")
            if show_str:
                return public.returnMsg(True,result)
            result = result.split('\n')
            replicate_status = {}
            tmp = ""
            for i in result:
                print(i)
                if i[-1] == ',':
                    tmp = i
                    continue
                if tmp:
                    tmp += i
                    i = tmp
                    tmp = ''
                i_split = i.split(":")
                if len(i_split) < 2:
                    continue
                elif len(i_split) > 2:
                    value = ":".join(i_split[1:]).strip()
                    key = i_split[0].strip()
                else:
                    value = i_split[1].strip()
                    key = i_split[0].strip()
                replicate_status[key] = value
            return public.returnMsg(True,replicate_status)
        except:
            return public.returnMsg(False, 'Get replicate status error!')

    def generate_number(self,num_len):
        import random,string
        return "".join(map(lambda x: random.choice(string.digits), range(num_len)))

    def write_log(self,log_str):
        if not log_str:
            f = open(logs_file, 'wb')
            log_str = "{}\n".format("-"*60)
        else:
            f = open(logs_file, 'ab+')
            log_str += "\n"
        f.write(log_str.encode('utf-8'))
        f.close()
        print(log_str)
        return True

    #字节单位转换
    def to_size(self,size):
        d = ('b','KB','MB','GB','TB')
        for b in d:
            if size < 1024: return ("%.2f" % size) + ' ' + b
            size = size / 1024
        return ("%.2f" % size) + ' ' + b

class replicate_repair:

    def __init__(self,slave_ip=None):
        """
        :param slave_ip: 192.168.1.41 从库IP，为空时选择列表的第一个
        :return:
        """
        self.slave_info = replicate_tools().get_slave_replicate_info(slave_ip)
        self.write_log = replicate_tools().write_log
        # 初始化从面板认证信息
        self.request_api = bt_api(self.slave_info)
        self.exec_shell_sql = replicate_tools(slave_ip).exec_shell_sql

    def table_not_exist(self,status):
        """
        :param status:mysql的同步状态
        :return:
        """
        # 数据表丢失
        error_msg = status['Last_SQL_Error']
        rep = "Error\s*'Table\s*'(.*)'\s*doesn't\s*exist'\s*on\s*query"
        res = re.search(rep,error_msg)
        if res:
            return public.returnMsg(True,
                                    "从库的数据表【{}】丢失！".format(res.group(1)) + '<br><a style="color:red;">！！！如果需要修复请先备份好从库以免使数据丢失！！！</a>')
        return public.returnMsg(False, "从库有数据表丢失但没有匹配到，请检查同步详情！将丢失的数据表手动导入到从库或重做主从复制")

    # 检测主从错误
    def check_replicate_error(self,slave_ip):
        """
        :param slave_ip: 192.168.1.41 从库IP
        :return:
        """
        if replicate_tools(slave_ip).check_replicate_status()['status']:
            return public.returnMsg(True, "同步正常无需修复")
        status = replicate_tools(slave_ip).get_slave_status()['msg']
        # 无法连接主库
        if status["Slave_IO_Running"] == "Connecting":
            return public.returnMsg(False, "从服务器同步用户无法连接主服务器")
        # 主键冲突处理
        if str(status['Last_SQL_Errno']) == "1062":
            return public.returnMsg(True,
                                    "从库已经存在插入的数据，修复时会先删除从库冲突数据，再尝试插入主库的数据到从库，是否尝试修复" + '<br><a style="color:red;">！！！如果需要修复请先备份好从库以免使数据丢失！！！</a>')
        # 数据表丢失
        if str(status['Last_SQL_Errno']) == "1146":
            return self.table_not_exist(status)
        # 主从配置丢失
        if str(status['Last_SQL_Errno']) == "1872":
            return public.returnMsg(False, "检查到数据库同步配置丢失，请尝试修复")
        return public.returnMsg(False,
                                "该错误无法修复，请查看同步详情")

    def fix_table_not_exist(self,status,slave_ip):
        """
        :param status:mysql的同步状态
        :param slave_ip: 192.168.1.41 从库IP
        :return:
        """
        error_msg = status['Last_SQL_Error']
        rep = "Error\s*'Table\s*'(.*)'\s*doesn't\s*exist'\s*on\s*query"
        res = re.search(rep, error_msg)
        if not res:
            return public.returnMsg(False, "从库有数据表丢失但没有匹配到，请检查同步详情！将丢失的数据表手动导入到从库或重做主从复制")
        table_name = res.group(1)
        # 备份相应数据表
        if not mysql_master().backup_specify_tables(table_name):
            return public.returnMsg(False,"备份数据表失败：{}".format(table_name))
        # 文件传输到从库
        target_path = source_file = backup_path+"/mysql_replicate.sql.gz"
        self.request_api.upload_file(source_file,target_path)
        # 数据导入到从库
        mysql_slave().master_backup_import(create_replicate=False,db=table_name.split('.')[0])
        # if not import_res:
        #     print(import_res)
        #     return public.returnMsg(False,"导入数据表失败")
        # 重启主从配置
        mysql_slave(slave_ip).restart_slave()
        status = replicate_tools(slave_ip).get_slave_status()['msg']
        if str(status['Last_SQL_Errno']) != '1146':
            return public.returnMsg(True,'修复成功！')
        return public.returnMsg(True,'修复失败！')

    def reset_master_info(self,status):
        """
        :param status:mysql的同步状态
        :return:
        """
        error_msg = status['Last_SQL_Error']
        print(error_msg)
        rep = "Slave\s*failed\s*to\s*initialize\s*relay\s*log\s*info\s*structure\s*from\s*the\s*repository"
        res = re.search(rep, error_msg)
        if not res:
            return public.returnMsg(False, "检查到数据库同步配置丢失，但无法匹配详情")
        sql = mysql_slave().generate_sql_replicate()
        print(sql)
        self.exec_shell_sql(sql)
        status = replicate_tools().get_slave_status()['msg']
        if status['Last_SQL_Errno'] != 1872:
            return public.returnMsg(True, "修复成功！")
        return public.returnMsg(True, "修复失败！")

    def fix_primary_key_exist(self, status,slave_ip):
        """
        :param slave_ip:192.168.1.41
        :return:
        """
        while True:
            errormsg = status['Last_SQL_Error']
            primary = "entry\s'(\w+)'"
            defdb = "database:\s'(\w*)'"
            db_tb = "(insert|INSERT)\s+(into|INTO)\s+(`|)([\w\_\-\.]+)(`|)"
            primary = re.search(primary, errormsg).group(1)
            try:
                defdb = re.search(defdb, errormsg).group(1)
            except:
                defdb = ""
            db_tb = re.search(db_tb, errormsg)
            if db_tb:
                db_tb = db_tb.group(4)
            if "`" in db_tb:
                db_tb = db_tb.split('`')[-2]

            if "." in db_tb and '`' not in db_tb:
                db_tb = db_tb.split('.')[-1]
            print(primary, defdb, db_tb)
            if defdb:
                db_tb = defdb + "." + db_tb.split(".")[-1]
            sql = "desc %s" % db_tb
            result = pm.panelMysql().query(sql)
            for i in result:
                if "PRI" in i:
                    prikey = i[0]
            self.exec_shell_sql('delete from %s where %s=%s' % (db_tb, prikey, primary))
            mysql_slave(slave_ip).restart_slave()
            time.sleep(0.3)
            status = replicate_tools(slave_ip).get_slave_status()['msg']
            last_sql_errno = status['Last_SQL_Errno']
            if last_sql_errno != "1062":
                return public.returnMsg(True, "修复成功")


    # 修复主从
    def fix_replicate(self,slave_ip):
        """
        :param slave_ip:192.168.1.41
        :return:
        """
        if replicate_tools(slave_ip).check_replicate_status()['status']:
            return public.returnMsg(True, "修复成功")
        status = replicate_tools(slave_ip).get_slave_status()['msg']
        if not status:
            return public.returnMsg(False, "获取主从状态失败或未配置主从！")
        # 修复日志丢失
        Last_IO_Errno = str(status['Last_IO_Errno'])
        last_sql_errno = str(status['Last_SQL_Errno'])
        # if Last_IO_Errno == "1236":
        #     return self.fix_binlog_lost(status)
        # 主键冲突处理
        if last_sql_errno == "1062":
            return self.fix_primary_key_exist(status,slave_ip)
        # 修复表丢失
        if last_sql_errno == "1146":
            return self.fix_table_not_exist(status,slave_ip)
        if last_sql_errno == "1872":
            print("检测到错误：1872，现在开始修复")
            return self.reset_master_info(status)
        return public.returnMsg(False, "目前无法修复，请将同步详情提交给宝塔官方人员")

class bt_api:
    _buff_size = 1024 * 1024 * 2
    _REQUESTS = None

    # 如果希望多台面板，可以在实例化对象时，将面板地址与密钥传入
    def __init__(self,api_info=None):
        if api_info:
            self.__BT_PANEL = api_info['panel_addr']
            self.__BT_KEY = api_info['panel_key']
        import requests
        if not self._REQUESTS:
            self._REQUESTS = requests.session()
        self.write_log = replicate_tools().write_log
        self.to_size = replicate_tools().to_size

    def get_slave_port_path(self):
        url = self.__BT_PANEL + '/database?action=GetMySQLInfo'
        p_data = self.__get_key_data()
        result = self.__http_post_cookie(url, p_data)
        # result {"datadir": "/www/server/data", "port": "3306"}
        return json.loads(result)

    def set_slave_root_password(self,password):
        url = self.__BT_PANEL + '/database?action=SetupPassword'
        p_data = self.__get_key_data()
        p_data['password'] = password
        result = self.__http_post_cookie(url, p_data)
        return result

    def get_slave_version(self):
        """
        空表示未安装数据库
        :return:
        """
        url = self.__BT_PANEL + '/files?action=GetFileBody'
        p_data = self.__get_key_data()
        p_data['path'] = '/www/server/mysql/version.pl'
        result = self.__http_post_cookie(url, p_data)
        # result 5.7.34
        return json.loads(result)

    # def check_slave_port_release(self):
    #     url = self.__BT_PANEL + '/plugin?action=get_soft_find'
    #     p_data = self.__get_key_data()
    #     p_data['sName'] = 'mysql'
    #     result = self.__http_post_cookie(url, p_data)
    #     return json.loads(result)['version']

    def get_data_list(self,tojs,table,p=1):
        """
        :param tojs:
        :param table:
        :param p:
        :return:
        """
        url = self.__BT_PANEL + '/data?action=getData'
        p_data = self.__get_key_data()
        p_data['tojs'] = tojs
        p_data['table'] = table
        p_data['limit'] = '50'
        p_data['p'] = p
        p_data['search'] = ''
        p_data['order'] = 'id desc'
        result = self.__http_post_cookie(url, p_data)
        return json.loads(result)

    def add_database(self,name,db_user,password,dataAccess,address,ps):
        url = self.__BT_PANEL + '/database?action=AddDatabase'
        p_data = self.__get_key_data()
        p_data['name'] = name
        p_data['dtype'] = 'MySQL'
        p_data['codeing'] = 'utf8'
        p_data['db_user'] = db_user
        p_data['password'] = password
        p_data['dataAccess'] = dataAccess
        p_data['address'] = address
        p_data['ps'] = ps
        result = self.__http_post_cookie(url, p_data)
        return json.loads(result)

    def get_slave_conf(self,path=None):
        """
        获取从库配置文件
        """
        url = self.__BT_PANEL + '/files?action=GetFileBody'
        p_data = self.__get_key_data()
        p_data['path'] = '/etc/my.cnf'
        if path:
            p_data['path'] = path
        result = self.__http_post_cookie(url, p_data)
        return json.loads(result)['data']

    def save_slave_conf(self,content,path=None):
        url = self.__BT_PANEL + '/files?action=SaveFileBody'
        p_data = self.__get_key_data()
        p_data['path'] = '/etc/my.cnf'
        if path:
            p_data['path'] = path
        p_data['encoding'] = 'utf-8'
        p_data['data'] = content
        result = self.__http_post_cookie(url, p_data)
        return json.loads(result)

    def port_release(self, f_path, f_name, f_size, f_start):
        """
        上传文件
        """
        url = self.__BT_PANEL + '/files?action=upload'
        p_data = self.__get_key_data()
        p_data['f_path'] = f_path
        p_data['f_name'] = f_name
        p_data['f_size'] = f_size
        p_data['f_start'] = f_start
        result = self.__http_post_cookie(url, p_data)
        return json.loads(result)['data']

    def slave_execute_command(self,shell,path='/tmp'):
        url = self.__BT_PANEL+'/files?action=ExecShell'
        p_data = self.__get_key_data()
        p_data["shell"] = shell
        p_data["path"] = path
        result = self.__http_post_cookie(url, p_data)
        return result

    def sync_db_to_panel(self):
        url = self.__BT_PANEL+'/database?action=SyncGetDatabases'
        p_data = self.__get_key_data()
        result = self.__http_post_cookie(url, p_data)
        return result

    def get_mysql_root_passwd(self):
        url = self.__BT_PANEL+'/data?action=getKey'
        p_data = self.__get_key_data()
        p_data['table'] = 'config'
        p_data['key'] = 'mysql_root'
        p_data['id'] = '1'
        result = self.__http_post_cookie(url, p_data)
        return result

    def control_mysqld_service(self,type=None):
        url = self.__BT_PANEL+'/system?action=ServiceAdmin'
        p_data = self.__get_key_data()
        p_data["name"] = 'mysqld'
        p_data["type"] = 'restart'
        if type:
            p_data["type"] = type
        result = self.__http_post_cookie(url, p_data)
        return result

    def get_execute_msg(self):
        url = self.__BT_PANEL+'/files?action=GetExecShellMsg'
        p_data = self.__get_key_data()
        result = self.__http_post_cookie(url, p_data)
        return result

    def get_user_info(self):
        url = self.__BT_PANEL+'/workorder/get_user_info'
        p_data = self.__get_key_data()
        result = self.__http_post_cookie(url, p_data)
        return result

    def import_database(self,name):
        url = self.__BT_PANEL+'/database?action=InputSql'
        p_data = self.__get_key_data()
        p_data["file"] = backup_path + "/mysql_replicate.sql.gz"
        p_data["name"] = name
        result = self.__http_post_cookie(url, p_data)
        return result

    #上传文件
    def upload_file(self,sfile,dfile):
        if not os.path.exists(sfile):
            self.write_log("|-指定目录不存在{}".format(sfile))
            return False
        pdata = self.__get_key_data()
        pdata['f_name'] = os.path.basename(dfile)
        pdata['f_path'] = os.path.dirname(dfile)
        pdata['f_size'] = os.path.getsize(sfile)
        pdata['f_start'] = 0
        f = open(sfile,'rb')
        return self.send_file(pdata,f)

    #发送文件
    def send_file(self,pdata,f):
        success_num = 0 #连续发送成功次数
        max_buff_size = int(1024 * 1024 * 8)  #最大分片大小
        min_buff_size = int(1024 * 32) #最小分片大小
        err_num = 0 #连接错误计数
        max_err_num = 5 #最大连接错误重试次数
        up_buff_num = 5 #调整分片的触发次数
        timeout = 30 #每次发送分片的超时时间
        split_num = 0
        split_done = 0
        total_time = 0

        self.write_log("|-上传文件[{}], 总大小：{}, 当前分片大小为：{}".format(pdata['f_name'],self.to_size(pdata['f_size']),self.to_size(self._buff_size)))
        while True:
            buff_size = self._buff_size
            max_buff = int(pdata['f_size'] - pdata['f_start'])
            if max_buff < buff_size: buff_size = max_buff #判断是否到文件尾
            files = {"blob":f.read(buff_size)}
            start_time = time.time()
            try:
                res = self._REQUESTS.post(self.__BT_PANEL + '/files?action=upload',data=pdata,files=files,timeout=timeout)
                success_num +=1
                err_num = 0
                #连续5次分片发送成功的情况下尝试调整分片大小, 以提升上传效率
                if success_num > up_buff_num and self._buff_size <  max_buff_size:
                    self._buff_size = int(self._buff_size * 2)
                    success_num = up_buff_num - 3 #如再顺利发送3次则继续提升分片大小
                    if self._buff_size > max_buff_size: self._buff_size = max_buff_size
                    self.write_log("|-发送顺利, 尝试调整分片大小为: {}".format(self.to_size(self._buff_size)))
            except Exception as ex:
                times = time.time() - start_time
                total_time += times
                ex = str(ex)
                if ex.find('Read timed out') != -1 or ex.find('Connection aborted') != -1:
                    #发生超时的时候尝试调整分片大小, 以确保网络情况不好的时候能继续上传
                    self._buff_size = int(self._buff_size / 2)
                    if self._buff_size < min_buff_size: self._buff_size = min_buff_size
                    success_num = 0
                    self.write_log("|-发送超时, 尝试调整分片大小为: {}".format(self.to_size(self._buff_size)))
                    continue
                #如果连接超时
                if ex.find('Max retries exceeded with') != -1 and err_num <= max_err_num:
                    err_num +=1
                    self.write_log("|-连接超时, 第{}次重试".format(err_num))
                    time.sleep(1)
                    continue
                #超过重试次数
                self.write_log("|-上传失败, 跳过本次上传任务")
                self.write_log(public.get_error_info())
                return False
            result = res.json()
            times = time.time() - start_time
            total_time += times
            if type(result) == int:
                if result == split_done:
                    split_num += 1
                else:
                    split_num = 0
                split_done = result
                if split_num > 10:
                    self.write_log("|-上传失败, 跳过本次上传任务")
                    return False
                if result > pdata['f_size']:
                    self.write_log("|-上传失败, 跳过本次上传任务")
                    return False
                self.write_log("|-已上传 {},上传速度 {}/s, 共用时 {}分{:.2f}秒,  {:.2f}%".format(self.to_size(float(result)), self.to_size(buff_size/times),int(total_time // 60),total_time % 60,(float(result) / float(pdata['f_size']) * 100)))
                pdata['f_start'] = result #设置断点
            else:
                if not result['status']:  #如果服务器响应上传失败
                    self.write_log(result['msg'])
                    return False

                if pdata['f_size']:

                    self.write_log("|-已上传 {},上传速度 {}/s, 共用时 {}分{:.2f}秒,  {:.2f}%".format(self.to_size(float(pdata['f_size'])), self.to_size(buff_size/times),int(total_time // 60),total_time % 60,(float(pdata['f_size']) / float(pdata['f_size']) * 100)))
                break
        self.write_log("|-总耗时：{} 分钟, {:.2f} 秒, 平均速度：{}/s".format(int(total_time // 60), total_time % 60,self.to_size(pdata['f_size']/total_time)))
        return True

    # 计算MD5
    def __get_md5(self, s):
        m = hashlib.md5()
        m.update(s.encode('utf-8'))
        return m.hexdigest()

    # 构造带有签名的关联数组
    def __get_key_data(self):
        now_time = int(time.time())
        p_data = {
            'request_token': self.__get_md5(str(now_time) + '' + self.__get_md5(self.__BT_KEY)),
            'request_time': now_time
        }
        return p_data

    # 发送POST请求并保存Cookie
    # @url 被请求的URL地址(必需)
    # @data POST参数，可以是字符串或字典(必需)
    # @timeout 超时时间默认1800秒
    # return string
    def __http_post_cookie(self,url,p_data,timeout=1800):
        try:
            res = self._REQUESTS.post(url,p_data,timeout= timeout)
            return res.text
        except Exception as ex:
            ex = str(ex)
            if ex.find('Max retries exceeded with') != -1:
                return public.returnJson(False,'连接服务器失败!')
            if ex.find('Read timed out') != -1 or ex.find('Connection aborted') != -1:
                return public.returnJson(False,'连接超时!')
            return public.returnJson(False,'连接服务器失败!')