--[[
#-------------------------------------------------------------------
# 宝塔Linux面板
#-------------------------------------------------------------------
# Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
#-------------------------------------------------------------------
# Author: 梁凯强 <1249648969@qq.com>
#-------------------------------------------------------------------

#----------------------
# WAF防火墙 for nginx  body 过滤
#----------------------
]]--
local headers = ngx.header
local uri = ngx.unescape_uri(ngx.var.uri)

local function get_body_character_string()
   local char_string=waf_config_data['body_character_string']
   if not char_string then return false end
   if arrlen(char_string) ==0 then return false end
   if arrlen(char_string) >=1 then return char_string end
end

local function get_site_character_string(waf_site_config)
   if not waf_site_config then return false end
   local char_string=waf_site_config['body_character_string']
   if not char_string then return false end
   if arrlen(char_string) ==0 then return false end
   if arrlen(char_string) >=1 then return char_string end
end

local function check_type()
  if headers["Content-Type"] == nil then return false end
  if string.find(headers["Content-Type"], "text/html") ~= nil or  string.find(headers["Content-Type"], "application/json") ~= nil then
    return true
  end
  return false
end

function body_btwaf()
   if not waf_config_data['open'] or not is_site_config('open') then return false end
   if not check_type() then return false end 
   if cc_increase_static() then return false end
   server_name2=get_server_name_waf()
   server_name = string.gsub(server_name2,'_','.')
   local chunk, eof = ngx.arg[1], ngx.arg[2]
   local buffered = ngx.ctx.buffered
   if not buffered then
        buffered = {}
        ngx.ctx.buffered = buffered
   end
   if chunk ~= "" then
       buffered[#buffered + 1] = chunk
       ngx.arg[1] = nil
   end
  if eof then
      local whole = table.concat(buffered)
      ngx.ctx.buffered = nil
      local get_body=get_body_character_string()
      if get_body then
          for __,v in pairs(get_body)
          do 
              for k2,v2 in pairs(v)
                  do
                      if type(k2)=='string' then
                              whole,c1 = string.gsub(whole,k2,v2)
                              if c1 > 0 then ngx.header.content_length = nil end
                      end
                 end
           end
      end
      if waf_site_config then 
        local site_body=get_site_character_string(waf_site_config[server_name])
        if site_body then
            for __,v in pairs(site_body)
            do 
                   for k2,v2 in pairs(v)
                    do
                        if type(k2)=='string' then
                            ngx.header.content_length = nil
                            whole,c2 = string.gsub(whole,k2,v2)
                            if c2 > 0 then ngx.header.content_length = nil end
                        end
                    end
            end
        end
    end
      ngx.arg[1] = whole
  end
end

local ok,_ = pcall(function()
	return body_btwaf()
end)