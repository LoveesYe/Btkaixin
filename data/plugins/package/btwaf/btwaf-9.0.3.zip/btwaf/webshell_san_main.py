# coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: 黄文良 <287962566@qq.com>
# | Author: 梁凯强 <1249648969@qq.com>
# +-------------------------------------------------------------------

# +--------------------------------------------------------------------
# |   宝塔网站防火墙
# +--------------------------------------------------------------------
import sys

sys.path.append('/www/server/panel/class')
import json, os, time, public, string, re, hashlib

os.chdir('/www/server/panel')
if __name__ != '__main__':
    from panelAuth import panelAuth

class webshell_san_main:
    __path = '/www/server/btwaf/'
    __state = {True: '开启', False: '关闭', 0: '停用', 1: '启用'}
    __config = None
    __webshell = '/www/server/btwaf/webshell.json'
    __PATH='/www/server/panel/plugin/btwaf/'
    __webshell_data=[]
    def __init__(self):
        if not os.path.exists(self.__webshell):
            os.system("echo '[]'>/www/server/btwaf/webshell.json && chown www:www /www/server/btwaf/webshell.json")

    # 返回站点
    def return_site(self, get):
        data = public.M('sites').field('name,path').select()
        ret = {}
        for i in data:
            ret[i['name']] = i['path']
        return public.returnMsg(True, ret)

    # 获取规则
    def shell_get_rule(self, get):
        ret = []
        if os.path.exists(self.__PATH + 'rule.json'):
            try:
                data = json.loads(public.ReadFile(self.__PATH + 'rule.json'))
                return data
            except:
                return False
        else:
            return False

    # 查询站点跟目录
    def getdir(self, dir, pc='', lis=[]):
        list = os.listdir(dir)
        for l in list:
            if os.path.isdir(dir + '/' + l):
                lis = self.getdir(dir + '/' + l, pc, lis)
            elif str(l.lower())[-4:] == '.php' and str(dir + '/' + l).find(pc) == -1:
                print (dir + '/' + l)
                lis.append(dir + '/' + l)
        return lis

    # 目录
    def getdir_list(self, get):
        path = get.path
        if os.path.exists(path):
            pc = 'hackcnm'
            rs = self.getdir(path, pc)
            return rs
        else:
            return False

    # 扫描
    def scan(self, filelist, rule):
        self.__webshell_data=[]
        import time
        time_data = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
        ret = []
        for file in filelist:
            data = open(file).read()
            for r in rule:
                if re.compile(r).findall(data):
                    result = {}
                    result[file] = r
                    self.__webshell_data.append(result)
                    data = ("%s [!] %s %s  \n" % (time_data, file, r))
                    self.insert_log(data)
        return self.__webshell_data

    def insert_log(self, data):
        public.writeFile(self.__PATH + 'webshell.log', data, 'a+')

    # Log 取100行操作
    def get_log(self, get):
        path = self.__PATH + 'webshell.log'
        if not os.path.exists(path): return False
        return public.GetNumLines(path, 3000)

    # 不是木马的过滤掉
    def path_json(self, path, data):
        path_file = str(path).replace('/', '')
        if os.path.exists(path):
            if os.path.exists(self.__PATH + path_file + '.json'):
                try:
                    path_data = json.loads(public.ReadFile(self.__PATH + path_file + '.json'))
                except:
                    ret = []
                    public.WriteFile(self.__PATH + path_file + '.json', json.dumps(ret))
                    path_data = []
                if not path_data: return self.__webshell_data
                for i in self.__webshell_data:
                    for i2 in path_data:
                        if i2 in i:
                            self.__webshell_data.remove(i)
                        # i['check']=0
                return self.__webshell_data
            else:
                ret = []
                public.WriteFile(self.__PATH + path_file + '.json', json.dumps(ret))
                path_data = []
                return self.__webshell_data

    def san_dir(self, get):
        file = self.getdir_list(get)
        if not file: return public.returnMsg(False, "目录不存在")
        rule = self.shell_get_rule(get)
        if not rule: return public.returnMsg(False, "规则为空或者规则文件错误")
        self.__webshell_data = []
        result = self.scan(file, rule)
        result = self.path_json(get.path, result)
        return self.__webshell_data

    #  xss 防御
    def xssencode(self, text):
        import cgi
        list = ['`', '~', '&', '<', '>']
        ret = []
        for i in text:
            if i in list:
                i = ''
            ret.append(i)
        str_convert = ''.join(ret)
        text2 = cgi.escape(str_convert, quote=True)
        return text2

    # 添加规则
    def shell_add_rule(self, get):
        rule = self.xssencode(get.rule)
        ret = []
        if os.path.exists(self.__PATH + 'rule.json'):
            try:
                data = json.loads(public.ReadFile(self.__PATH + 'rule.json'))
                if rule in data:
                    return public.returnMsg(False, '已经存在此规则')
                else:
                    data.append(rule)
                    public.WriteFile(self.__PATH + 'rule.json', json.dumps(data))
                    return public.returnMsg(True, '添加成功')
            except:
                return public.returnMsg(False, '规则库解析错误')
        else:
            return public.returnMsg(False, '规则库文件不存在')

    # 删除规则库
    def shell_del_rule(self, get):
        rule = get.rule
        if os.path.exists(self.__PATH + 'rule.json'):
            try:
                data = json.loads(public.ReadFile(self.__PATH + 'rule.json'))
                if rule in data:
                    data.remove(rule)
                    public.WriteFile(self.__PATH + 'rule.json', json.dumps(data))
                    return public.returnMsg(True, '删除成功')
                else:
                    return public.returnMsg(False, '规则库不存在此规则')
            except:
                return public.returnMsg(False, '规则库解析错误')
        else:
            return public.returnMsg(False, '规则库文件不存在')

			
    def upload_file_url(self,get):
        try:
            if os.path.exists(get.filename):
                    data = public.ExecShell('/usr/local/curl/bin/curl https://scanner.baidu.com/enqueue -F archive=@%s' % get.filename)
                    data=json.loads(data[0])
                    time.sleep(3)
                    import requests
                    default_headers = {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36'
                    }
                    data_list = requests.get(url=data['url'],headers=default_headers, verify=False)
                    data2=data_list.json()
                    if 'data' in data2[0]:
                        if len(data2[0]['data'])>=1:
                            if 'descr' in data2[0]['data'][0]:
                                if 'WebShell' in data2[0]['data'][0]['descr']:
                                    return public.returnMsg(True, '此文件为webshell')
                    return public.returnMsg(True, '未查出风险,需等待一段时间后查询')
            else:
                return public.returnMsg(False, '文件不存在')
        except:
            return public.returnMsg(True, '未查出风险,需等待一段时间后查询')			
			
    # 标记不是木马
    def lock_not_webshell(self, get):
        path = get.path
        not_path = get.not_path
        if not os.path.exists(not_path): return public.returnMsg(False, '文件不存在')
        path_file = str(path).replace('/', '')
        if not os.path.exists(self.__PATH + path_file + '.json'):
            ret = []
            ret.append(not_path)
            public.WriteFile(self.__PATH + path_file + '.json', json.dumps(ret))
        else:
            try:
                path_data = json.loads(public.ReadFile(self.__PATH + path_file + '.json'))
                if not not_path in path_data:
                    path_data.append(not_path)
                    public.WriteFile(self.__PATH + path_file + '.json', json.dumps(path_data))
                    return public.returnMsg(True, '添加成功')
                else:
                    return public.returnMsg(False, '已经存在')
            except:
                ret = []
                ret.append(not_path)
                public.WriteFile(self.__PATH + path_file + '.json', json.dumps(ret))
                return public.returnMsg(True, '11111111')