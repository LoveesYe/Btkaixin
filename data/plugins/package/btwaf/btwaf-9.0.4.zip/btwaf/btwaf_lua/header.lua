function header_btwaf()
    if type(waf_config_data)=='table' then
        local is_open_status=false
        if waf_config_data['scan_conf']['open'] ~=nil then 
            is_open_status=waf_config_data['scan_conf']['open']
        end
        --周期
        local cycle=60
        if waf_config_data['scan_conf']['cycle'] ~=nil then 
            cycle=tonumber(waf_config_data['scan_conf']['cycle'])
        end 
        --最大次数
        local limit=120
        if waf_config_data['scan_conf']['limit'] ~=nil then 
            limit=tonumber(waf_config_data['scan_conf']['limit'])
        end 
        if ngx.status==404 and is_open_status and not ngx.shared.spider:get(ip) and not ip_white() and not url_white() then
            if not ngx.shared.btwaf_data:get(ip..'_san') then
                ngx.shared.btwaf_data:set(ip..'_san',1,cycle)
            else 
                ngx.shared.btwaf_data:incr(ip..'_san',1)
            end 
            if ngx.shared.btwaf_data:get(ip..'_san') >limit then 
                lan_ip('scan','扫描器拦截')
            end 
        end
    end 
end
local ok,_ = pcall(function()
	return header_btwaf()
end)
