/*
 * @Description: 热力图展示
 * @Version: 1.0
 * @Autor: chudong
 * @Date: 2021-11-08 15:03:31
 * @LastEditors: chudong
 * @LastEditTime: 2021-11-11 11:31:43
 */



function Exhibition(){
  this.init();
  this.heatmap = null;
  this.statistical = true;
  this.heatmapsRefresh = null;  //热力图刷新定时器
  // this.
}

Exhibition.prototype = {
  /**
   * @description: 初始化
   */
  init(){
    this.heatmapEl = document.createElement('div')
    let exhibition = document.createElement('div'), // 范围
    heatmaps = this.heatmapEl, // 热力图地址
    displayBtn = document.createElement('button'), // 操作按钮
    refreshBtn = document.createElement('button'); // 按钮文字
    buttonGroup = document.createElement('div'), // 操作按钮组
    dragGroup = document.createElement('div'), // 拖拽功能
    dragTitle = document.createElement('div'), // 拖拽功能
    style = document.createElement('style'), // 拖拽功能
    height = document.documentElement.scrollHeight; // 屏幕高度
    heatmaps.id = 'heatmaps';
    heatmaps.style.cssText = 'height: '+ height +'px;display:none;';
    exhibition.classList.add('heatmap-exhibition');
    exhibition.style.cssText = 'position: absolute;right:10px;bottom:10px;width:250px;height: 180px;z-index: 999999999;background: #585858b3;border-radius: 4px;text-align:center;';
    buttonGroup.style.cssText = 'position: absolute;bottom: 20px;left: 0;right: 0;';
    buttonGroup.className = 'btnGroup';
    displayBtn.style.cssText = 'margin-right:15px';
    buttonGroup.appendChild(displayBtn);
    buttonGroup.appendChild(refreshBtn);
    dragTitle.style.cssText = 'margin:0 40px;border-bottom:1px dotted #ececec;';
    dragTitle.innerText = '热力图工具箱';
    dragGroup.style.cssText = 'font-size:13px;color:#eee;text-align:center;height: 42px;line-height: 42px;cursor: move;';
    dragGroup.appendChild(dragTitle);
    displayBtn.className = 'btn btn-success btn-sm';
    displayBtn.dataset.isShow = 0;
    refreshBtn.className = 'btn btn-default btn-sm';
    refreshBtn.setAttribute('disabled', 'disabled');
    displayBtn.innerText = '显示热力图';
    refreshBtn.innerText = '刷新数据';
    style.setAttribute('type','text/css');
    style.innerText = '#heatmaps{position:fixed !important;top: 0;left: 0;right:0;bottom:0;z-index:99999999;}';
    let body = document.querySelector('body');
    exhibition.appendChild(dragGroup);
    exhibition.appendChild(buttonGroup);
    body.appendChild(exhibition);
    body.appendChild(heatmaps);
    console.log(style);
    document.querySelector('head').appendChild(style);
    displayBtn.addEventListener('click',()=>{
      let isShow =  parseInt(displayBtn.dataset.isShow);
      if(!isShow){
        heatmaps.style.display = 'block';
        body.style.overflow = 'hidden';
        displayBtn.dataset.isShow = 1;
        displayBtn.className = 'btn btn-danger btn-sm'
        displayBtn.style.backgroundColor = '#d9534f';
        displayBtn.style.borderColor = '#d43f3a';
        displayBtn.style.color = '#fff';
        displayBtn.innerText = '关闭热力图';
        refreshBtn.removeAttribute('disabled');
        let loadT = bt.load('正在获取节点坐标，请稍后...')

        
        let captureTotalList = JSON.parse(window.localStorage.getItem('captureTotalList'))
        let captureTotal = this.nodeTransformCoordinates(captureTotalList);
        this.heatmap = h337.create({
          container: heatmaps,
          backgroundColor:'rgb(0 0 0 / 44%)',
          maxOpacity: .5,
          gradient: {
            '0': "#0ff",
            '.2': "#0f0",
            '.4': "#ff0",
            '1': "#f00",
          }
        });
        this.heatmap.setData({
          max: this.getDiagramThreshold(captureTotal),
          data: captureTotal
        });
        this.reanderTotal(captureTotal)
        loadT.close()
        this.heatmapsRefresh = setInterval(()=>{
          this.redrawView();
        },1000);
      }else{
        clearInterval(this.heatmapsRefresh);
        this.heatmap = null;
        body.style.overflow = '';
        displayBtn.dataset.isShow = 0;
        displayBtn.innerText = '渲染热力图';
        heatmaps.style.display = 'none';
        displayBtn.className = 'btn btn-success btn-sm';
        refreshBtn.setAttribute('disabled', 'disabled');
        displayBtn.style.cssText = 'margin-right:15px';
        for(var i = heatmaps.childNodes.length - 1; i >= 0; i--) { 
          let item = heatmaps.childNodes[i];
          heatmaps.removeChild(item); 
        }
      }
    })
    refreshBtn.addEventListener('click',()=>{
      console.log('刷新数据')
      this.redrawView();
    });
    let setTimeoutId = null;
    window.onresize = ()=>{
      clearTimeout(setTimeoutId);
      setTimeoutId = setTimeout(() => {
        this.redrawView();
      }, 100);
    }
  },
  /**
   * @description  渲染统计数据
   * @param {array} dataList 
   */
  reanderTotal(dataList){
    var ctx = document.querySelector('.heatmap-canvas').getContext("2d");
    ctx.font = "12px Arial";
    ctx.fillStyle = '#efefef'
    for (let i = 0; i < dataList.length; i++) {
      const item = dataList[i];
      ctx.fillText(item.value,item.x,item.y);
    }
  },


  /**
   * @description: 重绘视图
   * @param {object} heatmap heatmap对象
   */
  redrawView(){
    try {
      let captureTotalList = JSON.parse(window.localStorage.getItem('captureTotalList'))
      let captureTotal = this.nodeTransformCoordinates(captureTotalList);
      if(this.heatmap) {
        let height = document.documentElement.clientHeight;
        let width = document.documentElement.clientWidth;
        this.heatmapEl.style.height = height + 'px';
        this.heatmapEl.style.width = width + 'px';
        this.heatmapEl.querySelector('canvas').setAttribute('height', height);
        this.heatmapEl.querySelector('canvas').setAttribute('width', width);
        this.heatmap.setData({max:this.getDiagramThreshold(captureTotal),data:captureTotal})
        this.heatmap.repaint()
        this.reanderTotal(captureTotal)
      }
    } catch (error) {
      console.log(error)
    }
  },


  /**
   * @description: 节点转换坐标
   * @param {type} 
   * @param {type}
   */
  nodeTransformCoordinates(node){
    let route = window.location.pathname.substr(1) || 'home',coordinate = [],point = [];
    for (const key in node) {
      if (Object.hasOwnProperty.call(node, key)) {
        const total = node[key],tips = route + '-',config = {},layerPages = $('.layui-layer-page');
        let layerPage = layerPages[layerPages.length - 1];
        if(key.indexOf('heatmap-exhibition') > -1) continue;
        if(key.indexOf(route) === 0){
          let configList = key.replace(tips,'').split('|');
          config.select = configList[0];
          if(configList.length > 1){
            for (let i = 0; i < configList.length; i++) {
              if(i > 0){
                const item = configList[i],list = item.split('-');
                config[list[0]] = list[1]
                if(list.length > 3) config[list[2]] = list[3]
              }
            }
            if(typeof config.layer !== 'undefined'){
              let layers = layerPage,title = $(layers).find('.layui-layer-title');
              if(!title){
                title = ''
              }else{
                title = title.text()
              }
              if(title.indexOf(config.layer) > -1){
                if(config.layer !== '') layers = $('.layui-layer-page').find(':contains('+ config.layer  +')').parent()
                console.log(config.contains)
                if(typeof config.contains !== 'undefined') config.select += ':contains('+ config.contains +')'
                console.log(config.select)
                let element = $(layers).find(config.select);
                point = this.nodeCoordinatePoint(element[0],total);
                if(typeof point === "boolean") continue;
                coordinate.push(point)
              }
            }else if(typeof config.contains !== 'undefined' && layerPages.length < 1){
              point = this.nodeCoordinatePoint(config.select + ':contains('+ config.contains +')',total);
              if(typeof point === "boolean") continue;
              coordinate.push(point)
            }
          }else if(layerPages.length < 1){
            point = this.nodeCoordinatePoint(config.select,total);
            if(typeof point === "boolean") continue;
            coordinate.push(point)
          }
        }
        if(key.indexOf('menu') === 0 && layerPages.length < 1){
          let configList = key.split('menu-')[1].split('|');
          point = this.nodeCoordinatePoint(configList[0],total);
          if(typeof point === "boolean") continue;
          coordinate.push(point)
        }
      }
    }
    return coordinate
  },

  /**
   * @description 获取最大值
   * @param {*} arryList 
   * @returns 
   */
  getDiagramThreshold(arryList){
    let arry = []
    for (let i = 0; i < arryList.length; i++) {
      const item = arryList[i];
      arry.push(item.value)
    }
    return Math.max.apply(null,arry) / 2
  },

  /**
   * @description: 获取节点坐标
   * @param {string} selector 选择器
   * @param {number} value 值
   */
  nodeCoordinatePoint(element,value){
    try {
      if(typeof element !== 'string' && typeof element === "undefined") return false;
      element = $(element)[0];
      if(typeof element === "undefined") return false;
      let point = {x:0,y:0,value:value};
      let xOffset = element.offsetWidth / 2;
      let yOffset = element.offsetHeight / 2;
      if(element.tagName === 'INPUT' || element.tagName === 'TEXTAREA') xOffset =  20;
      if(element.offsetParent === null){
        point['x'] = element.offsetLeft + xOffset;
        point['y'] = element.offsetTop + yOffset;
      }else{
        function offsetParent(parentNode){
          point['x'] += parentNode.offsetLeft;
          point['y'] += parentNode.offsetTop;
          if(parentNode.offsetParent === null) return false
          offsetParent(parentNode.offsetParent)
        }
        point['x'] = xOffset;
        point['y'] = yOffset;
        offsetParent(element);
      }
      if(point['x'] === 0 && point['y'] === 0) return false;
      return point;
    } catch (error) {
      return false
    }
  }
}


document.onreadystatechange = () =>{
  if(document.readyState === 'complete'){
    new Exhibition();
  }
}